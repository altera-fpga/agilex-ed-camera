/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#pragma once

#include "IVc.h"
#include "IpUiControls.h"

/// Encapsulates UI functionality for the Vignette Correction IP
class VcControls : public IpUiControls
{
public:
    /// Creates an instance of the class that'll manage the given VC instance.
    VcControls(std::shared_ptr<SwApi::IVc> spVc, bool enableDebugUi = false);
    /// Generates the UI, and returns the resulting container(s)
    std::vector<std::shared_ptr<UiControlContainer>> AddUiElements() override;

    std::string GetSettingsSectionName() override
    {
        return "VignetteCorrection";
    };

    void GenerateAndApplyNewMesh();

    void StatsUpdateLoop();

private:
    std::shared_ptr<SwApi::IVc> _spVc;

    std::shared_ptr<UiControlItemBoolean> _spBypassControl;
    std::shared_ptr<UiControlItemSlider> _spRadialSlider;
    std::shared_ptr<UiControlItemSlider> _spCoronaSlider;
    std::shared_ptr<UiControlItemBoolean> _spInvertBool;

    std::shared_ptr<UiControlItemLabel> _spFrameStats;

    float _radialDistance = 0.0f;
    float _coronaStrength = 0.0f;
    bool _invertMesh = false;

    bool _enableDebugUi = false;
};
