/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/


#pragma once
#include "IpUiControls.h"
#include "IspCommon.h"
#include "IBlc.h"

/// Encapsulates UI functionality for the Black Level Correction IP
class BlcControls : public IpUiControls
{
public:
    /// Creates an instance of the class that'll manage the given BLC instance.
    BlcControls(std::shared_ptr<SwApi::IBlc> spBlc,
                bool enableDebugUi = true, bool powerUser = false);
    /// Generates the UI, and returns the resulting container(s)
    std::vector<std::shared_ptr<UiControlContainer>> AddUiElements() override;

    std::string GetSettingsSectionName() override { return "BlackLevelCorrection"; };
    void BlockUIBasedOnBLSCallback(bool isBLSDrivingBLC);
    void BypassBasedOnAWBCallback(bool isBypass);
    void StatsUpdateLoop();
private:
    std::shared_ptr<SwApi::IBlc> _spBlc;

    std::shared_ptr<UiControlItemBoolean> _spBypassControl;
    std::shared_ptr<UiControlItemEnum>    _spCfaPhaseControl;
    std::shared_ptr<UiControlItemBoolean> _spClipZeroControl;

    std::shared_ptr<UiControlItemUInteger> _spBlackPedestal00;
    std::shared_ptr<UiControlItemUInteger> _spBlackPedestal01;
    std::shared_ptr<UiControlItemUInteger> _spBlackPedestal10;
    std::shared_ptr<UiControlItemUInteger> _spBlackPedestal11;

    std::shared_ptr<UiControlItemUInteger> _spColorScalar00;
    std::shared_ptr<UiControlItemUInteger> _spColorScalar01;
    std::shared_ptr<UiControlItemUInteger> _spColorScalar10;
    std::shared_ptr<UiControlItemUInteger> _spColorScalar11;

    std::shared_ptr<UiControlItemLabel> _spFrameStats;

    bool _enableDebugUi = false;
    bool _powerUser = false;
};
