/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#include "AnrControls.h"
#include "UiElements.h"
#include "intel_vvp_anr.h"

#include <iostream>

using namespace SwApi;

#if defined(__linux__)
#include <unistd.h>
#endif

const float defaultStrength = 0.5f;

AnrControls::AnrControls(std::shared_ptr<SwApi::Anr> spAnr)
    : _spAnr(spAnr)
{
    if (_spAnr) {

    } else {

    }
}

std::vector<std::shared_ptr<UiControlContainer>> AnrControls::AddUiElements()
{
    if (not _spAnr) {
        return {};
    }

    auto spContainer = std::make_shared<UiControlContainer>("Adaptive Noise Reduction", GetSettingsSectionName());

    auto bypassCB = [this](uint32_t clientID, bool& val)
    {
        _spAnr->SetBypass(val, true);
    };
    _spBypass = spContainer->AddBoolControl("Bypass", bypassCB, "BypassANR", _spAnr->GetBypass());

    auto strengthCB = [this](uint32_t clientID, float& val)
    {
        _strength = val;
        _spAnr->ApplyLuts(_strength);
    };
    _spStrength = spContainer->AddSliderControl("Strength", 0.0f, 2.0f, strengthCB, "StrengthANR", defaultStrength);

    auto resetButtonCB = [this](uint32_t clientID)
    {
        _spStrength->UpdateValue(defaultStrength, true);
    };

    spContainer->AddHeaderButtons( {
        { "CornerControlsReset", resetButtonCB, "Reset", "OJL/Images/Reset.png" }
    });

    return {spContainer};
}
