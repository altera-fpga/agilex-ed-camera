/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#pragma once
#include "IWbc.h"
#include "IpUiControls.h"

/// Encapsulates UI functionality for the White Balance Correction IP
class WbcControls : public IpUiControls
{
public:
    /// Creates an instance of the class that'll manage the given WBC instance.
    WbcControls(std::shared_ptr<SwApi::IWbc> spWbc, bool enableDebugUi = false);
    /// Generates the UI, and returns the resulting container(s)
    std::vector<std::shared_ptr<UiControlContainer>> AddUiElements() override;

    std::string GetSettingsSectionName() override
    {
        return "WhiteBalanceCorrection";
    };

    void BlockUIBasedOnAWBCallback(bool isAWBDrivingWbc);
    void BypassBasedOnAWBCallback(bool isBypass);
    void StatsUpdateLoop();

private:
    std::shared_ptr<SwApi::IWbc> _spWbc;

    std::shared_ptr<UiControlItemBoolean> _spBypassControl;
    std::shared_ptr<UiControlItemEnum> _spCfaPhaseControl;

    std::shared_ptr<UiControlItemUInteger> _spScalar00;
    std::shared_ptr<UiControlItemUInteger> _spScalar01;
    std::shared_ptr<UiControlItemUInteger> _spScalar10;
    std::shared_ptr<UiControlItemUInteger> _spScalar11;

    std::shared_ptr<UiControlItemLabel> _spFrameStats;

    bool _enableDebugUi = false;
};
