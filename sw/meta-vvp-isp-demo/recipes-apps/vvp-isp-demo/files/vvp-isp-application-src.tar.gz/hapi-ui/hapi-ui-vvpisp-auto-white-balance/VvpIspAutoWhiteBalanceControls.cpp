/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#include "VvpIspAutoWhiteBalanceControls.h"
#include "UiElements.h"
#include "CoeffGen.h"
#include <string>


VvpIspAutoWhiteBalanceControls::VvpIspAutoWhiteBalanceControls(
    std::shared_ptr<WhiteBalanceController> spWBController,
    std::shared_ptr<SwApi::ITmoOverride> spTmo)
: _spWBController{spWBController},
  _spTmo{spTmo},
  _wbRoiHighlightCounter{0},
  _controlsInitialised{false}
{
    _measuredTempSamples.resize(_noMeasuredTempSamplesToAverage);
}


std::vector<std::shared_ptr<UiControlContainer>> VvpIspAutoWhiteBalanceControls::AddUiElements()
{
    auto spContainer = std::make_shared<UiControlContainer>("Auto White Balance", GetSettingsSectionName());

    auto autoWhiteBalanceResetCB = [this] (uint32_t clientID) -> void
    {
        AutoWhiteBalanceReset();
    };

    spContainer->AddHeaderButtons({{"AutoWhiteBalanceReset", autoWhiteBalanceResetCB, "Reset", "OJL/Images/Reset.png"}});

    auto operationModeDDCB = [this](uint32_t clientID, const UiEnumOption& selected, uint32_t) -> void
    {
        _selectedMode = static_cast<AWBUiModeSelect>(selected._userItemData);

        if(_controlsInitialised)
            SwitchAwbMode(_selectedMode);
    };

    std::vector<UiEnumOption> operationModes = {
        { "Disabled",               static_cast<uint32_t>(AWBUiModeSelect::Disabled) },
        { "Choose Temperature",     static_cast<uint32_t>(AWBUiModeSelect::ChooseTemperatureKelvin) },
        { "Choose Lighting",        static_cast<uint32_t>(AWBUiModeSelect::ChooseLigthing) },
        { "Automatic",              static_cast<uint32_t>(AWBUiModeSelect::Automatic) },
        { "Custom Preset (Spot)",   static_cast<uint32_t>(AWBUiModeSelect::CustomPreset) },
    };

    _spWhiteBalanceEnum = spContainer->AddEnumControl(
        "White Balance", operationModes, operationModeDDCB, "awbOperationModeEnum", AWBUiModeSelect::Automatic);

    auto lightingEnumCB = [this](uint32_t clientID, const UiEnumOption& selected, uint32_t) -> void
    {
        if (_spColTempSlider)
        {
            _spColTempSlider->UpdateValue((int32_t)selected._userItemData, true, clientID);
            _spColTempSlider->PushValueToUI();
        }
    };

    std::vector<UiEnumOption> wbLightingEnum = {
        { "Sunset",         static_cast<uint32_t>(AWBPresetValues::Sunset) },
        { "Incandescent",   static_cast<uint32_t>(AWBPresetValues::Incandescent) },
        { "Fluorescent",    static_cast<uint32_t>(AWBPresetValues::Fluorescent) },
        { "Sunlight",       static_cast<uint32_t>(AWBPresetValues::Sunlight) },
        { "Cloudy",         static_cast<uint32_t>(AWBPresetValues::Cloudy) },
        { "Shade",          static_cast<uint32_t>(AWBPresetValues::Shade) },
        { "Blue Sky",       static_cast<uint32_t>(AWBPresetValues::BlueSky) }
    };

    _spLightingEnum = spContainer->AddEnumControl(
        "Lighting", wbLightingEnum, lightingEnumCB, "wbLightingEnum", 0);

    auto tempChangeCB = [this] (uint32_t clientID, int32_t& value)
    {
        _targetTemp = value;
        _sceneTemp = value;
        if (_shouldCallWBOnSliderChange)
        {
            UpdateTint();
            _spWBController->ApplyWhiteBalance(_sceneTemp, _targetTemp, TCfaPhase::RGGB);
        }
    };

    _spColTempSlider = spContainer->AddSliderControl("Temperature (K)", 2000, 12000, tempChangeCB, "tempScaleSlider", 5700);

    auto TintChangeCB = [this] (uint32_t clientID, float& value)
    {
        _tint = value;
        UpdateTint();
    };

    _spTintSlider = spContainer->AddSliderControl("Tint Adjustment", 0.0f, -1.0, 1.0, TintChangeCB, 2);
    
    auto StrengthChangeCB = [this] (uint32_t clientID, float& value)
    {
        _tintStrength = value;
        auto ccm = _spWBController->GetCcm();
        if (ccm)
        {
            ccm->SetAWBInterpFactor(_tintStrength);
        }
    };

    _spCcmStrengthSlider = spContainer->AddSliderControl("CCM Strength", 1.0f, 0.0f, 2.0f, StrengthChangeCB, 2);

    auto wbCustomPresetCB = [this](uint32_t clientID)
    {
        _spWbRoiHighlightBool->UpdateValue(true, true);
        _wbRoiHighlightCounter = _NUM_ROI_HIGHLIGHT_ITER;
    };

    _spPresetManualButton = spContainer->AddButtonControl("Snapshot", wbCustomPresetCB);

    spContainer->AddSeparator();

    auto wbRoiHighlightCB = [this](uint32_t clientID, bool& value)
    {
        if(_spTmo)
        {
            if (value)
            {
                if (!_highlighting) // If not already overriding
                {
                    if(!_spTmo->RequestOverride())
                    {
                        return;
                    }
                }
            }
            else
            {
                if (_highlighting)
                {
                    _spTmo->ReleaseOverride();
                }
            }
            _highlighting = value;
        }

        UpdateRoi(false);
    };

    _spWbRoiHighlightBool = spContainer->AddBoolControl("Highlight Region of Interest", wbRoiHighlightCB, "roiHighlight", false);

    auto wbRoiResetCB = [this](uint32_t clientID)
    {
        _roi._x = 0.0f;
        _roi._y = 0.0f;
        _roi._width = 1.0f;
        _roi._height = 1.0f;
        UpdateRoi(true);
    };

    _spWbRoiResetButton = spContainer->AddButtonControl("Reset Region of Interest", wbRoiResetCB);

    auto roiUpdateCB = [this](uint32_t clientID, RoiSelectorData& value)
    {
        _roi._x = value._x;
        _roi._y = value._y;
        _roi._width = value._width;
        _roi._height = value._height;
        UpdateRoi(false);

        _spWbRoiHighlightBool->UpdateValue(true, true);
        _wbRoiHighlightCounter = _NUM_ROI_HIGHLIGHT_ITER;
    };

    static const std::string wbsRoiDefault{"0.0, 0.0, 1.0, 1.0, false,false,false"};
    auto roiSetting = std::make_shared<SettingValue<std::string>>(GetSettingsSectionName().c_str(), "WbcRoi", wbsRoiDefault);
    _spRoiCustomControl = std::make_shared<RoiCustomControl>("OJRoiControl", _roi, roiUpdateCB, nullptr, roiSetting);
    
    spContainer->Add(_spRoiCustomControl);

    _controlsInitialised = true;
    SwitchAwbMode(_selectedMode);

    if(_spTmo)
        _spTmo->ReleaseOverride();

    return {spContainer};
}


void VvpIspAutoWhiteBalanceControls::AutoWhiteBalanceUpdateFunc()
{
    switch (_selectedMode)
    {
        default:
        case AWBUiModeSelect::Disabled:
        case AWBUiModeSelect::ChooseTemperatureKelvin:
        case AWBUiModeSelect::ChooseLigthing:
        {
            break;
        }

        case AWBUiModeSelect::CustomPreset:
        {
            if (_wbRoiHighlightCounter <= 0)
            {
                // Spill into automatic only for the ROI highlighting duration
                break;
            }
        }
        case AWBUiModeSelect::Automatic:
        {
            static uint32_t avgTempPrev = 0;

            if (_wbRoiHighlightCounter > 0)
            {
                --_wbRoiHighlightCounter;
                if (_wbRoiHighlightCounter == 0)
                {
                    _spWbRoiHighlightBool->UpdateValue(false, true);
                }
            }

            // This is SceneDetection, but with the target temp locked to the detected scene temp
            uint16_t sceneTemp = _spWBController->GetCurrentSceneTemperature(_tempSampleCircularPointer == 0);

            if (sceneTemp == 0)
            {
                sceneTemp = 5700;
            }

            auto round_to_nearest = []<typename T>(const T v, const T n)->T {
                const T a = n ? ((v / n) * n) : v;  // Previous multiple
                const T b = a + n;                  // Next multiple
                return (v - a >= b - v) ? b : a;    // Return the closest
            };

            // Round to nearest 100 to try to smooth out fluctuations
            _measuredTempSamples[_tempSampleCircularPointer++] = round_to_nearest(sceneTemp, uint16_t{100});
            
            if (_tempSampleCircularPointer >= _noMeasuredTempSamplesToAverage)
            {
                _tempSampleCircularPointer = 0;
            }

            uint32_t avgTemp = 0;
            
            for (int i = 0; i < _noMeasuredTempSamplesToAverage; i++)
            {
                avgTemp += _measuredTempSamples[i];
            }
            
            avgTemp /= _noMeasuredTempSamplesToAverage;
            avgTemp = round_to_nearest(avgTemp, uint32_t{100});

            if(avgTemp != avgTempPrev)
            {
                _sceneTemp = (uint16_t)avgTemp;
                _targetTemp = (uint16_t)avgTemp;

                _spColTempSlider->UpdateValue((int32_t)avgTemp, false);
                _spWBController->ApplyWhiteBalance(_sceneTemp, _targetTemp, TCfaPhase::RGGB);
                avgTempPrev = avgTemp;
            }

            break;
        }
    }

    if (_fpBlockBlcWbcUiCB)
    {
        _fpBlockBlcWbcUiCB(_selectedMode != AWBUiModeSelect::Disabled);
    }
}


void VvpIspAutoWhiteBalanceControls::LoadBlockBlcWbcFunctionPointer(std::function<void(bool)> fpBlockBlcWbcUiCB)
{
    _fpBlockBlcWbcUiCB = fpBlockBlcWbcUiCB;
}


void VvpIspAutoWhiteBalanceControls::SetBypassBLCAndWBCFunctionPointer(std::function<void(bool)> fpSetBypassBlcWbcUiCB)
{
    _fpSetBypassBlcWbcUiCB = fpSetBypassBlcWbcUiCB;
}


void VvpIspAutoWhiteBalanceControls::UpdateTint()
{
    auto ccm = _spWBController->GetCcm();
    if (ccm)
    {
        auto tintMatrix = vvp::ccm::GenerateIdentityMatrix();
        vvp::ccm::ModifyMatrixByTint(tintMatrix, _targetTemp, _tint);
        ccm->ApplyAWBTintMatrix(tintMatrix);
    }
}


void VvpIspAutoWhiteBalanceControls::UpdateRoi(bool updateUI)
{
    // Make sure all the flags are correct
    _roi._enabled = true;
    _roi._outside = false;
    _roi._tmo_enabled = true;

    uint32_t w, h;
    SwApi::WbsRoI wbsRoi;
    _spWBController->GetWbs()->GetInputResolution(w, h);
    wbsRoi.h_start = w * _roi._x;
    wbsRoi.v_start = h * _roi._y;
    wbsRoi.h_end = w * (_roi._x + _roi._width);
    wbsRoi.v_end = h * (_roi._y + _roi._height);
    _spWBController->SetRoi(wbsRoi);

    if (updateUI)
    {
        _spRoiCustomControl->UpdateValue(_roi);
    }

    if (_highlighting)
    {
        _spTmo->SetBypass(false);
        _spTmo->SetEnableRoi(true);
        _spTmo->SetRoiOutside(false);
        _spTmo->SetThreshold(9000);
        _spTmo->SetLevel(100);
        intel_vvp_tmo_roi tmo_roi = {
            ._x = _roi._x,
            ._y = _roi._y,
            ._width = _roi._width,
            ._height = _roi._height
        };
        _spTmo->SetRegionOfInterest(tmo_roi);
    }
}


void VvpIspAutoWhiteBalanceControls::DisableRoiHighlighting()
{
    _spWbRoiHighlightBool->UpdateValue(false, true);
}


void VvpIspAutoWhiteBalanceControls::AutoWhiteBalanceReset()
{
    _spWBController->ApplyBlackLevel();
    _spTintSlider->UpdateValue(0.0f, true);
    _spCcmStrengthSlider->UpdateValue(1.0f, true);

    _roi._x = 0.0f;
    _roi._y = 0.0f;
    _roi._width = 1.0f;
    _roi._height = 1.0f;

    UpdateRoi(true);

    _spWhiteBalanceEnum->Enable(true);
    _spWhiteBalanceEnum->UpdateValue(AWBUiModeSelect::Automatic, true);
}


void VvpIspAutoWhiteBalanceControls::SwitchAwbMode(const AWBUiModeSelect& mode)
{
    switch(mode)
    {
        case AWBUiModeSelect::Disabled:
        {
            _spWBController->DeactivateCcmModifiers();
            _shouldCallWBOnSliderChange = false;

            _spLightingEnum->Enable(false);
            _spColTempSlider->Enable(false);
            _spTintSlider->Enable(false);
            _spCcmStrengthSlider->Enable(false);
            _spPresetManualButton->Enable(false);

            _spWbRoiResetButton->Enable(false);
            _spWbRoiHighlightBool->UpdateValue(false, true);
            _spWbRoiHighlightBool->Enable(false);
            _roi._enabled = false;
            _spRoiCustomControl->UpdateValue(_roi);

            _spWBController->GetCcm()->ApplyAWBTintMatrix(vvp::ccm::GenerateIdentityMatrix());
            break;
        }
        case AWBUiModeSelect::ChooseTemperatureKelvin:
        {
            _shouldCallWBOnSliderChange = true;

            _spLightingEnum->Enable(false);
            _spColTempSlider->Enable(true);
            _spTintSlider->Enable(true);
            _spCcmStrengthSlider->Enable(true);
            _spPresetManualButton->Enable(false);

            _spWbRoiResetButton->Enable(false);
            _spWbRoiHighlightBool->UpdateValue(false, true);
            _spWbRoiHighlightBool->Enable(false);
            _roi._enabled = false;
            _spRoiCustomControl->UpdateValue(_roi);
            UpdateTint();

            _spColTempSlider->UpdateValue(_spColTempSlider->GetValue<int32_t>(), true);
            //_spCurTempSlider->Enable(false); // FIXME - revert after demo
            break;
        }
        case AWBUiModeSelect::ChooseLigthing:
        {
            _shouldCallWBOnSliderChange = true;

            _spLightingEnum->Enable(true);
            _spColTempSlider->Enable(false);
            _spTintSlider->Enable(true);
            _spCcmStrengthSlider->Enable(true);
            _spPresetManualButton->Enable(false);

            _spWbRoiResetButton->Enable(false);
            _spWbRoiHighlightBool->UpdateValue(false, true);
            _spWbRoiHighlightBool->Enable(false);
            _roi._enabled = false;
            _spRoiCustomControl->UpdateValue(_roi);

            UpdateTint();

            _spLightingEnum->UpdateValue(_spLightingEnum->GetSelectedIndex(), true);
            //_spCurTempSlider->Enable(false);
            break;
        }
        case AWBUiModeSelect::Automatic:
        {
            _noMeasuredTempSamplesToAverage = 10;
            _shouldCallWBOnSliderChange = false;

            _spLightingEnum->Enable(false);
            _spColTempSlider->Enable(false);
            _spTintSlider->Enable(true);
            _spCcmStrengthSlider->Enable(true);
            _spPresetManualButton->Enable(false);

            _spWbRoiResetButton->Enable(true);
            _spWbRoiHighlightBool->Enable(true);
            _roi._enabled = true;
            _spRoiCustomControl->UpdateValue(_roi);
            UpdateTint();
            break;
        }
        case AWBUiModeSelect::CustomPreset:
        {
            _noMeasuredTempSamplesToAverage = 4;
            _shouldCallWBOnSliderChange = true;

            _spLightingEnum->Enable(false);
            _spColTempSlider->Enable(false);
            _spTintSlider->Enable(true);
            _spCcmStrengthSlider->Enable(true);
            _spPresetManualButton->Enable(true);

            _spWbRoiResetButton->Enable(true);
            _spWbRoiHighlightBool->Enable(true);
            _roi._enabled = true;
            _spRoiCustomControl->UpdateValue(_roi);
            UpdateTint();
            //_spCurTempSlider->Enable(false);
            break;
        }
    }

    if (_selectedMode == AWBUiModeSelect::Disabled)
    {
        if (_fpSetBypassBlcWbcUiCB)
        {
            _fpSetBypassBlcWbcUiCB(true);
        }
    }    
}