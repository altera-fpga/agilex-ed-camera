/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#pragma once

#include "IpUiControls.h"

#include "WhiteBalance.h"
#include "IWbs.h"
#include "ITmo.h"

#include "IspCommon.h"

class VvpIspAutoWhiteBalanceControls : public IpUiControls
{
    enum AWBUiModeSelect
    {
        Disabled = 0,
        ChooseTemperatureKelvin = 1,
        ChooseLigthing = 2,
        Automatic = 3,
        CustomPreset = 4
    };

    using RoiCustomControl = UiCustomControlWithValue<RoiSelectorData>;

public:

    /// Creates an instance of the class that'll manage the given Switch instance.
    VvpIspAutoWhiteBalanceControls(
        std::shared_ptr<WhiteBalanceController> spWBController,
        std::shared_ptr<SwApi::ITmoOverride> spTmo);

    /// Generates the UI, and returns the resulting container(s)
    std::vector<std::shared_ptr<UiControlContainer>> AddUiElements() override;

    std::string GetSettingsSectionName() override { return "VvpIspAutoWhiteBalance"; };

    void AutoWhiteBalanceUpdateFunc();

    void LoadBlockBlcWbcFunctionPointer(std::function<void(bool)> fpBlockBlcWbcUiCB);
    void SetBypassBLCAndWBCFunctionPointer(std::function<void(bool)> fpSetBypassBlcWbcUiCB);

    bool IsAwbEnabled() const { return (_selectedMode != AWBUiModeSelect::Disabled); }

    void UpdateRoi(bool updateUI);
    void DisableRoiHighlighting();

    void AutoWhiteBalanceReset();

    void SwitchAwbMode(const AWBUiModeSelect& mode);

private:

    void UpdateTint();

    std::shared_ptr<WhiteBalanceController> _spWBController;
    std::shared_ptr<SwApi::ITmoOverride> _spTmo;

    uint16_t _targetTemp = 6500;
    uint16_t _sceneTemp = 6500;

    float _tint = 0.0f;
    float _tintStrength = 1.0f;

    std::shared_ptr<UiControlItemEnum> _spWhiteBalanceEnum;
    std::shared_ptr<UiControlItemEnum> _spLightingEnum;
    std::shared_ptr<UiControlItemSlider> _spColTempSlider;
    std::shared_ptr<UiControlItemSlider> _spCurTempSlider;
    std::shared_ptr<UiControlItemSlider> _spTintSlider;
    std::shared_ptr<UiControlItemSlider> _spCcmStrengthSlider;
    std::shared_ptr<UiControlItemButton> _spPresetManualButton;

    std::shared_ptr<UiControlItemButton> _spWbRoiResetButton;
    std::shared_ptr<UiControlItemBoolean> _spWbRoiHighlightBool;
    std::shared_ptr<RoiCustomControl>  _spRoiCustomControl;

    RoiSelectorData _roi;

    bool _highlighting = false;

    bool _shouldCallWBOnSliderChange = false;

    AWBUiModeSelect _selectedMode = AWBUiModeSelect::Disabled;
    
    std::vector<uint16_t> _measuredTempSamples;
    uint8_t _tempSampleCircularPointer = 0;
    uint8_t _noMeasuredTempSamplesToAverage = 10;

    std::function<void(bool)> _fpBlockBlcWbcUiCB;
    std::function<void(bool)> _fpSetBypassBlcWbcUiCB;

    const uint32_t _NUM_ROI_HIGHLIGHT_ITER = 20;
    int32_t _wbRoiHighlightCounter;

    bool _controlsInitialised;
};
