/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#include "intel_pio.h"
#include "intel_pio_regs.h"

int intel_pio_init(intel_pio_instance* instance, void* base)
{
    if (instance == NULL) return 1;

    instance->base = base; // So complex!

    return 0;
}

bool intel_pio_set_window_address(intel_pio_instance* instance, uint8_t window, uint64_t address)
{
    if (instance == NULL) return false;


    return true;
}

uint32_t intel_pio_read(intel_pio_instance* instance)
{
    if (instance == NULL) return 0;

    return INTEL_PIO_REG_IORD(instance, 0);
}

void intel_pio_write(intel_pio_instance* instance, uint32_t value)
{
    if (instance == NULL) return;

    INTEL_PIO_REG_IOWR(instance, 0, value);
}