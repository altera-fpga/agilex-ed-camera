/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#ifndef __INTEL_ADDR_SPAN_EXP_REGS_H__
#define __INTEL_ADDR_SPAN_EXP_REGS_H__

#define LOWER_DWORD_FOR_WINDOW(i) (i * 2)
#define UPPER_DWORD_FOR_WINDOW(i) ((i * 2 ) + 1)

#endif // __INTEL_ADDR_SPAN_EXP_REGS_H__
