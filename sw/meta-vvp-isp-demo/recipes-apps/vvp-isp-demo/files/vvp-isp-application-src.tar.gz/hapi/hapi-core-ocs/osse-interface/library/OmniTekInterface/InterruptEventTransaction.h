/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once

#include "ImpInterruptInterface.h"
#include "HardwareDevice.h"

class InterruptEvent_Transaction: public IoOverlappedTransaction<InterruptEvent_TransactionBase,
                                                                 Ioctl_Struct(CapInterrupt_InterruptEvent_IOCTL),
                                                                 CAP_INTERRUPT_IOCTL_VERSION_InterruptEvent,
                                                                 CAP_INTERRUPT_IOCTL_InterruptEvent>
{
public:
	InterruptEvent_Transaction(ot_uint32_t numBits)
		: IoOverlappedTransaction(numBits * sizeof(Interrupt_Event_Struct))
		, _numBits(numBits)
	{
		if (!_pIoctl)
		{
			return;
		}

		// Set the number of bits
		Ioctl_Payload(_pIoctl)NumBits = numBits;
	}

	ot_uint32_t GetSetMask()
	{
		if (!_pIoctl)
		{
			return 0;
		}

		ot_uint32_t mask = 0;
		for( ot_uint32_t idx=0; idx<_numBits; idx++ )
		{
			if( Ioctl_Payload(_pIoctl)Bits[idx].Count != 0 )
				mask |= (1<<idx);
		}
		return mask;
	}

	ot_uint32_t GetIntCount(ot_uint32_t theBit)
	{
		if (!_pIoctl)
		{
			return 0;
		}

		ot_uint32_t count = 0;
		if( theBit < _numBits )
			count = Ioctl_Payload(_pIoctl)Bits[theBit].Count;
		return count;
	}

	otTime GetIntTime( ot_uint32_t theBit)
	{
		if (!_pIoctl)
		{
			return 0;
		}

		if( theBit < _numBits )
			return Ioctl_Payload(_pIoctl)Bits[theBit].Time;

		return 0;
	}

	ot_uint32_t GetNumBits() {return _numBits;};

private:
	ot_uint32_t _numBits;
};
