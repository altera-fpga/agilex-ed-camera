/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef _USERLAND_TYPES_H_
#define _USERLAND_TYPES_H_

#ifndef BUILDTYPE
#error "Do not include this file directly"
#endif
#ifdef BT_KERNEL
#error "Cannot include this file when building a User Mode module"
#endif

#if BUILDTYPE == BT_WINDOWS
#include "windows\UserTypes.h"
#else
#include "linux/UserTypes.h"
#endif // BUILDTYPE == BT_WINDOWS

#endif /* _USERLAND_TYPES_H_ */
