/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef VIDEOFDMA_IOCTL_H_
#error "Do not include this directly."
#endif

#include "../Common_IOCTL.h"
#include "../IOCTL_DMACommon.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


#pragma pack(push,4)

/**
 * @brief Linux specific wrapped "eventable" structure for data dma's
 * As there is no real concept of async io for ioctls under Linux we need to
 * use our own mechanism. This is very similar to how libaio works.
 */
typedef struct _CapDataFDMA_Event_IOCTL_Linux
{
    CapDataFDMA_Event_IOCTL IOCTLInfo; //!< The event specific information
    CapGeneral_EventCtx_IOCTL EventInfo; //!< The actual ioctl payload
} CapDataFDMA_Event_IOCTL_Linux;

#pragma pack(pop)


/**
 * @brief Current #CAP_VIDEOFDMA_IOCTL_Transfer ::DMATransaction_IOCTL::Version number to use
 */
#define CAP_VIDEOFDMA_IOCTL_Transfer_Version2 2
#define CAP_VIDEOFDMA_IOCTL_Transfer_Version1 1
#define CAP_VIDEOFDMA_IOCTL_Transfer_Version0 0

#define CAP_VIDEOFDMA_IOCTL_Transfer_Version CAP_VIDEOFDMA_IOCTL_Transfer_Version1

/**
 * @brief Current #CAP_VIDEOFDMA_IOCTL_Start CapVideoFDMA_VersionOnly_IOCTL::Version number to use
 */
#define CAP_VIDEOFDMA_IOCTL_Start_Version 0

/**
 * @brief Current #CAP_VIDEOFDMA_IOCTL_Stop CapVideoFDMA_VersionOnly_IOCTL::Version number to use
 */
#define CAP_VIDEOFDMA_IOCTL_Stop_Version 0

/**
 * @brief Current #CAP_DATAFDMA_IOCTL_Event CapDataFDMA_Event_IOCTL::Version number to use
 */
#define CAP_DATAFDMA_IOCTL_Event_Version 0


/**
 * @brief IOCTL on OT_Cap_VideoFDMA devices for setting up DMA transfers
 * Passed and received data type is ::DMATransaction_IOCTL_Linux
 */
#define CAP_VIDEOFDMA_IOCTL_Transfer   _IOWR( CAP_VIDEOFDMA_IOC_MAGIC, CAP_VIDEOFDMA_IOCTL_NUM_Transfer, DMATransaction_IOCTL_Linux * )

/**
 * @brief IOCTL on OT_Cap_VideoFDMA devices for setting up DMA transfers directly to a GPU
 * Passed and received data type is ::DMATransaction_IOCTL_Linux
 */
#define CAP_VIDEOFDMA_IOCTL_TransferGpuDirect _IOWR( CAP_VIDEOFDMA_IOC_MAGIC, CAP_VIDEOFDMA_IOCTL_NUM_TransferGpuDirect, DMATransaction_IOCTL_Linux * )

/**
 * @brief IOCTL on OT_Cap_VideoFDMA devices for telling the DMA engine it can start
 * Passed and received data type is CapVideoFDMA_VersionOnly_IOCTL
 */
#define CAP_VIDEOFDMA_IOCTL_Start   _IOWR( CAP_VIDEOFDMA_IOC_MAGIC, CAP_VIDEOFDMA_IOCTL_NUM_Start, CapVideoFDMA_VersionOnly_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_VideoFDMA devices for telling the DMA engine it can stop
 * Passed and received data type is CapVideoFDMA_VersionOnly_IOCTL
 */
#define CAP_VIDEOFDMA_IOCTL_Stop   _IOWR( CAP_VIDEOFDMA_IOC_MAGIC, CAP_VIDEOFDMA_IOCTL_NUM_Stop, CapVideoFDMA_VersionOnly_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_VideoFDMA devices for data events
 * Passed and received data type is CapDataFDMA_Event_IOCTL_Linux
 */
#define CAP_DATAFDMA_IOCTL_Event   _IOWR( CAP_VIDEOFDMA_IOC_MAGIC, CAP_DATAFDMA_IOCTL_NUM_Event, CapDataFDMA_Event_IOCTL_Linux * )



#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/
