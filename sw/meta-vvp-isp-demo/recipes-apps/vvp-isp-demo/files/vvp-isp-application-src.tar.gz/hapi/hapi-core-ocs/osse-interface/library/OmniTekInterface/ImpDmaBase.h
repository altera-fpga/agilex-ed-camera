/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
#include "InternalCapability.h"
#include "EAutoLock.h"
#include "ImpDmaXfer.h"
#include "InternalDmaBase.h"

using namespace OmniTek;
// Forward declarations
class PlatformImpDma;

class PlatformDmaEventXfer;
class ImpDmaEventBase : public IDmaEvent, ImpOmniTekBasePtr
{
public:
	ImpDmaEventBase( PlatformImpDma *pDmaChannel);
	virtual ~ImpDmaEventBase();

	// Interface Functions
	virtual OT_Status GetTransferSize(ot_uint32_t &bytesTransferred, ot_int32_t Timeout);
	virtual OT_Status ScheduleGetTransferSize(IDmaEventXferPtr *spDmaEventXfer);
	virtual OT_Status SetTransferSize(ot_uint32_t bytesTransferred);
	virtual OT_Status XferWait(IDmaEventXferPtr &spDmaEventXfer, ot_int32_t Timeout);

	virtual OT_Status SendIoctl(PlatformDmaEventXfer *pXfer) = 0;
	virtual OT_Status _WaitXfer(PlatformDmaEventXfer *pXfer, ot_int32_t Timeout) = 0;
	virtual OT_Status _Cancel(PlatformDmaEventXfer *pXfer) = 0;

	OT_Status XferWait(ImpDmaEventXfer *pXfer, ot_int32_t Timeout);
	OT_Status Cancel(PlatformDmaEventXfer *pXfer);

	void Clear();

	PlatformImpDma *_pDmaChannel;

	DECLARE_IMP_OMNITEK_PTR
private:
	IDmaEventXferPtr GetFirstPendingXfer();

	ECritSec			_pendingLock;
	omDmaEventXferList	_pendingList;
};
typedef ISmartPtr<ImpDmaEventBase> ImpDmaEventBasePtr;

class ImpDmaBase : public InternalDmaBase, ImpOmniTekBasePtr
{
public:
	ImpDmaBase(OTParentTracker* pParentTracker, InternalCapability *pCapability, OT_DMA_Type_BitField type);
	virtual ~ImpDmaBase(void);
	
	// Interface Functions
	virtual OT_DMA_Type_BitField	GetBitFieldType();
	virtual OT_DMA_Type				GetType();
	virtual OT_DMA_Direction		GetDirection();
	virtual OT_DMA_ContentType		GetContentType();

	virtual ICapability*			GetCapability();
	virtual IBoard*					GetBoard();
	virtual ot_uint32_t			GetMinSingleTransferSize();
//	virtual ot_uint32_t			GetMaxSingleTransferSize();
//	virtual ot_uint32_t 			GetMinBufferDepth();
	virtual	bool					bIsReadSupported();
	virtual bool					bIsWriteSupported();

	virtual OT_Status				GetTimingCounter( otTime &ticks );
	virtual OT_Status				GetTimingFrequency( otTime &ticksPerSecond );

	bool	bIsValid();
	void	SetInvalid();

	// Macro to connect up the Base Smart Pointer implementation
	//DECLARE_IMP_OMNITEK_PTR
	// We'll attach the Base Smart Pointer Manually so that we we can handle calling Stop once all client references have been removed
	virtual ot_uint32_t AddRef()
	{
		return ImpOmniTekBasePtr::AddRef();
	}
	virtual ot_uint32_t Release();
	virtual ot_uint32_t GetRefCount()
	{
		return ImpOmniTekBasePtr::GetRefCount();
	}

	virtual OT_Status	Start();
	virtual OT_Status Stop() = 0;
	virtual OT_Status MemoryXferWait( IDmaXferPtr spDmaXfer, ot_int32_t timeout);

	virtual OT_Status SendDmaXferRequest(PlatformImpDmaXfer *pDmaXfer, bool bOverlapped) = 0;
	virtual OT_Status PlatformMemoryXferWait(PlatformImpDmaXfer *pDmaXfer, ot_int32_t timeout) =0;
	virtual OT_Status PlatformCancelXfer(PlatformImpDmaXfer *pDmaXfer) = 0;
	virtual void CancelXfer(IDmaXfer* pDmaXfer);

	IDmaXferPtr				AddToTransactionPending(ImpDmaXfer *pTransaction);
	IDmaXferPtr				GetFirstPendingXfer();

	OT_Status				_MemoryXferWait( PlatformImpDmaXfer *pDmaXfer, ot_int32_t timeout);
	OT_Status				MemoryXferWait( PlatformImpDmaXfer* pTransaction, ot_int32_t timeout);

	ot_uint32_t				GetMaxTargets();

private:
	char*					_pName;
	InternalCapability*		_pOmniTekCapability;
	InternalRegisterCapability*	_pCapability;
	OT_DMA_Type_BitField	_bitFieldtype;

	ot_uint32_t				_maxSingleTransferSize;
	ot_uint32_t				_minSingleTransferSize;
	ot_uint32_t				_minBufferDepth;
	ot_uint32_t				_maxTargets;
	bool					_bReadSupported;
	bool					_bWriteSupported;

	bool					_bValid;

	ECritSec				_pendingLock;
	omDmaXferList			_pendingList;
};
