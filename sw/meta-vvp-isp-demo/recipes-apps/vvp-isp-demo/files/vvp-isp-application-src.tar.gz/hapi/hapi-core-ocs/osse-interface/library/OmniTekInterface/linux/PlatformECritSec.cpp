/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "StdAfx.h"
#include "PlatformECritSec.h"
#include <pthread.h>

#ifdef _DEBUG
#define new DEBUG_CLIENTBLOCK
#endif

#ifndef ATLASSERT
#define ATLASSERT(a)
#endif

ECritSec::ECritSec(const char* name)
:	_owning_thread_id(0)
,	_recursion_count(0)
,	_close_on_exit(true)
{
	//create mutex attribute variable
	pthread_mutexattr_t mutex_attribute;

	// setup recursive mutex for mutex attribute
	pthread_mutexattr_init(&mutex_attribute);
	pthread_mutexattr_settype(&mutex_attribute, PTHREAD_MUTEX_RECURSIVE_NP);

	// Use the mutex attribute to create the mutex
	pthread_mutex_init(&_mutex, &mutex_attribute);

	// Mutex attribute can be destroy after initializing the mutex variable
	pthread_mutexattr_destroy(&mutex_attribute);
}

ECritSec::ECritSec(pthread_mutex_t assign_mutex)
:	_owning_thread_id(0)
,	_recursion_count(0)
,	_mutex(assign_mutex)
,	_close_on_exit(false)
{
}

ECritSec::~ECritSec()
{
	ATLASSERT(_owning_thread_id == 0);
	ATLASSERT(_recursion_count == 0);
	if (_close_on_exit)
		pthread_mutex_destroy(&_mutex);
}

bool ECritSec::Lock(const struct timespec *abs_timeout)
{
	pthread_mutex_lock(&_mutex);
	_recursion_count++;
	_owning_thread_id = pthread_self();
	return true;
}

void ECritSec::Unlock()
{
	if (--_recursion_count == 0)
		_owning_thread_id = 0;
	pthread_mutex_unlock(&_mutex);
}

bool ECritSec::IsLocked()
{
	// NOTE: this is subject to race conditions. For use in debug / testing only.
	bool locked = true;
	int result = pthread_mutex_trylock(&_mutex);
	if (result == 0)
	{
		locked = (_recursion_count > 0);
		pthread_mutex_unlock(&_mutex);
	}

	return locked;
}

