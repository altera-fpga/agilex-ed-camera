/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#if BUILDTYPE==BT_LINUX
#include "linux/PlatformECritSec.h"
#else
#include "windows\PlatformECritSec.h"
#endif

class EAutoLock
{
public:
	EAutoLock(ECritSec& cs);
	~EAutoLock();

	EAutoLock(const EAutoLock& other) = delete;
	EAutoLock& operator=(const EAutoLock& other) = delete;
	EAutoLock(EAutoLock&& other) = delete;
	EAutoLock& operator=(EAutoLock&& other) = delete;

	void Lock();
	void Unlock();

	ECritSec& _cs;
};
