/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpCapabilityEnumerator.h"

ImpCapabilityEnumerator::ImpCapabilityEnumerator(OTParentTracker *pParentTracker)
	: InternalCapabilityEnumerator(pParentTracker)
{
}

ImpCapabilityEnumerator::~ImpCapabilityEnumerator()
{
	// Clear the _capability map, all capabilities are smart and should clean themselves up
	_capabilities.clear();
}

bool ImpCapabilityEnumerator::AddCapability(InternalCapability *pCapability)
{
	OmniTekCapabilityMap::iterator newCap = _capabilities.insert(std::make_pair(pCapability->GetType(), pCapability));

	// Update the associated capabilities
	{
		OmniTekCapabilityMap::iterator iter = _capabilities.begin();
		while( iter != _capabilities.end() )
		{
			const ICapabilityPtr a = iter->second;
			const ICapabilityPtr b = newCap->second;

			if( a != b )
			{
				ICapability* pOther = iter->second;

				// Check to see whether their associated ID are the same
				if( pOther->GetAssociatedID() == pCapability->GetAssociatedID() )
				{
					// If they have the same associated ID then add a reference to each capability
					InternalCapability *pImpOther = (InternalCapability*)pOther;
					pImpOther->AddAssociatedCapability(newCap->second);
					pCapability->AddAssociatedCapability(pOther);
				}
			}
			iter++;
		}
	}
	return true;
}

ot_int32_t ImpCapabilityEnumerator::GetNumCapabilities()
{
	return (ot_int32_t)_capabilities.size();
}

ICapabilityPtr ImpCapabilityEnumerator::GetCapability(ot_int32_t index)
{
	OmniTekCapabilityMap::iterator	iter = _capabilities.begin();
	ot_int32_t i=0;
	while( iter != _capabilities.end() )
	{
		if( index == i )
		{
			return iter->second;
		}
		iter++;
		i++;
	}

	return NULL;
}

ot_int32_t ImpCapabilityEnumerator::GetNumCapabilities(ot_uint32_t type)
{
	return (ot_int32_t)_capabilities.count(type);
}

ICapabilityPtr ImpCapabilityEnumerator::GetCapability(ot_uint32_t type, ot_int32_t index)
{
	ICapabilityPtr spCapability;

	OmniTekCapabilityPairIterator pair = _capabilities.equal_range(type);
	OmniTekCapabilityMap::iterator iter = pair.first;

	ot_int32_t i=0;
	while( iter != pair.second )
	{
		if( i==index )
		{
			return iter->second;
		}
		iter++;
		i++;
	}
	
	return NULL;
}

ICapabilityPtr ImpCapabilityEnumerator::GetCapabilityByUniqueId(ot_uint32_t type, ot_int32_t uniqueId)
{
	OmniTekCapabilityPairIterator pair = _capabilities.equal_range(type);
	OmniTekCapabilityMap::iterator iter = pair.first;

	while( iter != pair.second )
	{
		if( iter->second->GetUniqueID() == uniqueId )
		{
			return iter->second;
		}
		iter++;
	}
	return NULL;
}
