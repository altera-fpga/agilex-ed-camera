/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekTypes.h"
#include "IOmniTekPtr.h"

#ifdef _MSC_VER			// Building Using Visual Studio we should include the declspec
#ifdef OMNITEKINTERFACE_EXPORTS
#define OMNITEK_INTERFACE_API __declspec(dllexport)
#else
#define OMNITEK_INTERFACE_API __declspec(dllimport)
#endif
#else
#define OMNITEK_INTERFACE_API
#endif

/// \namespace OmniTek
/// Omnitek namespace
namespace OmniTek
{
/// Define for the default timeout for a DMA request
#define OT_DMA_DEFAULT_TIMEOUT (1000)

/// Define for the default timeout for an interrupt
#define OT_INT_DEFAULT_TIMEOUT (1000)

class IFpgaFactory;

class IBoard;
/// \brief Smart pointer implementation of an IBoard
typedef ISmartPtr<IBoard> IBoardPtr;

class IFpga;
/// \brief Smart pointer implementation of an ICapability
typedef ISmartPtr<IFpga> IFpgaPtr;

class ICapability;
/// \brief Smart pointer implementation of an ICapability
typedef ISmartPtr<ICapability> ICapabilityPtr;

// Forward Declaration for a IDmaChannel
class IDmaChannel;
/// \brief Smart pointer implementation of an IDmaChannel
typedef ISmartPtr<IDmaChannel> IDmaChannelPtr;

/// \class IRegisterBlock
/// \brief Exposes a class to use a Register Block within a capability
class OMNITEK_INTERFACE_API IRegisterBlock : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~IRegisterBlock(){}

	/// Get the number of Registers in the Register Block
	/// \return Number of registers
	virtual ot_int32_t		GetNumRegisters() = 0;

	/// Read from the value of the register in the hardware
	/// \param [in] offset Register Offset of the register
	/// \param [out] result The value of the register
	/// \return true if the read was successfull
	virtual bool	ReadRegister(ot_int32_t offset, ot_uint32_t &result) = 0;

	/// Read from the last value written to the hardware.
	/// \param [in] offset Register Offset of the register
	/// \param [out] result The value of the register
	/// \return true if the read was successfull
	virtual bool	ReadShadowRegister(ot_int32_t offset, ot_uint32_t &result) = 0;

	/// Write value to a register
	/// \param [in] offset Register Offset of the register
	/// \param [in] result The value of the register
	/// \return true if the write was successfull
	virtual bool	WriteRegister(ot_int32_t offset, ot_uint32_t value) = 0;

	/// Get Parent Capability Pointer
	/// \return Smart Pointer to the parent capability
	virtual ICapabilityPtr GetParentCapability() = 0;

	/// Get the Physical address of the Register Block
	/// The Physical address cannot be used directly for read/write operations.
	/// \return Physical address of the register block. -1 indicates that the address could not be read.
	virtual ot_uint64_t GetPhysicalAddress() = 0;
};
/// \brief Smart pointer implementation of an IRegisterBlock
typedef ISmartPtr<IRegisterBlock> IRegisterBlockPtr;

/// \class IInterruptWait
/// \brief Exposes a class to handle asynchronous waits for interrupts
class OMNITEK_INTERFACE_API IInterruptWait : public ISmartBasePtr
{
public:
	virtual ~IInterruptWait() {}

	/// Wait for an interrupt to fire
	/// \param [in] Timeout for the request. Negative number represent Infinite timeout
	/// \return OT_Status_OK if transfer completed successfully
	virtual OT_Status Wait(ot_int32_t Timeout = OT_INT_DEFAULT_TIMEOUT) = 0;

	/// Get the otEventHandle to the Event which is signaled when the Interrupt has fired
	/// \return HANDLE of the completion event. Once the completion event is signaled the IInterruptWait should be checked to see the completion status using Wait.
	/// Note: The HANDLE is only valid while the IInterruptWaitPtr is held.
	virtual otEventHandle	GetCompletionHandle() = 0;

	/// Get the mask of the interrupts fire.
	/// This becomes valid once the Wait call has completed successfully
	/// \return Non-Zero value indicates that an interrupt has fired
	virtual ot_uint32_t GetCompleteMask() = 0;

	/// Get the number of interrupts fired while waiting for the interrupts
	/// \param [in] Index of the interrupt enable that the count is required for.
	/// \return Count of how many interrupts for that bit occurred
	virtual ot_uint32_t GetInterruptCount( ot_uint32_t theBit) = 0;

	/// Get the time of the last last interrupt fired for the requested bit
	/// \param [in] Index of the interrupt enable that the time is required for.
	/// \param [out] Reference to a struct to receive the last interrupt time. If the counter is not supported by the firmware then 0 is returned.
	/// \return OT_Status_Timing_Not_Implemented if the hardware doesn't implement the timing value.
	virtual OT_Status GetInterruptTime( ot_uint32_t theBit, otTime &ticks ) = 0;

	/// Get the counts/second from the FPGA used for timing values
	/// \param Pointer to a struct to received the timing value. If the counter is not supported by the firmware then 0 is returned.
	/// \return OT_Status_Timing_Not_Implemented if the hardware doesn't implement the timing value.
	virtual OT_Status GetTimingFrequency( otTime &ticksPerSecond ) = 0;
};

/// \brief Smart pointer implementation of an IInterruptWait
typedef ISmartPtr<IInterruptWait> IInterruptWaitPtr;

/// \class IInterruptInterface
/// \brief Exposes a class to control the Interrupt Interface on a Capability
/// Once you have queried for and received a valid interface the Interrupts are
/// now locked while the interface is held
class OMNITEK_INTERFACE_API IInterruptInterface : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly
	virtual ~IInterruptInterface() {}

	/// Get current interrupt enable mask
	/// \return The current interrupt enable mask
	virtual ot_uint32_t GetInterruptMask() = 0;

	/// Set the Enable Mask of the Interrupt Enable Register, using the bit set in the enableMask.
	/// \param [in] enableMask, the bits to be enabled in the Interrupt Enable Register
	/// \return OT_Status_OK if successful
	virtual OT_Status SetEnableMask(ot_uint32_t enableMask) = 0;

	/// Clear the Disable Mask of the Interrupt Enable Register, clearing the bits set in the disableMask
	/// \param [in] disableMask, the bits to be disabled in the Interrupt Enable Register
	/// \return OT_Status_OK if successful
	virtual OT_Status SetDisableMask(ot_uint32_t disableMask) = 0;

	/// Schedules a wait for the next interrupt.
	/// param [out] Pointer to a smart
	/// \return OT_Status if successful
	virtual OT_Status ScheduleWaitForInterrupt(IInterruptWaitPtr *spWait) = 0;

	virtual ICapabilityPtr GetParentCapability() = 0;
};

/// \brief Smart pointer implementation of an IInturruptInterface
typedef ISmartPtr<IInterruptInterface> IInterruptInterfacePtr;

/// \class ICapability
/// \brief Exposes an object to talk to a capability in the FPGA
class OMNITEK_INTERFACE_API ICapability : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~ICapability(){}

	/// Get the Capability header type for this capability
	/// \return The capability header type, typically either Register or Register Offset
	virtual ot_uint32_t		GetHeaderType() = 0;

	/// Get the Capability Type for this capability
	/// \return The unique capability type.
	virtual ot_uint32_t		GetType() = 0;

	/// Get the number of register blocks in the capability.
	/// \return number of Register blocks
	virtual ot_int32_t		GetNumRegisterBlocks() = 0;

	/// Get the Reqister Block at index
	/// \param index The index of the required register block.
	/// \return Smart pointer to a IRegisterBlock, NULL if the Register Block doesn't exist at index.
	virtual IRegisterBlockPtr	GetRegisterBlock(ot_int32_t index) = 0;

	/// Get the Unique ID number of the Capability.
	/// \return The unique ID of the capability, as defined by the firmware.
	virtual ot_int32_t			GetUniqueID() = 0;

	/// Get the Associated ID number of the capability
	/// \return The Associated ID of the capability, as defined by the firmware
	virtual ot_uint32_t			GetAssociatedID() = 0;

	/// Get the number of Capabilities which are associated with this capability
	/// \return Number of associated capabilities.
	virtual ot_int32_t			GetNumAssociatedCapability() = 0;

	/// Get the associated capability at index
	/// \param index The index of the required associated capability.
	/// \return Smart pointer to the required associated capability, NULL if the capability does not exist.
	virtual ICapabilityPtr		GetAssociatedCapability(ot_int32_t index) = 0;

	/// Get the associated capability, by type, at index
	/// \param type The unique type of the associated capability
	/// \param index The index of the required associated capability.
	/// \return Smart pointer to the required associated capability, NULL if the capability does not exist.
	virtual ICapabilityPtr		GetAssociatedCapability(ot_uint32_t type, ot_int32_t index) = 0;

	/// Get the counts/second from the FPGA used for timing values
	/// \param Pointer to a struct to received the timing value. If the counter is not supported by the firmware then 0 is returned.
	/// \return OT_Status_Timing_Not_Implemented if the hardware doesn't implement the timing value.
	virtual OT_Status GetTimingFrequency( otTime &ticksPerSecond ) = 0;

	/// Get the current counter from the FPGA used for timing values
	/// \param Pointer to a struct to received the timing value. If the counter is not supported by the firmware then 0 is returned.
	/// \return OT_Status_Timing_Not_Implemented if the hardware doesn't implement the timing value.
	virtual OT_Status GetTimingCounter( otTime &ticks ) = 0;

	/// Get Parent FPGA Pointer
	/// \return Pointer to the parent FPGA
	virtual IFpgaPtr GetParentFpga() = 0;

	/// Get the version of the Capability
	/// \return the version number of the capability
	virtual ot_int32_t GetVersion() = 0;

	/// Get the path to the underlying device driver associated with this capability.
	/// \param [out]		Pointer to a buffer to receive the path
	/// \param [in, out]	Pointer to an integer for the size of the supplied buffer.
	/// \return OT_Status_Buffer_Too_Small if the output buffer is too small, pBufferSize if updated with the required path size.
	virtual OT_Status	GetDevicePath(ot_char_t *pBuffer, ot_uint32_t *pBufferSize) = 0;

	/// Get the HANDLE to the underlying device driver associated with this capability.
	/// The handle only remains valid while the FPGA interface is held open.
	/// \param [out]		Pointer to a buffer to receive the Device Handle
	/// \return OT_Status_OK if the Device Handle can be received.
	virtual OT_Status	GetDeviceHandle(otDeviceHandle *pDeviceHandle) = 0;

	/// Query to see if generic interrupt support is available
	/// \return OT_Status_OK if the Capability supports the Generic Interrupt Interface
	virtual OT_Status	GetIsInterruptSupported() = 0;

	/// Query to see how many interrupt bits the capability supports
	/// \return Number of interrupt bits supported. A value of 0 indicates that the capability does
	/// not support interrupts.
	virtual ot_uint32_t GetNumInterruptBits() = 0;

	/// Get the Interrupt Interface if supported and also if it is available to be used.
	/// The Capability Interface can only be queried for by a single caller. If the interface
	/// interface has already been take then all further queries are denied.
	/// \param [out]	Pointer to a buffer to accept the status code.
	/// \return Smart pointer to the Interrupt interface
	virtual IInterruptInterfacePtr GetInterruptInterface(OT_Status *pStatus) = 0;
};

/// \class ICapabilityEnumerator
/// \brief Exposes a class to find all the available capabilities in the FPGA
class OMNITEK_INTERFACE_API ICapabilityEnumerator : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~ICapabilityEnumerator(){}

	/// Get the number of Capabilities available in the FPGA
	/// \return Number of capabilities
	virtual ot_int32_t		GetNumCapabilities()	= 0;

	/// Get the number of Capabilities, of Type, available in the FPGA
	/// \param type 
	/// \return Number of capabilities
	virtual ot_int32_t		GetNumCapabilities(ot_uint32_t type) = 0;

	virtual ICapabilityPtr	GetCapability(ot_int32_t index) = 0;
	virtual ICapabilityPtr	GetCapability(ot_uint32_t type, ot_int32_t index) = 0;
	virtual ICapabilityPtr	GetCapabilityByUniqueId(ot_uint32_t type, ot_int32_t uniqueId) = 0;
};
/// \brief Smart pointer implementation of an ICapabilityEnumerator
typedef ISmartPtr<ICapabilityEnumerator> ICapabilityEnumeratorPtr;

/// \class IDmaEventXfer
/// \brief Exposes a class to handle Asynchronous DMA Event Transfer requests
class OMNITEK_INTERFACE_API IDmaEventXfer : public ISmartBasePtr
{
public:
	virtual ~IDmaEventXfer() {}

	/// Get the number of bytes transferred for the Event Interrupt (input only)
	virtual ot_int32_t GetBytesTransferred() = 0;

	/// Get the otEventHandle to the Event which is signaled when the Dma XFer is complete.
	/// \return HANDLE of the completion event. Once the completion event is signalled the IDmaXfer should be checked to completion status using MemoryXferWait.
	/// Note: The HANDLE is only valid while the IDmaXferPtr is held.
	virtual otEventHandle	GetCompletionHandle() = 0;

	/// Wait for the transfer to complete.
	/// \param [in] Timeout for the request. Negative number represent Infinite timeout
	/// \return OT_Status_OK if transfer completed successfully
	virtual OT_Status XferWait(ot_int32_t Timeout = OT_DMA_DEFAULT_TIMEOUT) = 0;

	/// Get the interrupt time of the last byte transferred
	virtual otTime GetInterruptTime() = 0;
};
/// \brief Smart pointer implementation of an IDmaEventXfer
typedef ISmartPtr<IDmaEventXfer> IDmaEventXferPtr;

/// \class IDmaEvent
/// \brief Exposes a class to handle getting event interrupts from a packet based DMA. FDMA
class OMNITEK_INTERFACE_API IDmaEvent : public ISmartBasePtr
{
public:
	virtual ~IDmaEvent() {}

	/// Get the transfer size on the DMA channel (input channels only).
	/// This can be used once the DMA Channel has started
	/// \param[out] Pointer to a variable to receive the number of bytes Transferred for this request
	/// \param [in] Timeout for the request. Negative number represent Infinite timeout
	/// \return OT_Status_OK if transfer completed successfully
	virtual OT_Status GetTransferSize(ot_uint32_t &bytesTransferred, ot_int32_t Timeout = OT_DMA_DEFAULT_TIMEOUT) = 0;

	/// Schedule a request to receive the next transfer size (input channels only).
	/// This can be used to pre-charge the DMA channel prior to starting the DMA Channel
	virtual OT_Status ScheduleGetTransferSize(IDmaEventXferPtr *spDmaEventXfer) = 0;

	/// Set the transfer size on the DMA channel (output channels only).
	/// This can be used once the DMA Channel has started
	/// \param[in] Number of bytes transferred for this request
	/// \return OT_Status_OK if successful, otherwise an appropriate error code
	virtual OT_Status SetTransferSize(ot_uint32_t bytesTransferred) = 0;
};

/// \brief Smart pointer implementation of an IDmaEvent
typedef ISmartPtr<IDmaEvent> IDmaEventPtr;

/// \class IDmaXfer
/// \brief Exposes a class to handle Asynchronous DMA resquests
class OMNITEK_INTERFACE_API IDmaXfer : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~IDmaXfer(){}

	/// Get the otEventHandle to the Event which is signed when the Dma XFer is complete.
	/// \return HANDLE of the completion event. Once the completion event is signalled the IDmaXfer should be checked to completion status using MemoryXferWait.
	/// Note: The HANDLE is only valid while the IDmaXferPtr is held.
	virtual otEventHandle	GetCompletionHandle() = 0;

	/// Get the base address of the Asynchronous DMA request
	/// \return Pointer of the DMA request buffer.
	virtual void*			GetTransferBuffer() = 0;

	/// Get the size of the Asychronous DMA request
	/// \return Size of DMA request
	virtual ot_uint32_t	GetTransferSize()	= 0;

	/// Get the FPGA Local Address of the Asychronous DMA request
	/// \return Local Address of the DMA request
	virtual ot_uint32_t	GetLocalAddr()		= 0;

	/// Get DMA Transaction time
	/// \return OT_Status_Timing_Not_Implemented if the FPGA does not support the hardware time counter.
	virtual OT_Status		GetTransactionTime(otDmaTiming *pTiming) const = 0;

	/// Wait fot the transaction to complete
	/// \param [in] Timeout for the request. Negative number represent Infinite timeout
	/// \return Status of the transfer
	virtual OT_Status XferWait( ot_int32_t timeout = OT_DMA_DEFAULT_TIMEOUT) = 0;

	/// Get the Smart Pointer to the owning IDmaChannel
	/// \return Smart Pointer to the owning IDmaChannel
	virtual IDmaChannelPtr GetParent() = 0;
};

/// \brief Smart pointer implementation of an IDmaXfer
typedef ISmartPtr<IDmaXfer> IDmaXferPtr;

/// \class IDmaTransaction
/// \brief Exposes DMA transactions to allow grouping of buffers
class OMNITEK_INTERFACE_API IDmaTransaction : public ISmartBasePtr
{
public:
    /// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~IDmaTransaction() {}

	/// Get the number of buffers in this transaction object
	/// \return Number of buffers in this transaction
	virtual ot_uint32_t GetNumBuffers() = 0;

	/// Add a virtual memory buffer to the transaction
    /// \param [in] Pointer to the buffer for use during the transfer
    /// \param [in] The local address on the FPGA
    /// \param [in] The size of the DMA transfer
    /// \param [in] Whether to sync to this buffer to the hardware. In general this is true.
	/// \return Status of the action
	virtual OT_Status	AddVirtualBuffer( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bSyncBuffer ) = 0;

	/// Get the maximum number of buffers that can be transfered in a single transaction
	/// \return Maximum number of buffers
	virtual ot_uint32_t GetMaxBuffers() = 0;

	/// Empty the current transaction object
	virtual	void		ClearBuffers() = 0;
};

/// \brief Smart pointer implementation of an IDmaTransaction
typedef ISmartPtr<IDmaTransaction> IDmaTransactionPtr;

/// \class IDmaChannel
/// \brief Exposes a DMA channel inside the FPGA
class OMNITEK_INTERFACE_API IDmaChannel : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~IDmaChannel(){}

	/// Get the bit field type of DMA channel.
	/// \return DMA channel bit field type.
	virtual OT_DMA_Type_BitField	GetBitFieldType() = 0;

	/// Get the basic Type of the DMA channel
	/// \return Dma channel type, If FDMA then a start is required to start overlapped transactions. MDMA always start their transaction immediately
	virtual OT_DMA_Type			GetType() = 0;

	/// Get the supported direction for this DMA channel
	/// \return Supported direction for the DMA Channels
	virtual OT_DMA_Direction		GetDirection() = 0;

	/// Get the Content Type of the DMA channel
	/// \return The Content Type of the DMA channel
	virtual OT_DMA_ContentType		GetContentType() = 0;

	/// Get the pointer to the capability interface for this DMA channel.
	/// \return Pointer to the capability interface for this DMA channel
	virtual ICapability*	GetCapability() = 0;

	/// Get the pointer to the owning IBoard
	/// \return Pointer to the owning IBoard
	virtual IBoard*			GetBoard() = 0;

	/// Get the Minimum Transfer size
	/// \return The size of a minimum transfer. If 0 then any size can be DMA'd
	virtual ot_uint32_t	GetMinSingleTransferSize() = 0;

	/// Get the maximum size of a single buffer the DMA channel will process without splitting into multiple requests to the DMA driver.
	/// \return The maximum buffer size, in bytes, that the DMA channel can handle in a single request. 
	/// \warning If the channel is based on a streaming DMA controller then any requests larger than MaxSingleTransferSize will be rejected.
//	virtual ot_uint32_t	GetMaxSingleTransferSize() = 0;

	/// Get the minimum number of buffers that are required to guarantee continuous buffering.
	/// \return return 1 for non streaming DMA channels and the min required buffers depth for DMA channels based on the streaming DMA controller.
	/// \warning If the channel is based on a streaming DMA controller and the queued buffers are below MinBufferDepth the DMA channel will be stopped and will reject all future buffers.
//	virtual ot_int32_t		GetMinBufferDepth() = 0;

	/// Is Read operation supported on this DMA Channel. Read = FPGA to Host transfer.
	/// \return True if Read is supported.
	virtual bool	bIsReadSupported() = 0;

	/// Is Write operation supported on this DMA Channel. Write = Host to FPGA transfer.
	/// \return True if Read is supported.
	virtual bool	bIsWriteSupported() = 0;

	/// Start, Start the DMA channel. Not required on non-streaming dama channels
	/// \return Status of the command.
	virtual OT_Status	Start() = 0;

	/// Stop, Stop the DMA channel. Not required on non-streaming dama channels
	/// \return Status of the command.
	virtual OT_Status Stop() = 0;

	/// MemoryXfer, used to do a single memory transfer. Typically only used to non streaming DMA channels. MemoryXfer will block until the transfer has completed
	/// \param [in] Pointer to the buffer for use during the transfer
	/// \param [in] The local address on the FPGA
	/// \param [in] The size of the DMA transfer
	/// \param [in] The direction of the transfer. The DMA must support this direction of transfer.
	/// \param [in] Timeout for the request. Negative number represent Infinite timeout
	/// \return OT_Status_OK if the transfer occurred successfully.
	virtual OT_Status MemoryXfer(void *pBuffer,  ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, otDmaTiming *pTiming = 0, ot_int32_t timeout=OT_DMA_DEFAULT_TIMEOUT) = 0;

	/// MemoryXferSchedule, used to perform a DMA transfer. The call will return immediately with the transfer request beng queued to the underlying HW channel.
	/// \param [in] Pointer to the buffer for use during the transfer
	/// \param [in] The local address on the FPGA
	/// \param [in] The size of the DMA transfer
	/// \param [in] The direction of the transfer. The DMA must support this direction of transfer.
	/// \param [out] Returns Smart Pointer to a transfer request.
	/// \return OT_Status_OK if the transfer occurred successfully.
	virtual OT_Status MemoryXferSchedule( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer) = 0;

	/// MemoryXferSchedule2, used to perform a DMA transfer. The call will return immediately with the transfer request being queued to the underlying HW channel.
	/// \param [in] Pointer to the buffer for use during the transfer
	/// \param [in] The local address on the FPGA
	/// \param [in] The size of the DMA transfer
	/// \param [in] The direction of the transfer. The DMA must support this direction of transfer.
	/// \param [out] Returns Smart Pointer to a transfer request.
	/// \param [in] Whether to sync to this buffer to the hardware. In general this is true, set to false if
    ///             the DMA synchronises with video frame boundaries and this buffer is not aligned with such a boundary
	/// \return OT_Status_OK if the transfer occurred successfully.
	virtual OT_Status MemoryXferSchedule2( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer=true) = 0;

    /// MemoryXferSchedule3, used to perform a DMA transfer. The call will return immediately with the transfer request being queued to the underlying HW channel.
    /// \param [in] Smart Pointer with the transaction payload
    /// \param [in] The direction of the transfer. The DMA must support this direction of transfer.
    /// \param [out] Returns Smart Pointer to a transfer request.
    /// \return OT_Status_OK if the transfer occurred successfully.
	virtual OT_Status MemoryXferSchedule3( IDmaTransactionPtr spTransaction, bool bWrite, IDmaXferPtr *spDmaXfer ) = 0;

	/// Allocate a IDmaTransaction for use with MemoryXferSchedule3
	/// \return Smart Pointer to platform specific IDmaTransaction object
	virtual IDmaTransactionPtr AllocateDmaTransaction()  = 0;

	/// Is GPUDirect RDMA operation supported on this DMA Channel.
	/// \return True if GPUDirect RDMA is supported.
	virtual bool bIsGpuDirectSupported() = 0;

	/// MemoryXferScheduleGpuDirect, used to perform an RDMA transfer directly between the FPGA and GPU memory.
	/// The call will return immediately with the transfer request beng queued to the underlying HW channel.
	/// \param [in] Pointer to the buffer for use during the transfer. Must be a GPU buffer aligned on a 64KB boundary.
	/// \param [in] The local address on the FPGA
	/// \param [in] The size of the DMA transfer
	/// \param [in] The direction of the transfer. The DMA must support this direction of transfer.
	/// \param [out] Returns Smart Pointer to a transfer request.
	/// \param [in] Whether to sync to this buffer to the hardware. In general this is true, set to false if
    ///             the DMA synchronises with video frame boundaries and this buffer is not aligned with such a boundary
	/// \return OT_Status_OK if the transfer occurred successfully; OT_Status_Not_Implemented if GPUDirect RDMA is not supported
	virtual OT_Status MemoryXferScheduleGpuDirect( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer=true) = 0;

	/// Get the Event Interface
	/// \return Pointer to an IDmaEventPtr, NULL if Events are not supported by the DMA channel
	virtual IDmaEventPtr GetDmaEvent() = 0;

	/// Get the counts/second from the FPGA used for timing values
	/// \param Pointer to a struct to received the timing value. If the counter is not supported by the firmware then 0 is returned.
	/// \return OT_Status_Timing_Not_Implemented if the hardware doesn't implement the timing value.
	virtual OT_Status GetTimingFrequency( otTime &ticksPerSecond ) = 0;

	/// Get the current counter from the FPGA used for timing values
	/// \param Pointer to a struct to received the timing value. If the counter is not supported by the firmware then 0 is returned.
	/// \return OT_Status_Timing_Not_Implemented if the hardware doesn't implement the timing value.
	virtual OT_Status GetTimingCounter( otTime &ticks ) = 0;
};

/// \class IDmaEnumerator
/// \brief Exposes a class to find the available DMA channels in the FPGA 
class OMNITEK_INTERFACE_API IDmaEnumerator: public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~IDmaEnumerator(){}

	/// Get the total number of DMA channels available in the FPGA
	/// \return Number of available DMA channels
	virtual ot_int32_t		GetNumDmaChannels() = 0;

	/// Get the pointer to a DMA channel by index
	/// \param [in] Index of the required DMA channel
	/// \return If a DMA channel at Index is found then the pointer to the DMA chanenl is returned. Else a NULL pointer.
	virtual IDmaChannelPtr	GetDmaChannel(ot_int32_t index) = 0;

	/// Get the total number of DMA channels of a specific bit type
	/// \param [in] The Bit Field Idenifiter for the requested DMA channel
	/// \return Number of available DMA channels of specific type
	virtual ot_int32_t		GetNumDmaChannels(OT_DMA_Type_BitField bitField) = 0;

	/// Get the pointer to a DMA channel of a specific bitfield type and index
	/// \param [in] The Bit Field Idenifiter for the requested DMA channel
	/// \param [in] Index of the required DMA channel
	/// \return If a DMA channel at Index is found then the pointer to the DMA chanenl is returned. Else a NULL pointer.
	virtual IDmaChannelPtr	GetDmaChannel(OT_DMA_Type_BitField bitField, ot_int32_t index) = 0;

	/// Get the total number of DMA channels of a specific OT_DMA_Type
	/// \param [in] The OT_DMA_Type for the requested DMA channel
	/// \param [in] The direction of the requested DMA Channel
	/// \return Number of available DMA channels of specific type
	virtual ot_int32_t		GetNumDmaChannels(OT_DMA_Type type, OT_DMA_Direction direction) = 0;

	/// Get the pointer to a DMA channel of a specific OT_DMA_Type and index
	/// \param [in] The OT_DMA_Type for the requested DMA channel
	/// \param [in] The direction of the requested DMA Channel
	/// \param [in] Index of the required DMA channel
	/// \return If a DMA channel at Index is found then the pointer to the DMA chanenl is returned. Else a NULL pointer.
	virtual IDmaChannelPtr	GetDmaChannel(OT_DMA_Type type, OT_DMA_Direction direction, ot_int32_t index) = 0;
};
/// \brief Smart pointer implementation of an IDmaEnumerator
typedef ISmartPtr<IDmaEnumerator> IDmaEnumeratorPtr;

/// \class ICapabilityRegions
/// \brief This class exposes read access to the regions of memory which contain the FPGA capability structures
class OMNITEK_INTERFACE_API ICapabilityRegions: public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly
	virtual ~ICapabilityRegions() {}

	/// Get the total number of Capability Regions
	/// \return Number of capability regions
	virtual ot_int32_t		GetNumRegions() = 0;

	/// Get the size of Capability Region
	/// \param [in] The index of the capability region
	/// \return The size of the capability region.
	virtual ot_uint32_t		GetRegionSize( ot_int32_t idx) = 0;

	/// Read the Capability to a buffer
	/// \param [in] The index of the capability region
	/// \param [in] A pointer to copy the region into
	/// \param [in] Size of the copy buffer
	/// \param [in] Offset of the region to copy
	/// \return OT_Status_OK if region read successfully
	virtual OT_Status ReadRegion(ot_int32_t idx, void* pBuffer, ot_uint32_t bufferSize, ot_uint32_t offset) = 0;
};
/// \brief Smart pointer implementation of an ICapabilityRegions
typedef ISmartPtr<ICapabilityRegions> ICapabilityRegionsPtr;

/// \brief This class exposes an interface to access the Platform the FPGA is running on.
class OMNITEK_INTERFACE_API IPlatformInfo : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly
	virtual ~IPlatformInfo() {}

	/// Get the platform interface for the FPGA
	/// \return Platform Interface.
	virtual OT_PLATFORM_INTERFACE GetPlatformInterface() = 0;

	/// Get the PCIe Information
	/// \param [out] PCIe Generation
	/// \param [out] PCIe Lanes
	/// \return OT_Status_OK if the PCIe is valid
	virtual OT_Status GetPCIeInfo(ot_uint32_t &gen, ot_uint32_t &lanes) = 0;

	/// Read Pci Config
	/// \param [in] Read PCI Config at offset
	/// \param [in] Read size
	/// \param [out] Buffer for the read
	/// \return Number of bytes read
	virtual ot_uint32_t ReadPciConfig(void *pBuffer, unsigned char offset, unsigned char readSize) = 0;
};
/// \brief Smart pointer implementation of an IPlatformInfo
typedef ISmartPtr<IPlatformInfo> IPlatformInfoPtr;

/// \brief This class exposes access to underlying FPGA functionality.
/// Initially all FPGAs will be exposed as IBoardPtr and IFpgaPtr pair, even if the FPGA exists on the same physical board.
class OMNITEK_INTERFACE_API IFpga : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~IFpga() {}

	/// Get a pointer to an ICapabilityEnumerator so that you can discover the available FPGA capabilities
	/// \return Smart Pointer to an ICapabiltyEnumerator, NULL if no enumerator exists.
	virtual ICapabilityEnumeratorPtr	GetCapabilities() = 0;

	/// Get a pointer to an IDmaEnumerator so that you can discover the available DMA channels
	/// \return Smart Pointer to an IDmaEnumerator, NULL if no enumerator exists
	virtual IDmaEnumeratorPtr			GetDmaChannels() = 0;

	/// Get a pointer to the Capability Regions. Used for Capability diagnostics only
	/// \return Smart Pointer to an ICapabilityRegions, NULL if no Capability Regions exists
	virtual ICapabilityRegionsPtr		GetCapabilityRegions() = 0;
	
	/// Get a pointer to a Platform Info. Used to display information about the platform the FPGA is running on. eg: PCIe or SOC
	virtual IPlatformInfoPtr			GetPlatformInfo() = 0;

	/// Get the counts/second from the FPGA used for timing values
	/// \param Pointer to a struct to received the timing value. If the counter is not supported by the firmware then 0 is returned.
	/// \return OT_Status_Timing_Not_Implemented if the hardware doesn't implement the timing value.
	virtual OT_Status GetTimingFrequency( otTime &ticksPerSecond ) = 0;

	/// Get the current counter from the FPGA used for timing values
	/// \param Pointer to a struct to received the timing value. If the counter is not supported by the firmware then 0 is returned.
	/// \return OT_Status_Timing_Not_Implemented if the hardware doesn't implement the timing value.
	virtual OT_Status GetTimingCounter( otTime &ticks ) = 0;

	/// Get the Parent Board
	/// \return smart pointer to the parent board
	virtual IBoardPtr GetParentBoard() = 0;

};

/// \brief This class exposes access to available FPGAs on a board.
/// \para Initially all FPGAs will be exposed as IBoardPtr and IFpgaPtr pair, even if the FPGA exists on the same physical board.
class OMNITEK_INTERFACE_API IBoard : public ISmartBasePtr
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~IBoard(){}

	/// Gets the number of available FPGAs on the board.
	/// \return Number of FPGAs.
	virtual ot_int32_t						GetNumFPGAs() = 0;

	/// Gets the pointer to an IFpga instance.
	/// \param instance Required instance number
	/// \return Pointer to an IFpgaPtr, NULL if instance does not exits
	virtual IFpgaPtr				GetFPGA(ot_int32_t instance) = 0;

	/// Gets the instance number of the board.
	/// \return The instance number of the board assigned by the Interface.
	virtual ot_int32_t						GetBoardInstance() = 0;

	/// Get the GUID type of the board.
	/// \return GUID type of the board.
	virtual otGUID					GetBoardType() = 0;

	/// Get the name of the board assigned by the driver
	/// \return NULL terminated string.
	virtual const char*				GetBoardName() = 0;
	
	/// Get the Manufacture name of the board.
	/// \return NULL terminated string.
	virtual const char*				GetManufacturer() = 0;

	/// Get the Version number of the driver associated with the board
	/// \return NULL terminated string.
	virtual const char*				GetVersionStr() = 0;

	/// Get the pointer to the IFpgaFactory
	/// \return the pointer to the IFpgaFactory managing the board.
	virtual IFpgaFactory*			GetApi() = 0;
};
 
/// \brief This class exposes an interface to discover boards and fpgas being managed by the Interface library.
 class OMNITEK_INTERFACE_API IFpgaFactory
{
public:
	/// Implement a virtual destructor to make sure that the internal implementation is cleaned up correctly.
	virtual ~IFpgaFactory() {}

	/// Test to check that all Smart Pointers to objects have been released.
	/// \return True if all the ISmartPtr smart pointers to objects have been released.
	/// \warning Until all the smart pointers to objects have been released, deletion of the API will fail.
	virtual bool				bSafeToRelease() = 0;

	/// The build version number of the Interface library.
	/// \return Pointer to an ascii string containing the version number of Interface library
	virtual const char*			GetVersionString()		= 0;

	/// The number of boards being managed by the Interface library.
	///\return Number of Boards found by the Interfacce library.
	virtual ot_int32_t					GetBoardCount()			= 0;

	/// Get an instance of a board being managed by the Interface library.
	/// \return Smart Pointer to an IBoard, NULL means board instance does not exist.
	virtual IBoardPtr			GetBoard(ot_int32_t instance)	= 0;

/*	virtual ot_int32_t					GetBoardCount(otGUID type) = 0;
	virtual IBoardPtr			GetBoard(otGUID type, ot_int32_t instance) = 0;*/
};

/// Creates an Interface to discovery and interact with FPGAs being managed by the 
/// Interface library.
/// \return Pointer to a IFpgaFactory, NULL if the Interface failed to create.
extern "C" OMNITEK_INTERFACE_API IFpgaFactory*		OT_InitializeFactory();

/// Shutdown the Interface managing the FPGAs. 
/// \param pFpgaFactory Pointer to an IFpgaFactory which was previously created with OT_InitializeFactory.
/// \return OT_Status_OK if the IFpgaFactory could be shutdown successfully.
/// If all the reference have not been released on all objects then OT_Status_Not_All_Children_Released will be returned and the
/// IFpgaFactory will not be deleted.
extern "C" OMNITEK_INTERFACE_API OT_Status	OT_TerminateFactory(IFpgaFactory *pFpgaFactory);

/// Typedef for OT_InitializeFactory, to make it easier to use as a plugin
/// \return See OT_InitializeFactory
typedef IFpgaFactory* (*OT_InitializeFactory_t)();

/// Typedef for OT_TerminateFactory, to make it easier to use as a plugin
/// \return See OT_TerminateFactory
typedef OT_Status (*OT_TerminateFactory_t)(OmniTek::IFpgaFactory *pFpgaFactory);

/// \brief Wrapper struct for the OmniTek API, to make it easier to use as a plugin
struct OT_API
{
    /// See OT_InitializeFactory
    OT_InitializeFactory_t InitializeFactory;
    /// See OT_TerminateFactory
    OT_TerminateFactory_t TerminateFactory;

    OT_API() : InitializeFactory(0), TerminateFactory(0) {}
};

}

