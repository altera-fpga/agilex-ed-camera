/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "StdAfx.h"
#include "PlatformRegisterCapability.h"
#include "capability/RegisterAccess_IOCTL.h"
#include "IOmniTekTypes.h"
#include <poll.h>

////////////////////////////////////////////////////////////////////////////////
PlatformIoDevice::PlatformIoDevice(const char *path)
	: _hDev(-1)
{
	// OK let's open this capability
	_hDev = open(path, O_RDWR);
}

PlatformIoDevice::~PlatformIoDevice()
{
	Close();
}

void PlatformIoDevice::Close()
{
	if( _hDev > -1 )
		close(_hDev);
	_hDev = -1;
}

bool PlatformIoDevice::bIsValid()
{
	return (_hDev > -1);
}

HANDLE PlatformIoDevice::GetFileHandle()
{
	return _hDev;
}

unsigned int PlatformIoDevice::SendTransaction(IoTransaction *pTransaction)
{
	unsigned int result;
	result = ioctl(_hDev, pTransaction->GetIoctlNum(), pTransaction->GetIoctl());
	return result;
}

unsigned int PlatformIoDevice::GetTransactionResult(IoTransaction *pTransaction)
{
	return 0;
}

OT_Status PlatformIoDevice::CancelTransaction(IoOverlappedTransactionBase *pTransaction)
{
	int ioctlVal = 0;
	OT_Status status = OT_Status_OK;

	CapGeneral_Cancel_IOCTL Cancel_IOCTL;
	INIT_IOCTL(&Cancel_IOCTL, CAP_COMMON_IOCTL_Cancel_Version, sizeof(Cancel_IOCTL));

	Cancel_IOCTL.EventInfo = *(pTransaction->GetEventIoctlCtx());

	ioctlVal = ioctl( _hDev, CAP_COMMON_IOCTL_Cancel, &Cancel_IOCTL );
	if( ioctlVal != 0 )
		status = OT_Status_Fail;

	return status;
}

OT_Status PlatformIoDevice::ScheduleTransaction(IoOverlappedTransactionBase *pTransaction)
{
	int iocltVal = 0;
	OT_Status status = OT_Status_Fail;

	iocltVal = ioctl(_hDev, pTransaction->GetIoctlNum(), pTransaction->GetIoctl());
	if( iocltVal == 0 )
		status = OT_Status_Request_Pending;

	return status;
}

OT_Status PlatformIoDevice::WaitForTransaction(IoOverlappedTransactionBase *pTransaction, ot_int32_t msTimeout)
{
	struct pollfd fds;
	int selectret;
	CapGeneral_EventCtx_IOCTL *pEventIoctl = pTransaction->GetEventIoctlCtx();

	int eventfd = pEventIoctl->EventFD;
	if( eventfd < 0 )
		return OT_Status_Fail;

	// Setup a wait object
	fds.fd = eventfd;
	fds.revents = 0;
	fds.events = POLLIN;

    selectret = poll(&fds, 1, (msTimeout < 0) ? -1 : msTimeout);
    if( selectret == -1 )
    {
        perror( "select failed");
        return OT_Status_Request_Failed;
    }
    else if( selectret == 0 )
    {
    	CancelTransaction(pTransaction);
        return OT_Status_Request_Timeout;
    }

   	return OT_Status_OK;
}
