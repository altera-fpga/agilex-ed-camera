/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
typedef enum
{
	OFC_InterruptCap = 0xff,
    OFC_RegisterCap = 0xfe,
    OFC_OffsetCap = 0xfd,
    OFC_MemMapCap = 0xfc,
    OFC_GroupingCap = 0xfb,
}OMNITEK_FPGA_CAPABILITY_TYPE;
