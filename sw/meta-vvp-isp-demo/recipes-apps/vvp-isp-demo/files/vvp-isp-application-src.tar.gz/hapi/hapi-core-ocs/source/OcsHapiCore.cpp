/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#include "OcsHapiCore.h"
#include "IpCapabilityNames.h"
#include "OcsHapiItemTunnel.h"
#include <sstream>
#include <iomanip>
#include <vector>
#include "HapiOCS.h"

namespace Hapi
{
    static constexpr DriverFrameworkType frameworkType = DriverFrameworkType::OCS;

    std::shared_ptr<IHapi> IHapiOCS::Create(uint32_t boardIndex,
                                            uint32_t fpgaIndex,
                                            bool testDmaChannels)
    {
        std::shared_ptr<IHapi> spIHapi;

        // Have we got an IHapi for this framework type?
        auto matches = _wpHapiCoreInstances.equal_range(frameworkType);

        for(auto i = matches.first; i != matches.second; ++i)
        {
            std::shared_ptr<OcsHapiCore> spOcsHapi = std::dynamic_pointer_cast<OcsHapiCore>(i->second.lock());

            if(spOcsHapi)
            {
                if((spOcsHapi->GetBoardIndex() == boardIndex) and (spOcsHapi->GetFpgaIndex() == fpgaIndex))
                {
                    spIHapi = spOcsHapi;
                }
            }
        }

        if (!spIHapi)
        {
            spIHapi = std::shared_ptr<IHapi>(new OcsHapiCore(boardIndex, fpgaIndex, testDmaChannels));
            _wpHapiCoreInstances.insert({frameworkType, spIHapi});
        }        

        return spIHapi;
    }

    OcsHapiCore::OcsHapiCore(uint32_t boardIndex,
                             uint32_t fpgaIndex,
                             bool testDmaChannels)
    :   HapiCore{frameworkType},
        _boardIndex{boardIndex},
        _fpgaIndex{fpgaIndex}
    {
        _pFpgaFactory = OmniTek::OT_InitializeFactory();
        if (_pFpgaFactory)
        {
            uint32_t num_boards = _pFpgaFactory->GetBoardCount();
            if (_boardIndex < num_boards)
            {
                auto board = _pFpgaFactory->GetBoard(_boardIndex);
                uint32_t num_fpgas = board->GetNumFPGAs();

                if (_fpgaIndex < num_fpgas)
                {
                    _spFpga = board->GetFPGA(_fpgaIndex);
                    FindDmaChannels(testDmaChannels);
                }
            }
        }
    }

    OcsHapiCore::~OcsHapiCore()
    {
        _spMdma = nullptr;
        _spInputFdma = nullptr;
        _spOutputFdma = nullptr;
        _spVideoInputFdma = nullptr;
        _spVideoOutputFdma = nullptr;
        _spFpga = nullptr;
        if (_pFpgaFactory)
        {
            OmniTek::OT_Status status = OmniTek::OT_TerminateFactory(_pFpgaFactory);
            (void)status;
        }
    }

    bool OcsHapiCore::ValidHardware()
    {
        return (_spFpga != nullptr);
    }

    void OcsHapiCore::FindDmaChannels(bool testDmaChannels)
    {
        if (not _spFpga)
            return;

        std::stringstream ss;

        // Find DMA channels
        auto spDmas = _spFpga->GetDmaChannels();
        if (spDmas)
        {
            uint32_t nChannelsFound = spDmas->GetNumDmaChannels();
            ss << "Number of DMA channels: " << nChannelsFound << '\n';

            for (uint32_t c = 0; c < nChannelsFound; c++)
            {
                OmniTek::IDmaChannelPtr spDmaChannel = spDmas->GetDmaChannel(c);
                if (not spDmaChannel)
                    continue;

                OmniTek::OT_DMA_Type dmaType = spDmaChannel->GetType();
                OmniTek::OT_DMA_Direction direction = spDmaChannel->GetDirection();
                OmniTek::OT_DMA_ContentType contentType = spDmaChannel->GetContentType();

                std::string dma_type_str;
                if (dmaType == OmniTek::OT_DMA_Type_MDMA)
                    dma_type_str = "MDMA";
                else if (dmaType == OmniTek::OT_DMA_Type_FDMA)
                    dma_type_str = "FDMA";
                else if (dmaType == OmniTek::OT_DMA_Type_Target)
                    dma_type_str = "Target";
                else if (dmaType == OmniTek::OT_DMA_Type_Peer)
                    dma_type_str = "Peer";

                std::string dma_direction_str;
                if (direction == OmniTek::OT_DMA_Direction_Input)
                    dma_direction_str = "Input";
                else if (direction == OmniTek::OT_DMA_Direction_Output)
                    dma_direction_str = "Output";
                else if (direction == OmniTek::OT_DMA_Direction_BiDirectional)
                    dma_direction_str = "BiDirectional";

                std::string content_type_str;
                if (contentType == OmniTek::OT_DMA_ContentType_Data)
                    content_type_str = "Data";
                else if (contentType == OmniTek::OT_DMA_ContentType_Video)
                    content_type_str = "Video";
                else if (contentType == OmniTek::OT_DMA_ContentType_Audio)
                    content_type_str = "Audio";
                else if (contentType == OmniTek::OT_DMA_ContentType_Packet)
                    content_type_str = "Packet";

                uint32_t dmaUniqueId = spDmaChannel->GetCapability()->GetUniqueID();

                OmniTek::IRegisterBlockPtr spRegisterBlock = spDmaChannel->GetCapability()->GetRegisterBlock(0);
                uint64_t physicalAddress = spRegisterBlock ? spRegisterBlock->GetPhysicalAddress() : 0;

                auto spDmaCapability = spDmaChannel->GetCapability();
                uint32_t numInterruptBits = spDmaCapability ? spDmaCapability->GetNumInterruptBits() : 0;

                ss.fill('0');
                ss << "DMA ch[" << c << "] type = " << dma_type_str <<
                             ", dir = " << dma_direction_str <<
                             ", content = " << content_type_str <<
                             ", unique_id = 0x" << std::hex << dmaUniqueId <<
                             ", phys addr = 0x" << std::hex << std::setw(8) << (uint32_t)physicalAddress <<
                             ", num_interrupt_bits = " << std::dec << numInterruptBits <<
                             '\n';
            }

            _spVideoInputFdma = spDmas->GetDmaChannel(OmniTek::OT_DMA_VIDEO_FDMA_IN, 0);
            _spVideoOutputFdma = spDmas->GetDmaChannel(OmniTek::OT_DMA_VIDEO_FDMA_OUT, 0);

            _spInputFdma = spDmas->GetDmaChannel(OmniTek::OT_DMA_PACKET_FDMA_IN, 0);
            if (not _spInputFdma)
                _spInputFdma = spDmas->GetDmaChannel(OmniTek::OT_DMA_META_FDMA_IN, 0);

            _spOutputFdma = spDmas->GetDmaChannel(OmniTek::OT_DMA_META_FDMA_OUT, 0);
            if (not _spOutputFdma)
                _spOutputFdma = spDmas->GetDmaChannel(OmniTek::OT_DMA_PACKET_FDMA_OUT, 0);

            _spMdma = spDmas->GetDmaChannel(OmniTek::OT_DMA_MDMA, 0);

            if (testDmaChannels and _spMdma)
            {
                if (not TestMdmaChannel(_spMdma, 4096, 3))
                    ss << "MDMA transfer test failed\n";
            }

            if (_isWindows)
            {
                DisableDmaSyncControl(_spVideoInputFdma);
                DisableDmaSyncControl(_spVideoOutputFdma);
                DisableDmaSyncControl(_spInputFdma);
                DisableDmaSyncControl(_spOutputFdma);
                DisableDmaSyncControl(_spMdma);
            }

            std::cout << ss.str();
        }
    }

    bool OcsHapiCore::TestMdmaChannel(OmniTek::IDmaChannelPtr spMdma, size_t testSize, size_t nTests)
    {
        std::vector<uint8_t> uploadBuffer(testSize);
        std::vector<uint8_t> downloadBuffer(testSize);

        uint8_t* pUploadBuffer = uploadBuffer.data();
        uint8_t* pDownloadBuffer = downloadBuffer.data();

        for (size_t test = 0; test < nTests; test++)
        {
            for (size_t i = 0; i < testSize; i++)
                pUploadBuffer[i] = (uint8_t)(i * (3 + test));

            if (spMdma->MemoryXfer(pUploadBuffer, 0, static_cast<OmniTek::ot_uint32_t>(testSize), true) != OmniTek::OT_Status_OK)
                return false;

            if (spMdma->MemoryXfer(pDownloadBuffer, 0, static_cast<OmniTek::ot_uint32_t>(testSize), false) != OmniTek::OT_Status_OK)
                return false;

            if (uploadBuffer != downloadBuffer)
                return false;
        }

        return true;
    }

    void OcsHapiCore::DisableDmaSyncControl(OmniTek::IDmaChannelPtr& spDmaChannel)
    {
        if (spDmaChannel and _isWindows)
        {
            // Need to disable the Sync Control.
            // NOTE: The Linux driver does this automatically
            OmniTek::ot_uint32_t regval;
            spDmaChannel->GetCapability()->GetRegisterBlock(0)->ReadRegister((OmniTek::ot_uint32_t)DmaRegister::CSR, regval);
            regval |= (OmniTek::ot_uint32_t)CSRegisterterFlags::DisableSyncControl;
            spDmaChannel->GetCapability()->GetRegisterBlock(0)->WriteRegister((OmniTek::ot_uint32_t)DmaRegister::CSR, regval);
        }
    }

    // void OcsHapiCore::AddMockCapability(FPGA_CAPABILITY type,
    //                                  const std::unordered_map<uint32_t, uint32_t>& regValues)
    // {
    //     auto spCaps = _spFpga->GetCapabilities();
    //     MockCapabilities* pMockCaps = dynamic_cast<MockCapabilities*>(spCaps._Get());
    //     if (pMockCaps)
    //     {
    //         pMockCaps->AddMockCapability(type, regValues);
    //     }
    // }

    OmniTek::ICapabilityPtr OcsHapiCore::FindCapabilityByIndex(HapiItemBase* pHapiItem, uint32_t index)
    {
        if (_spFpga and (pHapiItem != nullptr))
        {
            auto spCapabilities = _spFpga->GetCapabilities();
            if (spCapabilities)
            {
                HapiItemIdentifier* itemID = pHapiItem->GetIpCoreItemIdentifier(GetDriverFrameworkType());

                if(itemID)
                {
                    FPGA_CAPABILITY capabilityType = itemID->_ocsID._ocsCapabilityID;

                    auto spCapability = spCapabilities->GetCapability((uint32_t)capabilityType, index);

                    if (spCapability)
                        return spCapability;
                }
            }
        }

        return nullptr;
    }

    OmniTek::ICapabilityPtr OcsHapiCore::FindCapabilityByUniqueID(HapiItemBase* pHapiItem, uint32_t unique_id)
    {
        if (_spFpga and (pHapiItem != nullptr))
        {
            auto spCapabilities = _spFpga->GetCapabilities();
            if (spCapabilities)
            {
                HapiItemIdentifier* itemID = pHapiItem->GetIpCoreItemIdentifier(GetDriverFrameworkType());

                if(itemID)
                {
                    FPGA_CAPABILITY capabilityType = itemID->_ocsID._ocsCapabilityID;
                    auto spCapability = spCapabilities->GetCapabilityByUniqueId((uint32_t)capabilityType, unique_id);

                    if (spCapability)
                        return spCapability;
                }
            }
        }

        return nullptr;
    }

    OmniTek::ICapabilityPtr OcsHapiCore::FindCapabilityByAssociatedID(HapiItemBase* pHapiItem, uint32_t associated_id)
    {
        if (_spFpga and (pHapiItem != nullptr))
        {
            auto spCapabilities = _spFpga->GetCapabilities();
            if (spCapabilities)
            {
                HapiItemIdentifier* itemID = pHapiItem->GetIpCoreItemIdentifier(GetDriverFrameworkType());

                if(itemID)
                {
                    FPGA_CAPABILITY capabilityType = itemID->_ocsID._ocsCapabilityID;

                    for (int i = 0, n = spCapabilities->GetNumCapabilities(); i < n; i++)
                    {
                        auto spCapability = spCapabilities->GetCapability(i);

                        if ((spCapability->GetType() == (uint32_t)capabilityType) and
                            (spCapability->GetAssociatedID() == associated_id))
                        {
                            return spCapability;
                        }
                    }
                }
            }
        }

        return nullptr;
    }

    OmniTek::ICapabilityPtr OcsHapiCore::FindCapabilityByType(uint32_t type, uint32_t index)
    {
        if (_spFpga)
        {
            auto spCapabilities = _spFpga->GetCapabilities();
            return spCapabilities->GetCapability(type, index);
        }

        return nullptr;
    }

    OmniTek::ICapabilityPtr OcsHapiCore::FindCapabilityByIndex(uint32_t index)
    {
        if (_spFpga)
        {
            auto spCapabilities = _spFpga->GetCapabilities();
            return spCapabilities->GetCapability((OmniTek::ot_int32_t)index);
        }

        return nullptr;
    }

    bool OcsHapiCore::InitializeHapiItem(HapiItemBase* pHapiItem, OmniTek::ICapabilityPtr spCapability)
    {
        if (not pHapiItem)
            return false;

        std::shared_ptr<HapiCore> p_me = shared_from_this();
        std::weak_ptr<HapiCore> wp_me = p_me;

        // Already initialized?
        if (pHapiItem->_spTunnel)
            return false;

        auto spOcsHapiItemTunnel = std::make_shared<OcsHapiItemTunnel>();
        pHapiItem->_spTunnel = spOcsHapiItemTunnel;

        HapiItemIdentifier* ipCoreItemID = pHapiItem->GetIpCoreItemIdentifier(GetDriverFrameworkType());
        HapiItemIdentifier* driverItemID = pHapiItem->GetIpCoreItemIdentifier(GetDriverFrameworkType());

        if (!ipCoreItemID or !driverItemID)
        {
            std::cout << "Can't initialize HapiItem with OCS HapiCore.\n";
            std::cout << "No valid OCS ID has been found. Use a HapiCore with the relevant DriverFrameworkType\n"
                         "or change the last template parameter for your HAPI class definition to contain an OCS FPGA_CAPABILITY\n";
            return false;
        }

        if (!spCapability)
            return false;

        spOcsHapiItemTunnel->_spCapability = spCapability;
        ipCoreItemID->_ocsID._capabilityIndex = GetIndexOfCapability(spCapability);
        ipCoreItemID->_ocsID._capabilityAssociatedID = spCapability->GetAssociatedID();
        ipCoreItemID->_ocsID._capabilityUniqueID = spCapability->GetUniqueID();

        // Copy to the driver ID too
        driverItemID->_ocsID._capabilityIndex = ipCoreItemID->_ocsID._capabilityIndex;
        driverItemID->_ocsID._capabilityAssociatedID = ipCoreItemID->_ocsID._capabilityAssociatedID;
        driverItemID->_ocsID._capabilityUniqueID = ipCoreItemID->_ocsID._capabilityUniqueID;

        spOcsHapiItemTunnel->_spRegisterBlock = spCapability->GetRegisterBlock(0);
        if (spOcsHapiItemTunnel->_spRegisterBlock)
            pHapiItem->_registerPhysicalAddress = spOcsHapiItemTunnel->_spRegisterBlock->GetPhysicalAddress();

        // If you override Initialize, you can access pHapiItem->_spDetails,
        // dynamic cast it to OcsHapiItemDetails, and get access to the capability
        pHapiItem->Initialize(wp_me);

        // Call the C instance initializer
        if (not pHapiItem->InitializeInstance())
            return false;

        // Cache this item if a request for the same spCapability come in
        pHapiItem->AddToActiveHapiItems(*driverItemID);
        return true;
    }

    bool OcsHapiCore::InitializeByIndex(HapiItemBase* pHapiItem, uint32_t index)
    {
        if (pHapiItem == nullptr)
            return false;

        auto spCapability = FindCapabilityByIndex(pHapiItem, index);

        if(spCapability == nullptr)
            return false;

        return InitializeHapiItem(pHapiItem, spCapability);
    }

    bool OcsHapiCore::InitializeByUniqueID(HapiItemBase* pHapiItem, uint32_t unique_id)
    {
        if (pHapiItem == nullptr)
            return false;

        auto spCapability = FindCapabilityByUniqueID(pHapiItem, unique_id);

        if(spCapability == nullptr)
            return false;

        return InitializeHapiItem(pHapiItem, spCapability);
    }

    bool OcsHapiCore::InitializeByAssociatedID(HapiItemBase* pHapiItem, uint32_t unique_id)
    {
        if (pHapiItem == nullptr)
            return false;

        auto spCapability = FindCapabilityByAssociatedID(pHapiItem, unique_id);

        if(spCapability == nullptr)
            return false;

        return InitializeHapiItem(pHapiItem, spCapability);
    }


    void OcsHapiCore::LogDevices()
    {
        if (not _spFpga)
            return;

        auto spCapabilities = _spFpga->GetCapabilities();

        std::stringstream ss;

        if (spCapabilities)
        {
            int n = spCapabilities->GetNumCapabilities();
            ss << "Number of device spCapabilities: " << n << '\n';

            for (int i = 0; i < n; i++)
            {
                auto spCapability = spCapabilities->GetCapability(i);

                uint32_t type = spCapability->GetType();
                int32_t num_register_blocks = spCapability->GetNumRegisterBlocks();
                int32_t unique_id = spCapability->GetUniqueID();
                uint32_t associated_id = spCapability->GetAssociatedID();
                int32_t version = spCapability->GetVersion();
                bool interrupts_supported = (spCapability->GetIsInterruptSupported() == OmniTek::OT_Status::OT_Status_OK);
                (void)interrupts_supported;
                std::string friendlyName;
                auto pos = capabilityNames.find(type);
                if (pos != capabilityNames.end())
                    friendlyName = pos->second;
                else
                    friendlyName = "[no name]";

                uint64_t register_address = 0;
                auto register_block_0 = spCapability->GetRegisterBlock(0);
                if (register_block_0)
                {
                    register_address = register_block_0->GetPhysicalAddress();

                    ss << "[" << i << "]\t";
                    ss << " type = 0x" << std::hex << type;
                    ss << "\t" << friendlyName;
                    ss << ", unique_id = 0x" << std::hex << unique_id;
                    ss << ", associated_id = 0x" << std::hex << associated_id;
                    ss << ", version = " << std::dec << version;
                    ss << ", n_registers = " << num_register_blocks;
                    ss << ", physicalAddress = 0x" << std::hex << (uint32_t)register_address << '\n';
                }
                else
                {
                    ss << "[" << i << "]";
                    ss << " type = 0x" << std::hex << type;
                    ss << ", unique_id = 0x" << std::hex << unique_id;
                    ss << ", associated_id = 0x" << std::hex << associated_id;
                    ss << ", version = " << std::dec << version << '\n';
                }
            }
        }

        OmniTek::IPlatformInfoPtr platform_info = _spFpga->GetPlatformInfo();
        OmniTek::ot_uint32_t gen = 0;
        OmniTek::ot_uint32_t lanes = 0;
        if (platform_info)
        {
            platform_info->GetPCIeInfo(gen, lanes);
            ss << "PCIe generation: " << gen << '\n';
            ss << "PCIe lanes: " << lanes << '\n';
        }

        std::cout << ss.str();
    }

    uint32_t OcsHapiCore::GetIndexOfCapability(OmniTek::ICapabilityPtr& spCapability)
    {
        uint32_t index = 0;
        auto spCapabilities = spCapability->GetParentFpga()->GetCapabilities();
        if (spCapabilities)
        {
            uint32_t capabilityType = spCapability->GetType();

            while (true)
            {
                auto spNextCapability = spCapabilities->GetCapability((uint32_t)capabilityType, index);
                if (not spNextCapability)
                    return 0;

                if ((OmniTek::ICapability*)spNextCapability == (OmniTek::ICapability*)spCapability)
                    return index;

                index++;
            }
        }

        return 0;
    }

} // namespace Hapi
