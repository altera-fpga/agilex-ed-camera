/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include <list>
#include <string>
#include "ImpCapability.h"
#include "ImpDmaChannel.h"

#include "ImpOmniTekPtr.h"
#include "ImpFpga.h"

#include "InternalFpgaCreator.h"

typedef std::vector<IFpgaPtr>	omFpgaPtrList;

class OmniTekApi;
class ImpBoard :
	public IBoard,
	public ImpOmniTekBasePtr,
	public OTParentTracker
{
public:
	ImpBoard(ot_int32_t instance, IFpgaFactory *pParent);
	virtual ~ImpBoard(void);

	virtual ot_int32_t				GetNumFPGAs();
	virtual IFpgaPtr		GetFPGA(ot_int32_t instance);

	virtual ot_int32_t				GetBoardInstance();

	virtual const char*		GetBoardName(){return _name;};
	virtual const char*		GetManufacturer() {return _manufacturer;};
	virtual const char*		GetVersionStr() {return _version;};
	virtual otGUID			GetBoardType() {return _type;};

	virtual IFpgaFactory*				GetApi();

	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR

	// Implementation functions to allow Childern to reference count themselves to this Object
	virtual void AddParentRef();
	virtual void ReleaseParentRef();
	virtual bool bSafeToRelease();

	void	AddFpga(const OTBus_SlotInfo *pSlotInfo, const InternalFpgaCreator& fpgaCreator);
private:
	char		_name[256];
	char		_manufacturer[100];
	char		_version[100];

	ot_int32_t		_instance;
	IFpgaFactory*	_pParent;
	otGUID			_type;

	// Smart pointer list of available Fpgas on the board
	omFpgaPtrList					_fpgaPtrList;
	
	// Reference count to be used by the OTParentTracker
	RefCounter	_parentRefCounter;
};
