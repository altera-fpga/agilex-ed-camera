/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
#include "InternalCapabilityFactory.h"
#include "InternalDmaBase.h"
#include <map>
#include <memory>

#include "EAutoLock.h"

using namespace OmniTek;

typedef std::multimap<OT_DMA_Type, IDmaChannelPtr> OmDmaMultiMapByDmaType;
typedef std::pair<OmDmaMultiMapByDmaType::iterator, OmDmaMultiMapByDmaType::iterator> OmDmaPairIterator;

class ImpDmaEnumerator : public InternalDmaEnumerator
{
public:
	ImpDmaEnumerator(OTParentTracker *pParentTracker, std::shared_ptr<InternalDmaChannelFactory> spChannelFactory);
	virtual ~ImpDmaEnumerator(void);

	// IDmaEnumerator Interface Functions
	virtual ot_int32_t	GetNumDmaChannels();
	virtual ot_int32_t	GetNumDmaChannels(OT_DMA_Type_BitField type);

	virtual IDmaChannelPtr GetDmaChannel(ot_int32_t index);
	virtual IDmaChannelPtr GetDmaChannel(OT_DMA_Type_BitField type, ot_int32_t index);	

	virtual ot_int32_t		GetNumDmaChannels(OT_DMA_Type type, OT_DMA_Direction direction);
	virtual IDmaChannelPtr	GetDmaChannel(OT_DMA_Type type, OT_DMA_Direction direction, ot_int32_t index);

	// Internal implementation functions (InternalDmaEnumerator)
	bool	AddCapability(InternalCapability *pCapability);
private:
	OmDmaPairIterator GetDmaChannelsIterator(OT_DMA_Type type);
	OmDmaMultiMapByDmaType	_channelsByType;
	std::shared_ptr<InternalDmaChannelFactory> _spChannelFactory;
};

