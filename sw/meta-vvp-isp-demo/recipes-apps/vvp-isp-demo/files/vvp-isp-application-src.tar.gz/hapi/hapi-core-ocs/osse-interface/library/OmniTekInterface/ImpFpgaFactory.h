/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "LocalCommon.h"
#include "BusEnumerator.h"
#include "InternalFpgaCreator.h"

#include <vector>
using namespace std;
using namespace OmniTek;

typedef std::vector<IBoardPtr> BoardImpList;

class ImpFpgaFactory :
	public IFpgaFactory
{
public:
	ImpFpgaFactory(BusEnumerator& busEnum, const InternalFpgaCreator& fpgaCreator);
	virtual ~ImpFpgaFactory(void);

	virtual bool	bSafeToRelease();

	virtual ot_int32_t GetBoardCount()		{return (ot_int32_t)_boards.size();};
	virtual IBoardPtr				GetBoard(ot_int32_t instance);
	virtual const char*				GetVersionString();

	virtual ot_int32_t						GetBoardCount(otGUID type);
	virtual IBoardPtr				GetBoard(otGUID type, ot_int32_t instance);

private:
	BoardImpList	_boards;

	char		_versionNumber[100];
};
