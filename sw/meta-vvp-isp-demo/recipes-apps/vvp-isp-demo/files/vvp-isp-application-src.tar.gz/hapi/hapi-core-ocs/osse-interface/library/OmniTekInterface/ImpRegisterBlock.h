/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
using namespace OmniTek;
#include "InternalRegisterCapability.h"

#include <vector>
class InternalCapability;
class ImpRegisterBlock : public IRegisterBlock, public ImpOmniTekBasePtr
{
public:
	ImpRegisterBlock(InternalCapability *pCapability, InternalRegisterCapability *pCap, ot_uint32_t blkNum, ot_uint32_t numReg);
	virtual ~ImpRegisterBlock();

	virtual ot_int32_t		GetNumRegisters();

	virtual bool	ReadRegister(ot_int32_t regNum, ot_uint32_t &result);
	virtual bool	ReadShadowRegister(ot_int32_t regNum, ot_uint32_t &result);
	virtual bool	WriteRegister(ot_int32_t regNum, ot_uint32_t value);
	virtual ICapabilityPtr GetParentCapability() {return _pCapability;};
	virtual ot_uint64_t	GetPhysicalAddress();

	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR
private:
	ot_uint32_t				_blkNum;
	ot_int32_t				_numRegs;
	InternalRegisterCapability*	_pCap;
	ICapability*			_pCapability; // Take a weak pointer
};
