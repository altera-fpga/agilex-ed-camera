/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
#include "bus/OmniTekBus_IOCTL.h"
#include "InternalCapabilityFactory.h"

using namespace OmniTek;

class HostController;
class ImpBoard;

class ImpFpga :
	public IFpga,
	public ImpOmniTekBasePtr
{
public:
	ImpFpga(const ImpFpga& other) = delete;
	ImpFpga(ImpFpga&& other) = delete;
	ImpFpga& operator=(const ImpFpga& other) = delete;
	ImpFpga& operator=(ImpFpga&& other) = delete;

	ImpFpga(const OTBus_SlotInfo *pSlotInfo, ImpBoard *pBoard, HostController *pHostController,
			InternalCapabilityFactory& capabilityFactory);
	virtual ~ImpFpga(void);

	virtual ICapabilityEnumeratorPtr	GetCapabilities() {return _spCapabilities;};
	virtual IDmaEnumeratorPtr			GetDmaChannels()  {return _spDmaChannels;};
	virtual ICapabilityRegionsPtr		GetCapabilityRegions() {return _spCapabilityRegions;};
	virtual IPlatformInfoPtr			GetPlatformInfo() {return _spPlatformInfo;};
	virtual OT_Status					GetTimingCounter( otTime &ticks );
	virtual OT_Status					GetTimingFrequency( otTime &ticksPerSecond );
	virtual IBoardPtr					GetParentBoard() {return _pBoard;};

	ICapabilityEnumeratorPtr	_spCapabilities;
	IDmaEnumeratorPtr			_spDmaChannels;
	ICapabilityRegionsPtr		_spCapabilityRegions;
	IPlatformInfoPtr			_spPlatformInfo;

	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR

private:
	HostController *_pHostController;
	IBoard*		_pBoard; // Hold a weak pointer to the board
};

