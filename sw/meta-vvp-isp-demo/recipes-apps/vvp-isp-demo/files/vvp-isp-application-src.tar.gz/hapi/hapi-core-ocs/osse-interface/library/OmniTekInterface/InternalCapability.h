/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "InternalRegisterCapability.h"
#include "ImpOmniTekPtr.h"

#include <cstdint>

#include "capability/Common_IOCTL.h"

/* Internal interface allowing mocks for unit-testing */

class InternalCapability: public ICapability, public ImpOmniTekBasePtr
{
public:
    InternalCapability(OTParentTracker *pParentTracker) : ImpOmniTekBasePtr{pParentTracker} {}

    virtual ~InternalCapability() {}

    virtual void AddRegisterBlock(OmniTek::IRegisterBlock *pRegisterBlock) = 0;
    virtual InternalRegisterCapability* GetRegisterCapability() = 0;
    virtual OT_Status QueryCommonCapabilities(_QueryInfoEnum queryEnum, uint64_t &result) = 0;
    virtual void AddAssociatedCapability(OmniTek::ICapability*) = 0;

    DECLARE_IMP_OMNITEK_PTR
};
