/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/**
 * \defgroup UserlandInterface Application Level Interfaces
 * Application level interfaces for OmniTek FPGA Bus and Capabilities
 */

/** \addtogroup UserlandInterface
 *  @{
 */



/*
 * Standard way of determining the platform we are building for so we can select
 * and behaviour elsewhere.
 */

#ifndef BUILDTYPE

#define BT_LINUX 1
#define BT_WINDOWS 2

#ifdef _MSC_VER
#define BUILDTYPE BT_WINDOWS
#endif

#ifdef _NTDDK_
#define BUILDTYPE BT_WINDOWS
#endif

#ifdef __KERNEL__
#define BUILDTYPE BT_LINUX
#endif

#ifdef __linux__
#define BUILDTYPE BT_LINUX
#endif

#endif

#ifndef BUILDTYPE
#error "unsupported build..."
#endif

/* Define the macro which allows the system to share IOCTL Numbers between drivers */
#if BUILDTYPE==BT_WINDOWS
/**
 * @brief IOCTL number macro to make a consistent interface for windows / linux
 * @param[in] magic Driver/Class specific number. Must not exceed 4 bytes
 * @param[in] num Specific ioctl id
 * @return Unique id for use as an ioctl number
 */
#define OT_IOCTL_NUMBER(magic, num) ((((magic)&0xf)<<8)+ num) /* NOTE: Windows magic number can only be upto 4 bits in value */
#else
/**
 * @brief IOCTL number macro to make a consistent interface for windows / linux
 * @param[in] magic Driver/Class specific number. Must not exceed 4 bytes
 * @param[in] num Specific ioctl id
 * @return Unique id for use as an ioctl number
 */
#define OT_IOCTL_NUMBER(magic, num) (num)
#ifdef __KERNEL__
#include <asm-generic/ioctl.h>
#endif

#endif


/**
 * @brief zero and set version of an ioctl structure
 */
#define INIT_IOCTL(ioctl, version, size) \
{ \
	memset(ioctl, 0x00, size); \
	(ioctl)->Version = version; \
}

#include "Types.h"

/** @}*/
