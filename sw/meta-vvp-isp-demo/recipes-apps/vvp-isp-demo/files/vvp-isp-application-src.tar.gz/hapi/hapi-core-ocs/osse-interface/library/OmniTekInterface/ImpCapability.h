/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "InternalCapability.h"
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
using namespace OmniTek;

#include <vector>
#include <map>
#include <memory>

#include "bus/OmniTekBus_IOCTL.h"

#include "InternalRegisterFactory.h"

typedef std::multimap<ot_uint32_t, ICapability*> OmniTekCapabilityWeakMap;
typedef std::pair<OmniTekCapabilityWeakMap::iterator, OmniTekCapabilityWeakMap::iterator> OmniTekCapabilityWeakPairIterator;

typedef std::vector<IRegisterBlockPtr> OmniTekRegisterBlockList;

class ImpFpga;
class ImpCapability :	public InternalCapability
{
public:
	ImpCapability(const ImpCapability& other) = delete;
	ImpCapability(ImpCapability&& other) = delete;
	ImpCapability& operator=(const ImpCapability& other) = delete;
	ImpCapability& operator=(ImpCapability&& other) = delete;

	ImpCapability(OTParentTracker* pParentTracker, IFpga *pFpga, const OTBus_CapDevInfo& capDevInfo,
					std::shared_ptr<IoDevice> spIoDevice, std::shared_ptr<InternalRegisterFactory> spRegisterFactory);
	virtual ~ImpCapability();

	// ICapability Interface Functions
	virtual ot_uint32_t					GetHeaderType();
	virtual ot_uint32_t					GetType();
	virtual ot_int32_t					GetVersion();

	virtual ot_int32_t					GetNumRegisterBlocks();
	virtual IRegisterBlockPtr			GetRegisterBlock(ot_int32_t index);

	virtual ot_int32_t					GetUniqueID();
	virtual ot_uint32_t					GetAssociatedID();

	virtual ot_int32_t					GetNumAssociatedCapability();
	virtual ICapabilityPtr				GetAssociatedCapability(ot_int32_t index);
	virtual ICapabilityPtr				GetAssociatedCapability(ot_uint32_t type, ot_int32_t index);
	virtual IFpgaPtr					GetParentFpga(void){return _pFpga;};

	virtual OT_Status					GetTimingCounter(otTime &ticks);
	virtual OT_Status					GetTimingFrequency(otTime &ticksPerSecond);

	virtual OT_Status					GetDevicePath(ot_char_t *pBuffer, ot_uint32_t *pBufferSize);
	virtual OT_Status					GetDeviceHandle(otDeviceHandle *pDeviceHandle);

	virtual OT_Status					GetIsInterruptSupported();
	virtual ot_uint32_t					GetNumInterruptBits();
	virtual IInterruptInterfacePtr 		GetInterruptInterface(OT_Status *pStatus);

	// InternalCapability Implementation Functions
	void	AddRegisterBlock(IRegisterBlock *pRegisterBlock);

	InternalRegisterCapability*				GetRegisterCapability() {return _capability;};

	OT_Status							QueryCommonCapabilities(_QueryInfoEnum queryEnum, uint64_t &result);

	void								AddAssociatedCapability(ICapability*);
private:
	void							Display();

	OmniTekCapabilityWeakMap		_associatedCapabilities;
	OmniTekRegisterBlockList		_registerBlocks;
	char							_path[MAX_FILEPATH_LEN];
	ot_uint32_t						_headerType;
	ot_uint32_t						_capType;
	ot_uint32_t						_capHeaderVersion;

	InternalRegisterCapability*			_capability;
	IFpga							*_pFpga; // Take a weak pointer

	std::shared_ptr<InternalRegisterFactory> _spRegisterFactory;
};
