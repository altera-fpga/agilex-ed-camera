/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#pragma once
#include "HapiCore.h"
#include "IOmniTekInterface.h"
#include <map>

namespace Hapi
{
    class OcsHapiItem;

    class OcsHapiCore : public HapiCore
    {
    public:
        enum class DmaRegister : uint32_t
        {
            CapReg = 0,
            ChannelConf,
            Reserved0,
            PADRLower,
            PADRUpper,
            LADRLower,
            LADRUpper,
            DPRLower,
            DPRUpper,
            Size,
            Reserved1,
            CSR,
            Reserved2,
            BytesTransfered,
            SGBackLog,
            NumDMARegisters
        };

        // Flags in the CS Register
        enum class CSRegisterterFlags : uint32_t
        {
            DMAEnable = (1 << 0),
            DMAStart = (1 << 1),
            DMAAbort = (1 << 2),
            DMADone = (1 << 4),
            SGInterruptStatus = (1 << 5),
            EventInterruptStatus = (1 << 6),
            SGMode = (1 << 8),
            DisableSyncControl = (1 << 9),
            EventInterruptEnable = (1 << 10)
        };

        OcsHapiCore(uint32_t boardIndex, 
                    uint32_t fpgaIndex,
                    bool testDmaChannels);
        virtual ~OcsHapiCore();

        OmniTek::IDmaChannelPtr GetMDMA() { return _spMdma; }
        OmniTek::IDmaChannelPtr GetInputFDMA() { return _spInputFdma; }
        OmniTek::IDmaChannelPtr GetOutputFDMA() { return _spOutputFdma; }
        OmniTek::IDmaChannelPtr GetVideoInputFDMA() { return _spVideoInputFdma; }
        OmniTek::IDmaChannelPtr GetVideoOutputFDMA() { return _spVideoOutputFdma; }
        uint32_t GetIndexOfCapability(OmniTek::ICapabilityPtr& spCapability);
        uint32_t GetBoardIndex() const { return _boardIndex; }
        uint32_t GetFpgaIndex() const { return _fpgaIndex; }

    private:
        uint32_t _boardIndex;
        uint32_t _fpgaIndex;
        void LogDevices() override;
        bool ValidHardware() override;
        bool InitializeHapiItem(HapiItemBase* pHapiItem, OmniTek::ICapabilityPtr capability);
        bool InitializeByIndex(HapiItemBase* pHapiItem, uint32_t index) override;
        bool InitializeByUniqueID(HapiItemBase* pHapiItem, uint32_t uniqueId) override;
        bool InitializeByAssociatedID(HapiItemBase* pHapiItem, uint32_t associatedId) override;

        OmniTek::ICapabilityPtr FindCapabilityByIndex(HapiItemBase* pHapiItem, uint32_t index);
        OmniTek::ICapabilityPtr FindCapabilityByUniqueID(HapiItemBase* pHapiItem, uint32_t uniqueId);
        OmniTek::ICapabilityPtr FindCapabilityByAssociatedID(HapiItemBase* pHapiItem, uint32_t associatedId);
        OmniTek::ICapabilityPtr FindCapabilityByType(uint32_t type, uint32_t index);
        OmniTek::ICapabilityPtr FindCapabilityByIndex(uint32_t index);

        void FindDmaChannels(bool testDmaChannels);
        void DisableDmaSyncControl(OmniTek::IDmaChannelPtr& spDmaChannel);
        bool TestMdmaChannel(OmniTek::IDmaChannelPtr spMdma, size_t testSize, size_t nTests);

        OmniTek::IFpgaFactory*	_pFpgaFactory = nullptr;
        OmniTek::IFpgaPtr		_spFpga;
        OmniTek::IDmaChannelPtr	_spMdma;
        OmniTek::IDmaChannelPtr	_spInputFdma;
        OmniTek::IDmaChannelPtr	_spOutputFdma;
        OmniTek::IDmaChannelPtr	_spVideoInputFdma;
        OmniTek::IDmaChannelPtr	_spVideoOutputFdma;    
    };
}