/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef COMMON_IOCTL_H_
#define COMMON_IOCTL_H_

#include "global_defs.h"
#include <linux/version.h>

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/** \addtogroup UserlandInterface
 *  @{
 */

/** \cond */

// these values are written to the eventfd for reading...
#define EventCompleted ( 1 << 0 )
#if LINUX_VERSION_CODE < KERNEL_VERSION(6,7,12)
#define EventCanceled ( 1 << 1 )
#endif

#define CAP_COMMON_IOC_MAGIC (6)
/** \endcond */

/** \cond */
enum
{
    CAP_COMMON_IOCTL_NUM_Cancel = OT_IOCTL_NUMBER(CAP_COMMON_IOC_MAGIC , 1), //!< LINUX ONLY: CapGeneral_Cancel_IOCTL
    CAP_COMMON_IOCTL_NUM_QueryInfo = OT_IOCTL_NUMBER(CAP_COMMON_IOC_MAGIC , 2), //!< CapCommon_QueryInfo_IOCTL
    CAP_COMMON_IOCTL_NUM_QueryIOCTLInfo = OT_IOCTL_NUMBER(CAP_COMMON_IOC_MAGIC , 3), // !< CapCommon_QueryIOCTLInfo_IOCTL
};
/** \endcond */

/**
 * @brief OmniTek / system defined property query number macro
 * @param[in] x Unique number for the property
 * @return Specifically ranged id number for a property query
 */
#define OmniTekQueryInfoNumber( x ) ( x & 0x7fffffff )

/**
 * @brief Manufacturer specific property query number macro
 * @param[in] x Unique number for the property
 * @return Specifically ranged id number for a property query
 */
#define OtherQueryInfoNumber( x ) ( x | 0x80000000 )

/**
 * @brief Valid return values from #QueryInfo_DMASupported query
 */
enum _DmaType
{
	DmaType_NotSupported = 0, //!< DMA is not supported. An error code means the same...
	DmaType_Standard = 1, //!< DMA block transfer, single transfer
	DmaType_Streaming = 2, //!< DMA is streaming, so you can queue multiple buffers
};

/**
 * @brief Known ids for CapCommon_QueryInfo_IOCTL::Key
 */
enum _QueryInfoEnum
{
    QueryInfo_RegisterUniqueID = OmniTekQueryInfoNumber( 1 ), //!< Unique Component ID as per capability documentation for Register + Offset Capabilities
    QueryInfo_RegisterAssociationID = OmniTekQueryInfoNumber( 2 ), //!< Association ID as per capability documentation for Register + Offset Capabilities

    QueryInfo_DMASupported = OmniTekQueryInfoNumber( 3 ), //!< Does the device has any DMA support? Value is one of enum _DmaType
    QueryInfo_DMAEventsSupported = OmniTekQueryInfoNumber( 4 ), //!< Does the device has dma event support? true or false is value
    QueryInfo_DMADirectionRead =  OmniTekQueryInfoNumber( 5 ), //!< Does the dma device have read support
    QueryInfo_DMADirectionWrite =  OmniTekQueryInfoNumber( 6 ), //!< Does the dma device have write support
    QueryInfo_DMAMinTransferBytes = OmniTekQueryInfoNumber( 7 ), //!< Minimum size for a dma transfer with this device

    QueryInfo_MemMapType = OmniTekQueryInfoNumber( 8 ), //!< Type as per capability documentation for Memory Map Capabilities
    QueryInfo_MemMapBar = OmniTekQueryInfoNumber( 9 ), //!< Bar as per capability documentation for Memory Map Capabilities
    QueryInfo_MemMapByteSize = OmniTekQueryInfoNumber( 10 ), //!< Size as per capability documentation for Memory Map Capabilities
    QueryInfo_MemMapByteOffset = OmniTekQueryInfoNumber( 11 ), //!< Offset as per capability documentation for Memory Map Capabilities

    QueryInfo_TimerGetTime = OmniTekQueryInfoNumber( 12 ), //!< If there is a timer device read the current value
    QueryInfo_TimerGetFrequency = OmniTekQueryInfoNumber( 13 ), //!< If there is a time device read the frequency (so you can convert the time to a useful value)

    QueryInfo_DMAMaxSingleHWTransfer = OmniTekQueryInfoNumber( 14 ), //!< For a DMA device get the maximum number of bytes for a single target
    QueryInfo_DMAMaxTargets = OmniTekQueryInfoNumber( 15 ), //!< For a DMA device get the maximum number of targets in a single transfer
    QueryInfo_DMAMinQueueDepth = OmniTekQueryInfoNumber( 16 ), //!< For a DMA device get the minimum number of pending transfers to keep a streaming DMA auto queueing
    QueryInfo_DMAMaxQueueLength = OmniTekQueryInfoNumber( 17 ), //!< For a DMA device get the maximum number of hardware queued dma transfers

    QueryInfo_CapabilityId = OmniTekQueryInfoNumber( 18 ), //!< Get the id associated with this capability.  ( Host Controller Slot Number << 24 ) | ( enumerated device instance number )

    QueryInfo_RegisterVersionId = OmniTekQueryInfoNumber(19), //!< Get the version number for a Register or Offset capability

    QueryInfo_InterruptNumInterrupts = OmniTekQueryInfoNumber(20), //!< if the device has "generic interrupts" how many bits are used....

    QueryInfo_RegisterPhysAddr = OmniTekQueryInfoNumber( 21 ), //!< Get the physical address for a register block. The request must specify in value which block

    QueryInfo_DMAGpuDirectSupported = OmniTekQueryInfoNumber( 22 ), //!< Does the device has GPUDirect RDMA support? Value either true or false.

    QueryInfo_LastEntry = QueryInfo_RegisterPhysAddr //!< Used for testing only... Note: Update to the last entry
};

#pragma pack(push,4)

/**
 * @brief IOCTL container for #CAP_COMMON_IOCTL_QueryInfo
 */
typedef struct _CapCommon_QueryInfo_IOCTL
{
    uint32_t Version; //!< Must be #CAP_COMMON_IOCTL_QueryInfo_Version
    uint32_t Key; //!< use enum _QueryInfoEnum
    uint64_t Value; //!< The return value (sometimes also as a param)
} CapCommon_QueryInfo_IOCTL;

/**
 * @brief IOCTL container for #CAP_COMMON_IOCTL_QueryIOCTLInfo
 */
typedef struct _CapCommon_QueryIOCTLInfo_IOCTL
{
    uint32_t Version; //!< Must be #CAP_COMMON_IOCTL_QueryIOCTLInfo_Version
    uint32_t IOCTLNumber; //!< The IOCTL you are interested in
    uint32_t IOCTLVersion; //!< Either max IOCTL version number (returned), or the version number of interest
    uint8_t QueryMaxVersion; //!< Setting to 1 means you are ask for the max version number, otherwise you are asking if the passes IOCTLVersion is supported....
} CapCommon_QueryIOCTLInfo_IOCTL;

#pragma pack(pop)


/* Include the platform specific headers  */
#if BUILDTYPE == BT_WINDOWS
#include "windows/Common_IOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/Common_IOCTL.h"
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/



#endif /* COMMON_IOCTL_H_ */
