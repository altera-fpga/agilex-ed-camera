/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "../BusEnumerator.h"
#include "../InternalAllocator.h"

class PlatformBusEnumerator : public BusEnumerator
{
public:
	PlatformBusEnumerator(InternalAllocator* allocator);

	virtual ~PlatformBusEnumerator(void);

	virtual bool Open();
	virtual void Close();

private:
	// Disable copying
	PlatformBusEnumerator(const PlatformBusEnumerator& other);
	PlatformBusEnumerator& operator=(const PlatformBusEnumerator& other);

	int _hBus; // Handle to the bus
};
