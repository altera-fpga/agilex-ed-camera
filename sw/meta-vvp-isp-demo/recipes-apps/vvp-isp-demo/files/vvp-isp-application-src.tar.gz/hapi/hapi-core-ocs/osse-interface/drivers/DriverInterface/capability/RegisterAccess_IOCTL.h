/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef REGISTERACCESS_IOCTL_H_
#define REGISTERACCESS_IOCTL_H_

/** \addtogroup UserlandInterface
 *  @{
 */

#include "global_defs.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/** \cond */
#define CAP_RA_IOC_MAGIC (0)
/** \endcond */

/** \cond */
enum
{
    CAP_RA_IOCTL_NUM_GetRegisterCount	= OT_IOCTL_NUMBER(CAP_RA_IOC_MAGIC, 1), //!< CapRA_Count_IOCTL
    // cannot use value 2 for some unknown reason...
    CAP_RA_IOCTL_NUM_RegisterWrite		= OT_IOCTL_NUMBER(CAP_RA_IOC_MAGIC, 3), //!< CapRA_Register_IOCTL
    CAP_RA_IOCTL_NUM_RegisterShadowRead	= OT_IOCTL_NUMBER(CAP_RA_IOC_MAGIC, 4), //!< CapRA_Register_IOCTL
    CAP_RA_IOCTL_NUM_GetBlockCount		= OT_IOCTL_NUMBER(CAP_RA_IOC_MAGIC, 5), //!< CapRA_Count_IOCTL
    CAP_RA_IOCTL_NUM_RegisterRead		= OT_IOCTL_NUMBER(CAP_RA_IOC_MAGIC, 6), //!< CapRA_Register_IOCTL
    CAP_RA_IOCTL_NUM_GetMetaData		= OT_IOCTL_NUMBER(CAP_RA_IOC_MAGIC, 7), //!< CapRA_MetaData_IOCTL
};
/** \endcond */

#pragma pack(push,4)

/**
 * @brief IOCTL container for #CAP_RA_IOCTL_GetMetaData
 *
 * Version must be #CAP_RA_IOCTL_GetMetaData_Version
 * Returns The unique component id and the association id
 * of the register or offset capability
 *
 */
typedef struct
{
    uint32_t Version; //!< see the description for more information
    uint32_t AssociationId; //!< refer to the capability specification document
    uint32_t UniqueComponentId; //!< refer to the capability specification document
} CapRA_MetaData_IOCTL;

/**
 * @brief IOCTL container for #CAP_RA_IOCTL_GetRegisterCount and #CAP_RA_IOCTL_GetBlockCount
 *
 * For #CAP_RA_IOCTL_GetRegisterCount Count has two meanings. When sent from the user application
 * it is the block number being queried for a register count. When its returned it is the
 * register count.
 *
 * For #CAP_RA_IOCTL_GetRegisterCount Version must be #CAP_RA_IOCTL_GetRegisterCount_Version
 *
 * For #CAP_RA_IOCTL_GetBlockCount Count will be returned with the number of register
 * blocks for this device.
 *
 * For #CAP_RA_IOCTL_GetBlockCount Version must be #CAP_RA_IOCTL_GetBlockCount_Version
 *
 */
typedef struct
{
    uint32_t Version; //!< see the description for more information
    uint32_t Count; //!< see the description for more information
} CapRA_Count_IOCTL;

/**
 * @brief IOCTL container for #CAP_RA_IOCTL_RegisterWrite, #CAP_RA_IOCTL_RegisterRead and #CAP_RA_IOCTL_RegisterShadowRead
 *
 * For #CAP_RA_IOCTL_RegisterWrite Version must be #CAP_RA_IOCTL_RegisterWrite_Version
 *
 * For #CAP_RA_IOCTL_RegisterRead Version must be #CAP_RA_IOCTL_RegisterRead_Version
 *
 * For #CAP_RA_IOCTL_RegisterShadowRead Version must be #CAP_RA_IOCTL_RegisterShadowRead_Version
 */
typedef struct _CapRA_Register_IOCTL
{
    uint32_t Version; //!< see the description for more information
    uint32_t BlockNum; //!< Out of the possible register blocks which one should we use
    uint32_t RegNum; //!< Out of the possible registers within the selected block which one should be use
    uint32_t Value; //!< What value should we write / where the returned read value goes
} CapRA_Register_IOCTL;

#pragma pack(pop)

/* Include the platform specific headers  */
#if BUILDTYPE == BT_WINDOWS
#include "windows/RegisterAccess_IOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/RegisterAccess_IOCTL.h"
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/

#endif /* REGISTERACCESS_IOCTL_H_ */
