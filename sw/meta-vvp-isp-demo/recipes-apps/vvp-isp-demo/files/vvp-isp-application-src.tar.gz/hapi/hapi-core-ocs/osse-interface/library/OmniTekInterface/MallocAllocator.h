/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once

#include "InternalAllocator.h"

#include <cstdlib>

class MallocAllocator : public InternalAllocator
{
public:
    void* Allocate(size_t size) override { return ::malloc(size); }
    void Free(void* ptr) override { ::free(ptr); }
};
