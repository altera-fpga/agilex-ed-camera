/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef OMNIFB_IOCTL_H_
#error "Do not include this directly."
#endif

#include "../Common_IOCTL.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/**
 * @brief Current #CAP_OMNIFB_IOCTL_SetColourMatrix ::CapOmniFB_SetColourMatrix_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_SetColourMatrix_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_GetBusConfig ::CapOmniFB_GetBusConfig_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_GetBusConfig_Version 0

#define CAP_OMNIFB_IOCTL_GetComponents_Version1 0 // Legacy version
#define CAP_OMNIFB_IOCTL_GetComponents_Version CAP_OMNIFB_IOCTL_GetComponents_Version1 // Backwards compatibility
#define CAP_OMNIFB_IOCTL_GetComponents_Version2 1 // Current version

/**
 * @brief Current #CAP_OMNIFB_IOCTL_CursorEnable ::CapOmniFB_CursorEnable_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_CursorEnable_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_CursorMove ::CapOmniFB_CursorPosition_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_CursorMove_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_CursorSetPalette ::CapOmniFB_CursorPalette_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_CursorSetPalette_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_CursorSetImage ::CapOmniFB_CursorImage_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_CursorSetImage_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_DiscardAlpha ::CapOmniFB_DiscardAlpha_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_DiscardAlpha_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_GetResizerEnabled ::CapOmniFB_Resizer_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_GetResizerEnabled_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_SetResizerEnabled ::CapOmniFB_Resizer_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_SetResizerEnabled_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_GetChromaKey ::CapOmniFB_ChromaKey_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_GetChromaKey_Version 0

/**
 * @brief Current #CAP_OMNIFB_IOCTL_SetChromaKey ::CapOmniFB_ChromaKey_IOCTL::Version number to use
 */
#define CAP_OMNIFB_IOCTL_SetChromaKey_Version 0

/**
 * @brief IOCTL on OT_Cap_OmniFB devices for changing the colour matrix
 * Passed data type is ::CapOmniFB_SetColourMatrix_IOCTL
 */
#define CAP_OMNIFB_IOCTL_SetColourMatrix   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_SetColourMatrix, CapOmniFB_SetColourMatrix_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_OmniFB devices for obtaining information about the AXIS Steam setup
 * Passed and returned data type is ::CapOmniFB_GetBusConfig_IOCTL
 */
#define CAP_OMNIFB_IOCTL_GetBusConfig   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_GetBusConfig, CapOmniFB_GetBusConfig_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_OmniFB devices for obtaining information about the components of the framebuffer
 * Passed and returned data type is ::CapOmniFB_GetComponents_IOCTL
 */
#define CAP_OMNIFB_IOCTL_GetComponents   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_GetComponents, CapOmniFB_GetComponents_V2_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_OmniFB devices for setting the state of the cursor
 * Passed and returned data type is ::CapOmniFB_CursorEnable_IOCTL
 */
#define CAP_OMNIFB_IOCTL_CursorEnable   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_CursorEnable, CapOmniFB_CursorEnable_IOCTL * )
/**
 * @brief IOCTL on OT_Cap_OmniFB devices for setting the screen position of the hardware cursor
 * Passed and returned data type is ::CapOmniFB_CursorPosition_IOCTL
 */
#define CAP_OMNIFB_IOCTL_CursorMove   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_CursorMove, CapOmniFB_CursorPosition_IOCTL * )
/**
 * @brief IOCTL on OT_Cap_OmniFB devices for setting the palatte the cursor will use
 * Passed and returned data type is ::CapOmniFB_CursorPalette_IOCTL
 */
#define CAP_OMNIFB_IOCTL_CursorSetPalette   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_CursorSetPalette, CapOmniFB_CursorPalette_IOCTL * )
/**
 * @brief IOCTL on OT_Cap_OmniFB devices for setting the image used for the hardware cursor
 * Passed and returned data type is ::CapOmniFB_GetComponents_IOCTL
 */
#define CAP_OMNIFB_IOCTL_CursorSetImage   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_CursorSetImage, CapOmniFB_CursorImage_IOCTL * )
/**
 * @brief IOCTL on OT_Cap_OmniFB devices for enabling or disabling the 4th component (alpha)
 * Passed and returned data type is ::CapOmniFB_DiscardAlpha_IOCTL
 */
#define CAP_OMNIFB_IOCTL_DiscardAlpha   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_DiscardAlpha, CapOmniFB_DiscardAlpha_IOCTL * )
/**
 * @brief IOCTL on OT_Cap_OmniFB devices for getting the state of the 2k to 4k resizer
 * Passed and returned data type is ::CapOmniFB_Resizer_IOCTL
 */
#define CAP_OMNIFB_IOCTL_GetResizerEnabled   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_GetResizerEnabled, CapOmniFB_Resizer_IOCTL * )
/**
 * @brief IOCTL on OT_Cap_OmniFB devices for enabling or disabling the 2k to 4k resizer
 * Passed and returned data type is ::CapOmniFB_Resizer_IOCTL
 */
#define CAP_OMNIFB_IOCTL_SetResizerEnabled   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_SetResizerEnabled, CapOmniFB_Resizer_IOCTL * )
/**
 * @brief IOCTL on OT_Cap_OmniFB devices for getting the state of the optional chroma key
 * Passed and returned data type is ::CapOmniFB_ChromaKey_IOCTL
 */
#define CAP_OMNIFB_IOCTL_GetChromaKey   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_GetChromaKey, CapOmniFB_ChromaKey_IOCTL * )
/**
 * @brief IOCTL on OT_Cap_OmniFB devices for setting the state of the optional chroma key
 * Passed and returned data type is ::CapOmniFB_ChromaKey_IOCTL
 */
#define CAP_OMNIFB_IOCTL_SetChromaKey   _IOWR( CAP_OMNIFB_IOC_MAGIC, CAP_OMNIFB_IOCTL_NUM_SetChromaKey, CapOmniFB_ChromaKey_IOCTL * )

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/
