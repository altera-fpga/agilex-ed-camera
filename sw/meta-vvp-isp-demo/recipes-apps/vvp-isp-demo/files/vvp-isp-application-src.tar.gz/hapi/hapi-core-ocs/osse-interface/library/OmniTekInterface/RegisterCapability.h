/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "InternalRegisterCapability.h"
#include "HardwareDevice.h"

#include <vector>
#include <memory>

class RegisterCapability : public InternalRegisterCapability
{
public:
	RegisterCapability(std::shared_ptr<IoDevice> spIoDevice);
	virtual ~RegisterCapability();

	bool	bIsValid();

	ot_int32_t		GetNumRegisterBlocks();
	ot_int32_t		GetNumRegisters(ot_int32_t block);

	bool	WriteRegister(ot_int32_t blk, ot_int32_t regNum, ot_uint32_t value);
	bool	ReadRegister( ot_int32_t blk, ot_int32_t regNum, ot_uint32_t &value);
	bool	ReadShadowRegister( ot_int32_t blk, ot_int32_t regNum, ot_uint32_t &value);

	virtual otDeviceHandle			GetFileHandle() {return _spIoDevice->GetFileHandle();};

	virtual ot_uint32_t				GetUniqueID() {return _uniqueId;};
	virtual ot_uint32_t				GetAssociatedID() {return _associatedId;};
	virtual ot_uint32_t				GetVersion() { return _version;};

	OmniTek::OT_Status		QueryInfo(_QueryInfoEnum info, uint64_t &result);
	OmniTek::OT_Status		GetRegisterBlockPhysAddr(ot_uint32_t blkNum, ot_uint64_t &result);

	IoDevice*		GetioDevice() { return _spIoDevice.get(); };

private:
	void			Close();
	std::shared_ptr<IoDevice> _spIoDevice;
	std::vector<ot_int32_t> _blocks;
	ot_uint32_t				 _uniqueId; // This is the unique ID for the capability
	ot_uint32_t				 _associatedId; // This is the associated ID for the capability
	ot_uint32_t				 _version;
};

#if BUILDTYPE == BT_WINDOWS
#include "windows\PlatformRegisterCapability.h"
#else
#include "linux/PlatformRegisterCapability.h"
#endif
