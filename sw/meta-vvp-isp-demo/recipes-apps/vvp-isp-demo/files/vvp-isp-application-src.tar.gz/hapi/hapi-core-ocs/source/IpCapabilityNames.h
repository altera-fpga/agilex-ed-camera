/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#pragma once
#include <unordered_map>
#include <string>
#include <stdint.h>

namespace Hapi
{
    extern std::unordered_map<uint32_t, std::string> capabilityNames;
} // namespace Hapi