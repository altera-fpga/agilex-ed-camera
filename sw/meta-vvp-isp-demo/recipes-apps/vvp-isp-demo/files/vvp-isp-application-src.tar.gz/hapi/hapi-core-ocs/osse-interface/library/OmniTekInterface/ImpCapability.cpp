/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpCapability.h"
#include "ImpRegisterBlock.h"
#include "RegisterCapability.h"
#include "capability/RegisterAccess_IOCTL.h"
#include "ImpFpga.h"
#include "ImpInterruptInterface.h"
////////////////////////////////////////////////////////////////////////////////

namespace
{

const uint32_t MAX_BLOCK_COUNT = 256;

}

class MetaDataTransaction : public IoTransaction
{
public:
	MetaDataTransaction()
	{
		INIT_IOCTL(&_ioctl, CAP_RA_IOCTL_GetMetaData_Version, sizeof(_ioctl));
	}
	~MetaDataTransaction() {};
	
	virtual void			*GetIoctl() {return &_ioctl;};
	virtual const void		*GetIoctl() const {return &_ioctl;};
	virtual ot_uint32_t	GetSize() const {return sizeof(_ioctl);};
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_RA_IOCTL_GetMetaData;};

	ot_uint32_t GetUniqueId() const {return _ioctl.UniqueComponentId;};
	ot_uint32_t GetAssociatedId() const {return _ioctl.AssociationId;};
private:
	CapRA_MetaData_IOCTL	_ioctl;
};

class BlockCountTransaction : public IoTransaction
{
public:
	BlockCountTransaction()
	{
		INIT_IOCTL(&_blkIoctl, CAP_RA_IOCTL_GetBlockCount_Version, sizeof(_blkIoctl));
	}

	virtual void			*GetIoctl() {return &_blkIoctl;};
	virtual const void		*GetIoctl() const {return &_blkIoctl;};
	virtual ot_uint32_t	GetSize() const {return sizeof(_blkIoctl);};
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_RA_IOCTL_GetBlockCount;};

	ot_uint32_t GetCount() const {return _blkIoctl.Count;};
private:
	CapRA_Count_IOCTL	_blkIoctl;
};

class RegisterCountTransaction : public IoTransaction
{
public:
	RegisterCountTransaction( ot_uint32_t blk)
	{
		INIT_IOCTL(&regIoctl, CAP_RA_IOCTL_GetRegisterCount_Version, sizeof(regIoctl));
		regIoctl.Count = blk;
	}

	virtual void			*GetIoctl() {return &regIoctl;};
	virtual const void		*GetIoctl() const {return &regIoctl;};
	virtual ot_uint32_t	GetSize() const {return sizeof(regIoctl);};
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_RA_IOCTL_GetRegisterCount;};

	ot_uint32_t GetCount() const {return regIoctl.Count;};
private:
	CapRA_Count_IOCTL	regIoctl;
};

class ReadRegisterTransaction;
class ReadShadowRegisterTransaction;
class WriteRegisterTransaction;
class RegisterTransaction : public IoTransaction
{
	friend class ReadShadowRegisterTransaction;
	friend class ReadRegisterTransaction;
	friend class WriteRegisterTransaction;
public:
	virtual void			*GetIoctl() {return &regIoctl;};
	virtual const void		*GetIoctl() const {return &regIoctl;};
	virtual ot_uint32_t	GetSize() const {return sizeof(regIoctl);};

	ot_uint32_t GetValue() const {return regIoctl.Value;};
private:
	CapRA_Register_IOCTL	regIoctl;
};

class ReadShadowRegisterTransaction : public RegisterTransaction
{
public:
	ReadShadowRegisterTransaction(ot_uint32_t blk, ot_uint32_t regNum)
	{
		INIT_IOCTL(&regIoctl, CAP_RA_IOCTL_GetRegisterCount_Version, sizeof(regIoctl));
		regIoctl.BlockNum = blk;
		regIoctl.RegNum = (uint32_t)regNum;
	}
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_RA_IOCTL_RegisterShadowRead;};

};

class ReadRegisterTransaction : public RegisterTransaction
{
public:
	ReadRegisterTransaction(ot_uint32_t blk, ot_uint32_t regNum)
	{
		INIT_IOCTL(&regIoctl, CAP_RA_IOCTL_RegisterRead_Version, sizeof(regIoctl));
		regIoctl.BlockNum = blk;
		regIoctl.RegNum = (uint32_t)regNum;
	}
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_RA_IOCTL_RegisterRead;};

};

class WriteRegisterTransaction : public RegisterTransaction
{
public:
	WriteRegisterTransaction(ot_uint32_t blk, ot_uint32_t regNum, ot_uint32_t value)
	{
		INIT_IOCTL(&regIoctl, CAP_RA_IOCTL_RegisterWrite_Version, sizeof(regIoctl));
		regIoctl.BlockNum = blk;
		regIoctl.RegNum = (uint32_t)regNum;
		regIoctl.Value = value;
	}
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_RA_IOCTL_RegisterWrite;};

};

class CommonCapabilityTransaction : public IoTransaction
{
public:
	CommonCapabilityTransaction()
	{
		INIT_IOCTL(&_ioctl, CAP_COMMON_IOCTL_QueryInfo_Version, sizeof(_ioctl));
	}
	~CommonCapabilityTransaction() {};

	virtual void			*GetIoctl() {return &_ioctl;};
	virtual const void		*GetIoctl() const {return &_ioctl;};
	virtual ot_uint32_t	GetSize() const {return sizeof(_ioctl);};
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_COMMON_IOCTL_QueryInfo;};

	void SetQueryEnum(_QueryInfoEnum infoEnum)
	{
		_ioctl.Key = infoEnum;
	};

	void SetValue( ot_uint64_t value )
	{
		_ioctl.Value = value;
	};

	uint64_t GetValue() const
	{
		return _ioctl.Value;
	};

private:
	CapCommon_QueryInfo_IOCTL	_ioctl;
};

class PhysicalAddressTransaction : public CommonCapabilityTransaction
{
public:
	PhysicalAddressTransaction( ot_uint32_t blkNum )
		: CommonCapabilityTransaction()
	{
		SetQueryEnum(QueryInfo_RegisterPhysAddr);
		SetValue((ot_uint64_t)blkNum);
	}
};

////////////////////////////////////////////////////////////////////////////////////////////////
RegisterCapability::RegisterCapability(std::shared_ptr<IoDevice> spIoDevice)
	: _spIoDevice(std::move(spIoDevice))
	, _blocks{}
	, _uniqueId{0}
	, _associatedId{0}
	, _version{0}
{
	// OK let's open this capability
	if( _spIoDevice->bIsValid() )
	{
		// Query for the Unique ID
		uint64_t queryResult;
		if( QueryInfo(QueryInfo_RegisterUniqueID, queryResult) != OT_Status_OK )
		{
			Close();
			return;
		}
		_uniqueId = (ot_int32_t)queryResult;

		// Query for the Associated ID
		if( QueryInfo(QueryInfo_RegisterAssociationID, queryResult) != OT_Status_OK )
		{
			Close();
			return;
		}
		_associatedId = (ot_int32_t)queryResult;

		if( QueryInfo(QueryInfo_RegisterVersionId, queryResult) != OT_Status_OK )
			_version = 1;
		else
			_version = (ot_int32_t)queryResult;

		BlockCountTransaction blkTransaction;

		if( _spIoDevice->SendTransaction(&blkTransaction) != 0 )
		{
			Close();
			return;
		}

		if (blkTransaction.GetCount() > MAX_BLOCK_COUNT)
		{
			Close();
			return;
		}

		for(ot_int32_t blk=0; blk<(ot_int32_t)blkTransaction.GetCount(); blk++ )
		{
			RegisterCountTransaction regCountTransaction(blk);

			if( _spIoDevice->SendTransaction(&regCountTransaction) != 0 )
			{
				Close();
				return;
			}

			// Add the number of registers to the blocks
			_blocks.push_back((ot_int32_t)regCountTransaction.GetCount());
		}
	}
}

RegisterCapability::~RegisterCapability()
{
	Close();
}

void RegisterCapability::Close()
{
	_blocks.clear();
	_spIoDevice->Close();
}

bool RegisterCapability::bIsValid()
{
	return _spIoDevice->bIsValid();
}

OmniTek::OT_Status RegisterCapability::QueryInfo(_QueryInfoEnum info, uint64_t &result)
{
	OT_Status status = OT_Status_Fail;
	CommonCapabilityTransaction commonCapabilityTransaction;

	commonCapabilityTransaction.SetQueryEnum(info);

	if( _spIoDevice->SendTransaction(&commonCapabilityTransaction) == 0 )
	{
		result = commonCapabilityTransaction.GetValue();
		status = OT_Status_OK;
	}
	return status;
}

OmniTek::OT_Status RegisterCapability::GetRegisterBlockPhysAddr(ot_uint32_t blkNum, ot_uint64_t &result)
{
	OT_Status status = OT_Status_Fail;
	PhysicalAddressTransaction transaction(blkNum);

	result = -1;
	if( _spIoDevice->SendTransaction(&transaction) == 0 )
	{
		result = transaction.GetValue();
		status = OT_Status_OK;
	}
	return status;
}

ot_int32_t RegisterCapability::GetNumRegisterBlocks()
{
	return (ot_int32_t)_blocks.size();
}

ot_int32_t RegisterCapability::GetNumRegisters(ot_int32_t block)
{
	ot_int32_t iResult = 0;

	if( block < (ot_int32_t)_blocks.size() )
		iResult = _blocks[block];

	return iResult;
}

bool RegisterCapability::WriteRegister(ot_int32_t blk, ot_int32_t regNum, ot_uint32_t value)
{
	WriteRegisterTransaction transaction(blk, regNum, value);
	if( _spIoDevice->SendTransaction(&transaction) != 0 )
		return false;
	return true;
}

bool RegisterCapability::ReadRegister( ot_int32_t blk, ot_int32_t regNum, ot_uint32_t &value)
{
	ReadRegisterTransaction transaction(blk, regNum);
	if( _spIoDevice->SendTransaction(&transaction) != 0 )
		return false;
	value = transaction.GetValue();
	return true;
}

bool RegisterCapability::ReadShadowRegister( ot_int32_t blk, ot_int32_t regNum, ot_uint32_t &value)
{
	ReadShadowRegisterTransaction transaction(blk, regNum);
	if( _spIoDevice->SendTransaction(&transaction) != 0 )
		return false;
	value = transaction.GetValue();
	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////
ImpCapability::ImpCapability(OTParentTracker* pParentTracker, IFpga *pFpga, const OTBus_CapDevInfo& capDevInfo,
								std::shared_ptr<IoDevice> spIoDevice, std::shared_ptr<InternalRegisterFactory> spRegisterFactory)
	: InternalCapability(pParentTracker)
	, _capability(NULL)
	, _pFpga(pFpga)
	, _spRegisterFactory(std::move(spRegisterFactory))
{
	StrCpy(_path, MAX_FILEPATH_LEN, capDevInfo.Path);
	_headerType = capDevInfo.Type;
	_capType = capDevInfo.SubType;
	_capHeaderVersion = capDevInfo.Version;

	// We can now open a capability enumerator
	_capability = new RegisterCapability(std::move(spIoDevice));
	if( _capability && _capability->bIsValid() )
	{
		// Read the Unique ID for this capability

		for(ot_int32_t i=0; i<_capability->GetNumRegisterBlocks(); i++)
		{
			if (_capability->GetNumRegisters(i))
			{
				// Adding to the _registerBlocks will wrap the pointer inside a smart pointer.
				_registerBlocks.push_back(_spRegisterFactory->CreateRegisterBlock(this, _capability, i, _capability->GetNumRegisters(i)));
			}
		}
		
		// If we have no valid register blocks, ignore the capability as it is likely incomplete
		if (!_registerBlocks.size())
		{
			printf("ERROR: Cap Id 0x%x : Register blocks are defined but with no registers allocated. Ignoring.\n", _capType);
			delete _capability;
			_capability = NULL;
		}
	}
	else
	{
		delete _capability;
		_capability = NULL;
	}
}

ImpCapability::~ImpCapability()
{
	// Simple clear the Reference to the Register Blocks
	_registerBlocks.clear();

	// Now need to delete the capability enumerator
	delete _capability;
}

ot_uint32_t ImpCapability::GetHeaderType()
{
	return _headerType;
}

ot_uint32_t ImpCapability::GetType()
{
	return _capType;
}

void ImpCapability::AddRegisterBlock(IRegisterBlock *pRegisterBlock)
{
	_registerBlocks.push_back(pRegisterBlock);
}

ot_int32_t ImpCapability::GetNumRegisterBlocks()
{
	return (ot_int32_t)_registerBlocks.size();
}

IRegisterBlockPtr ImpCapability::GetRegisterBlock(ot_int32_t index)
{
	IRegisterBlockPtr spRegBlk;

	if( index < GetNumRegisterBlocks() )
		spRegBlk = _registerBlocks[index];
	return spRegBlk;
}

void ImpCapability::AddAssociatedCapability(ICapability* pCapability)
{
	_associatedCapabilities.insert(std::make_pair(pCapability->GetType(), pCapability));
}

ot_int32_t ImpCapability::GetNumAssociatedCapability()
{
	return (ot_int32_t)_associatedCapabilities.size();
}

ICapabilityPtr ImpCapability::GetAssociatedCapability(ot_int32_t index)
{
	OmniTekCapabilityWeakMap::iterator	iter = _associatedCapabilities.begin();
	ot_int32_t i=0;
	while( iter != _associatedCapabilities.end() )
	{
		if( index == i )
		{
			return iter->second;
		}
		iter++;
		i++;
	}

	return NULL;
}

ICapabilityPtr ImpCapability::GetAssociatedCapability(ot_uint32_t type, ot_int32_t index)
{
	ICapabilityPtr spCapability;

	OmniTekCapabilityWeakPairIterator pair = _associatedCapabilities.equal_range(type);
	OmniTekCapabilityWeakMap::iterator iter = pair.first;

	ot_int32_t i=0;
	while( iter != pair.second )
	{
		if( i==index )
		{
			return iter->second;
		}
		iter++;
		i++;
	}
	
	return NULL;
}

ot_int32_t ImpCapability::GetVersion()
{
	ot_int32_t version = 0;
	if( _capability )
		version = _capability->GetVersion();
	return version;
}

ot_int32_t ImpCapability::GetUniqueID()
{
	ot_int32_t uniqueId = 0; // Default to zero for the capability
	if( _capability )
		uniqueId = _capability->GetUniqueID();

	return uniqueId;
}

ot_uint32_t ImpCapability::GetAssociatedID()
{
	ot_int32_t associatedID = 0; // Default to zero for the capability
	if( _capability )
	{
		associatedID = _capability->GetAssociatedID();
	}

	return associatedID;
}

OT_Status ImpCapability::QueryCommonCapabilities(_QueryInfoEnum queryEnum, uint64_t &result)
{
	return GetRegisterCapability()->QueryInfo(queryEnum, result);
}

OT_Status ImpCapability::GetTimingCounter(otTime &ticks)
{
	OT_Status status = OT_Status_Timing_Not_Implemented;
	CommonCapabilityTransaction transaction;

	transaction.SetQueryEnum(QueryInfo_TimerGetTime);
	if( GetRegisterCapability()->GetioDevice()->SendTransaction(&transaction) == 0 )
	{
		ticks = transaction.GetValue();
		status = OT_Status_OK;
	}

	return status;
}

OT_Status ImpCapability::GetTimingFrequency(otTime &ticksPerSecond)
{
	OT_Status status = OT_Status_Timing_Not_Implemented;
	CommonCapabilityTransaction transaction;

	transaction.SetQueryEnum(QueryInfo_TimerGetFrequency);
	if( GetRegisterCapability()->GetioDevice()->SendTransaction(&transaction) == 0 )
	{
		ticksPerSecond = transaction.GetValue();
		status = OT_Status_OK;
	}

	return status;
}


OT_Status ImpCapability::GetDevicePath(ot_char_t *pBuffer, ot_uint32_t *pBufferSize)
{
	if ((!pBuffer) || (!pBufferSize))
	{
		return OT_Status_InvalidParameter;
	}

	OT_Status status = OT_Status_OK;

	if( *pBufferSize < ((ot_uint32_t)strlen(_path)+1) )
	{
		status = OT_Status_Buffer_Too_Small;
		*pBufferSize = (ot_uint32_t)strlen(_path) + 1;
	}
	else
		StrCpy(pBuffer, *pBufferSize, _path);

	return status;
}

OT_Status ImpCapability::GetDeviceHandle(otDeviceHandle *pDeviceHandle)
{
	if (!pDeviceHandle)
	{
		return OT_Status_InvalidParameter;
	}

	OT_Status status = OT_Status_OK;
	*pDeviceHandle = _capability->GetFileHandle();
	return status;
}

OT_Status ImpCapability::GetIsInterruptSupported()
{
	OT_Status status = OT_Status_Not_Implemented;

	if( GetNumInterruptBits() != 0 )
		status = OT_Status_OK;
	return status;
}

ot_uint32_t ImpCapability::GetNumInterruptBits()
{
	ot_uint32_t numIntBits = 0;
	CommonCapabilityTransaction transaction;

	transaction.SetQueryEnum(QueryInfo_InterruptNumInterrupts);
	if( GetRegisterCapability()->GetioDevice()->SendTransaction(&transaction) == 0 )
	{
		numIntBits = (ot_uint32_t)transaction.GetValue();
	}

	return numIntBits;
}

IInterruptInterfacePtr ImpCapability::GetInterruptInterface(OT_Status *pStatus)
{
	IInterruptInterfacePtr spInterruptInterface;
	OT_Status status = GetIsInterruptSupported();
	if( status == OT_Status_OK )
	{
		spInterruptInterface = _spRegisterFactory->CreateInterruptInterface(GetRegisterCapability()->GetioDevice(), this);
		if( !spInterruptInterface )
			status = OT_Status_Device_Busy;
	}
	if( pStatus )
		*pStatus = status;
	return spInterruptInterface;
}
