/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "StdAfx.h"
#include "Customise.h"
#include "../BusEnumerator.h"

const char *_gBusName="/dev/" MANUF_BUS_FILE;

PlatformBusEnumerator::PlatformBusEnumerator(InternalAllocator* allocator)
:
    BusEnumerator(allocator),
    _hBus(-1)
{
}

PlatformBusEnumerator::~PlatformBusEnumerator()
{
	Close();
}

void PlatformBusEnumerator::Close()
{
	if( _hBus > -1 )
		close(_hBus);
	_hBus = -1;
}

bool PlatformBusEnumerator::Open()
{
	// Try and find the bus driver
	_hBus = open( _gBusName, O_RDWR );
	if( _hBus > -1 )
	{
		OTBus_Slots *pSlots = NULL;
		pSlots = ResizeSlots(NULL, 0);

		if (!pSlots)
		{
			return false;
		}

		// Initially we need to find out how many slot ids are attached to the Bus
		if( ioctl(_hBus, OTBUS_IOCTL_GetNumSlots, pSlots) == -1 )
		{
			if( errno != EINVAL )
			{
				printf("Failed to read number of slots from OmniTek Bus, %d\n", errno);
				Clean(pSlots);
				return false;
			}

//			printf("Found %d slot(s)\n", pSlots->NumSlots);

			// Now we should know how many Slots are required
			if( pSlots->NumSlots == 0 )
			{
				printf("No FPGAs attached to Bus\n");
				Clean(pSlots);
				return false;
			}
		}

		// pSlots should now contain the number of slots available
		uint32_t numSlots = pSlots->NumSlots;
		pSlots = ResizeSlots(pSlots, numSlots);

		if (!pSlots)
		{
			return false;
		}

		// Read the slots
		if( ioctl(_hBus, OTBUS_IOCTL_GetNumSlots, pSlots) == -1 )
		{
			printf("Failed to read the slot ids from OmniTek Bus, %d\n", errno);
			Clean(pSlots);
			return false;
		}

		// OK, go get the Slot Info for each board
		for( uint32_t i=0; i<pSlots->NumSlots; i++ )
		{
			OTBus_SlotInfo *pSlotInfo = NULL;
//			printf("Get Slot %d\n", pSlots->SlotIds[i]);
			pSlotInfo = ResizeSlotInfo(NULL, 0, pSlots->SlotIds[i]);

			if (!pSlotInfo)
			{
				Clean(pSlots);
				return false;
			}

			// Initially to read the size of the SlotInfo
			if( ioctl(_hBus, OTBUS_IOCTL_GetSlot, pSlotInfo) == -1)
			{
				if( errno != EINVAL )
				{
					printf("Failed to get size of Slot %d, err %d\n", pSlots->SlotIds[i], errno);
					Clean(pSlotInfo);
					Clean(pSlots);
					return false;
				}
			}

			// We now know how many device capabilities are attached to the Slot
			uint32_t numCapDev = pSlotInfo->NumCapDevs;

			if( numCapDev ==  0 )
			{
				Clean(pSlotInfo);
			}
			else // Read the Slot Info
			{
				pSlotInfo = ResizeSlotInfo(pSlotInfo, numCapDev, pSlots->SlotIds[i]);

				if (!pSlotInfo)
				{
					Clean(pSlots);
					return false;
				}

//				printf("Retrieve SlotId %d, numCapDev %d\n", pSlotInfo->SlotId, pSlotInfo->NumCapDevs);

				// Ok Read the SlotInfo
				if( ioctl(_hBus, OTBUS_IOCTL_GetSlot, pSlotInfo) == -1 )
				{
					printf("Failed to read slot[%d] info, %d", pSlots->SlotIds[i], errno);
					Clean(pSlotInfo);
					Clean(pSlots);
					return false;
				}

				// Push the SlotInfo on the SlotInfo Store
				// Note: BusEnumerator now owns the SlotInfo memory and
				// will free once the BusEnumerator is destroyed
				_slots.push_back(pSlotInfo);
				pSlotInfo = NULL; // As the previous comment says, the BusEnumerator now owns this memory
			}
		}
		// Clean up the memory for the slots
		Clean(pSlots);
	}

	return true;
}
