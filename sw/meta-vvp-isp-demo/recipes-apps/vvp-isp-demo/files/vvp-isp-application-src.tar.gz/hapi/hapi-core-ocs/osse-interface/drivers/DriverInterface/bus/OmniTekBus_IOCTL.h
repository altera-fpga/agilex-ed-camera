/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef OMNITEKBUS_IOCTL_H_
#define OMNITEKBUS_IOCTL_H_

/** \addtogroup UserlandInterface
 *  @{
 */

#include "../global_defs.h"
#include "Types.h"

#ifdef _MSC_VER
// warning C4200: nonstandard extension used : zero-sized array in struct/union
#pragma warning(disable: 4200)
#endif

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/** \cond */
#define OTBUS_IOC_MAGIC (0)
/** \endcond */

/** \cond */
enum
{
	OTBUS_IOCTL_NUM_GetNumSlots	= OT_IOCTL_NUMBER(OTBUS_IOC_MAGIC, 1),
    // skip value 2 as it breaks linux.....
    OTBUS_IOCTL_NUM_GetSlot		= OT_IOCTL_NUMBER(OTBUS_IOC_MAGIC, 3),
};
/** \endcond */

/* All IOCTL structures should be padded to 4 bytes */
#pragma pack(push, 4)

/**
 * @brief Individual capability description
 */
typedef struct
{
    char     Path[MAX_FILEPATH_LEN]; //!< Path to open this device
    uint32_t Type;      //!< The capability type
    uint32_t Version;   //!< Version of the capability header
    uint32_t SubType;   //!< Optionally set depending on Type
} OTBus_CapDevInfo;

/**
 * @brief Per host controller / slot description
 */
typedef struct
{
    char Path[MAX_FILEPATH_LEN]; //!< Path to open this device
    char TypeName[MAX_NAME_LEN]; //!< HC driver defined
    struct
    {
        uint32_t Data1;
        uint16_t Data2;
        uint16_t Data3;
        uint8_t  Data4[ 8 ];
    } Uuid; //!< aka a windows GUID
} OTBus_HCInfo;

/**
 * @brief Main IOCTL container for #OTBUS_IOCTL_GetNumSlots requests
 *
 * When sent from an application NumSlots means the number of SlotIds that have
 * been allocated. If it is insufficient an error code will be returned
 * and NumSlots will be filled with the number of needed SlotIds.
 */
typedef struct
{
    uint32_t Version; //!< must be #OTBUS_IOCTL_GetNumSlots_Version
    uint32_t NumSlots; //!< Either number of SlotIds allocated in SlotIds OR the number or required slots
    uint32_t SlotIds[]; //!< Ids to use in OTBus_SlotInfo SlotId
} OTBus_Slots;

/**
 * @brief Main IOCTL container for #OTBUS_IOCTL_GetSlot requests
 *
 * When sent from the application NumCapDevs means the number of allocated CapDevs.
 * IF it is insufficient and error code will be returned and NumCapDevs will be filled
 * with the number of required CapDevs.
 */
typedef struct
{
    uint32_t         Version; //!< must be #OTBUS_IOCTL_GetSlot_Version
    uint32_t         SlotId; //!< Host Controller slot id of interest obtained from a previous call to #OTBUS_IOCTL_GetNumSlots
    OTBus_HCInfo     HostControllerInfo; //!< information about the host controller
    uint32_t         NumCapDevs; //!< Either number of CapDevs allocated  OR the number of required CapDevs
    OTBus_CapDevInfo CapDevs[]; //!< Information about each capability device on this host controller
} OTBus_SlotInfo;

#pragma pack(pop)

/* Include the platform specific headers  */
#if BUILDTYPE == BT_WINDOWS
#include "windows/OmniTekBus_IOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/OmniTekBus_IOCTL.h"
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/

#endif /* OMNITEKBUS_IOCTL_H_ */
