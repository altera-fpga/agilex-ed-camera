/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpInterruptInterface.h"
#include "Interrupt_IOCTL.h"
#include "ImpCapability.h"

////////////////////////////////////////////////////////////////////////////////
template<typename IOCTL>
class BaseInterrupt_Transaction : public IoTransaction
{
public:
	BaseInterrupt_Transaction(uint32_t ioctlVersion)
	{
		INIT_IOCTL(&_ioctl, ioctlVersion, sizeof(_ioctl));
	}

	virtual void		*GetIoctl() {return (void*)&_ioctl;};
	virtual const void	*GetIoctl() const {return (void*)&_ioctl;};
	virtual ot_uint32_t	GetSize() const {return sizeof(_ioctl);};
	virtual ot_uint32_t	GetIoctlNum() const = 0;

	IOCTL _ioctl;
};

class AcquireInterrupt_Transaction : public BaseInterrupt_Transaction<CapInterrupt_AcquireController_IOCTL>
{
public:
	AcquireInterrupt_Transaction()
		: BaseInterrupt_Transaction(CAP_INTERRUPT_IOCTL_VERSION_AcquireController)
	{
	}
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_INTERRUPT_IOCTL_AcquireController;};
	ot_uint32_t			GetNumBits() const {return (ot_uint32_t)_ioctl.NumBits;};
};

class ReleaseInterrupt_Transaction : public BaseInterrupt_Transaction<CapInterrupt_ReleaseController_IOCTL>
{
public:
	ReleaseInterrupt_Transaction()
		: BaseInterrupt_Transaction(CAP_INTERRUPT_IOCTL_VERSION_ReleaseController)
	{
	}
	virtual ot_uint32_t	GetIoctlNum() const { return CAP_INTERRUPT_IOCTL_ReleaseController;};
};

class SetMask_Transaction : public BaseInterrupt_Transaction<CapInterrupt_Mask_IOCTL>
{
public:
	SetMask_Transaction( ot_uint32_t mask, bool bEnable )
		: BaseInterrupt_Transaction(bEnable?CAP_INTERRUPT_IOCTL_VERSION_EnableMask:CAP_INTERRUPT_IOCTL_VERSION_DisableMask)
		, _bEnable(bEnable)
	{
		_ioctl.Mask = mask;
	}
	virtual ot_uint32_t	GetIoctlNum() const { return _bEnable?CAP_INTERRUPT_IOCTL_EnableMask:CAP_INTERRUPT_IOCTL_DisableMask;};

	bool					_bEnable;
};
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////

ImpInterruptInterface::ImpInterruptInterface(IoDevice* pIoDevice, ICapability *pParent, ot_uint32_t numIntBits,
												InterruptTransactionFactory createInterruptTransaction)
: _pIoDevice(pIoDevice)
, _spParent(pParent) // Also take the smart pointer to make sure the parent doesn't go away
, _numIntBits(numIntBits)
, _mask(0)
, _ticksPerSecond{0}
, _createInterruptTransaction{std::move(createInterruptTransaction)}
{
	_spParent->GetTimingFrequency(_ticksPerSecond);
}

ImpInterruptInterface::~ImpInterruptInterface()
{
	ReleaseInterrupt_Transaction releaseTransaction;

	// Make sure that all bits are disabled

	// Release the interface
	_pIoDevice->SendTransaction(&releaseTransaction);
}

ot_uint32_t ImpInterruptInterface::GetInterruptMask()
{
	return _mask;
}

OT_Status ImpInterruptInterface::SetEnableMask(ot_uint32_t enableMask)
{
	_mask |= enableMask;
	SetMask_Transaction transaction(enableMask, true);
	_pIoDevice->SendTransaction(&transaction);
	return OT_Status_OK;
}

OT_Status ImpInterruptInterface::SetDisableMask(ot_uint32_t disableMask)
{
	_mask &= ~disableMask;
	SetMask_Transaction transaction(disableMask, false);
	_pIoDevice->SendTransaction(&transaction);

	return OT_Status_OK;
}

OT_Status ImpInterruptInterface::ScheduleWaitForInterrupt(IInterruptWaitPtr *spWait)
{
	// Create a new IInterruptWait and schedule the hardware
	ImpInterruptWait *pInterruptWait = new ImpInterruptWait(this, _pIoDevice, _ticksPerSecond,
															_createInterruptTransaction(_numIntBits));
	if( !pInterruptWait->bIsValid() )
	{
		delete pInterruptWait;
		return OT_Status_Memory_Allocation_Fail;
	}

	// The Wait object has been created correctly, so we can now schedule to the Hardware
	OT_Status status = pInterruptWait->Schedule();
	if( status == OT_Status_Request_Pending )
	{
		// Let the smart pointer take ownership of the memory
		IInterruptWaitPtr spLocalWait(pInterruptWait);
		*spWait = spLocalWait;

		status = OT_Status_OK;
	}
	else
		delete pInterruptWait;

	return status;
}

IInterruptInterfacePtr ImpInterruptInterface::CreateInterruptInterface(IoDevice* pIoDevice, ICapability *pParent,
																		InterruptTransactionFactory transactionFactory)
{
	ImpInterruptInterface *pInterface = NULL;
	AcquireInterrupt_Transaction acquireTransaction;

	if( pIoDevice->SendTransaction(&acquireTransaction) == 0 )
	{
		pInterface = new ImpInterruptInterface(pIoDevice, pParent, acquireTransaction.GetNumBits(), std::move(transactionFactory));
	}
	return pInterface;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

ImpInterruptWait::ImpInterruptWait(IInterruptInterfacePtr spParent, IoDevice *pPlatformDevice, otTime ticksPerSecond,
									InterruptEvent_TransactionBasePtr spTransaction)
	: _spParent(spParent)
	, _spTransaction(std::move(spTransaction))
	, _pPlatformDevice(pPlatformDevice)
	, _bComplete(false)
	, _ticksPerSecond(ticksPerSecond)
{

}

ImpInterruptWait::~ImpInterruptWait()
{
	_pPlatformDevice->CancelTransaction(_spTransaction.get());
	_pPlatformDevice->WaitForTransaction(_spTransaction.get(), OT_INT_DEFAULT_TIMEOUT);
}

OT_Status ImpInterruptWait::Schedule()
{
	return _pPlatformDevice->ScheduleTransaction(_spTransaction.get());
}

OT_Status ImpInterruptWait::Wait(ot_int32_t Timeout)
{
	OT_Status status = _pPlatformDevice->WaitForTransaction(_spTransaction.get(), Timeout);

	if( status == OT_Status_OK )
		_bComplete = true;

	return status;
}

otEventHandle ImpInterruptWait::GetCompletionHandle()
{
	return _spTransaction->GetCompletetionHandle();
}

ot_uint32_t ImpInterruptWait::GetCompleteMask()
{
	return _bComplete?_spTransaction->GetSetMask():0;
}

ot_uint32_t ImpInterruptWait::GetInterruptCount(ot_uint32_t theBit)
{
	if( theBit < _spTransaction->GetNumBits() )
		return _bComplete ? _spTransaction->GetIntCount(theBit):0;

	return OT_Status_InvalidParameter;
}

OT_Status ImpInterruptWait::GetInterruptTime(ot_uint32_t theBit, otTime &ticks)
{
	if( !_bComplete )
		return OT_Status_Request_Pending;

	if( theBit < _spTransaction->GetNumBits() )
	{
		if( _ticksPerSecond == 0)
			return OT_Status_Timing_Not_Implemented;

		ticks = _spTransaction->GetIntTime(theBit);

		return OT_Status_OK;
	}

	return OT_Status_InvalidParameter;
}

OT_Status ImpInterruptWait::GetTimingFrequency(otTime &ticksPerSecond)
{
	ticksPerSecond = _ticksPerSecond;
	return (ticksPerSecond!=0)?OT_Status_OK:OT_Status_Timing_Not_Implemented;
}
