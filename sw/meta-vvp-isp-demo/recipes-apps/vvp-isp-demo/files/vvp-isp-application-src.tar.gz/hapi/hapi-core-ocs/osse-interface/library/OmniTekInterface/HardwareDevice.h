/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "global_defs.h"
#include "Interrupt_IOCTL.h"
#include "IOmniTekTypes.h"

using namespace OmniTek;

#if BUILDTYPE == BT_LINUX
typedef void OVERLAPPED;
typedef ot_int32_t	 HANDLE;
#endif

#if BUILDTYPE==BT_WINDOWS
#define Ioctl_Struct(ioctlName) ioctlName
#define Ioctl_Payload(ioctl) ioctl->
#else
#include <sys/eventfd.h>
#define Ioctl_Struct(ioctlName) ioctlName##_Linux
#define Ioctl_Payload(ioctl) ioctl->IOCTLInfo.
#endif

class IoOverlappedTransactionBase
{
public:
	virtual ~IoOverlappedTransactionBase() {};

	virtual ot_uint32_t	GetIoctlNum() = 0;
	virtual ot_uint32_t GetIoctlSize() =0;
	virtual void		*GetIoctl() = 0;

	virtual otEventHandle	GetCompletetionHandle() = 0;
#if BUILDTYPE == BT_WINDOWS
	virtual OVERLAPPED		*GetOverlapped() = 0;
#else
	virtual CapGeneral_EventCtx_IOCTL *GetEventIoctlCtx() = 0;
#endif
};

template <typename Base, typename IoctlStruct, ot_uint32_t IoctlVersion, ot_uint32_t IoctlNum>
class IoOverlappedTransaction : public Base
{
public:
	IoOverlappedTransaction(const IoOverlappedTransaction& other) = delete;
	IoOverlappedTransaction(IoOverlappedTransaction&& other) = delete;
	IoOverlappedTransaction& operator=(const IoOverlappedTransaction& other) = delete;
	IoOverlappedTransaction& operator=(IoOverlappedTransaction&& other) = delete;

	IoOverlappedTransaction(ot_uint32_t payloadSize)
		: _pIoctl(NULL)
	{
		_ioctlSize = sizeof(IoctlStruct) + payloadSize;
		_pIoctl = (IoctlStruct*)malloc(_ioctlSize);
		if (!_pIoctl)
		{
			return;
		}

#if BUILDTYPE == BT_WINDOWS
		INIT_IOCTL(_pIoctl, IoctlVersion, _ioctlSize);
		// Create the overlapped event
		_ol.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
		if( _ol.hEvent == INVALID_HANDLE_VALUE )
		{
			free(_pIoctl);
			_pIoctl = NULL;
		}
#else
		INIT_IOCTL(&(_pIoctl->IOCTLInfo), IoctlVersion, sizeof(_pIoctl->IOCTLInfo) + payloadSize);
		_pIoctl->EventInfo.EventFD = eventfd(0,0);
		if( _pIoctl->EventInfo.EventFD < 0 )
		{
			free(_pIoctl);
			_pIoctl = NULL;
		}
#endif
	};

	virtual ~IoOverlappedTransaction()
	{
		if( _pIoctl )
		{
#if BUILDTYPE == BT_WINDOWS
			::CloseHandle(_ol.hEvent);
#else
			if( _pIoctl->EventInfo.EventFD > -1 )
			{
				close(_pIoctl->EventInfo.EventFD);
				_pIoctl->EventInfo.EventFD = -1;
			}
			else
			{
				perror("Error: ~IoOverlappedTransaction - EventFd already closed\n");
				assert(0);
			}
#endif
			free(_pIoctl); _pIoctl=NULL;
		}
	};

	virtual ot_uint32_t	GetIoctlNum() {return IoctlNum;};
	virtual ot_uint32_t GetIoctlSize() {return _ioctlSize;};
	virtual void		*GetIoctl() {return _pIoctl;};

#if BUILDTYPE == BT_WINDOWS
	virtual OVERLAPPED		*GetOverlapped() { return &_ol;};
	virtual otEventHandle	GetCompletetionHandle() {return _ol.hEvent;};
#else
	virtual CapGeneral_EventCtx_IOCTL *GetEventIoctlCtx() {return &(_pIoctl->EventInfo);};
	virtual otEventHandle	GetCompletetionHandle()
	{
		otEventHandle handle = -1;
		if( _pIoctl )
			handle = _pIoctl->EventInfo.EventFD;

		return handle;
	};
#endif

	bool		bIsValid()
	{
		return (_pIoctl != NULL);
	}

#if BUILDTYPE == BT_WINDOWS
	IoctlStruct *_pIoctl;
	OVERLAPPED	_ol;
#else
	IoctlStruct *_pIoctl;
#endif

private:
	ot_uint32_t	_ioctlSize;
};

struct IoTransaction
{
public:
	virtual ~IoTransaction() {};

	virtual void			*GetIoctl() = 0;
	virtual const void		*GetIoctl() const = 0;
	virtual ot_uint32_t	GetSize() const = 0;
	virtual ot_uint32_t	GetIoctlNum() const = 0;
};

class IoDevice
{
public:
	virtual ~IoDevice() {};

	virtual void Close() = 0;
	virtual bool bIsValid() = 0;

	virtual ot_uint32_t SendTransaction(IoTransaction *pTransaction) = 0;
	virtual ot_uint32_t GetTransactionResult(IoTransaction *pTransaction) = 0;

	virtual OT_Status CancelTransaction(IoOverlappedTransactionBase *pTransaction) = 0;
	virtual OT_Status ScheduleTransaction(IoOverlappedTransactionBase *pTransaction) = 0;
	virtual OT_Status WaitForTransaction(IoOverlappedTransactionBase *pTransaction, ot_int32_t msTimeout) = 0;

	virtual HANDLE GetFileHandle() = 0;
};

#if BUILDTYPE == BT_WINDOWS
class PlatformIoDevice : public IoDevice
{
public:
	PlatformIoDevice(const char *path);
	~PlatformIoDevice();
public:
	virtual void Close();
	virtual bool bIsValid();
	virtual ot_uint32_t SendTransaction(IoTransaction *pTransaction);
	virtual ot_uint32_t GetTransactionResult(IoTransaction *pTransaction);

	virtual OT_Status CancelTransaction(IoOverlappedTransactionBase *pTransaction);
	virtual OT_Status ScheduleTransaction(IoOverlappedTransactionBase *pTransaction);
	virtual OT_Status WaitForTransaction(IoOverlappedTransactionBase *pTransaction, ot_int32_t msTimeout);

	// Debug
	HANDLE GetFileHandle() {return _hDev;};
private:
	HANDLE _hDev;
};
#else
class PlatformIoDevice : public IoDevice
{
public:
	PlatformIoDevice(const char *path);
	~PlatformIoDevice();
public:
	virtual void Close();
	virtual bool bIsValid();
	virtual ot_uint32_t SendTransaction(IoTransaction *pTransaction);
	virtual ot_uint32_t GetTransactionResult(IoTransaction *pTransaction);

	virtual OT_Status CancelTransaction(IoOverlappedTransactionBase *pTransaction);
	virtual OT_Status ScheduleTransaction(IoOverlappedTransactionBase *pTransaction);
	virtual OT_Status WaitForTransaction(IoOverlappedTransactionBase *pTransaction, ot_int32_t msTimeout);

	HANDLE GetFileHandle();

private:
	// Disable copying
	PlatformIoDevice(const PlatformIoDevice& other);
	PlatformIoDevice& operator=(const PlatformIoDevice& other);

	ot_int32_t					_hDev;
};
#endif
