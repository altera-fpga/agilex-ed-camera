/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpDmaBase.h"
#include "ImpDmaChannel.h"
#include "InternalCapability.h"
#include "OTCapabilityTypes.h"
#include "ImpBoard.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
DmaBuffer::DmaBuffer(void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bVirtualAddress, bool bSyncBuffer)
	: _pBuffer(pBuffer)
	, _localAddr(LocalAddr)
	, _size(Size)
	, _bVirtualAddress(bVirtualAddress)
	, _bSyncBuffer(bSyncBuffer)
{
}
void*		DmaBuffer::GetBufferAddress()
{
	return _pBuffer;
}

ot_uint32_t	DmaBuffer::GetLocalAddress()
{
	return _localAddr;
}

ot_uint32_t	DmaBuffer::GetBufferSize()
{
	return _size;
}

bool		DmaBuffer::bVirtualAddress()
{
	return _bVirtualAddress;
}

bool		DmaBuffer::bSyncBuffer()
{
	return _bSyncBuffer;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ImpDmaTransaction::ImpDmaTransaction(bool bAllowRead, bool bAllowWrite, ot_uint32_t maxBuffers)
	: _bAllowRead(bAllowRead)
	, _bAllowWrite(bAllowWrite)
	, _maxBuffers(maxBuffers)
{
}

void ImpDmaTransaction::ClearBuffers()
{
	_buffers.clear();
}

DmaBuffer* ImpDmaTransaction::GetBuffer(ot_uint32_t idx)
{
	if( idx >= (ot_uint32_t)_buffers.size() )
		return NULL;
	
	return &_buffers[idx];
}

ImpDmaTransaction::~ImpDmaTransaction()
{
}

ot_uint32_t ImpDmaTransaction::GetMaxBuffers()
{
	return _maxBuffers;
}

ot_uint32_t ImpDmaTransaction::GetNumBuffers()
{
	return (ot_uint32_t)_buffers.size();
}

OT_Status ImpDmaTransaction::AddVirtualBuffer(void *pBuffer,  ot_uint32_t LocalAddr, ot_uint32_t Size, bool bSyncBuffer)
{
	// Check that we haven't exceed the max number of targets for
	if( (ot_uint32_t)_buffers.size() >= _maxBuffers )
		return OT_Status_Max_Buffers;

	// All's well so add to the buffers
	_buffers.push_back(DmaBuffer(pBuffer, LocalAddr, Size, true, bSyncBuffer));

	return OT_Status_OK;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ImpDmaXfer::ImpDmaXfer(IDmaChannelPtr& spDmaChannel)
	: _pBuffer(NULL)
	, _transferSize(0)
	, _localAddr(0)
	, _spDmaChannel(spDmaChannel)
{
}

ImpDmaXfer::~ImpDmaXfer()
{
}

void ImpDmaXfer::SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer)
{
	_pBuffer		= pBuffer;
	_transferSize	= size;
	_localAddr		= localAddr;
	_SetTarget(target, pBuffer, localAddr, size, bSyncBuffer);
}

void ImpDmaXfer::SetVersion(ot_uint32_t version)
{
	_SetVersion(version);
}
void ImpDmaXfer::_EarlyReleaseCount()
{
	// DMA channel may be destroyed when this Xfer is cancelled below.
	// Keep the channel alive by creating a local reference.
	IDmaChannelPtr spKeepChannelAlive = _spDmaChannel;

	if( _spDmaChannel )
	{
		// When the reference count gets to 1 it means the DMA Channel itself is the only person holding onto it
		// so cancel the request as the client doesn't care about it anymore
		ImpDmaBase *pDma = (ImpDmaBase*)(IDmaChannel*)_spDmaChannel;
		pDma->CancelXfer(this);
		_spDmaChannel = NULL; // Release the parent as we don't need to cancel the request any more
	}
}

OT_Status ImpDmaXfer::XferWait(ot_int32_t timeout)
{
	OT_Status status;
	ImpDmaBase *pDma = NULL;

	{
		EAutoLock lock(ImpOmniTekBasePtr::GetLock());

		pDma = (ImpDmaBase*)(IDmaChannel*)_spDmaChannel;
	}

	if( pDma )
		status = pDma->MemoryXferWait(this, timeout);
	else
		status = OT_Status_Request_Cancelled;
	return status;
}

void ImpDmaXfer::ClearParent()
{
	EAutoLock lock(ImpOmniTekBasePtr::GetLock());
	// Release the parent lock
	_spDmaChannel = NULL;
}

//////////////////////////////////////////////////////////////////////////////////////////////////
ImpDmaEventXfer::ImpDmaEventXfer(ImpDmaEventBasePtr& spDmaEventBase)
	: ImpOmniTekBasePtr(NULL)
	, _spDmaEventBase(spDmaEventBase)
{
}

ImpDmaEventXfer::~ImpDmaEventXfer()
{
}

void ImpDmaEventXfer::_EarlyReleaseCount()
{
	// DMA event object may be destroyed in XferWait below.
	// Keep the channel alive by creating a local reference.
	ImpDmaEventBasePtr spKeepEventAlive = _spDmaEventBase;

	if( _spDmaEventBase )
	{
		// Cancel the IO Request
		PlatformDmaEventXfer *pXfer = (PlatformDmaEventXfer*)this;
		_spDmaEventBase->Cancel(pXfer);

		_spDmaEventBase->XferWait(this, 0);
		_spDmaEventBase = NULL; // Release the parent as we don't need to cancel anymore
	}
}

OT_Status ImpDmaEventXfer::XferWait(ot_int32_t Timeout)
{
	OT_Status status = OT_Status_Request_Cancelled;
	ImpDmaEventBasePtr spDmaEventBase;

	{
		EAutoLock lock(ImpOmniTekBasePtr::GetLock());
		spDmaEventBase = _spDmaEventBase;
	}

	if( spDmaEventBase )
		status = spDmaEventBase->XferWait(this, Timeout);

	return status;
}

void ImpDmaEventXfer::ClearParent()
{
	EAutoLock lock(ImpOmniTekBasePtr::GetLock());
	// Release the parent
	_spDmaEventBase = NULL;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ImpDmaEventBase::ImpDmaEventBase(PlatformImpDma *pDmaChannel)
	: ImpOmniTekBasePtr(NULL)
	, _pDmaChannel(pDmaChannel)
{
}

ImpDmaEventBase::~ImpDmaEventBase()
{
	Clear();
}

IDmaEventXferPtr ImpDmaEventBase::GetFirstPendingXfer()
{
	EAutoLock lock(_pendingLock);
	IDmaEventXferPtr	spXfer;
	if( !_pendingList.empty() )
	{
		omDmaEventXferList::iterator iter = _pendingList.begin();
		spXfer = iter->second;
	}
	return spXfer;
}

void ImpDmaEventBase::Clear()
{
	// Clear Wait for all the Overlapped structures to complete
	while( true )
	{
		IDmaEventXferPtr spXfer;
		spXfer = GetFirstPendingXfer();

		if( spXfer )
		{
			XferWait(spXfer, OT_DMA_DEFAULT_TIMEOUT);
		}
		else
			break;
	}
}

OT_Status ImpDmaEventBase::GetTransferSize(ot_uint32_t &bytesTransferred, ot_int32_t Timeout)
{
	OT_Status status = OT_Status_Fail;

	IDmaEventXferPtr spDmaEventPtr;

	if( (status = ScheduleGetTransferSize(&spDmaEventPtr)) == OT_Status_OK )
	{
		if( (status = XferWait(spDmaEventPtr, Timeout)) == OT_Status_OK )
		{
			bytesTransferred = spDmaEventPtr->GetBytesTransferred();
		}
	}

	return status;
}

OT_Status ImpDmaEventBase::ScheduleGetTransferSize(IDmaEventXferPtr *spDmaEventXfer)
{
	if (!spDmaEventXfer)
	{
		return OT_Status_InvalidParameter;
	}

	OT_Status status = OT_Status_Fail;

	// Create a PlatformDmaEventXfer
	PlatformDmaEventXfer *pXfer = new PlatformDmaEventXfer(this);

	// Send the Ioctl to the HARDWARE
	if( (status = SendIoctl(pXfer) )== OT_Status_Request_Pending )
	{
		IDmaEventXferPtr spEventXfer(pXfer);

		EAutoLock lock(_pendingLock);
		_pendingList.insert(std::make_pair(pXfer, spEventXfer));
		*spDmaEventXfer=spEventXfer;
		status = OT_Status_OK;
	}
	else
		delete pXfer;

	return status;
}

OT_Status ImpDmaEventBase::SetTransferSize(ot_uint32_t bytesTransferred)
{
	PlatformDmaEventXfer xfer(this);
	xfer.SetBytesTransferred(bytesTransferred);

	return SendIoctl(&xfer);
}

OT_Status ImpDmaEventBase::Cancel(PlatformDmaEventXfer *pXfer)
{
	return _Cancel(pXfer);
}

OT_Status ImpDmaEventBase::XferWait(ImpDmaEventXfer *pXfer, ot_int32_t Timeout)
{
	OT_Status status = OT_Status_OK;

	// Wait for the event in the overlapped structure to complete
	PlatformDmaEventXfer *pTransaction = (PlatformDmaEventXfer*)pXfer;

	if( pTransaction == NULL )
		return OT_Status_InvalidParameter;

	status = _WaitXfer(pTransaction, Timeout);

	// Assume it passed - TODO: Need to do a GetOverlappedResult really

	if( (status == OT_Status_OK) || (status == OT_Status_Request_Failed) || (status == OT_Status_Request_Cancelled) )
	{
		IDmaEventXferPtr spTemp;
		{
			// Remove the Transaction from the pending list
			EAutoLock lock(_pendingLock);

			omDmaEventXferList::iterator iter = _pendingList.find(pTransaction);
			if( iter != _pendingList.end() )
			{
				spTemp = iter->second;

				// Clear the parent on this transaction as we know that the transaction has finished
				pXfer->ClearParent();
				_pendingList.erase(iter);
			}
		}
	}
	return status;
}

OT_Status ImpDmaEventBase::XferWait(IDmaEventXferPtr &spDmaEventXfer, ot_int32_t Timeout)
{
	// Wait for the event in the overlapped structure to complete
	ImpDmaEventXfer *pTransaction = (ImpDmaEventXfer*)(IDmaEventXfer*)spDmaEventXfer;

	return XferWait(pTransaction, Timeout);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ImpDmaBase::ImpDmaBase(OTParentTracker* pParentTracker, InternalCapability *pOmniTekCapability, OT_DMA_Type_BitField bitFieldType)
	: ImpOmniTekBasePtr(pParentTracker)
	, _pName(NULL)
	, _pOmniTekCapability(pOmniTekCapability)
	, _pCapability(pOmniTekCapability->GetRegisterCapability())
	, _bitFieldtype(bitFieldType)
	, _maxSingleTransferSize(0)
	, _minSingleTransferSize(0)
	, _minBufferDepth(0)
	, _maxTargets(1)
	, _bReadSupported(false)
	, _bWriteSupported(false)
	, _bValid(false)
	, _pendingLock()
	, _pendingList()
{
	uint64_t result;

	// Need to setup which direction is supported
	if( _pOmniTekCapability->QueryCommonCapabilities(QueryInfo_DMADirectionRead, result) == OT_Status_OK )
		_bReadSupported = (result!=0);

	if( _pOmniTekCapability->QueryCommonCapabilities(QueryInfo_DMADirectionWrite, result) == OT_Status_OK )
		_bWriteSupported = (result!=0);

	// Check that the DMA has atleast one direction supported
	if( !bIsReadSupported() && !bIsWriteSupported() )
	{
		_bValid = false; // We must have a direction
		return;
	}
	// Read the min transfer size
	if( _pOmniTekCapability->QueryCommonCapabilities(QueryInfo_DMAMinTransferBytes, result) == OT_Status_OK )
		_minSingleTransferSize = (ot_uint32_t)result;

	// Read the maximum number of targets can be bundled in a request
	if( _pOmniTekCapability->QueryCommonCapabilities(QueryInfo_DMAMaxTargets, result) == OT_Status_OK )
		_maxTargets = (ot_uint32_t)result;

	// Assume we're are going to succeed and mark the DMA as valid
	_bValid = true;
}


ImpDmaBase::~ImpDmaBase(void)
{
	// Make sure that the DMA channel is stopped
//	Stop();
}

ot_uint32_t ImpDmaBase::GetMaxTargets()
{
	return _maxTargets;
}

OT_Status ImpDmaBase::GetTimingCounter(otTime &ticks)
{
	return _pOmniTekCapability->GetTimingCounter(ticks);
}

OT_Status ImpDmaBase::GetTimingFrequency(otTime &ticksPerSecond)
{
	return _pOmniTekCapability->GetTimingFrequency(ticksPerSecond);
}

ot_uint32_t ImpDmaBase::Release()
{
	ot_uint32_t lockCount = ImpOmniTekBasePtr::Release();
	
	//if( lockCount == 1 ) // All client references have gone if the Lock Count == 1
	//{
	//	// Call stop when all clients have released this interface
	//	Stop();
	//}
	return lockCount;
}

OT_DMA_Type_BitField ImpDmaBase::GetBitFieldType()
{
	return _bitFieldtype;
}

OT_DMA_Type	ImpDmaBase::GetType()
{
	return OT_GET_DMA_TYPE(_bitFieldtype);
}

OT_DMA_Direction ImpDmaBase::GetDirection()
{
	return OT_GET_DMA_DIRECTION(_bitFieldtype);
}

OT_DMA_ContentType ImpDmaBase::GetContentType()
{
	return OT_GET_DMA_CONTENT_TYPE(_bitFieldtype);
}

ICapability* ImpDmaBase::GetCapability()
{
	return _pOmniTekCapability;
}

IBoard*	ImpDmaBase::GetBoard()
{
	return NULL;
}

ot_uint32_t ImpDmaBase::GetMinSingleTransferSize()
{
	return _minSingleTransferSize;
}

//ot_uint32_t ImpDmaBase::GetMaxSingleTransferSize()
//{
//	return _maxSingleTransferSize;
//}
//
//ot_int32_t ImpDmaBase::GetMinBufferDepth()
//{
//	return _minBufferDepth;
//}

bool ImpDmaBase::bIsReadSupported()
{
	return _bReadSupported;
}

bool ImpDmaBase::bIsWriteSupported()
{
	return _bWriteSupported;
}

bool ImpDmaBase::bIsValid()
{
	return _bValid;
}

void ImpDmaBase::SetInvalid()
{
	_bValid = false;
}

// Implementation for DMA Transfers
OT_Status ImpDmaBase::Start()
{
	return OT_Status_OK;
}

IDmaXferPtr ImpDmaBase::AddToTransactionPending(ImpDmaXfer *pTransaction)
{
	// Lock the pending lock
	EAutoLock lock(_pendingLock);

	IDmaXferPtr spTransaction(pTransaction);

	_pendingList.insert(std::make_pair(pTransaction, spTransaction));

	return spTransaction;
}

void ImpDmaBase::CancelXfer(IDmaXfer* pDmaXfer)
{
	PlatformImpDmaXfer *pTransaction = (PlatformImpDmaXfer*)pDmaXfer;

	// Ask the platform to cancel this request
	PlatformCancelXfer(pTransaction);

	// Now wait until the transaction has been cancelled
	static_cast<void>(MemoryXferWait(pTransaction, 0));
}

OT_Status ImpDmaBase::_MemoryXferWait( PlatformImpDmaXfer *pDmaXfer, ot_int32_t timeout)
{
	return PlatformMemoryXferWait(pDmaXfer, timeout);
}

OT_Status ImpDmaBase::MemoryXferWait( PlatformImpDmaXfer* pTransaction, ot_int32_t timeout)
{
	OT_Status status = OT_Status_OK;

	if( pTransaction == NULL )
		return OT_Status_InvalidParameter;

	status = _MemoryXferWait(pTransaction, timeout);

	// Assume it passed - TODO: Need to do a GetOverlappedResult really

	if( (status == OT_Status_OK) || (status == OT_Status_Request_Failed)||(status == OT_Status_Request_Cancelled))
	{
		IDmaXferPtr spTemp;

		{
			// Remove the Transaction from the pending list
			EAutoLock lock(_pendingLock);

			omDmaXferList::iterator iter = _pendingList.find(pTransaction);
			if( iter != _pendingList.end() )
			{
				spTemp = iter->second;
				pTransaction->ClearParent(); // Clear the parent on this transaction so that it is not cancelled in early release
				_pendingList.erase(iter);
			}
		}
	}
	return status;
}

OT_Status ImpDmaBase::MemoryXferWait( IDmaXferPtr spDmaXfer, ot_int32_t timeout)
{
	// Wait for the event in the overlapped structure to complete
	PlatformImpDmaXfer *pTransaction = (PlatformImpDmaXfer*)(IDmaXfer*)spDmaXfer;
	return MemoryXferWait(pTransaction, timeout);
}


IDmaXferPtr ImpDmaBase::GetFirstPendingXfer()
{
	EAutoLock lock(_pendingLock);
	IDmaXferPtr	spXfer;
	if( !_pendingList.empty() )
	{
		omDmaXferList::iterator iter = _pendingList.begin();
		spXfer = iter->second;
	}
	return spXfer;
}

/////////////////////////////////////////////////////////////////////////////////

ImpVideoFDma::ImpVideoFDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, ot_uint32_t fdma_type)
	: PlatformImpVideoFDma(pParentTracker, pCapability, fdma_type)
	, _spDmaEvent{nullptr}
	, _bGpuDirectSupported{false}
{
	// Now check that we don't have Bidirection support
	if( bIsReadSupported() && bIsWriteSupported() )
		SetInvalid(); // If the FDMA is bi-directional then we've got something wrong

	InternalRegisterCapability *pRegCap = pCapability->GetRegisterCapability();
	if( pRegCap )
	{
		uint64_t result;
		if( pRegCap->QueryInfo(QueryInfo_DMAEventsSupported, result) == OT_Status_OK )
		{
            if( result == 1 )
				_spDmaEvent = new PlatformImpDmaEvent(this);
		}

		if( pRegCap->QueryInfo(QueryInfo_DMAGpuDirectSupported, result) == OT_Status_OK )
		{
			_bGpuDirectSupported = result;
		}
	}
}

ImpVideoFDma::~ImpVideoFDma()
{
}

PlatformImpDmaXfer* ImpVideoFDma::AllocateTransaction(ot_int32_t nTargets, bool bWrite, int version)
{
	if ( version >= CAP_VIDEOFDMA_IOCTL_Transfer_Version2 )
	{
		PlatformImpVideo_FDMAXferV2 *pDmaXfer = new PlatformImpVideo_FDMAXferV2(this, nTargets, bWrite);
		if( pDmaXfer && !pDmaXfer->bIsValid() ) // If not valid then return NULL
		{
			delete pDmaXfer;
			pDmaXfer = NULL;
		}

		if ( pDmaXfer ) // Set the version number for the IOCTL
			pDmaXfer->SetVersion(version);
			
		return pDmaXfer;
	}
	else
	{
		PlatformImpVideo_FDMAXfer *pDmaXfer = new PlatformImpVideo_FDMAXfer(this, nTargets, bWrite, CAP_VIDEOFDMA_IOCTL_Transfer);
		if( pDmaXfer && !pDmaXfer->bIsValid() ) // If not valid then return NULL
		{
			delete pDmaXfer;
			pDmaXfer = NULL;
		}

		if ( pDmaXfer ) // Set the version number for the IOCTL
			pDmaXfer->SetVersion(version);
			
		return pDmaXfer;
	}
}	

PlatformImpDmaXfer* ImpVideoFDma::AllocateTransactionGpuDirect(ot_int32_t nTargets, bool bWrite, int version)
{
	PlatformImpVideo_FDMAXfer *pDmaXfer = new PlatformImpVideo_FDMAXfer(this, nTargets, bWrite, CAP_VIDEOFDMA_IOCTL_TransferGpuDirect);
	if( pDmaXfer && !pDmaXfer->bIsValid() ) // If not valid then return NULL
	{
		delete pDmaXfer;
		pDmaXfer = NULL;
	}

	if ( pDmaXfer ) // Set the version number for the IOCTL
		pDmaXfer->SetVersion(version);

	return pDmaXfer;
}

OT_Status ImpVideoFDma::MemoryXferScheduleTransaction( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bSyncBuffer,
														PlatformImpDmaXfer *pTransaction, IDmaXferPtr *spDmaXfer)
{
	if( pTransaction == NULL )
		return OT_Status_Memory_Allocation_Fail;

	pTransaction->SetTarget(0, pBuffer, LocalAddr, Size, bSyncBuffer);

	OT_Status status = SendDmaXferRequest(pTransaction, true);
	if( status != OT_Status_Request_Pending )
	{
		// Failed so clean-up
		delete pTransaction;

		return OT_Status_Fail;
	}

	// The transaction was queued, now add to the pendingList and setup the smart pointer
	// Note: AddToTransactionPending now owns the transaction so we don't need to delete 
	// the transaction. Infact it would be really bad if it was deleted
	*spDmaXfer = AddToTransactionPending(pTransaction);

	return OT_Status_OK;
}

OT_Status ImpVideoFDma::MemoryXfer(void *pBuffer,  ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, otDmaTiming *pTiming, ot_int32_t timeout)
{
	OT_Status status = OT_Status_OK;

	// Stop any outstanding DMA transfers
	Stop();

	IDmaXferPtr spDmaXfer;
	
	if( (status=MemoryXferSchedule(pBuffer, LocalAddr, Size, bWrite, &spDmaXfer)) == OT_Status_OK )
	{
		// The Transfer is ready to go, so start it
		if( (status = Start()) == OT_Status_OK )
		{
			if (bWrite && _spDmaEvent)
			{
				// For event-based DMA, signal that all data in the buffer is available now
				_spDmaEvent->SetTransferSize(Size);
			}

			// Wait for the transfer to complete
			status = MemoryXferWait(spDmaXfer, timeout);

			if( status == OT_Status_OK )
				spDmaXfer->GetTransactionTime(pTiming);

			// Stop the DMA Engine
			Stop();
		}
	}
	return status;
}

OT_Status ImpVideoFDma::MemoryXferSchedule( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer)
{
	// Check that we have an IDmaXferPtr
	if( spDmaXfer == NULL )
		return OT_Status_InvalidParameter;

	PlatformImpDmaXfer *pTransaction = AllocateTransaction(1, bWrite, CAP_VIDEOFDMA_IOCTL_Transfer_Version0);
	return MemoryXferScheduleTransaction( pBuffer, LocalAddr, Size, true, pTransaction, spDmaXfer );
}

OT_Status ImpVideoFDma::MemoryXferSchedule2( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer)
{
	// Check that we have an IDmaXferPtr
	if( spDmaXfer == NULL )
		return OT_Status_InvalidParameter;

	PlatformImpDmaXfer *pTransaction = AllocateTransaction(1, bWrite, CAP_VIDEOFDMA_IOCTL_Transfer_Version1);
	return MemoryXferScheduleTransaction( pBuffer, LocalAddr, Size, bSyncBuffer, pTransaction, spDmaXfer );
}

OT_Status ImpVideoFDma::MemoryXferSchedule3( IDmaTransactionPtr spDmaTransaction, bool bWrite, IDmaXferPtr *spDmaXfer )
{
	if( spDmaXfer == NULL )
		return OT_Status_InvalidParameter;
	
	if( spDmaTransaction->GetNumBuffers() == 0 ) 
		return OT_Status_Buffer_Too_Small;

	PlatformImpDmaXfer *pTransaction = AllocateTransaction(spDmaTransaction->GetNumBuffers(), bWrite, CAP_VIDEOFDMA_IOCTL_Transfer_Version2);
	if( pTransaction == NULL )
		return OT_Status_Memory_Allocation_Fail;

	ImpDmaTransaction *pDmaTransaction = (ImpDmaTransaction*)((IDmaTransaction*)spDmaTransaction);
	for( ot_uint32_t idx=0; idx<pDmaTransaction->GetNumBuffers(); idx++)
	{
		DmaBuffer *pBuffer = pDmaTransaction->GetBuffer(idx);
		pTransaction->SetTarget(idx, pBuffer->GetBufferAddress(), pBuffer->GetLocalAddress(), pBuffer->GetBufferSize(), pBuffer->bSyncBuffer());
	}

	OT_Status status = SendDmaXferRequest(pTransaction, true);
	if( status != OT_Status_Request_Pending )
	{
		// Failed so clean-up
		delete pTransaction;

		return OT_Status_Fail;
	}

	// The transaction was queued, now add to the pendingList and setup the smart pointer
	// Note: AddToTransactionPending now owns the transaction so we don't need to delete
	// the transaction. Infact it would be really bad if it was deleted
	*spDmaXfer = AddToTransactionPending(pTransaction);

	return OT_Status_OK;
}

IDmaTransactionPtr ImpVideoFDma::AllocateDmaTransaction()
{
	IDmaTransactionPtr spDmaTransaction = new ImpDmaTransaction(bIsReadSupported(), bIsWriteSupported(), GetMaxTargets());
	return spDmaTransaction;
}

bool ImpVideoFDma::bIsGpuDirectSupported()
{
    return _bGpuDirectSupported;
}

OT_Status ImpVideoFDma::MemoryXferScheduleGpuDirect( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer)
{
	// Check that we have an IDmaXferPtr
	if( spDmaXfer == NULL )
		return OT_Status_InvalidParameter;

	if ( !bIsGpuDirectSupported() )
	{
		return OT_Status_Not_Implemented;
	}

	PlatformImpDmaXfer *pTransaction = AllocateTransactionGpuDirect(1, bWrite, CAP_VIDEOFDMA_IOCTL_Transfer_Version1);
	return MemoryXferScheduleTransaction( pBuffer, LocalAddr, Size, bSyncBuffer, pTransaction, spDmaXfer );
}

OT_Status ImpVideoFDma::Start()
{
	return PlatformStart();
}

OT_Status ImpVideoFDma::Stop()
{
	PlatformStop();
	
	// Clear Wait for all the Overlapped structures to complete
	while( true )
	{
		IDmaXferPtr spXfer;
		spXfer = GetFirstPendingXfer();

		if( spXfer )
		{
#ifdef __linux__
			// Cancel the
			ImpDmaBase::CancelXfer(spXfer);
#endif
			OT_Status status = MemoryXferWait(spXfer, OT_DMA_DEFAULT_TIMEOUT);
			if ((status != OT_Status_OK) && (status != OT_Status_Request_Cancelled))
				fprintf(stderr, "ImpVideoFDma::Stop; bad timeout %x, %p %d\n", status, GetCapability(), GetCapability()->GetUniqueID());
		}
		else
			break;
	}

	// Clear all the pending Event Request, if any are queued
	if( _spDmaEvent )
	{
		ImpDmaEventBase *pDmaEventBase = (ImpDmaEventBase*)(IDmaEvent*)_spDmaEvent;
		pDmaEventBase->Clear();
	}

	return OT_Status_OK;
}

IDmaEventPtr ImpVideoFDma::GetDmaEvent()
{
	return _spDmaEvent;
}

/////////////////////////////////////////////////////////////////////////////////


ImpMDma::ImpMDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, ot_uint32_t mdma_type)
	: PlatformImpMDma(pParentTracker, pCapability, mdma_type)
{
}

ImpMDma::~ImpMDma()
{
}

PlatformImpDmaXfer* ImpMDma::AllocateTransaction(ot_int32_t nTargets, bool bWrite, int version)
{
    if( version >= CAP_MDMA_IOCTL_Transfer_Version2 )
    {
        PlatformImpDmaXfer *pDmaXfer = new PlatformImpMDmaXferV2( this, nTargets, bWrite );
        if( pDmaXfer && ( !pDmaXfer->bIsValid( ) ) ) // If not valid then return NULL
        {
            delete pDmaXfer;
            pDmaXfer = NULL;
        }
        if ( pDmaXfer ) // Set the version number for the IOCTL
            pDmaXfer->SetVersion(version);

        return pDmaXfer;
    }
    else
    {
        PlatformImpDmaXfer *pDmaXfer = new PlatformImpMDmaXfer( this, nTargets, bWrite );
        if( pDmaXfer && ( !pDmaXfer->bIsValid( ) ) ) // If not valid then return NULL
        {
            delete pDmaXfer;
            pDmaXfer = NULL;
        }
        if ( pDmaXfer ) // Set the version number for the IOCTL
            pDmaXfer->SetVersion(version);

        return pDmaXfer;
    }
}	

OT_Status ImpMDma::MemoryXfer(void *pBuffer,  ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, otDmaTiming *pTiming, ot_int32_t timeout)
{
	OT_Status status = OT_Status_OK;

	IDmaXferPtr spDmaXfer;
	
	if( (status=MemoryXferSchedule(pBuffer, LocalAddr, Size, bWrite, &spDmaXfer)) == OT_Status_OK )
	{
		// Wait for the transfer to complete
		status = MemoryXferWait(spDmaXfer, timeout);
		if( status == OT_Status_OK )
			spDmaXfer->GetTransactionTime(pTiming);
	}
	return status;
}

OT_Status ImpMDma::MemoryXferSchedule( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer)
{
	// Check that we have an IDmaXferPtr
	if( spDmaXfer == NULL )
		return OT_Status_InvalidParameter;

	PlatformImpDmaXfer *pTransaction = AllocateTransaction(1, bWrite, CAP_MDMA_IOCTL_Transfer_Version0);
	if( pTransaction == NULL )
		return OT_Status_Memory_Allocation_Fail;

	pTransaction->SetTarget(0, pBuffer, LocalAddr, Size, true);

	OT_Status status = SendDmaXferRequest(pTransaction, true);

	if( status != OT_Status_Request_Pending )
	{
		// Clean up the transaction
		delete pTransaction;

		// Return that we failed
		return OT_Status_Fail;
	}

	// The transaction was queued, now add to the pendingList and setup the smart pointer
	// Note: AddToTransactionPending now owns the transaction so we don't need to delete 
	// the transaction. Infact it would be really bad if it was deleted
	*spDmaXfer = AddToTransactionPending(pTransaction);

	return OT_Status_OK;
}

// Note: Sync Buffer makes no sense for MDMA buffers, so do a regular schedule
OT_Status ImpMDma::MemoryXferSchedule2( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer)
{
	return MemoryXferSchedule(pBuffer, LocalAddr, Size, bWrite, spDmaXfer);
}

OT_Status ImpMDma::MemoryXferSchedule3( IDmaTransactionPtr spDmaTransaction, bool bWrite, IDmaXferPtr *spDmaXfer )
{
	if( spDmaXfer == NULL )
		return OT_Status_InvalidParameter;
	
	if( spDmaTransaction->GetNumBuffers() == 0 ) 
		return OT_Status_Buffer_Too_Small;

	PlatformImpDmaXfer *pTransaction = AllocateTransaction(spDmaTransaction->GetNumBuffers(), bWrite, CAP_MDMA_IOCTL_Transfer_Version2);
	if( pTransaction == NULL )
		return OT_Status_Memory_Allocation_Fail;

	ImpDmaTransaction *pDmaTransaction = (ImpDmaTransaction*)((IDmaTransaction*)spDmaTransaction);
	for( ot_uint32_t idx=0; idx<pDmaTransaction->GetNumBuffers(); idx++)
	{
		DmaBuffer *pBuffer = pDmaTransaction->GetBuffer(idx);
		pTransaction->SetTarget(idx, pBuffer->GetBufferAddress(), pBuffer->GetLocalAddress(), pBuffer->GetBufferSize(), pBuffer->bSyncBuffer());
	}

	OT_Status status = SendDmaXferRequest(pTransaction, true);
	if( status != OT_Status_Request_Pending )
	{
		// Failed so clean-up
		delete pTransaction;

		return OT_Status_Fail;
	}

	// The transaction was queued, now add to the pendingList and setup the smart pointer
	// Note: AddToTransactionPending now owns the transaction so we don't need to delete
	// the transaction. Infact it would be really bad if it was deleted
	*spDmaXfer = AddToTransactionPending(pTransaction);

	return OT_Status_OK;
}

IDmaTransactionPtr ImpMDma::AllocateDmaTransaction()
{
	IDmaTransactionPtr spDmaTransaction = new ImpDmaTransaction(bIsReadSupported(), bIsWriteSupported(), GetMaxTargets());
	return spDmaTransaction;
}

bool ImpMDma::bIsGpuDirectSupported()
{
    return false;
}

OT_Status ImpMDma::MemoryXferScheduleGpuDirect( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer)
{
    return OT_Status_Not_Implemented;
}

OT_Status ImpMDma::Stop()
{
	return OT_Status_Fail;
}
