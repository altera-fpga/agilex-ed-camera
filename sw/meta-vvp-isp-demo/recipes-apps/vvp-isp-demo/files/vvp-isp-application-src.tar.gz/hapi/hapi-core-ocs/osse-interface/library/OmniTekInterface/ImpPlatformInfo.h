/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"

using namespace OmniTek;

class HostController;
class ImpPlatformInfo : public IPlatformInfo, ImpOmniTekBasePtr
{
public:
	ImpPlatformInfo(OTParentTracker* pParentTracker, HostController *pHostController);
	virtual ~ImpPlatformInfo(void);


	virtual OT_PLATFORM_INTERFACE GetPlatformInterface();
	virtual OT_Status GetPCIeInfo(ot_uint32_t &gen, ot_uint32_t &lanes);
	virtual ot_uint32_t ReadPciConfig(void *pBuffer, ot_uint8_t offset, ot_uint8_t readSize);

	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR
protected:
	HostController *_pHostController;

	ot_uint8_t ReadPciConfigNextCapabilityOffset();
	ot_uint8_t ReadPciConfigHeaderType();
	ot_uint8_t GetPciConfigHeaderOffset(ot_uint8_t ID);
};

