/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the 
License.
*******************************************************************************/

#include "OcsHapiCore.h"
#include "OcsHapiItemTunnel.h"

namespace Hapi
{
    uint32_t OcsHapiItemTunnel::ReadRegister(uint32_t registerIndex)
    {
        uint32_t value = 0;
        if (_spRegisterBlock)
            _spRegisterBlock->ReadRegister(registerIndex, (OmniTek::ot_uint32_t&)value);

        return value;
    }

    void OcsHapiItemTunnel::WriteRegister(uint32_t registerIndex, uint32_t value)
    {
        if (_spRegisterBlock)
            _spRegisterBlock->WriteRegister(registerIndex, (OmniTek::ot_uint32_t)value);
    }
} // namespace Hapi