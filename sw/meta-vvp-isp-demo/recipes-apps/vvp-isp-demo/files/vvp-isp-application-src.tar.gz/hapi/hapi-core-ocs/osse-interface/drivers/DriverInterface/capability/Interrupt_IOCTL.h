/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef INTERRUPT_IOCTL_H_
#define INTERRUPT_IOCTL_H_

#include "global_defs.h"

#ifdef _MSC_VER
// warning C4200: nonstandard extension used : zero-sized array in struct/union
#pragma warning(disable: 4200)
#endif

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/** \addtogroup UserlandInterface
 *  @{
 */

/** \cond */

#define CAP_INTERRUPT_IOC_MAGIC (4)
/** \endcond */

/** \cond */

/**
 * This interface is currently limiting the number of possible status / enable bits to 32.
 * Only one file handle is allowed to own the controller.
 *
 * For LINUX:
 * To cancel queued interrupts use the standard cancel mechanism. CAP_COMMON_IOCTL_Cancel
 */

enum
{
    CAP_INTERRUPT_IOCTL_NUM_AcquireController  = OT_IOCTL_NUMBER(CAP_INTERRUPT_IOC_MAGIC , 1), //!< CapInterrupt_AcquireController_IOCTL
    CAP_INTERRUPT_IOCTL_NUM_ReleaseController  = OT_IOCTL_NUMBER(CAP_INTERRUPT_IOC_MAGIC , 2), //!< CapInterrupt_ReleaseController_IOCTL
    CAP_INTERRUPT_IOCTL_NUM_EnableMask         = OT_IOCTL_NUMBER(CAP_INTERRUPT_IOC_MAGIC , 3), //!< CapInterrupt_Mask_IOCTL
    CAP_INTERRUPT_IOCTL_NUM_DisableMask        = OT_IOCTL_NUMBER(CAP_INTERRUPT_IOC_MAGIC , 4), //!< CapInterrupt_Mask_IOCTL
    CAP_INTERRUPT_IOCTL_NUM_InterruptEvent     = OT_IOCTL_NUMBER(CAP_INTERRUPT_IOC_MAGIC , 5), //!< CapInterrupt_InterruptEvent_IOCTL. Linux uses the _Linux postfix version
};
/** \endcond */

#pragma pack(push,4)

/**
 * @brief IOCTL container for #CAP_INTERRUPT_IOCTL_AcquireController
 */
typedef struct _CapInterrupt_AcquireController_IOCTL
{
    uint32_t Version; //!< must be #CAP_INTERRUPT_IOCTL_VERSION_AcquireController
    uint32_t NumBits; //!< return value
} CapInterrupt_AcquireController_IOCTL;

/**
 * @brief IOCTL container for #CAP_INTERRUPT_IOCTL_ReleaseController
 */
typedef struct _CapInterrupt_ReleaseController_IOCTL
{
    uint32_t Version; //!< must be #CAP_INTERRUPT_IOCTL_VERSION_AcquireController
} CapInterrupt_ReleaseController_IOCTL;

/**
 * @brief IOCTL container for #CAP_INTERRUPT_IOCTL_EnableMask and #CAP_INTERRUPT_IOCTL_DisableMask
 *
 * If CAP_INTERRUPT_IOCTL_EnableMask
 * - Version: must be CAP_INTERRUPT_IOCTL_VERSION_EnableMask
 * - Mask: Bit mask to enable. This is an additive change
 *
 * If CAP_INTERRUPT_IOCTL_DisableMask
 * - Version: must be CAP_INTERRUPT_IOCTL_VERSION_DisableMask
 * - Mask: Bit mask to disable. This is a subtractive change
 */
typedef struct _CapInterrupt_Mask_IOCTL
{
    uint32_t Version; //!< see description
    uint32_t Mask; //!< see description
} CapInterrupt_Mask_IOCTL;

/**
 *
 * *brief structure for receiving InterruptEvent information
 */
typedef struct _Interrupt_Event_Struct
{
	uint32_t Count; //!< Number of interrupts that have occurred since last request
	uint64_t Time; //!< Time of the last interrupt
} Interrupt_Event_Struct;
/**
 * @brief IOCTL container for #CAP_INTERRUPT_IOCTL_InterruptEvent
 *
 */
typedef struct _CapInterrupt_InterruptEvent_IOCTL
{
    uint32_t Version; //!< Must be #CAP_INTERRUPT_IOCTL_VERSION_InterruptEvent
    uint32_t NumBits; //!< Must be at least CapInterrupt_AcquireController_IOCTL::NumBits
    Interrupt_Event_Struct Bits[]; //!< supplied by the user, must be NumBits long
} CapInterrupt_InterruptEvent_IOCTL;


#pragma pack(pop)


/* Include the platform specific headers  */
#if BUILDTYPE == BT_WINDOWS
#include "windows/Interrupt_IOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/Interrupt_IOCTL.h"
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/


#endif /* INTERRUPT_IOCTL_H_ */
