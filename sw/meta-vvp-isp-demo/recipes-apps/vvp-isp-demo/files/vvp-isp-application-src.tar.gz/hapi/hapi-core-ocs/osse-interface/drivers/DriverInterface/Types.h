/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef _TYPES_H_
#define _TYPES_H_

/** \addtogroup UserlandInterface
 *  @{
 */

/**
 * @brief the maximum length of any paths
 */
#define MAX_FILEPATH_LEN (260) // Make this the same as windows MAX_PATH

/**
 * @brief Maximum size of a friendly name
 */
#define MAX_NAME_LEN 32

// Note: BT_KERNEL needs to be setup on all Kernel Modules
#ifndef BT_KERNEL
#include "UserTypes.h"
#else
#include "KernelTypes.h"
#endif

/** @}*/

#endif // _TYPES_H

