/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
#include "global_defs.h"
#include <map>

#include "VideoFDMA_IOCTL.h"
#include "MDMA_IOCTL.h"

#include "EAutoLock.h"

using namespace OmniTek;
// Forward declarations

class ImpDmaXfer : public IDmaXfer, ImpOmniTekBasePtr
{
public:
	ImpDmaXfer(IDmaChannelPtr& spDmaChannel);
	virtual ~ImpDmaXfer();

	// Get the completion handle
	virtual otEventHandle	GetCompletionHandle() = 0;
	virtual bool			bIsValid() = 0;	

	virtual IDmaChannelPtr	GetParent() {return _spDmaChannel;};

	virtual OT_Status XferWait( ot_int32_t timeout);

	void	SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer);
	void	SetVersion(ot_uint32_t version);
	
	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR_WITH_EARLY_RELEASE(1)

	virtual void _EarlyReleaseCount();

	// Debug Functions
	virtual void*			GetTransferBuffer() {return _pBuffer;};
	virtual ot_uint32_t		GetTransferSize()	{return _transferSize;};
	virtual ot_uint32_t		GetLocalAddr()		{return	_localAddr;};

	void	ClearParent();
private:
	virtual void	_SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer) = 0;
	virtual void	_SetVersion(ot_uint32_t version) = 0;

	void*			_pBuffer;
	ot_uint32_t 	_transferSize;
	ot_uint32_t	_localAddr;

	IDmaChannelPtr	_spDmaChannel;
};

typedef std::map<ImpDmaXfer *, IDmaXferPtr> omDmaXferList;

/////////////////////////////////////////////////////////////////////////////////
class ImpDmaEventBase;
typedef ISmartPtr<ImpDmaEventBase> ImpDmaEventBasePtr;
class ImpDmaEventXfer : public IDmaEventXfer, public ImpOmniTekBasePtr
{
public:
	ImpDmaEventXfer(ImpDmaEventBasePtr& spDmaEventBase);
	virtual ~ImpDmaEventXfer();
	
	virtual OT_Status XferWait(ot_int32_t Timeout = OT_DMA_DEFAULT_TIMEOUT);

	virtual void _EarlyReleaseCount();

	void ClearParent();
	DECLARE_IMP_OMNITEK_PTR_WITH_EARLY_RELEASE(1)
private:
	ImpDmaEventBasePtr	_spDmaEventBase;
};
typedef std::map<ImpDmaEventXfer *, IDmaEventXferPtr> omDmaEventXferList;

#if UNIT_TEST
// Define some custom platform classes to make unit-testing easier
#include "unit_test/PlatformImpDmaXfer.h"
#elif BUILDTYPE==BT_WINDOWS
#include "windows\PlatformImpDmaXfer.h"
#else
#include "linux/PlatformImpDmaXfer.h"
#endif

