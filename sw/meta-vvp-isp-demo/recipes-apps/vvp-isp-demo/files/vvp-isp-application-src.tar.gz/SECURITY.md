# Security Policy
Altera is committed to the security of its products.

## Reporting a Vulnerability
Security vulnerabilities in this project can be reported to Altera’s security incident response team utilizing the guidelines here: https://www.altera.com/security/psirt.html.
