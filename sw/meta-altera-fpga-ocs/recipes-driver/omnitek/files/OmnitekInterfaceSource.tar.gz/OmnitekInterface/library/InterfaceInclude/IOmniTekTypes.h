/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once

#ifndef __linux__
#ifndef _WINNT_
typedef void* HANDLE; // Define HANDLE so that other build envirnoment work under windows. IE QT
#endif // _WINNT_
#include "guiddef.h"
#endif // __linux__

#ifdef __linux__
#include <stdint.h>
#include <stddef.h>
#endif

// Export the interface into the OmniTek namespace
namespace OmniTek
{
#if defined( __linux__ )
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef char  ot_char_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef uint8_t ot_uint8_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef uint16_t ot_uint16_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef uint32_t ot_uint32_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef int32_t ot_int32_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef uint64_t ot_uint64_t;

typedef struct{
	ot_uint32_t	Data1;
	ot_uint16_t	Data2;
	ot_uint16_t	Data3;
	ot_uint8_t	Data4[8];
}otGUID;

typedef int otEventHandle;

typedef int otDeviceHandle;
#else
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef char  ot_char_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef unsigned char ot_uint8_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef unsigned short ot_uint16_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef unsigned long ot_uint32_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef long ot_int32_t;
/**
 * @brief Redefinition for cross platform consistency in interfaces
 */
typedef unsigned __int64 ot_uint64_t;

/// 128byte unique identifer, based on the Windows implemetation
typedef GUID otGUID;

/// Event handle which can be used by WaitForSingleObject/WaitForMultipleObject in windows, and AIO wait functions in Linux.
typedef void*	otEventHandle;

typedef HANDLE	otDeviceHandle;
#endif

/// A timing value return by the FPGA hardware. 0 = not available in hardware
typedef ot_uint64_t otTime;

/// \struct otDmaTiming
/// \brief This struct exposes the Start and End time of a DMA transfer
typedef struct
{
	/// Start Time of the DMA Transfer. 0 if timing block in FPGA is not available
	otTime _startTime;

	/// End Time of the DMA Transfer. 0 if timing block in FPGA is not available
	otTime _endTime;
}otDmaTiming;

////////////////////////////////////////////////////
// Error Codes

#define OT_MAKE_ERROR_CODE(code) (0xA0000000 | code)
/// \enum OT_Status
/// This is an enumeration of status codes
typedef enum
{
	OT_Status_OK = 0,

	OT_Status_Fail						= OT_MAKE_ERROR_CODE(1),
	OT_Status_Not_All_Children_Released	= OT_MAKE_ERROR_CODE(2),
	OT_Status_Memory_Allocation_Fail	= OT_MAKE_ERROR_CODE(3),
	OT_Status_InvalidParameter			= OT_MAKE_ERROR_CODE(4),
	OT_Status_Request_Failed			= OT_MAKE_ERROR_CODE(5),
	OT_Status_Request_Timeout			= OT_MAKE_ERROR_CODE(6),
	OT_Status_Request_Pending			= OT_MAKE_ERROR_CODE(7),
	OT_Status_Buffer_Too_Small			= OT_MAKE_ERROR_CODE(8),
	OT_Status_Timing_Not_Implemented	= OT_MAKE_ERROR_CODE(9),
	OT_Status_Not_Implemented			= OT_MAKE_ERROR_CODE(10),
	OT_Status_Request_Cancelled			= OT_MAKE_ERROR_CODE(11),
	OT_Status_Device_Busy				= OT_MAKE_ERROR_CODE(12),
	OT_Status_Max_Buffers				= OT_MAKE_ERROR_CODE(13)
}OT_Status;

/**
 * DMA Capability defintions
 */
typedef enum
{
    OT_DMA_Type_MDMA	= 0x00000000,
    OT_DMA_Type_FDMA	= 0x00000004,
	OT_DMA_Type_Target	= 0x00000008,
	OT_DMA_Type_Peer	= 0x0000000C
} OT_DMA_Type;

typedef enum
{
    OT_DMA_Direction_Input			= 0x0000,
    OT_DMA_Direction_Output			= 0x0001,
    OT_DMA_Direction_BiDirectional	= 0x0002
} OT_DMA_Direction;

typedef enum
{
    OT_DMA_ContentType_Data		= 0x0000,
    OT_DMA_ContentType_Video	= 0x0010,
    OT_DMA_ContentType_Audio	= 0x0020,
	OT_DMA_ContentType_Packet	= 0x0030
} OT_DMA_ContentType;

// Defines whether the Type the above definitions ot
// bits 7-0 are custom
typedef enum
{
	OT_DMA_Domain_Standard		= 0x0000,
	OT_DMA_Domain_Custom		= 0x0080
} OT_DMA_Domain;

#define OT_GET_DMA_DIRECTION(bitField)    ((OT_DMA_Direction  )(bitField & 0x0003))
#define OT_GET_DMA_TYPE(bitField)		  ((OT_DMA_Type       )(bitField & 0x000c))
#define OT_GET_DMA_CONTENT_TYPE(bitField) ((OT_DMA_ContentType)(bitField & 0x0030))
#define OT_GET_DMA_DOMAIN_TYPE(bitfield)  ((OT_DMA_Domain)(bitfield & 0x0x0080))

typedef ot_uint32_t OT_DMA_Type_BitField;

// Some useful types of OT_DMA_TYPES for Standard DMA Controllers
const OT_DMA_Type_BitField OT_DMA_VIDEO_FDMA_IN		= ((ot_uint32_t)OT_DMA_Domain_Standard | (ot_uint32_t)OT_DMA_Type_FDMA | (ot_uint32_t)OT_DMA_ContentType_Video | (ot_uint32_t)OT_DMA_Direction_Input );
const OT_DMA_Type_BitField OT_DMA_VIDEO_FDMA_OUT	= ((ot_uint32_t)OT_DMA_Domain_Standard | (ot_uint32_t)OT_DMA_Type_FDMA | (ot_uint32_t)OT_DMA_ContentType_Video | (ot_uint32_t)OT_DMA_Direction_Output );
const OT_DMA_Type_BitField OT_DMA_PACKET_FDMA_IN	= ((ot_uint32_t)OT_DMA_Domain_Standard | (ot_uint32_t)OT_DMA_Type_FDMA | (ot_uint32_t)OT_DMA_ContentType_Packet | (ot_uint32_t)OT_DMA_Direction_Input );
const OT_DMA_Type_BitField OT_DMA_PACKET_FDMA_OUT	= ((ot_uint32_t)OT_DMA_Domain_Standard | (ot_uint32_t)OT_DMA_Type_FDMA | (ot_uint32_t)OT_DMA_ContentType_Packet | (ot_uint32_t)OT_DMA_Direction_Output );
const OT_DMA_Type_BitField OT_DMA_META_FDMA_IN		= ((ot_uint32_t)OT_DMA_Domain_Standard | (ot_uint32_t)OT_DMA_Type_FDMA | (ot_uint32_t)OT_DMA_ContentType_Data  | (ot_uint32_t)OT_DMA_Direction_Input);
const OT_DMA_Type_BitField OT_DMA_META_FDMA_OUT		= ((ot_uint32_t)OT_DMA_Domain_Standard | (ot_uint32_t)OT_DMA_Type_FDMA | (ot_uint32_t)OT_DMA_ContentType_Data  | (ot_uint32_t)OT_DMA_Direction_Output);
const OT_DMA_Type_BitField OT_DMA_MDMA				= ((ot_uint32_t)OT_DMA_Domain_Standard | (ot_uint32_t)OT_DMA_Type_MDMA | (ot_uint32_t)OT_DMA_Direction_BiDirectional);

typedef enum
{
	OT_PLATFORM_INTERFACE_UNKNOWN	= 0,
	OT_PLATFORM_INTERFACE_PCIe		= 1,
	OT_PLATFORM_INTERFACE_SOC		= 2
}OT_PLATFORM_INTERFACE;

/**
 * OmniTek FPGA Capability defintions
 */
#define OMNITEK_CAPABILITY(a)	(a)

#define OMNITEK_FPGA_CAPABILITY			(OMNITEK_CAPABILITY(0x0001))
#define OMNITEK_VIDEO_IO_CAPABILITY		(OMNITEK_CAPABILITY(0x0002))
#define OMNITEK_DMA_CAPABILITY			(OMNITEK_CAPABILITY(0x0006))
#define OMNITEK_TIMER_CAPABILITY		(OMNITEK_CAPABILITY(0x0010))

#define OMNITEK_CLK_VIDEO_IN_CAPABILITY		(0x200 + 0x0000)
#define OMNITEK_CLK_VIDEO_OUT_CAPABILITY	(0x200 + 0x0001)
#define OMNITEK_AUDIO_EXTRACT_CAPABILITY	(0x200 + 0x0002)
#define OMNITEK_AUDIO_EMBED_CAPABILITY		(0x200 + 0x0003)
#define OMNITEK_ANC_EXTRACT_CAPABILITY		(0x200 + 0x0004)
#define OMNITEK_ANC_EMBED_CAPABILITY		(0x200 + 0x0005)
#define OMNITEK_I2C_MASTER_CAPABILITY		(0x200 + 0x0008)
#define OMNITEK_PAGE_CTRL_CAPABILITY		(0x200 + 0x0009)

/**
 * Altera FPGA Capability defintions
 */
#define ALTERA_CLK_VIDEO_IN_CAPABILITY		OMNITEK_CLK_VIDEO_IN_CAPABILITY
#define ALTERA_CLK_VIDEO_OUT_CAPABILITY		OMNITEK_CLK_VIDEO_OUT_CAPABILITY 
#define ALTERA_AUDIO_EXTRACT_CAPABILITY		OMNITEK_AUDIO_EXTRACT_CAPABILITY 
#define ALTERA_AUDIO_EMBED_CAPABILITY		OMNITEK_AUDIO_EMBED_CAPABILITY	
#define ALTERA_ANC_EXTRACT_CAPABILITY		OMNITEK_ANC_EXTRACT_CAPABILITY	
#define ALTERA_ANC_EMBED_CAPABILITY			OMNITEK_ANC_EMBED_CAPABILITY		
#define ALTERA_I2C_MASTER_CAPABILITY		OMNITEK_I2C_MASTER_CAPABILITY	
#define ALTERA_PAGE_CTRL_CAPABILITY			OMNITEK_PAGE_CTRL_CAPABILITY		
};
