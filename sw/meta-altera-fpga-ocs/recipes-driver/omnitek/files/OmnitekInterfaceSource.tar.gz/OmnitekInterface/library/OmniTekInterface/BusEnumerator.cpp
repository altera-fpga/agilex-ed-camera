/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "BusEnumerator.h"
#include "bus/OmniTekBus_IOCTL.h"

BusEnumerator::BusEnumerator(InternalAllocator* allocator)
:
	_slots(),
	_allocator(allocator)
{
}

BusEnumerator::~BusEnumerator()
{
	while( _slots.size() )
	{
		_allocator->Free(_slots.back());
		_slots.pop_back();
	}
}

uint32_t BusEnumerator::GetNumSlots()
{
	return (uint32_t)_slots.size();
}

const OTBus_SlotInfo* BusEnumerator::GetSlotInfo(uint32_t index)
{
	OTBus_SlotInfo *pSlotInfo = NULL;
	if( index < (uint32_t)_slots.size() )
	{
		pSlotInfo = _slots[index];
	}

	return pSlotInfo;
}

OTBus_Slots* BusEnumerator::ResizeSlots(OTBus_Slots *pOldSlots, uint32_t numSlots)
{
	OTBus_Slots *pNewSlot = NULL;
	Clean(pOldSlots);

	uint32_t ioctlSize = sizeof(OTBus_Slots) + (numSlots * sizeof( uint32_t));
	pNewSlot= (OTBus_Slots*)(_allocator->Allocate( ioctlSize ));
	if( pNewSlot != NULL )
	{
		INIT_IOCTL(pNewSlot, OTBUS_IOCTL_GetNumSlots_Version, ioctlSize);
		pNewSlot->NumSlots = numSlots;
	}

	return pNewSlot;
}

OTBus_SlotInfo* BusEnumerator::ResizeSlotInfo(OTBus_SlotInfo *pOldInfo, uint32_t numDevCaps, uint32_t slotId)
{
	OTBus_SlotInfo *pNewInfo = NULL;

	Clean(pOldInfo);

	uint32_t ioctlSize = sizeof(OTBus_SlotInfo) + (numDevCaps * sizeof(OTBus_CapDevInfo));
	pNewInfo = (OTBus_SlotInfo*)(_allocator->Allocate(ioctlSize));
	if(pNewInfo)
	{
		INIT_IOCTL(pNewInfo, OTBUS_IOCTL_GetSlot_Version, ioctlSize);
		pNewInfo->SlotId 	 = slotId;
		pNewInfo->NumCapDevs = numDevCaps;
	}
	return pNewInfo;
}
