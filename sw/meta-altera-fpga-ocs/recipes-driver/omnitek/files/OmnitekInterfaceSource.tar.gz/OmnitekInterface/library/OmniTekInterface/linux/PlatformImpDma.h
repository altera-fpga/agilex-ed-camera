/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "../ImpDmaBase.h"

class PlatformImpDma: public ImpDmaBase
{
public:
	PlatformImpDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OT_DMA_Type_BitField type);
	virtual ~PlatformImpDma();

	virtual OT_Status SendDmaXferRequest(PlatformImpDmaXfer *pDmaXfer, bool bOverlapped);
	virtual OT_Status PlatformMemoryXferWait(PlatformImpDmaXfer *pDmaXfer, ot_int32_t timeout);
	virtual OT_Status PlatformCancelXfer(PlatformImpDmaXfer *pXfer);

	virtual OT_Status PlatformStart()	= 0;
	virtual OT_Status PlatformStop()		= 0;

	int GetDeviceHandle() {return _hCap;};

	OT_Status CancelXfer(CapGeneral_EventCtx_IOCTL *pEventIoctl);
	OT_Status _WaitForXfer(CapGeneral_EventCtx_IOCTL *pEventIoctl, ot_int32_t timeout_ms);

private:
	int		_hCap; // File handle of the underlying capability
};

class PlatformImpVideoFDma : public PlatformImpDma
{
public:
	PlatformImpVideoFDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OT_DMA_Type_BitField type);
	virtual ~PlatformImpVideoFDma();

	virtual OT_Status PlatformStart();
	virtual OT_Status PlatformStop();
};

class PlatformImpMDma : public PlatformImpDma
{
public:
	PlatformImpMDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OT_DMA_Type_BitField type);
	virtual ~PlatformImpMDma();

	virtual OT_Status PlatformStart()	{return OT_Status_OK;};
	virtual OT_Status PlatformStop()	{return OT_Status_OK;};
};

/////////////////////////////////////////////////////////////////////////////////
class PlatformDmaEventXfer;
class PlatformImpDmaEvent : public ImpDmaEventBase
{
public:
	PlatformImpDmaEvent(PlatformImpDma* pChannel);
	virtual ~PlatformImpDmaEvent();

	OT_Status SendIoctl(PlatformDmaEventXfer *pXfer);
	OT_Status _WaitXfer(PlatformDmaEventXfer *pXfer, ot_int32_t Timeout);
	OT_Status _Cancel(PlatformDmaEventXfer *pXfer);

private:
};
