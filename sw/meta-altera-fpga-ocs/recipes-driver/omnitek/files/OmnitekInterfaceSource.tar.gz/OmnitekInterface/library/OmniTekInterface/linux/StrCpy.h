/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once

// Safe string copy - writes as little as possible to
// the destination buffer but guarantees NUL termination and
// avoids buffer overruns in destination as long as destSize
// is correctly specified, and avoids buffer overruns in src
// as long as it is NUL-terminated.
// Not using a safe string library to avoid forcing an additional
// dependency on users of this library.
inline void StrCpy(char* dest, size_t destSize, const char* src)
{
    if (destSize == 0)
    {
        return;
    }

    // Leave room for terminator in dest.
    size_t maxCharacterCount = destSize - 1;

    // Copy characters only excluding NUL terminator
    for (size_t index = 0; index < maxCharacterCount; ++index)
    {
        if (*src == '\0')
        {
            break;  // Don't copy past NUL-terminator in src
        }

        *dest = *src;
        dest++;
        src++;
    }

    *dest = '\0';  // Add NUL terminator at the end
}
