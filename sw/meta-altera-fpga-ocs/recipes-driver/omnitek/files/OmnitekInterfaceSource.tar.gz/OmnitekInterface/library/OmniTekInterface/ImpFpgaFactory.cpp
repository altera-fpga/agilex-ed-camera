/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpFpgaFactory.h"
#include "ImpBoard.h"

//#define SIMULATOR 1
#ifdef SIMULATOR
#include "HW_Defs.h"
#include "OTCapabilityTypes.h"
#endif

ImpFpgaFactory::ImpFpgaFactory(BusEnumerator& busEnum, const InternalFpgaCreator& fpgaCreator)
{
	StrCpy(_versionNumber, 100, "1.1.1.1");
#ifndef SIMULATOR

	if( busEnum.Open() )
	{
		for( uint32_t i=0; i<busEnum.GetNumSlots(); i++ )
		{
			const OTBus_SlotInfo *pSlotInfo = busEnum.GetSlotInfo(i);
			if( pSlotInfo )
			{
				ImpBoard *pBoard = new ImpBoard(i, this);
				_boards.push_back(pBoard);

				pBoard->AddFpga(pSlotInfo, fpgaCreator);
			}
		}
		busEnum.Close();
	}
#else
	for( ot_int32_t i=0; i<1; i++ )
	{
		ot_int32_t numCapDev = 2;
		ot_int32_t numFdmaInCapDev = 4;
		ot_int32_t numFdmaOutCapDev = 2;
		ot_int32_t numMdmaOutCapDev = 3;

		ot_int32_t totalCaps = numCapDev + numFdmaInCapDev + numFdmaOutCapDev + numMdmaOutCapDev;

		ot_int32_t size = sizeof(OTBus_SlotInfo) + ((totalCaps) * sizeof(OTBus_CapDevInfo));
		OTBus_SlotInfo *pSlotInfo = (OTBus_SlotInfo*)malloc(size);

		pSlotInfo->Version = 1;
		pSlotInfo->SlotId = 10 * i;
		pSlotInfo->NumCapDevs = totalCaps;
		ot_int32_t capIdx = 0;
		for(ot_int32_t c=0; c<numCapDev; c++ )
		{
			StrCpy(pSlotInfo->CapDevs[capIdx].Path, MAX_FILEPATH_LEN, "Test");
			pSlotInfo->CapDevs[capIdx].SubType = 123+i+c;
			pSlotInfo->CapDevs[capIdx].Type = 253;
			pSlotInfo->CapDevs[capIdx].Version = 0;
			capIdx++;
		}

		// Now add some Video FDMA In Channels
		for(ot_int32_t c=0; c<numFdmaInCapDev; c++ )
		{
			OTBus_CapDevInfo &capDev = pSlotInfo->CapDevs[capIdx];
			StrCpy(capDev.Path, MAX_FILEPATH_LEN, "Video FDMA In");
			capDev.SubType	= RegCap_DMA_Base | OmDmaSetType(DMAType_FDMA) | OmDmaSetContentType(DMAContentType_Video) | OmDmaGetDirection(DMADirection_Input);
			capDev.Type		= OFC_RegisterCap;
			capDev.Version	= 0;
			capIdx++;
		}

		// Now add some Video FDMA Out Channels
		for(ot_int32_t c=0; c<numFdmaOutCapDev; c++ )
		{
			OTBus_CapDevInfo &capDev = pSlotInfo->CapDevs[capIdx];
			StrCpy(capDev.Path, MAX_FILEPATH_LEN, "Video FDMA In");
			capDev.SubType	= RegCap_DMA_Base | OmDmaSetType(DMAType_FDMA) | OmDmaSetContentType(DMAContentType_Video) | OmDmaGetDirection(DMADirection_Output);
			capDev.Type		= OFC_RegisterCap;
			capDev.Version	= 0;
			capIdx++;
		}

		// Now add some MDMA Channels
		for(ot_int32_t c=0; c<numMdmaOutCapDev; c++ )
		{
			OTBus_CapDevInfo &capDev = pSlotInfo->CapDevs[capIdx];
			StrCpy(capDev.Path, MAX_FILEPATH_LEN, "Video FDMA In");
			capDev.SubType	= RegCap_DMA_Base | OmDmaSetType(DMAType_MDMA) | OmDmaGetDirection(DMADirection_BiDirectional);
			capDev.Type		= OFC_RegisterCap;
			capDev.Version	= 0;
			capIdx++;
		}

		StrCpy(pSlotInfo->HostControllerInfo.Path, MAX_FILEPATH_LEN, "HC");
		if( i == 0 )
			StrCpy(pSlotInfo->HostControllerInfo.TypeName, 32,"Simulated Host Controller");
		else
			StrCpy(pSlotInfo->HostControllerInfo.TypeName, 32,"Donkey Host Controller");

		BoardImp *pBoard = new BoardImp(pSlotInfo, this);
		_boards.push_back(pBoard);
		free(pSlotInfo);
	}
#endif
}

ImpFpgaFactory::~ImpFpgaFactory(void)
{
	while( _boards.size() )
	{
		_boards.pop_back();
	}
}

bool ImpFpgaFactory::bSafeToRelease()
{
	bool bSafe = true; // Assume we're safe

	for( ot_int32_t i=0; i<(ot_int32_t)_boards.size(); i++ )
	{
		IBoard* pBoard = _boards[i];
		ImpBoard *pImpBoard = (ImpBoard*)pBoard;

		if( (pImpBoard->GetRefCount() != 1) || !pImpBoard->bSafeToRelease() )
			bSafe = false;
	}
	return bSafe;
}

const char* ImpFpgaFactory::GetVersionString()
{
	return _versionNumber;
}

IBoardPtr ImpFpgaFactory::GetBoard(ot_int32_t instance)
{
	IBoardPtr pBoard;
	if( instance < GetBoardCount() )
		pBoard = _boards[instance];

	return pBoard;
}

ot_int32_t ImpFpgaFactory::GetBoardCount(otGUID type)
{
	ot_int32_t iResult = 0;

	for(ot_int32_t i=0; i< GetBoardCount(); i++ )
	{
//		if( _boards[i]->GetBoardType() == type )
//			iResult++;
	}
	return iResult;
}

IBoardPtr ImpFpgaFactory::GetBoard(otGUID type, ot_int32_t instance)
{
	IBoardPtr pBoard;

	return pBoard;
}
