/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "StdAfx.h"
#include "host_controller/HostController_IOCTL.h"
#include "PlatformHostController.h"

PlatformHostController::PlatformHostController()
	: _hDev(-1)
{
}

PlatformHostController::~PlatformHostController()
{
	Close();
}

void PlatformHostController::Close()
{
	if( _hDev != -1 )
		close(_hDev);
	_hDev = -1;
}

bool PlatformHostController::Open(const OTBus_HCInfo &hcInfo)
{
	 _hDev = open( hcInfo.Path, O_RDWR );
	return (_hDev > -1);
}

int PlatformHostController::GetNumRegions()
{
	int iNumRegions = 0;

	if( _hDev != -1 )
	{
		HC_GetNumRegions_IOCTL numRegions;
		INIT_IOCTL(&numRegions, HC_IOCTL_GetNumRegions_Version, sizeof(numRegions));
		numRegions.NumRegions = 0;

		if( ioctl(_hDev, HC_IOCTL_GetNumRegions, &numRegions) == 0 )
		{
			iNumRegions = numRegions.NumRegions;
		}
	}

	return iNumRegions;
}
unsigned int PlatformHostController::GetRegionSize( int idx)
{
	unsigned int size = 0;

	if( idx < GetNumRegions() )
	{
		if( _hDev != -1 )
		{
			HC_GetRegion_IOCTL region;
			INIT_IOCTL(&region, HC_IOCTL_GetRegion_Version, sizeof(region));

			// Setup the Region to be read
			region.Idx = idx;
			if( ioctl(_hDev, HC_IOCTL_GetRegion, &region) == -1 )
			{
				if( errno == ENOMEM )
					size = region.Size;
			}
			else
				printf("Passes\n");
		}
	}
	return size;
}

OT_Status PlatformHostController::ReadRegion(int idx, void* pBuffer, unsigned int bufferSize, unsigned int offset)
{
	OT_Status status = OT_Status_Fail;

	if( idx < GetNumRegions() )
	{
		HC_GetRegion_IOCTL region;

		INIT_IOCTL(&region, HC_IOCTL_GetRegion_Version, sizeof(region));
		region.Idx = idx;
		region.Size = bufferSize;
		region.Buffer.pVa = pBuffer;
		region.Offset = offset;

		if( ioctl(_hDev, HC_IOCTL_GetRegion, &region) == 0 )
			status = OT_Status_OK;
		else
		{
			if( errno == EINVAL )
				status = OT_Status_Buffer_Too_Small;
		}
	}
	return status;
}

OT_PLATFORM_INTERFACE	PlatformHostController::GetPlatformInterface()
{
	OT_PLATFORM_INTERFACE platformInterface = OT_PLATFORM_INTERFACE_UNKNOWN;

	if( _hDev != -1 )
	{
		HC_GetPlatformInfo_IOCTL platformInfo;
		INIT_IOCTL(&platformInfo, HC_IOCTL_GetPlatformInfo_Version, sizeof(platformInfo));

		if( ioctl(_hDev, HC_IOCTL_GetPlatformInfo, &platformInfo) == 0 )
		{
			if( platformInfo.type == HC_PlatformInfoPCIe )
				platformInterface = OT_PLATFORM_INTERFACE_PCIe;
			else if( platformInfo.type == HC_PlatformInfoSoc )
				platformInterface = OT_PLATFORM_INTERFACE_SOC;
		}
	}
	return platformInterface;
}

unsigned int PlatformHostController::ReadPciConfig(void *pBuffer, unsigned int size, unsigned offset)
{
	unsigned int bytesRead = 0;

	if( _hDev != -1 )
	{
		// Call to the driver requires the buffer to be on aligned on 8byte(32bit) or 16 byte boundary
		uint8_t *pTempBuffer = (uint8_t*)malloc(size+sizeof(uint64_t));
		uintptr_t round = (uintptr_t)pTempBuffer;
		if( (round % sizeof(uint64_t)) != 0 )
			round += sizeof(uint64_t) - (round % sizeof(uint64_t));
		uint8_t *pReadPtr = (uint8_t*)round;

		HC_ReadPciConfig readPciConfig;
		INIT_IOCTL(&readPciConfig, HC_IOCTL_ReadPciConfig_Version, sizeof(readPciConfig));

		readPciConfig.buffer.pVa = pReadPtr;
		readPciConfig.Size = size;
		readPciConfig.Offset = offset;

		if( ioctl( _hDev, HC_IOCTL_ReadPciConfig, &readPciConfig) == 0 )
		{
			// Copy the config data to return read buffer
			memcpy(pBuffer, pReadPtr, size);
			bytesRead = readPciConfig.Size;
		}
		free(pTempBuffer);
	}
	return bytesRead;
}


