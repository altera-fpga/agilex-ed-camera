/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "bus/OmniTekBus_IOCTL.h"
#include "InternalAllocator.h"

#include <vector>
class PlatformBusEnumerator;

typedef std::vector<OTBus_SlotInfo*> SlotList;

class BusEnumerator
{
public:
	BusEnumerator(InternalAllocator* allocator);
	virtual ~BusEnumerator(void);

	// To Be Implemented By Inherited Class
	virtual bool Open() = 0;
	virtual void Close() = 0;

	uint32_t GetNumSlots();
	const OTBus_SlotInfo* GetSlotInfo(uint32_t index);

	template<typename T>
	void Clean(T*& data)
	{
		if( data != NULL )
		{
			_allocator->Free(data);
			data = NULL;
		}
	}

protected:
	OTBus_Slots*	ResizeSlots(OTBus_Slots *pOldSlots, uint32_t numSlots);
	OTBus_SlotInfo* ResizeSlotInfo(OTBus_SlotInfo *pOldInfo, uint32_t numDevCaps, uint32_t slotId);

	SlotList _slots;
	InternalAllocator* _allocator;
};

#if BUILDTYPE==BT_WINDOWS
#include "windows\PlatformBusEnumerator.h"
#else
#include "linux/PlatformBusEnumerator.h"
#endif
