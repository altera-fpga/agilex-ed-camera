/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
using namespace OmniTek;

#include "HardwareDevice.h"

#include <memory>
#include <functional>

// Forware declare ImpCapability
class ImpCapability;

class InterruptEvent_TransactionBase : public IoOverlappedTransactionBase
{
public:
    virtual ~InterruptEvent_TransactionBase() {}
	virtual ot_uint32_t GetSetMask() = 0;
	virtual ot_uint32_t GetIntCount(ot_uint32_t theBit) = 0;
	virtual otTime GetIntTime(ot_uint32_t theBit) = 0;
	virtual ot_uint32_t GetNumBits() = 0;
	virtual bool bIsValid() = 0;
};

typedef std::shared_ptr<InterruptEvent_TransactionBase> InterruptEvent_TransactionBasePtr;
typedef std::function<InterruptEvent_TransactionBasePtr(ot_uint32_t numIntBits)> InterruptTransactionFactory;

class ImpInterruptInterface : public IInterruptInterface, public ImpOmniTekBasePtr
{
public:
	ImpInterruptInterface(IoDevice* pIoDevice, ICapability* pParent, ot_uint32_t numIntBits,
							InterruptTransactionFactory createInterruptTransaction);
	static IInterruptInterfacePtr CreateInterruptInterface(IoDevice* pIoDevice, ICapability *pParent,
															InterruptTransactionFactory transactionFactory);

	// IInterruptInterface Implementations
	virtual ~ImpInterruptInterface();
	virtual ot_uint32_t GetInterruptMask();
	virtual OT_Status SetEnableMask(ot_uint32_t enableMask);
	virtual OT_Status SetDisableMask(ot_uint32_t disableMask);
	virtual OT_Status ScheduleWaitForInterrupt(IInterruptWaitPtr *spWait);
	virtual ICapabilityPtr GetParentCapability() {return _spParent;};

	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR

protected:
	IoDevice*	_pIoDevice;
	ICapabilityPtr	_spParent;
	ot_uint32_t		_numIntBits;
	ot_uint32_t		_mask;
	otTime			_ticksPerSecond;
	InterruptTransactionFactory _createInterruptTransaction;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct ImpInterruptWait : public IInterruptWait, public ImpOmniTekBasePtr
{
	ImpInterruptWait(IInterruptInterfacePtr spParent, IoDevice *pPlatformDevice, otTime ticksPerSecond,
						InterruptEvent_TransactionBasePtr spTransaction);

	// IInterruptWaitPtr implementations
	virtual ~ImpInterruptWait();
	OT_Status Wait(ot_int32_t Timeout = OT_INT_DEFAULT_TIMEOUT);
	virtual ot_uint32_t GetCompleteMask();
	virtual ot_uint32_t GetInterruptCount( ot_uint32_t theBit);
	virtual OT_Status GetInterruptTime( ot_uint32_t theBit, otTime &ticks );
	virtual OT_Status GetTimingFrequency( otTime &ticksPerSecond );
	virtual otEventHandle	GetCompletionHandle();

	OT_Status Schedule();
	bool	  bIsValid() {return _spTransaction->bIsValid();}
	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR
private:
	IInterruptInterfacePtr		_spParent;
	InterruptEvent_TransactionBasePtr _spTransaction;
	IoDevice					*_pPlatformDevice;
	bool						_bComplete;
	otTime						_ticksPerSecond;
};

