/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
#include <map>
#include <vector>

#include "EAutoLock.h"

#include "ImpDmaXfer.h"

using namespace OmniTek;
// Forward declarations
class	OmniTekCapability;
class	OmniTekVideoFDMA;
class	BoardImp;
class	RegisterCapability;
class	InternalCapability;

#if UNIT_TEST
// We need to define some custom platform classes for use when unit-testing
#include "unit_test/PlatformImpDma.h"
#elif BUILDTYPE==BT_WINDOWS
#include "windows\PlatformImpDma.h"
#else
#include "linux/PlatformImpDma.h"
#endif
/////////////////////////////////////////////////////////////////////////////////////////////////////////
class DmaBuffer
{
public:
	DmaBuffer(void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bVirtualAddress, bool bSyncBuffer);

	void*		GetBufferAddress();
	ot_uint32_t	GetLocalAddress();
	ot_uint32_t	GetBufferSize();
	bool		bVirtualAddress();
	bool		bSyncBuffer();
private:
	DmaBuffer();

	void*		_pBuffer;
	ot_uint32_t	_localAddr;
	ot_uint32_t	_size;
	bool		_bVirtualAddress;
	bool		_bSyncBuffer;
};

class ImpDmaTransaction : public IDmaTransaction, ImpOmniTekBasePtr
{
public:
	ImpDmaTransaction(bool bAllowRead, bool bAllowWrite, ot_uint32_t maxTargets);
	virtual ~ImpDmaTransaction();

	virtual ot_uint32_t GetNumBuffers();
	virtual OT_Status	AddVirtualBuffer(void *pBuffer,  ot_uint32_t LocalAddr, ot_uint32_t Size, bool bSyncBuffer);
	virtual ot_uint32_t GetMaxBuffers();
	virtual	void		ClearBuffers();

	DmaBuffer*			GetBuffer(ot_uint32_t idx);
	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR
private:
	bool					_bAllowRead;
	bool					_bAllowWrite;
	ot_uint32_t				_maxBuffers;
	std::vector<DmaBuffer>	_buffers;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------------------------------
class ImpVideoFDma : public PlatformImpVideoFDma
{
public:
	ImpVideoFDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, ot_uint32_t type);
	virtual ~ImpVideoFDma();

	virtual OT_Status MemoryXfer(void *pBuffer,  ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, otDmaTiming *pTiming, ot_int32_t timeout);
	virtual OT_Status MemoryXferSchedule( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer);
	virtual OT_Status MemoryXferSchedule2( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer);
	virtual OT_Status MemoryXferSchedule3( IDmaTransactionPtr spTransaction, bool bWrite, IDmaXferPtr *spDmaXfer );

	virtual IDmaTransactionPtr AllocateDmaTransaction();

	virtual bool bIsGpuDirectSupported();
	virtual OT_Status MemoryXferScheduleGpuDirect( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer);

	virtual OT_Status Start();
	virtual OT_Status Stop();

	virtual IDmaEventPtr GetDmaEvent();

private:
	PlatformImpDmaXfer * AllocateTransaction(ot_int32_t nTargets, bool bWrite, int version);
	PlatformImpDmaXfer* AllocateTransactionGpuDirect(ot_int32_t nTargets, bool bWrite, int version);
	OT_Status MemoryXferScheduleTransaction( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bSyncBuffer,
											PlatformImpDmaXfer *pTransaction, IDmaXferPtr *spDmaXfer);

	IDmaEventPtr		_spDmaEvent;
	bool _bGpuDirectSupported;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------------------------------
class ImpMDma : public PlatformImpMDma
{
public:
	ImpMDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, ot_uint32_t type);
	virtual ~ImpMDma();
	virtual OT_Status MemoryXfer(void *pBuffer,  ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, otDmaTiming *pTiming, ot_int32_t timeout);
	virtual OT_Status MemoryXferSchedule( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer);
	virtual OT_Status MemoryXferSchedule2( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer);
	virtual OT_Status MemoryXferSchedule3( IDmaTransactionPtr spTransaction, bool bWrite, IDmaXferPtr *spDmaXfer );

	virtual IDmaTransactionPtr AllocateDmaTransaction();

	virtual bool bIsGpuDirectSupported();
	virtual OT_Status MemoryXferScheduleGpuDirect( void *pBuffer, ot_uint32_t LocalAddr, ot_uint32_t Size, bool bWrite, IDmaXferPtr *spDmaXfer, bool bSyncBuffer);


	virtual OT_Status Stop();
	virtual IDmaEventPtr GetDmaEvent() {return NULL;}; // IDmaEvent not supported on MDMA interface
private:
	PlatformImpDmaXfer * AllocateTransaction(ot_int32_t nTargets, bool bWrite, int version);
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////
