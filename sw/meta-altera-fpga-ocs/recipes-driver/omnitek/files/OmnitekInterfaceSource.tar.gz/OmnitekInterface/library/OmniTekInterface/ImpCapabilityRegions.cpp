/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpCapabilityRegions.h"
#include "HostController.h"

ImpCapabilityRegions::ImpCapabilityRegions(OTParentTracker* pParentTracker, HostController *pHostController)
:	ImpOmniTekBasePtr(pParentTracker)
,	_pHostController(pHostController)
{
}


ImpCapabilityRegions::~ImpCapabilityRegions(void)
{
}

ot_int32_t ImpCapabilityRegions::GetNumRegions()
{
	ot_int32_t iRegions = 0;
	if( _pHostController )
		iRegions = _pHostController->GetNumRegions();

	return iRegions;
}

ot_uint32_t ImpCapabilityRegions::GetRegionSize( ot_int32_t idx)
{
	ot_uint32_t iSize = 0;
	if( _pHostController )
		iSize = _pHostController->GetRegionSize(idx);

	return iSize;
}

OT_Status ImpCapabilityRegions::ReadRegion(ot_int32_t idx, void* pBuffer, ot_uint32_t bufferSize, ot_uint32_t offset)
{
	OT_Status status = OT_Status_Fail;
	if( _pHostController )
		status = _pHostController->ReadRegion(idx, pBuffer, bufferSize, offset);
	return status;
}
