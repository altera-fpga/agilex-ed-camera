/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"
#include "InternalCapabilityFactory.h"
using namespace OmniTek;
#include "InternalCapability.h"

#include <vector>
#include <map>

#include "bus/OmniTekBus_IOCTL.h"

typedef std::multimap<ot_uint32_t, ICapabilityPtr> OmniTekCapabilityMap;
typedef std::pair<OmniTekCapabilityMap::iterator, OmniTekCapabilityMap::iterator> OmniTekCapabilityPairIterator;

class ImpCapabilityEnumerator : public InternalCapabilityEnumerator
{
public:
	ImpCapabilityEnumerator(OTParentTracker *pParentTracker);
	virtual ~ImpCapabilityEnumerator();

	// ICapabilityEnumerator Interface Functions
	virtual ot_int32_t		GetNumCapabilities();
	virtual ot_int32_t		GetNumCapabilities(ot_uint32_t type);

	virtual ICapabilityPtr	GetCapability(ot_int32_t index);
	virtual ICapabilityPtr	GetCapability(ot_uint32_t type, ot_int32_t index);
	virtual ICapabilityPtr	GetCapabilityByUniqueId(ot_uint32_t type, ot_int32_t uniqueId);

	// Internal implementation functions (InternalCapabilityEnumerator)
	bool	AddCapability(InternalCapability *pCapability);
private:
	OmniTekCapabilityMap	_capabilities;
};
