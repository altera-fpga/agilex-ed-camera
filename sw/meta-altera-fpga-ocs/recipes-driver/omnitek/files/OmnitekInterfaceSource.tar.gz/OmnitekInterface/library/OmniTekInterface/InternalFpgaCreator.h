/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once

#include <functional>

#include "bus/OmniTekBus_IOCTL.h"
#include "IOmniTekInterface.h"

class ImpBoard;

/* Internal interface allowing mocks for unit-testing */

typedef std::function<OmniTek::IFpgaPtr(const OTBus_SlotInfo *pSlotInfo, ImpBoard *pBoard)> InternalFpgaCreator;
