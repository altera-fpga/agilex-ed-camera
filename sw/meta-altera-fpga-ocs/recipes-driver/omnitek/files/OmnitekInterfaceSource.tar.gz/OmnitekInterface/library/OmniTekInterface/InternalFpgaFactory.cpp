/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpFpgaFactory.h"
#include "ImpFpga.h"

#if BUILDTYPE==BT_WINDOWS
#include "windows\PlatformHostController.h"
#else
#include "linux/PlatformHostController.h"
#endif

#include "InternalCapabilityFactory.h"
#include "InternalRegisterFactory.h"

#include "ImpDmaEnumerator.h"
#include "ImpCapabilityEnumerator.h"
#include "ImpCapabilityRegions.h"
#include "ImpPlatformInfo.h"
#include "ImpCapability.h"
#include "ImpDmaChannel.h"
#include "ImpRegisterBlock.h"
#include "ImpInterruptInterface.h"
#include "InterruptEventTransaction.h"

#include "MallocAllocator.h"

#include <memory>

namespace
{

class ImpDmaChannelFactory : public InternalDmaChannelFactory
{
public:
    InternalDmaBase* CreateMDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OmniTek::ot_uint32_t type)
    {
        return new ImpMDma(pParentTracker, pCapability, type);
    }

    InternalDmaBase* CreateVideoFDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OmniTek::ot_uint32_t type)
    {
        return new ImpVideoFDma(pParentTracker, pCapability, type);
    }
};

InterruptEvent_TransactionBasePtr CreateInterruptTransaction(ot_uint32_t numIntBits)
{
    return std::make_shared<InterruptEvent_Transaction>(numIntBits);
}

class ImpRegisterFactory : public InternalRegisterFactory
{
private:
    IRegisterBlock* CreateRegisterBlock(InternalCapability *pCapability, InternalRegisterCapability *pCap,
                                        ot_uint32_t blkNum, ot_uint32_t numReg)
    {
        return new ImpRegisterBlock(pCapability, pCap, blkNum, numReg);
    }

    virtual OmniTek::IInterruptInterfacePtr CreateInterruptInterface(IoDevice* pIoDevice, ICapability *pParent)
    {
        return ImpInterruptInterface::CreateInterruptInterface(pIoDevice, pParent, CreateInterruptTransaction);
    }
};

class ImpCapabilityFactory : public InternalCapabilityFactory
{
private:
    InternalDmaEnumerator* CreateDmaEnumerator(OTParentTracker* pParentTracker)
    {
        static auto spDmaChannelFactory = std::make_shared<ImpDmaChannelFactory>();

        return new ImpDmaEnumerator(pParentTracker, spDmaChannelFactory);
    }

    InternalCapabilityEnumerator* CreateCapabilityEnumerator(OTParentTracker* pParentTracker)
    {
        return new ImpCapabilityEnumerator(pParentTracker);
    }

    OmniTek::ICapabilityRegions* CreateCapabilityRegions(OTParentTracker* pParentTracker, HostController* pHostController)
    {
        return new ImpCapabilityRegions(pParentTracker, pHostController);
    }

    OmniTek::IPlatformInfo* CreatePlatformInfo(OTParentTracker* pParentTracker, HostController *pHostController)
    {
        return new ImpPlatformInfo(pParentTracker, pHostController);
    }

    InternalCapability* CreateCapability(OTParentTracker* pParentTracker, IFpga *pFpga, const OTBus_CapDevInfo& capDevInfo)
    {
        static auto spRegisterFactory = std::make_shared<ImpRegisterFactory>();

        std::shared_ptr<IoDevice> spIoDevice = std::make_shared<PlatformIoDevice>(capDevInfo.Path);

        return new ImpCapability(pParentTracker, pFpga, capDevInfo, std::move(spIoDevice), spRegisterFactory);
    }
};

IFpgaPtr CreateFpga(const OTBus_SlotInfo *pSlotInfo, ImpBoard *pBoard)
{
    ImpCapabilityFactory capFactory{};
    return new ImpFpga(pSlotInfo, pBoard, new PlatformHostController(), capFactory);
}

InternalAllocator* GetAllocator()
{
    static MallocAllocator allocator{};
    return &allocator;
}

} // namespace

// These factory routines are implemented in the OmniTek namespace
IFpgaFactory *OmniTek::OT_InitializeFactory()
{
	PlatformBusEnumerator busEnum{GetAllocator()};
	IFpgaFactory *pFpgaFactory = new ImpFpgaFactory(busEnum, CreateFpga);

	return pFpgaFactory;
}

void Diagnostics(IFpgaFactory *pFpgaFactory)
{
#if defined(DEBUG) | defined(_DEBUG)
	for( ot_int32_t b=0; b<pFpgaFactory->GetBoardCount(); b++ )
	{
		// Weak pointer so that refcounts don't change
		IBoard * pBoard = pFpgaFactory->GetBoard(0);
		if( pBoard )
		{
			for( ot_int32_t f=0; f<pBoard->GetNumFPGAs(); f++ )
			{
				IFpga *pFpga = pBoard->GetFPGA(f);
				if( pFpga )
				{
					ICapabilityEnumerator *pEnum = pFpga->GetCapabilities();
					for( ot_int32_t c=0; c<pEnum->GetNumCapabilities(); c++ )
					{
						ICapability *pCap = pEnum->GetCapability(c);
						if( pCap && (pCap->GetRefCount()>1) )
						{
							fprintf(stderr, "Cap 0%03x [%d] not released. [RefCount = %d]\n", pCap->GetType(), pCap->GetUniqueID(), pCap->GetRefCount());
						}

						if( pCap )
						{
							for( ot_int32_t r=0; r<pCap->GetNumRegisterBlocks() ; r++ )
							{
								IRegisterBlock *pRegs = pCap->GetRegisterBlock(r);
								if( pRegs && (pRegs->GetRefCount()>1) )
								{
									fprintf(stderr, "Reg Block %2d on Cap 0%03x [%d] not released. [RefCount = %d]\n", r, pCap->GetType(), pCap->GetUniqueID(), pCap->GetRefCount());
								}
							}
						}
					}

					IDmaEnumerator* pDmas = pFpga->GetDmaChannels();
					for( ot_int32_t d=0; d<pDmas->GetNumDmaChannels(); d++ )
					{
						IDmaChannel *pDmaChannel = pDmas->GetDmaChannel(d);
						if( pDmaChannel && (pDmaChannel->GetRefCount()>1) )
						{
							ICapability *pCap = pDmaChannel->GetCapability();
							fprintf(stderr, "Dma 0x%03x [%d] not released. [RefCount = %d]\n", pDmaChannel->GetBitFieldType(), pCap->GetUniqueID(), pDmaChannel->GetRefCount());
						}
					}
				}
			}
		}
	}
#endif
}

OT_Status OmniTek::OT_TerminateFactory(IFpgaFactory *pFpgaFactory)
{
	OT_Status status = OT_Status_OK;

	// Check that the client has released all the child objects of the API
	if( !pFpgaFactory->bSafeToRelease() )
	{
		Diagnostics(pFpgaFactory);
		status = OT_Status_Not_All_Children_Released;
	}
	else
		delete (IFpgaFactory*)pFpgaFactory;

	return status;
}
