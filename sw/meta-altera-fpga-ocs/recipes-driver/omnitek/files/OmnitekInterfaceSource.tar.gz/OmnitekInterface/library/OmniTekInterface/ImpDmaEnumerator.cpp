/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpDmaEnumerator.h"
#include "OTCapabilityTypes.h"

#include "InternalDmaBase.h"

ImpDmaEnumerator::ImpDmaEnumerator(OTParentTracker *pParentTracker, std::shared_ptr<InternalDmaChannelFactory> spChannelFactory)
	: InternalDmaEnumerator(pParentTracker)
	, _channelsByType()
	, _spChannelFactory(std::move(spChannelFactory))

{
};

ImpDmaEnumerator::~ImpDmaEnumerator()
{
	// All channels erased, we can simple clear the multi-map
	_channelsByType.clear();
}

ot_int32_t ImpDmaEnumerator::GetNumDmaChannels()
{
	return (ot_int32_t)_channelsByType.size();
}

IDmaChannelPtr ImpDmaEnumerator::GetDmaChannel(ot_int32_t index)
{
	IDmaChannelPtr spDmaChannel;

	// Make sure we have enough DMA channels
	if( index < GetNumDmaChannels() )
	{
		OmDmaMultiMapByDmaType::iterator iter = _channelsByType.begin();
		
		// Now move the iterator to the required entry
		for( int i=0; i<index; i++ )
			iter++;

		// We should be at the request DMA controller
		if( iter != _channelsByType.end() )
			spDmaChannel = iter->second;
	}
	return spDmaChannel;
}

OmDmaPairIterator ImpDmaEnumerator::GetDmaChannelsIterator(OT_DMA_Type type)
{
	OmDmaPairIterator pairIterator;

	pairIterator = _channelsByType.equal_range(type);
	return pairIterator;
}

ot_int32_t ImpDmaEnumerator::GetNumDmaChannels(OT_DMA_Type type, OT_DMA_Direction direction)
{
	OmDmaPairIterator pairIterator = GetDmaChannelsIterator(type);
	OmDmaMultiMapByDmaType::iterator iter = pairIterator.first;

	// Now iterator through the available DMAs looking for the correct direction
	ot_int32_t uiResult = 0;
	while( iter != pairIterator.second )
	{
		if( iter->second->GetDirection() == direction )
			uiResult++;
		iter++;
	}
	
	return uiResult;
}

IDmaChannelPtr ImpDmaEnumerator::GetDmaChannel(OT_DMA_Type type, OT_DMA_Direction direction, ot_int32_t index)
{
	IDmaChannelPtr spDmaChannel;

	OmDmaPairIterator pairIterator = GetDmaChannelsIterator(type);
	OmDmaMultiMapByDmaType::iterator iter = pairIterator.first;

	// Now iterator through the available DMAs looking for the correct direction
	ot_int32_t uiFound = 0;

	while( iter != pairIterator.second )
	{
		if( iter->second->GetDirection() == direction )
		{
			if( uiFound == index )
			{
				spDmaChannel = iter->second;
				break;
			}
			uiFound++;
		}
		iter++;
	}
	
	return spDmaChannel;
}

ot_int32_t ImpDmaEnumerator::GetNumDmaChannels(OT_DMA_Type_BitField bitField)
{
	ot_int32_t uiResult = 0;

	// What is the base type for this DMA Channel Request
	OT_DMA_Type type = OT_GET_DMA_TYPE(bitField);
	OmDmaPairIterator pairIterator = GetDmaChannelsIterator(type);
	OmDmaMultiMapByDmaType::iterator iter = pairIterator.first;

	// Now iterate through the available DMAs looking for the bitfield type
	while( iter != pairIterator.second )
	{
		if( iter->second->GetBitFieldType() == bitField )
			uiResult++; // We have a match
		iter++;
	}
	
	return uiResult;
}

IDmaChannelPtr ImpDmaEnumerator::GetDmaChannel(OT_DMA_Type_BitField bitField, ot_int32_t index)
{
	IDmaChannelPtr spDmaChannel;

	OmDmaPairIterator pairIterator = GetDmaChannelsIterator(OT_GET_DMA_TYPE(bitField));
	OmDmaMultiMapByDmaType::iterator iter = pairIterator.first;

	// Now iterator through looking for the requested bitfield type
	ot_int32_t uiFound = 0;
	while( iter != pairIterator.second )
	{
		if( iter->second->GetBitFieldType() == bitField )
		{
			if(index == uiFound )
			{
				spDmaChannel = iter->second;
				break;
			}
			uiFound++;
		}
		iter++;
	}

	return spDmaChannel;
}



bool ImpDmaEnumerator::AddCapability(InternalCapability *pCapability)
{
	bool bResult = true;

	InternalDmaBase *pDmaChannel = NULL;

	ot_uint32_t type= pCapability->GetType();

	InternalRegisterCapability *pRegCap = pCapability->GetRegisterCapability();
	if( pRegCap == NULL ) // This should never happen, but check just in case
		return false;


	// Check to see whether DMAs are supported on this DMA controller
	uint64_t result;
	if( pRegCap->QueryInfo(QueryInfo_DMASupported, result) != OT_Status_OK )
		return false; // If QueryInfo fails we know that the capability doesn't support DMAs

	_DmaType dmaType = (_DmaType)result;
	switch( dmaType )
	{
		case DmaType_Standard:
			pDmaChannel = _spChannelFactory->CreateMDma(GetParentTracker(), pCapability, OmDmaFunctionMask(type));
			break;
		case DmaType_Streaming:
			pDmaChannel = _spChannelFactory->CreateVideoFDma(GetParentTracker(), pCapability, OmDmaFunctionMask(type));
			break;
		default:
			break;
	}

	if( pDmaChannel )
	{
		if( pDmaChannel->bIsValid() )
			_channelsByType.insert(std::make_pair(pDmaChannel->GetType(), pDmaChannel));
		else
		{
			delete pDmaChannel;
			bResult = false;
		}
	}
	else
		bResult = false;
	return bResult;
}
