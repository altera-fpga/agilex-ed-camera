/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "StdAfx.h"
#include "PlatformImpDma.h"
#include "IOmniTekInterface.h"
#include "capability/VideoFDMA_IOCTL.h"
#include "capability/MDMA_IOCTL.h"
#include <poll.h>

///////////////////////////////////////////////////////////////////////////////////////
PlatformImpDma::PlatformImpDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OT_DMA_Type_BitField type)
	: ImpDmaBase(pParentTracker, pCapability, type)
{
	int test = pCapability->GetRegisterCapability()->GetFileHandle();
	_hCap = test;
}

PlatformImpDma::~PlatformImpDma()
{
}

OT_Status PlatformImpDma::SendDmaXferRequest(PlatformImpDmaXfer *pDmaXfer, bool bOverlapped)
{
	int ioctlVal = 0;
	OT_Status status = OT_Status_Fail;

	ioctlVal = ioctl(_hCap, pDmaXfer->GetIoctlNum(), pDmaXfer->GetIoctl());
	if( ioctlVal != 0 )
		return OT_Status_Fail;

    status = OT_Status_Request_Pending;

	if (bOverlapped==false)
	{
		status = PlatformMemoryXferWait(pDmaXfer, OT_DMA_DEFAULT_TIMEOUT);
	}
	return status;
}

OT_Status PlatformImpDma::PlatformMemoryXferWait(PlatformImpDmaXfer *pDmaXfer, ot_int32_t timeout_ms)
{
	return _WaitForXfer(pDmaXfer->GetEventIoctlCtx(), timeout_ms);
}

OT_Status PlatformImpDma::PlatformCancelXfer(PlatformImpDmaXfer *pDmaXfer)
{
	return CancelXfer(pDmaXfer->GetEventIoctlCtx());
}

OT_Status PlatformImpDma::CancelXfer(CapGeneral_EventCtx_IOCTL *pEventIoctl)
{
	OT_Status status = OT_Status_OK;

	if( pEventIoctl->EventFD < 0 )
		return OT_Status_Fail;

	// Check to see if the event has already been canceled?
	struct pollfd fds;
	int selectret;

	// Setup a wait object
	fds.fd = pEventIoctl->EventFD;
	fds.revents = 0;
	fds.events = POLLIN;

    selectret = poll( &fds, 1, 0);
	if( selectret == 1 )
	{
		// Must have either completed or been canceled to we don't need to cancel
		return OT_Status_OK;
	}

	// Not already canceled so try and cancel
	int ioctlVal = 0;
	CapGeneral_Cancel_IOCTL Cancel_IOCTL;
	INIT_IOCTL(&Cancel_IOCTL, CAP_COMMON_IOCTL_Cancel_Version, sizeof(Cancel_IOCTL));
	Cancel_IOCTL.EventInfo = *pEventIoctl;

	ioctlVal = ioctl( _hCap, CAP_COMMON_IOCTL_Cancel, &Cancel_IOCTL );
	if( ioctlVal != 0 )
		status = OT_Status_Fail;
	return status;
}

OT_Status PlatformImpDma::_WaitForXfer(CapGeneral_EventCtx_IOCTL *pEventIoctl, ot_int32_t timeout_ms)
{
	struct pollfd fds;
	int selectret;

	int eventfd = pEventIoctl->EventFD;
	if( eventfd < 0 )
		return OT_Status_Fail;

	// Setup a wait object
	fds.fd = eventfd;
	fds.revents = 0;
	fds.events = POLLIN;

    selectret = poll( &fds, 1, (timeout_ms<0) ? -1 : timeout_ms);

    if( selectret == -1 )
    {
        perror( "select failed");
        return OT_Status_Request_Failed;
    }
    else if( selectret == 0 )
    {
    	CancelXfer(pEventIoctl);
        return OT_Status_Request_Timeout;
    }

   	return OT_Status_OK;
}

///////////////////////////////////////////////////////////////////////////////////////
PlatformImpVideoFDma::PlatformImpVideoFDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OT_DMA_Type_BitField type)
	: PlatformImpDma(pParentTracker, pCapability, type)
{
}

PlatformImpVideoFDma::~PlatformImpVideoFDma()
{
}

OT_Status PlatformImpVideoFDma::PlatformStart()
{
    int ioctlVal = 0;
    CapVideoFDMA_VersionOnly_IOCTL start;

    INIT_IOCTL(&start, CAP_VIDEOFDMA_IOCTL_Start_Version, sizeof(start));

    ioctlVal = ioctl( GetDeviceHandle(), CAP_VIDEOFDMA_IOCTL_Start, &start );
    if ( ioctlVal != 0 )
    {
        //perror( "%s. CAP_VIDEOFDMA_IOCTL_Stop failed: %d.\n", strerror(errno), ioctlVal );
        return OT_Status_Fail;
    }
    return OT_Status_OK;
}

OT_Status PlatformImpVideoFDma::PlatformStop()
{
    int ioctlVal = 0;
    CapVideoFDMA_VersionOnly_IOCTL stop;

    INIT_IOCTL(&stop, CAP_VIDEOFDMA_IOCTL_Stop_Version, sizeof(stop));

    ioctlVal = ioctl( GetDeviceHandle(), CAP_VIDEOFDMA_IOCTL_Stop, &stop );
    if ( ioctlVal != 0 )
    {
        //perror( "%s. CAP_VIDEOFDMA_IOCTL_Stop failed: %d.\n", strerror(errno), ioctlVal );
        return OT_Status_Fail;
    }
    return OT_Status_OK;
}

///////////////////////////////////////////////////////////////////////////////////////
PlatformImpMDma::PlatformImpMDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OT_DMA_Type_BitField type)
	: PlatformImpDma(pParentTracker, pCapability, type)
{
}

PlatformImpMDma::~PlatformImpMDma()
{
}
///////////////////////////////////////////////////////////////////////////////////////
PlatformImpDmaEvent::PlatformImpDmaEvent(PlatformImpDma* pChannel)
	: ImpDmaEventBase(pChannel)
{
}
PlatformImpDmaEvent::~PlatformImpDmaEvent()
{
}

OT_Status PlatformImpDmaEvent::SendIoctl(PlatformDmaEventXfer *pXfer)
{
	OT_Status status = OT_Status_Fail;
	unsigned int ioctlResult = -1;

	ioctlResult = ioctl(_pDmaChannel->GetDeviceHandle(), pXfer->GetIoctlNum(), pXfer->GetIoctl());
	if( ioctlResult == 0 )
		status = OT_Status_Request_Pending; // Mark this event as pending

	return status;
}
OT_Status PlatformImpDmaEvent::_WaitXfer(PlatformDmaEventXfer *pXfer, ot_int32_t Timeout)
{
	return _pDmaChannel->_WaitForXfer(pXfer->GetEventIoctlCtx(), Timeout);
}

OT_Status PlatformImpDmaEvent::_Cancel(PlatformDmaEventXfer *pXfer)
{
	return _pDmaChannel->CancelXfer(pXfer->GetEventIoctlCtx());
}
