/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "../ImpDmaXfer.h"
#include "capability/IOCTL_DMACommon.h"
#include "capability/VideoFDMA_IOCTL.h"
#include "capability/MDMA_IOCTL.h"

class PlatformImpDmaXfer : public ImpDmaXfer
{
public:
	PlatformImpDmaXfer( IDmaChannelPtr &spDmaChannel );
	virtual ~PlatformImpDmaXfer();

    virtual ot_int32_t GetIoctlNum( ) = 0;

    virtual otEventHandle GetCompletionHandle( );
    virtual bool bIsValid( ) = 0;

    virtual CapGeneral_EventCtx_IOCTL *GetEventIoctlCtx( ) = 0;
    virtual void *GetIoctl( ) = 0;
    virtual OT_Status GetTransactionTime( otDmaTiming *pTiming ) const = 0;

protected:
    // Disable copying
    PlatformImpDmaXfer(const PlatformImpDmaXfer& other);
    PlatformImpDmaXfer& operator=(const PlatformImpDmaXfer& other);

	int _eventFD;

    DMATransaction_IOCTL_Linux *AllocateTransactionV1( unsigned int nTargets, bool bWrite, uint32_t payloadVersion );
    DMATransaction_IOCTL_V2_Linux *AllocateTransactionV2( unsigned int nTargets, uint32_t payloadVersion );
};

class PlatformImpMDmaXfer : public PlatformImpDmaXfer
{
public:
    PlatformImpMDmaXfer(const PlatformImpMDmaXfer& other) = delete;
    PlatformImpMDmaXfer(PlatformImpMDmaXfer&& other) = delete;
    PlatformImpMDmaXfer& operator=(const PlatformImpMDmaXfer& other) = delete;
    PlatformImpMDmaXfer& operator=(PlatformImpMDmaXfer&& other) = delete;

    PlatformImpMDmaXfer( IDmaChannelPtr spDmaChannel, ot_uint32_t nTargets, bool bWrite );
    virtual ~PlatformImpMDmaXfer( );

    virtual ot_int32_t GetIoctlNum( );
    virtual bool bIsValid( );
    virtual CapGeneral_EventCtx_IOCTL *GetEventIoctlCtx( );
    virtual void *GetIoctl( );
    virtual OT_Status GetTransactionTime( otDmaTiming *pTiming ) const;
private:
    virtual void    _SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer);
    virtual void    _SetVersion(ot_uint32_t version);

    DMATransaction_IOCTL_Linux  *_pIoctl;
};

class PlatformImpMDmaXferV2 : public PlatformImpDmaXfer
{
public:
    PlatformImpMDmaXferV2(const PlatformImpMDmaXferV2& other) = delete;
    PlatformImpMDmaXferV2(PlatformImpMDmaXferV2&& other) = delete;
    PlatformImpMDmaXferV2& operator=(const PlatformImpMDmaXferV2& other) = delete;
    PlatformImpMDmaXferV2& operator=(PlatformImpMDmaXferV2&& other) = delete;

    PlatformImpMDmaXferV2( IDmaChannelPtr spDmaChannel, ot_uint32_t nTargets, bool bWrite );
    virtual ~PlatformImpMDmaXferV2( );

    virtual ot_int32_t GetIoctlNum( );
    virtual bool bIsValid( );
    virtual CapGeneral_EventCtx_IOCTL *GetEventIoctlCtx( );
    virtual void *GetIoctl( );
    virtual OT_Status GetTransactionTime( otDmaTiming *pTiming ) const;
private:
    virtual void    _SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer);
    virtual void    _SetVersion(ot_uint32_t version);

    const bool _bWrite;
    DMATransaction_IOCTL_V2_Linux  *_pIoctl;
};

class PlatformImpVideo_FDMAXfer : public PlatformImpDmaXfer
{
public:
    PlatformImpVideo_FDMAXfer(const PlatformImpVideo_FDMAXfer& other) = delete;
    PlatformImpVideo_FDMAXfer(PlatformImpVideo_FDMAXfer&& other) = delete;
    PlatformImpVideo_FDMAXfer& operator=(const PlatformImpVideo_FDMAXfer& other) = delete;
    PlatformImpVideo_FDMAXfer& operator=(PlatformImpVideo_FDMAXfer&& other) = delete;

	PlatformImpVideo_FDMAXfer(IDmaChannelPtr spDmaChannel, ot_uint32_t nTargets, bool bWrite, ot_int32_t ioctlNum);
	virtual ~PlatformImpVideo_FDMAXfer();

    virtual ot_int32_t GetIoctlNum( );
    virtual bool bIsValid( );
    virtual CapGeneral_EventCtx_IOCTL *GetEventIoctlCtx( );
    virtual void *GetIoctl( );
    virtual OT_Status GetTransactionTime( otDmaTiming *pTiming ) const;
private:
    virtual void    _SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer);
    virtual void    _SetVersion(ot_uint32_t version);

    DMATransaction_IOCTL_Linux  *_pIoctl;
    ot_int32_t _ioctlNum;
};

class PlatformImpVideo_FDMAXferV2 : public PlatformImpDmaXfer
{
public:
    PlatformImpVideo_FDMAXferV2(const PlatformImpVideo_FDMAXferV2& other) = delete;
    PlatformImpVideo_FDMAXferV2(PlatformImpVideo_FDMAXferV2&& other) = delete;
    PlatformImpVideo_FDMAXferV2& operator=(const PlatformImpVideo_FDMAXferV2& other) = delete;
    PlatformImpVideo_FDMAXferV2& operator=(PlatformImpVideo_FDMAXferV2&& other) = delete;

    PlatformImpVideo_FDMAXferV2(IDmaChannelPtr spDmaChannel, ot_uint32_t nTargets, bool bWrite);
    virtual ~PlatformImpVideo_FDMAXferV2();

    virtual ot_int32_t GetIoctlNum( );
    virtual bool bIsValid( );
    virtual CapGeneral_EventCtx_IOCTL *GetEventIoctlCtx( );
    virtual void *GetIoctl( );
    virtual OT_Status GetTransactionTime( otDmaTiming *pTiming ) const;
private:
    virtual void    _SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer);
    virtual void    _SetVersion(ot_uint32_t version);

    const bool _bWrite;
    DMATransaction_IOCTL_V2_Linux  *_pIoctl;
};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class PlatformDmaEventXfer : public ImpDmaEventXfer
{
public:
	PlatformDmaEventXfer(ImpDmaEventBasePtr spDmaEvent);
	virtual ~PlatformDmaEventXfer();

	// Interface Functions
	ot_int32_t GetBytesTransferred();
	otTime	   GetInterruptTime();
	otEventHandle GetCompletionHandle();
	void SetBytesTransferred(ot_int32_t bytesTransferred);

	ot_int32_t GetIoctlNum()	{return CAP_DATAFDMA_IOCTL_Event;};
	void *GetIoctl() {return &_ioctl;};
	CapGeneral_EventCtx_IOCTL *GetEventIoctlCtx() {return &(_ioctl.EventInfo);};
private:
	CapDataFDMA_Event_IOCTL_Linux _ioctl;
};

