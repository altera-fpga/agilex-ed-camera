/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#pragma pack(push, 1)

#define OT_PCI_HEADER_TYPE_OFFSET (0x0E)

#define OT_PCI_NEXT_CAPABILITY_OFFSET	(0x34)
typedef struct _OT_PCI_CAPABILITIES_HEADER {
	uint8_t CapabilityID;
	uint8_t Next;
} OT_PCI_CAPABILITIES_HEADER;

//***********************************************************************
// PCI Express Capability
#define OT_PCI_CAPABILITY_ID_PCI_EXPRESS	(0x10)

#define OT_PCIE_LINK_STATUS_OFFSET (0x12)
#define OT_PCIE_LINK_STATUS_SPEED_MASK (0x000f)
#define OT_PCIE_LINK_STATUS_SPEED_SHIFT (0)
#define OT_PCIE_LINK_STATUS_WIDTH_MASK (0x03f0)
#define OT_PCIE_LINK_STATUS_WIDTH_SHIFT (4)

#pragma pack (pop)
