/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "../HostController.h"

class PlatformHostController : public HostController
{
public:
	PlatformHostController();
	virtual ~PlatformHostController();

	virtual bool Open(const OTBus_HCInfo &hcInfo);
	virtual void Close();

	virtual ot_int32_t	GetNumRegions();
	virtual ot_uint32_t	GetRegionSize( ot_int32_t idx);
	virtual OT_Status	ReadRegion(ot_int32_t idx, void* pBuffer, ot_uint32_t bufferSize, ot_uint32_t offset);

	virtual OT_PLATFORM_INTERFACE	GetPlatformInterface();
	virtual ot_uint32_t			ReadPciConfig(void *pBuffer, ot_uint32_t size, ot_uint32_t offset);
private:
	// Disable copying
	PlatformHostController(const PlatformHostController& other);
	PlatformHostController operator=(const PlatformHostController& other);

	int _hDev; // Handle to the Host Controller
};
