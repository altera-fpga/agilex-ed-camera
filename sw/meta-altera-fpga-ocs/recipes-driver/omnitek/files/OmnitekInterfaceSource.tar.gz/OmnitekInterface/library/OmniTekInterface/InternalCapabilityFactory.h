/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once

#include "IOmniTekInterface.h"

#include "InternalCapability.h"
#include "ImpOmniTekPtr.h"

#include "bus/OmniTekBus_IOCTL.h"

class InternalCapabilityCollection
{
public:
    virtual ~InternalCapabilityCollection() {}
    virtual bool AddCapability(InternalCapability *pCapability) = 0;
};

class InternalDmaEnumerator : public OmniTek::IDmaEnumerator, public InternalCapabilityCollection, public ImpOmniTekBasePtr
{
public:
    InternalDmaEnumerator(OTParentTracker *pParentTracker) : ImpOmniTekBasePtr{pParentTracker} {}

    DECLARE_IMP_OMNITEK_PTR
};

class InternalCapabilityEnumerator : public OmniTek::ICapabilityEnumerator, public InternalCapabilityCollection,
                                     public ImpOmniTekBasePtr
{
public:
    InternalCapabilityEnumerator(OTParentTracker *pParentTracker) : ImpOmniTekBasePtr{pParentTracker} {}

    DECLARE_IMP_OMNITEK_PTR
};


class ImpBoard;
class HostController;
class ImpFpga;

namespace OmniTek
{
    class ICapabilityRegions;
    class IPlatformInfo;
} // namespace OmniTek

class InternalCapabilityFactory
{
public:
    virtual ~InternalCapabilityFactory() {}

    virtual InternalDmaEnumerator* CreateDmaEnumerator(OTParentTracker* pParentTracker) = 0;
    virtual InternalCapabilityEnumerator* CreateCapabilityEnumerator(OTParentTracker* pParentTracker) = 0;
    virtual OmniTek::ICapabilityRegions* CreateCapabilityRegions(OTParentTracker* pParentTracker, HostController* pHostController) = 0;
    virtual OmniTek::IPlatformInfo* CreatePlatformInfo(OTParentTracker* pParentTracker, HostController *pHostController) = 0;
    virtual InternalCapability* CreateCapability(OTParentTracker* pParentTracker, IFpga *pFpga, const OTBus_CapDevInfo& capDevInfo) = 0;
};

