/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekTypes.h"
#include "bus/OmniTekBus_IOCTL.h"
using namespace OmniTek;

class HostController
{
public:
	HostController(void);
	virtual ~HostController(void);

	virtual bool Open(const OTBus_HCInfo &hcInfo) = 0;
	virtual void Close() = 0;

	virtual ot_int32_t				GetNumRegions() = 0;
	virtual ot_uint32_t	GetRegionSize( ot_int32_t idx) = 0;
	virtual OT_Status		ReadRegion(ot_int32_t idx, void* pBuffer, ot_uint32_t bufferSize, ot_uint32_t offset) = 0;

	virtual OT_PLATFORM_INTERFACE	GetPlatformInterface() = 0;
	virtual ot_uint32_t			ReadPciConfig(void *pBuffer, ot_uint32_t size, unsigned offset) = 0;
};

#if BUILDTYPE==BT_WINDOWS
#include "windows\PlatformHostController.h"
#else
#include "linux/PlatformHostController.h"
#endif
