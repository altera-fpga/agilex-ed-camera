/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "ImpOmniTekPtr.h"

using namespace OmniTek;

class HostController;
class ImpCapabilityRegions : public ICapabilityRegions, ImpOmniTekBasePtr
{
public:
	ImpCapabilityRegions(OTParentTracker* pParentTracker, HostController *pHostController);

	virtual ~ImpCapabilityRegions(void);

	// Interface Functions
	virtual ot_int32_t				GetNumRegions();
	virtual ot_uint32_t	GetRegionSize( ot_int32_t idx);
	virtual OT_Status		ReadRegion(ot_int32_t idx, void* pBuffer, ot_uint32_t bufferSize, ot_uint32_t offset);

	// Macro to connect up the Base Smart Pointer implementation
	DECLARE_IMP_OMNITEK_PTR
protected:
	HostController*	_pHostController;
};

