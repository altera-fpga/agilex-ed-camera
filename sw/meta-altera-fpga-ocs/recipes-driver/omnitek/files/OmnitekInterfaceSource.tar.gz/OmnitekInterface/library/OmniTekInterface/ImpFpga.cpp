/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "IOmniTekInterface.h"
#include "ImpFpga.h"
#include "ImpBoard.h"
#include "HW_Defs.h"
#include "HostController.h"

ImpFpga::ImpFpga(const OTBus_SlotInfo *pSlotInfo, ImpBoard *pBoard, HostController *pHostController,
				InternalCapabilityFactory& capabilityFactory)
	: ImpOmniTekBasePtr(pBoard)
	, _pHostController(pHostController)
	, _pBoard(pBoard)
{
	if( _pHostController->Open(pSlotInfo->HostControllerInfo) )
	{
		// Create a DMA Channel Basket
		InternalDmaEnumerator *pDmaChannels = capabilityFactory.CreateDmaEnumerator(pBoard);

		// Let the Smart Pointer take care of cleaning up this pointer
		_spDmaChannels = IDmaEnumeratorPtr(pDmaChannels);

		// Create a Capability Basket
		InternalCapabilityEnumerator* pCapabilities = capabilityFactory.CreateCapabilityEnumerator(pBoard);
		// Let the Smart Pointer take care of cleaning up this pointer
		_spCapabilities = ICapabilityEnumeratorPtr(pCapabilities);

		// Create a Capability Region Helper
		_spCapabilityRegions = capabilityFactory.CreateCapabilityRegions(pBoard, _pHostController);

		// Create a Platform Info Helper
		_spPlatformInfo = capabilityFactory.CreatePlatformInfo(pBoard, _pHostController);

		if (!_spDmaChannels || !_spCapabilities || !_spCapabilityRegions || !_spPlatformInfo)
		{
			_spDmaChannels = nullptr;
			_spCapabilities = nullptr;
			_spCapabilityRegions = nullptr;
			_spPlatformInfo = nullptr;
			return;
		}

		// Enumerate the board to find all the available slots
		for( int i=0; i<(int)pSlotInfo->NumCapDevs; i++ )
		{
			const OTBus_CapDevInfo& capDevInfo = pSlotInfo->CapDevs[i];

			if( (capDevInfo.Type == OFC_RegisterCap) || (capDevInfo.Type==OFC_OffsetCap ) ) // This is a register capability
			{
				InternalCapability *pCap = capabilityFactory.CreateCapability(GetParentTracker(), this, capDevInfo);
				if( pCap && (pCap->GetRegisterCapability() != NULL) ) //Make sure the capability is valid
				{
					pCapabilities->AddCapability(pCap);

					// Try and add to the dma channels.
					pDmaChannels->AddCapability(pCap);
				}
				else
				{
					delete pCap; // Delete the capability
				}
			}
		}
	}
}


ImpFpga::~ImpFpga(void)
{
	_spCapabilities = NULL;
	_spDmaChannels = NULL;
	_spCapabilityRegions = NULL;

	// Now delete the host controller
	delete _pHostController;
}

OT_Status ImpFpga::GetTimingCounter(otTime &ticks)
{
	OT_Status status = OT_Status_Timing_Not_Implemented;
	ticks = 0;

	ICapability* pCap = _spCapabilities->GetCapability(0); // Simply get the first capability and try and get the timing value
	if( pCap )
		status = pCap->GetTimingCounter(ticks);

	return status;
}

OT_Status ImpFpga::GetTimingFrequency(otTime &ticksPerSecond)
{
	OT_Status status = OT_Status_Timing_Not_Implemented;
	ticksPerSecond = 0;

	ICapability* pCap = _spCapabilities->GetCapability(0); // Simply get the first capability and try and get the timing value
	if( pCap )
		status = pCap->GetTimingFrequency(ticksPerSecond);

	return status;
}
