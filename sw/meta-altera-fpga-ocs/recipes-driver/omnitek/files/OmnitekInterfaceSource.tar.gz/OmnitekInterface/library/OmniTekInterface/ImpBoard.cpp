/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpBoard.h"
#include "ImpFpgaFactory.h"
#include "ImpCapability.h"
#include "HW_Defs.h"

#define MAX_BOARD_DETAILS (4)

typedef struct
{
	char	_manufacturer[100];
	char	_boardName[100];
	char	_version[100];
}BOARD_DETAILS;

BOARD_DETAILS _gDetails[MAX_BOARD_DETAILS] =
{
	{"OmniTek", "DataLab", "V1.0"},
	{"Xilinx", "AVDP", "V2.3"},
	{"OmniTekLegacy", "Atlantic", "V4.0"},
	{"OmniTekLegacy", "Artic", "V1.0"},
};

ImpBoard::ImpBoard(ot_int32_t instance, IFpgaFactory *pParent)
: _name{'\0'}
, _manufacturer{'\0'}
, _version{'\0'}
, _instance{instance}
, _pParent{pParent}
, _type{}
, _fpgaPtrList{}
, _parentRefCounter{}
{

}

ImpBoard::~ImpBoard(void)
{
}

void ImpBoard::AddFpga(const OTBus_SlotInfo *pSlotInfo, const InternalFpgaCreator& fpgaCreator)
{
	_fpgaPtrList.push_back(fpgaCreator(pSlotInfo, this));

	// TODO : Need to get the manufacturer details
	StrCpy(_manufacturer, 100, "OmniTek Ltd.");
	StrCpy(_version, 100, "1.2.3.4");
	StrCpy(_name, 256, pSlotInfo->HostControllerInfo.TypeName);
	_type.Data1 = pSlotInfo->HostControllerInfo.Uuid.Data1;
	_type.Data2 = pSlotInfo->HostControllerInfo.Uuid.Data2;
	_type.Data3 = pSlotInfo->HostControllerInfo.Uuid.Data3;
	for( ot_int32_t a=0; a<8; a++ )
		_type.Data4[a] = pSlotInfo->HostControllerInfo.Uuid.Data4[a];

}

ot_int32_t ImpBoard::GetBoardInstance()
{
	return _instance;
}

IFpgaFactory*	ImpBoard::GetApi()
{
	return (IFpgaFactory*)_pParent;
}

ot_int32_t ImpBoard::GetNumFPGAs()
{
	return (ot_int32_t)_fpgaPtrList.size();
}

IFpgaPtr ImpBoard::GetFPGA(ot_int32_t instance)
{
	IFpgaPtr spFpga;

	if( instance < (ot_int32_t)_fpgaPtrList.size() )
		spFpga = _fpgaPtrList[instance];

	return spFpga;
}

//////////////////////////////////////////////////////////////
// Implementation functions for OTParentTracker
void ImpBoard::AddParentRef()
{
	_parentRefCounter.InterlockedIncrement();
//	ot_uint32_t lockCount = _parentRefCounter.InterlockedIncrement();
//	printf("AddParentRef %d\n", lockCount);
}

void ImpBoard::ReleaseParentRef()
{
	_parentRefCounter.InterlockedDecrement();
//	ot_uint32_t lockCount = _parentRefCounter.InterlockedDecrement();
//	printf("ReleaseParentRef %d\n", lockCount);
}

bool ImpBoard::bSafeToRelease()
{
//	printf("BoardImp::bSafeToRelease %d\n", _parentRefCounter.GetRefCount());
	return _parentRefCounter.GetRefCount() == 0;
}
