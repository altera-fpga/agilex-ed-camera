/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "StdAfx.h"
#include <assert.h>
#include "PlatformImpDmaXfer.h"
#include <sys/eventfd.h>

PlatformImpDmaXfer::PlatformImpDmaXfer( IDmaChannelPtr& spDmaChannel )
	: ImpDmaXfer(spDmaChannel)
    , _eventFD( eventfd( 0, 0 ) )
{
}

PlatformImpDmaXfer::~PlatformImpDmaXfer()
{
    if( _eventFD > -1 )
        close( _eventFD );
}

otEventHandle PlatformImpDmaXfer::GetCompletionHandle()
{
	otEventHandle handle = -1;
	if( bIsValid() && (_eventFD>-1) )
        handle = _eventFD;

	return handle;
}

DMATransaction_IOCTL_Linux *PlatformImpDmaXfer::AllocateTransactionV1( unsigned int nTargets, bool bWrite, uint32_t payloadVersion )
{
    if ( _eventFD < 0 )
    {
        perror("Could not allocate eventfd\n");
        return NULL;
    }
	DMATransaction_IOCTL_Linux *pIoctl = NULL;
    uint32_t allocate = sizeof( DMATransaction_IOCTL_Linux ) + ( nTargets * sizeof( DmaTarget ) );
	pIoctl = (DMATransaction_IOCTL_Linux*)malloc(allocate);
	if( pIoctl == NULL )
	{
		perror("Could not allocate ioctl\n");
		return NULL;
	}
	INIT_IOCTL(&(pIoctl->IOCTLInfo), payloadVersion, sizeof(pIoctl->IOCTLInfo));
	pIoctl->IOCTLInfo.Dma.Write = bWrite?1:0;
	pIoctl->IOCTLInfo.Dma.nTargets = nTargets;
	pIoctl->EventInfo.EventFD = _eventFD;

	return pIoctl;
}

DMATransaction_IOCTL_V2_Linux *PlatformImpDmaXfer::AllocateTransactionV2( unsigned int nTargets, uint32_t payloadVersion )
{
    if ( _eventFD < 0 )
    {
        perror("Could not allocate eventfd\n");
        return NULL;
    }
    DMATransaction_IOCTL_V2_Linux *pIoctl = NULL;
    uint32_t allocate = sizeof( DMATransaction_IOCTL_V2_Linux ) + ( nTargets * sizeof( DmaTarget_V2 ) );
    pIoctl = (DMATransaction_IOCTL_V2_Linux*)malloc(allocate);
    if( pIoctl == NULL )
    {
        perror("Could not allocate ioctl\n");
        return NULL;
    }
    INIT_IOCTL(&(pIoctl->IOCTLInfo), payloadVersion, sizeof(pIoctl->IOCTLInfo));
    pIoctl->IOCTLInfo.Dma.nTargets = nTargets;
    pIoctl->EventInfo.EventFD = _eventFD;

    return pIoctl;
}

/////////////////////////////////////////////////////////////////////////////////
PlatformImpVideo_FDMAXfer::PlatformImpVideo_FDMAXfer(IDmaChannelPtr spDmaChannel, unsigned int nTargets, bool bWrite,
                                                     ot_int32_t ioctlNum)
	: PlatformImpDmaXfer( spDmaChannel )
    , _pIoctl( NULL )
    , _ioctlNum( ioctlNum )
{
    _pIoctl = AllocateTransactionV1( nTargets, bWrite, CAP_VIDEOFDMA_IOCTL_Transfer_Version1 );
}

PlatformImpVideo_FDMAXfer::~PlatformImpVideo_FDMAXfer()
{
    if( _pIoctl )
    {
        free(_pIoctl);
        _pIoctl = NULL;
    }
}

OT_Status PlatformImpVideo_FDMAXfer::GetTransactionTime( otDmaTiming *pTiming ) const
{
    OT_Status status = OT_Status_Timing_Not_Implemented;
    if( pTiming )
    {
        pTiming->_endTime = _pIoctl->IOCTLInfo.Dma.EndTime;
        pTiming->_startTime = _pIoctl->IOCTLInfo.Dma.StartTime;
        status = OT_Status_OK;
    }
    return status;
}

ot_int32_t PlatformImpVideo_FDMAXfer::GetIoctlNum( )
{
    return _ioctlNum;
}

bool PlatformImpVideo_FDMAXfer::bIsValid( )
{
    return ( ( _pIoctl != NULL ) && ( _eventFD > -1 ) );
}

CapGeneral_EventCtx_IOCTL *PlatformImpVideo_FDMAXfer::GetEventIoctlCtx( )
{
    return ( bIsValid( ) ? &( _pIoctl->EventInfo ) : NULL );
}

void *PlatformImpVideo_FDMAXfer::GetIoctl( )
{
    return _pIoctl;
}

void PlatformImpVideo_FDMAXfer::_SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer)
{
    if( target < _pIoctl->IOCTLInfo.Dma.nTargets )
    {
        DmaTarget* pTarget = &(_pIoctl->IOCTLInfo.Dma.Targets[target]);
        memset(pTarget, 0, sizeof(DmaTarget));

        pTarget->LocalAddr  = localAddr;
        pTarget->DUMMYUNIONNAME.pVa        = pBuffer;
        pTarget->Size       = size;
        pTarget->bNoSync    = !bSyncBuffer;
    }
}

void PlatformImpVideo_FDMAXfer::_SetVersion(ot_uint32_t version)
{
    if( _pIoctl )
    {
        if( version == 0 )
            _pIoctl->IOCTLInfo.Version = CAP_VIDEOFDMA_IOCTL_Transfer_Version0;
        else if( version == 1 )
            _pIoctl->IOCTLInfo.Version = CAP_VIDEOFDMA_IOCTL_Transfer_Version1;
        else
            assert(0);
    }
}

/////////////////////////////////////////////////////////////////////////////////
PlatformImpVideo_FDMAXferV2::PlatformImpVideo_FDMAXferV2(IDmaChannelPtr spDmaChannel, unsigned int nTargets, bool bWrite)
    : PlatformImpDmaXfer( spDmaChannel )
    , _bWrite( bWrite )
    , _pIoctl( NULL )
{
    _pIoctl = AllocateTransactionV2( nTargets, CAP_VIDEOFDMA_IOCTL_Transfer_Version2 );
}

PlatformImpVideo_FDMAXferV2::~PlatformImpVideo_FDMAXferV2()
{
    if( _pIoctl )
    {
        free(_pIoctl);
        _pIoctl = NULL;
    }
}

OT_Status PlatformImpVideo_FDMAXferV2::GetTransactionTime( otDmaTiming *pTiming ) const
{
    OT_Status status = OT_Status_Timing_Not_Implemented;
    if( pTiming )
    {
        pTiming->_endTime = _pIoctl->IOCTLInfo.Dma.EndTime;
        pTiming->_startTime = _pIoctl->IOCTLInfo.Dma.StartTime;
        status = OT_Status_OK;
    }
    return status;
}

ot_int32_t PlatformImpVideo_FDMAXferV2::GetIoctlNum( )
{
    return CAP_VIDEOFDMA_IOCTL_Transfer;
}

bool PlatformImpVideo_FDMAXferV2::bIsValid( )
{
    return ( ( _pIoctl != NULL ) && ( _eventFD > -1 ) );
}

CapGeneral_EventCtx_IOCTL *PlatformImpVideo_FDMAXferV2::GetEventIoctlCtx( )
{
    return ( bIsValid( ) ? &( _pIoctl->EventInfo ) : NULL );
}

void *PlatformImpVideo_FDMAXferV2::GetIoctl( )
{
    return _pIoctl;
}

void PlatformImpVideo_FDMAXferV2::_SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer)
{
    if( target < _pIoctl->IOCTLInfo.Dma.nTargets )
    {
        DmaTarget_V2* pTarget = &(_pIoctl->IOCTLInfo.Dma.Targets[target]);
        memset(pTarget, 0, sizeof(DmaTarget_V2));

        pTarget->LocalAddr  = localAddr;
        pTarget->DUMMYUNIONNAME.pVa        = pBuffer;
        pTarget->Size       = size;
        pTarget->bNoSync    = !bSyncBuffer;
        pTarget->Write      = _bWrite;
    }
}

void PlatformImpVideo_FDMAXferV2::_SetVersion(ot_uint32_t version)
{
    if( _pIoctl )
    {
        if( version == 2 )
            _pIoctl->IOCTLInfo.Version = CAP_VIDEOFDMA_IOCTL_Transfer_Version2;
        else
            assert(0);
    }
}

/////////////////////////////////////////////////////////////////////////////////

PlatformImpMDmaXfer::PlatformImpMDmaXfer(IDmaChannelPtr spDmaChannel, unsigned int nTargets, bool bWrite)
	: PlatformImpDmaXfer( spDmaChannel )
    , _pIoctl( NULL )
{
    _pIoctl = AllocateTransactionV1( nTargets, bWrite, CAP_MDMA_IOCTL_Transfer_Version0 );
}

PlatformImpMDmaXfer::~PlatformImpMDmaXfer()
{
    if( _pIoctl )
    {
        free(_pIoctl);
        _pIoctl = NULL;
    }
}

OT_Status PlatformImpMDmaXfer::GetTransactionTime( otDmaTiming *pTiming ) const
{
    OT_Status status = OT_Status_Timing_Not_Implemented;
    if( pTiming )
    {
        pTiming->_endTime = _pIoctl->IOCTLInfo.Dma.EndTime;
        pTiming->_startTime = _pIoctl->IOCTLInfo.Dma.StartTime;
        status = OT_Status_OK;
    }
    return status;
}

ot_int32_t PlatformImpMDmaXfer::GetIoctlNum( )
{
    return CAP_MDMA_IOCTL_Transfer;
}

bool PlatformImpMDmaXfer::bIsValid( )
{
    return ( ( _pIoctl != NULL ) && ( _eventFD > -1 ) );
}

CapGeneral_EventCtx_IOCTL *PlatformImpMDmaXfer::GetEventIoctlCtx( )
{
    return ( bIsValid( ) ? &( _pIoctl->EventInfo ) : NULL );
}

void *PlatformImpMDmaXfer::GetIoctl( )
{
    return _pIoctl;
}

void PlatformImpMDmaXfer::_SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer)
{
    if( target < _pIoctl->IOCTLInfo.Dma.nTargets )
    {
        DmaTarget* pTarget = &(_pIoctl->IOCTLInfo.Dma.Targets[target]);
        memset(pTarget, 0, sizeof(DmaTarget));

        pTarget->bNoSync    = false;
        pTarget->LocalAddr  = localAddr;
        pTarget->DUMMYUNIONNAME.pVa        = pBuffer;
        pTarget->Size       = size;
    }
}

void PlatformImpMDmaXfer::_SetVersion(ot_uint32_t version)
{
    if( _pIoctl )
    {
        if( version == 0 )
            _pIoctl->IOCTLInfo.Version = CAP_MDMA_IOCTL_Transfer_Version;
        else
            assert(0);
    }
}

/////////////////////////////////////////////////////////////////////////////////

PlatformImpMDmaXferV2::PlatformImpMDmaXferV2(IDmaChannelPtr spDmaChannel, unsigned int nTargets, bool bWrite)
    : PlatformImpDmaXfer( spDmaChannel )
    , _bWrite( bWrite )
    , _pIoctl( NULL )
{
    _pIoctl = AllocateTransactionV2( nTargets, CAP_MDMA_IOCTL_Transfer_Version0 );
}

PlatformImpMDmaXferV2::~PlatformImpMDmaXferV2()
{
    if( _pIoctl )
    {
        free(_pIoctl);
        _pIoctl = NULL;
    }
}

OT_Status PlatformImpMDmaXferV2::GetTransactionTime( otDmaTiming *pTiming ) const
{
    OT_Status status = OT_Status_Timing_Not_Implemented;
    if( pTiming )
    {
        pTiming->_endTime = _pIoctl->IOCTLInfo.Dma.EndTime;
        pTiming->_startTime = _pIoctl->IOCTLInfo.Dma.StartTime;
        status = OT_Status_OK;
    }
    return status;
}

ot_int32_t PlatformImpMDmaXferV2::GetIoctlNum( )
{
    return CAP_MDMA_IOCTL_Transfer;
}

bool PlatformImpMDmaXferV2::bIsValid( )
{
    return ( ( _pIoctl != NULL ) && ( _eventFD > -1 ) );
}

CapGeneral_EventCtx_IOCTL *PlatformImpMDmaXferV2::GetEventIoctlCtx( )
{
    return ( bIsValid( ) ? &( _pIoctl->EventInfo ) : NULL );
}

void *PlatformImpMDmaXferV2::GetIoctl( )
{
    return _pIoctl;
}

void PlatformImpMDmaXferV2::_SetTarget(ot_uint32_t target, void *pBuffer, ot_uint32_t localAddr, ot_uint32_t size, bool bSyncBuffer)
{
    if( target < _pIoctl->IOCTLInfo.Dma.nTargets )
    {
        DmaTarget_V2* pTarget = &(_pIoctl->IOCTLInfo.Dma.Targets[target]);
        memset(pTarget, 0, sizeof(DmaTarget_V2));

        pTarget->bNoSync    = false;
        pTarget->LocalAddr  = localAddr;
        pTarget->DUMMYUNIONNAME.pVa        = pBuffer;
        pTarget->Size       = size;
        pTarget->Write = _bWrite;
    }
}

void PlatformImpMDmaXferV2::_SetVersion(ot_uint32_t version)
{
    if( _pIoctl )
    {
        if( version == 2 )
            _pIoctl->IOCTLInfo.Version = CAP_MDMA_IOCTL_Transfer_Version2;
        else
            assert(0);
    }
}

////////////////////////////////////////////////////////////////////////////
PlatformDmaEventXfer::PlatformDmaEventXfer(ImpDmaEventBasePtr spDmaEvent)
	: ImpDmaEventXfer(spDmaEvent)
{
	INIT_IOCTL(&_ioctl.IOCTLInfo, CAP_DATAFDMA_IOCTL_Event_Version, sizeof(_ioctl.IOCTLInfo));
	memset(&_ioctl.EventInfo, 0, sizeof(_ioctl.EventInfo));
	_ioctl.EventInfo.EventFD = eventfd(0,0);
}

PlatformDmaEventXfer::~PlatformDmaEventXfer()
{
	if( _ioctl.EventInfo.EventFD > 0 )
	{
		close(_ioctl.EventInfo.EventFD); // Clean up the event fd file handle
		_ioctl.EventInfo.EventFD = -1;
	}
	else
	{
		perror("~PlatformDmaEventXfer : Warning EventFD already closed\n");
		assert(0);
	}
}

int PlatformDmaEventXfer::GetBytesTransferred()
{
	return _ioctl.IOCTLInfo.BytesTransfered;
}

otTime PlatformDmaEventXfer::GetInterruptTime()
{
	return _ioctl.IOCTLInfo.EndTime;
}

otEventHandle PlatformDmaEventXfer::GetCompletionHandle()
{
	return _ioctl.EventInfo.EventFD;
}

void PlatformDmaEventXfer::SetBytesTransferred(ot_int32_t bytesTransferred)
{
    _ioctl.IOCTLInfo.BytesTransfered = bytesTransferred;
}
