/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekInterface.h"
#include "IOmniTekTypes.h"
#include "ImpOmniTekPtr.h"
#include "InternalCapability.h"

/* Internal interfaces allowing mocks for unit-testing */

class InternalDmaBase : public IDmaChannel
{
public:
    virtual bool bIsValid() = 0;
};

class InternalDmaChannelFactory
{
public:
    virtual ~InternalDmaChannelFactory() {}

    virtual InternalDmaBase* CreateMDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OmniTek::ot_uint32_t type) = 0;
    virtual InternalDmaBase* CreateVideoFDma(OTParentTracker* pParentTracker, InternalCapability *pCapability, OmniTek::ot_uint32_t type) = 0;
};
