/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include <pthread.h>

class ECritSec
{
public:
	ECritSec(const char* name = 0);
	ECritSec(pthread_mutex_t assign_mutex);
	~ECritSec();

    ECritSec(const ECritSec& other) = delete;
    ECritSec& operator=(const ECritSec& other) = delete;
    ECritSec(ECritSec&& other) = delete;
    ECritSec& operator=(ECritSec&& other) = delete;

	bool Lock(const struct timespec *abs_timeout = NULL);
	void Unlock();
	bool IsLocked();
	operator pthread_mutex_t() { return _mutex; }

private:
	pthread_t		_owning_thread_id;
	int				_recursion_count;
	pthread_mutex_t	_mutex;
	bool			_close_on_exit;
};
