/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "global_defs.h"
#include "HardwareDevice.h"
#include "IOmniTekTypes.h"
#include "capability/Common_IOCTL.h"

/* Internal interface allowing mocks for unit-testing */

class InternalRegisterCapability
{
public:
    virtual ~InternalRegisterCapability() {}

    virtual bool bIsValid() = 0;
    virtual ot_int32_t GetNumRegisterBlocks() = 0;
    virtual ot_int32_t GetNumRegisters(ot_int32_t block) = 0;
    virtual bool WriteRegister(ot_int32_t blk, ot_int32_t regNum, ot_uint32_t value) = 0;
    virtual bool ReadRegister( ot_int32_t blk, ot_int32_t regNum, ot_uint32_t &value) = 0;
    virtual bool ReadShadowRegister( ot_int32_t blk, ot_int32_t regNum, ot_uint32_t &value) = 0;
    virtual otDeviceHandle GetFileHandle() = 0;
    virtual ot_uint32_t GetUniqueID() = 0;
    virtual ot_uint32_t GetAssociatedID() = 0;
    virtual ot_uint32_t GetVersion() = 0;
    virtual OmniTek::OT_Status QueryInfo(_QueryInfoEnum info, uint64_t &result) = 0;
    virtual OmniTek::OT_Status GetRegisterBlockPhysAddr(ot_uint32_t blkNum, ot_uint64_t &result) = 0;
    virtual IoDevice* GetioDevice() = 0;
};
