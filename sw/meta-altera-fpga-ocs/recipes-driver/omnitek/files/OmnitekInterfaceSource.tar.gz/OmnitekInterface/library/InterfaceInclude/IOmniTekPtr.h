/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekTypes.h"

namespace OmniTek
{
	/// \class ISmartPtr
	/// Smart Pointer Implementation for access of Object from the IFpgaFactory api.
	/// Primarily used to make sure that all Objects are released prior to updating the firmware
	/// on an FPGA. While the smart pointer is held it can be assumed that the underlying Object is valid.
	/// Trick: When passing the ISmartPtr into a routine on the stack try passing a reference to the pointer as this doesn't
	/// increment the reference count.
	template <class T>
	class ISmartPtr
	{
	public:
		/// Constructor for a new ISmartPtr smart pointer
		/// \param [in] Pointer to the class you want to make smart :-)
		ISmartPtr(T* pItem=0)
			: _pItem(pItem)
		{
			// Add the firt reference to the Item
			AddRef();
		};

		/// Copy constructor for a new ISmartPtr smart pointer
		/// \param const_other Reference to another ISmartPtr
		ISmartPtr(const ISmartPtr<T>& const_other)
			: _pItem(0)
		{
			ISmartPtr<T>& other = const_cast<ISmartPtr<T>&>(const_other);
			if( other._pItem != _pItem )
			{
				// Release the current pointer
				Release();

				// Copy the template class
				_pItem = other._pItem;

				// Add the reference
				AddRef();
			}
		};

		virtual ~ISmartPtr(void)
		{
			Release();
		};

		ISmartPtr<T>& operator= (const ISmartPtr<T>& const_other)
		{
			ISmartPtr<T>& other = const_cast<ISmartPtr<T>&>(const_other);
			if( other._pItem != _pItem )
			{
				// Add a reference to the other to make sure it remains
				other.AddRef();

				// Release the previous instance
				Release();

				// Copy the class template pointer. Don't need to AddRef as this has been performed above
				_pItem = other._pItem;
			}
			return *this;
		};

		T* operator->() {return _pItem;};
		const T* operator->() const {return _pItem;};
		operator bool() {return _pItem!=0;};
		operator T*() { return _pItem; };

		bool operator == (T * pOther)
		{
			return _pItem == pOther;
		}

		bool operator != (T * pOther)
		{
			return _pItem != pOther;
		}

		bool operator == (const ISmartPtr<T>& other) const
		{
			return (_pItem == other._pItem);
		}
		bool operator != (const ISmartPtr<T>& other) const
		{
			return (_pItem != other._pItem);
		}

		bool operator ==(int other) // For test with 0 (ie null pointer)
		{
			return (_pItem == (T*)other);
		}
		bool operator != (int other) // For test with 0 (ie null pointer)
		{
			return (_pItem != (T*)other);
		}

		bool operator ==(long other) // For test with 0 (ie null pointer)
		{
			return (_pItem == (T*)other);
		}
		bool operator != (long other) // For test with 0 (ie null pointer)
		{
			return (_pItem != (T*)other);
		}

		T* _Get() const
		{
			return _pItem;
		}

	protected:
		void AddRef()
		{
			if( _pItem )
				_pItem->AddRef();
		}

		void Release()
		{
			if( _pItem )
			{
				if( _pItem->Release() == 0 )
				{
					delete _pItem;
					_pItem = 0;
				}
			}
		}

	private:
		T*	_pItem;
	};

	template<class _Ty1, class _Ty2>
	bool operator== (const ISmartPtr<_Ty1>& s1, const ISmartPtr<_Ty2>& s2)
	{
		return (s1._Get() == s2._Get() );
	}
	template<class _Ty1, class _Ty2>
	bool operator!= (const ISmartPtr<_Ty1>& s1, const ISmartPtr<_Ty2>& s2)
	{
		return (s1._Get() != s2._Get() );
	}

	class ISmartBasePtr
	{
	public:
		virtual ot_uint32_t AddRef() = 0;
		virtual ot_uint32_t Release() = 0;

		virtual ot_uint32_t GetRefCount() = 0;
	};
}
