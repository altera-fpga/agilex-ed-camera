/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpRegisterBlock.h"
#include "InternalCapability.h"

ImpRegisterBlock::ImpRegisterBlock(InternalCapability *pCapability, InternalRegisterCapability *pCap, ot_uint32_t blkNum, ot_uint32_t numReg)
	: ImpOmniTekBasePtr(pCapability->GetParentTracker())
, _blkNum(blkNum)
, _numRegs((ot_int32_t)numReg)
, _pCap(pCap)
, _pCapability(pCapability)
{
}

ImpRegisterBlock::~ImpRegisterBlock()
{
}

ot_int32_t ImpRegisterBlock::GetNumRegisters()
{
	return _numRegs;
}

bool ImpRegisterBlock::ReadRegister(ot_int32_t regNum, ot_uint32_t &result)
{
	return _pCap->ReadRegister(_blkNum, regNum, result);
}

bool ImpRegisterBlock::ReadShadowRegister(ot_int32_t regNum, ot_uint32_t &result)
{
	return _pCap->ReadShadowRegister(_blkNum, regNum, result);
}

bool ImpRegisterBlock::WriteRegister(ot_int32_t regNum, ot_uint32_t value)
{
	return _pCap->WriteRegister(_blkNum, regNum, value);
}

ot_uint64_t ImpRegisterBlock::GetPhysicalAddress()
{
	ot_uint64_t result = -1;
	_pCap->GetRegisterBlockPhysAddr(_blkNum, result);
	return result;
}

