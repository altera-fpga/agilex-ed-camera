/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once

#include "IOmniTekInterface.h"
#include "InternalCapability.h"
#include "InternalRegisterCapability.h"
#include "IOmniTekTypes.h"
#include "HardwareDevice.h"

/* Internal interface allowing mocks for unit-testing */

class InternalRegisterFactory
{
public:
    virtual ~InternalRegisterFactory() {}

    virtual OmniTek::IRegisterBlock* CreateRegisterBlock(InternalCapability *pCapability, InternalRegisterCapability *pCap,
                                                         OmniTek::ot_uint32_t blkNum, OmniTek::ot_uint32_t numReg) = 0;

    virtual OmniTek::IInterruptInterfacePtr CreateInterruptInterface(IoDevice* pIoDevice, OmniTek::ICapability *pParent) = 0;
};
