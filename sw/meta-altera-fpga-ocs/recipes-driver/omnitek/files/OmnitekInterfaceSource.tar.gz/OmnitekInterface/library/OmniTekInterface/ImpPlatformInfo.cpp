/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "ImpPlatformInfo.h"
#include "HostController.h"
#include "pciConfig.h"

ImpPlatformInfo::ImpPlatformInfo(OTParentTracker* pParentTracker, HostController *pHostController)
	: ImpOmniTekBasePtr(pParentTracker)
	, _pHostController(pHostController)
{
}

ImpPlatformInfo::~ImpPlatformInfo(void)
{
}

OT_PLATFORM_INTERFACE ImpPlatformInfo::GetPlatformInterface()
{
	OT_PLATFORM_INTERFACE platformInterface = OT_PLATFORM_INTERFACE_UNKNOWN;
	if( _pHostController )
		platformInterface = _pHostController->GetPlatformInterface();
	return platformInterface;
}

ot_uint32_t ImpPlatformInfo::ReadPciConfig(void *pBuffer, ot_uint8_t offset, ot_uint8_t readSize)
{
	ot_uint32_t bytesRead = 0;

	if( GetPlatformInterface() == OT_PLATFORM_INTERFACE_PCIe )
	{
		if( _pHostController )
			bytesRead = _pHostController->ReadPciConfig(pBuffer, readSize, offset);
	}
	return bytesRead;
}

ot_uint8_t ImpPlatformInfo::ReadPciConfigHeaderType()
{
	ot_uint8_t headerType = 0;
	ot_uint32_t bytesRead;

	if( (bytesRead=ReadPciConfig(&headerType, OT_PCI_HEADER_TYPE_OFFSET, sizeof(headerType))) != sizeof(headerType) )
		return -1;

	return headerType;
}

ot_uint8_t ImpPlatformInfo::ReadPciConfigNextCapabilityOffset()
{
	ot_uint32_t bytesRead;
	ot_uint8_t offset = 0;
	ot_uint8_t headerType = ReadPciConfigHeaderType();
	if( (headerType!=0) && (headerType!=1) )
		return 0; // Not the correct Header Type

	if( (bytesRead=ReadPciConfig(&offset, OT_PCI_NEXT_CAPABILITY_OFFSET, sizeof(offset))) != sizeof(offset) )
		return 0; // Failed to read the Next Capability

	return offset;
}

ot_uint8_t ImpPlatformInfo::GetPciConfigHeaderOffset(ot_uint8_t ID)
{
	bool bFound = false;
	OT_PCI_CAPABILITIES_HEADER header;

	//Read the first capability offset
	ot_uint8_t offset = ReadPciConfigNextCapabilityOffset();

	// Search for the required ID
	while( offset != 0 )
	{
		ot_uint32_t bytesRead;
		if( (bytesRead=ReadPciConfig(&header, offset, sizeof(header))) != sizeof(header) )
			break; // Failed to read Header

		if(header.CapabilityID == ID )
		{
			// We've found the ID we want, exit the loop
			bFound = true;
			break;
		}
		// Read the next header
		offset = header.Next;
	}
	return (bFound==true)?offset:0;
}

OT_Status ImpPlatformInfo::GetPCIeInfo(ot_uint32_t &gen, ot_uint32_t &lanes)
{
	OT_Status status = OT_Status_Fail;
	gen = 0;
	lanes = 0;

	if( _pHostController )
	{
		ot_uint8_t pciExpressOffset = GetPciConfigHeaderOffset(OT_PCI_CAPABILITY_ID_PCI_EXPRESS);
		if( pciExpressOffset != 0 )
		{
			uint16_t pcieLinkStatus = 0;
			ot_uint32_t bytesRead;
			bytesRead = ReadPciConfig(&pcieLinkStatus,
							pciExpressOffset + OT_PCIE_LINK_STATUS_OFFSET, sizeof(pcieLinkStatus));
			if(bytesRead == sizeof(pcieLinkStatus))
			{
				gen   = (pcieLinkStatus & OT_PCIE_LINK_STATUS_SPEED_MASK) >> OT_PCIE_LINK_STATUS_SPEED_SHIFT;
				lanes = (pcieLinkStatus & OT_PCIE_LINK_STATUS_WIDTH_MASK) >> OT_PCIE_LINK_STATUS_WIDTH_SHIFT;
				status = OT_Status_OK;
			}
		}
	}
	return status;
}


