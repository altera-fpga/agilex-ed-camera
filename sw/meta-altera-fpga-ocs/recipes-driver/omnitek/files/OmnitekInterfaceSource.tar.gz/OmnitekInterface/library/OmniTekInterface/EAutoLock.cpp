/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#include "stdafx.h"
#include "EAutoLock.h"

EAutoLock::EAutoLock(ECritSec& cs) : _cs(cs)
{
	cs.Lock();
}

EAutoLock::~EAutoLock()
{
	_cs.Unlock();
}

void EAutoLock::Lock()
{
	_cs.Lock();
}

void EAutoLock::Unlock()
{
	_cs.Unlock();
}


