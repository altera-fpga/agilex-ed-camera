/*******************************************************************************
Copyright (C) Altera Corporation

This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

/*
 ***** THIS FILE IS AUTO-GENERATED DO NOT MODIFY *****
 * Generated 2025-08-12 @ 10:59:52
 */

#ifndef FPGATYPES_H_
#define FPGATYPES_H_

#define FPGA_CAPABILITY_NULL (0x0000) /* Placeholder */
#define FPGA_CAPABILITY_fpga (0x0010) /* Legacy name for: Timer Capability V2 */
#define FPGA_CAPABILITY_OmniTimer (0x0010) /* Timer Capability V2 */
/* Missing name for 0x0012 = OmniTek Altera Video Input V3 */
/* Missing name for 0x0013 = OmniTek Altera Video Output V3 */
#define FPGA_CAPABILITY_OmniAlteraGenericInterrupt (0x0014) /* OmniTek Altera Generic Interrupt */
#define FPGA_CAPABILITY_MDMA (0x0102) /* Legacy name for: Bi-Directional Data MDMA V5 */
#define FPGA_CAPABILITY_OmniDataBiMDMA (0x0102) /* Bi-Directional Data MDMA V5 */
#define FPGA_CAPABILITY_FDMA (0x0104) /* Legacy name for: Data In FDMA V5 */
#define FPGA_CAPABILITY_OmniDataInFDMA (0x0104) /* Data In FDMA V5 */
#define FPGA_CAPABILITY_OmniDataOutFDMA (0x0105) /* Data Out FDMA */
#define FPGA_CAPABILITY_OmniVideoInFDMA (0x0114) /* Video In FDMA V5 */
#define FPGA_CAPABILITY_OmniVideoOutFDMA (0x0115) /* Video Out FDMA */
#define FPGA_CAPABILITY_OmniPacketInFDMA (0x0134) /* Packet In FDMA */
#define FPGA_CAPABILITY_OmniPacketOutFDMA (0x0135) /* Packet Out FDMA */
#define FPGA_CAPABILITY_intel_vvp_tmo (0x0163) /* Intel VVP Tone Mapping Operator */
#define FPGA_CAPABILITY_intel_vvp_3d_lut (0x0165) /* Intel VVP 3D Lut */
#define FPGA_CAPABILITY_IntelOSWP (0x016F) /* Intel Scalable Warp Processor */
#define FPGA_CAPABILITY_intel_vvp_cvi (0x0170) /* Intel VVP Clocked Video In */
#define FPGA_CAPABILITY_intel_vvp_generic_crosspoint (0x0171) /* Intel VVP Generic Crosspoint */
#define FPGA_CAPABILITY_intel_vvp_genlock_router (0x0172) /* Intel VVP Genlock Router */
#define FPGA_CAPABILITY_intel_vvp_cvs_2_vpplite (0x0173) /* Intel VVP CVI_2_VVPLite */
#define FPGA_CAPABILITY_intel_vvp_black_level_stats (0x0174) /* Intel VVP Black Level Stats */
#define FPGA_CAPABILITY_intel_vvp_defective_pixel_correction (0x0175) /* Intel VVP Defective Pixel Correction */
#define FPGA_CAPABILITY_intel_vvp_adaptive_noise_reduction (0x0176) /* Intel VVP Adaptive Noise Reduction */
#define FPGA_CAPABILITY_intel_vvp_black_level_correction (0x0177) /* Intel VVP Black Level Correction */
#define FPGA_CAPABILITY_intel_vvp_vignette_correction (0x0178) /* Intel VVP Vignette Correction */
#define FPGA_CAPABILITY_intel_vvp_white_balance_stats (0x0179) /* Intel VVP White Balance Stats */
#define FPGA_CAPABILITY_intel_vvp_white_balance_correction (0x017a) /* Intel VVP White Balance Correction */
#define FPGA_CAPABILITY_intel_vvp_histogram_stats (0x017b) /* Intel VVP Histogram Stats */
#define FPGA_CAPABILITY_intel_vvp_unsharp_masking_filter (0x017c) /* Intel VVP Unsharp Masking Filter */
#define FPGA_CAPABILITY_intel_vvp_1d_lut (0x017d) /* Intel VVP 1D Lut */
#define FPGA_CAPABILITY_intel_vvp_text_box (0x017e) /* Intel VVP Text Box */
#define FPGA_CAPABILITY_EyeScan (0x0180) /* Legacy name for: OmniTek SDI Eye Pattern */
#define FPGA_CAPABILITY_OmniEyeScanDMA (0x0180) /* OmniTek SDI Eye Pattern */
#define FPGA_CAPABILITY_AlteraClockedVideoIn (0x0200) /* Altera Clocked Video Input V2 */
#define FPGA_CAPABILITY_AlteraClockedVideoOut (0x0201) /* Altera Clocked Video Output */
#define FPGA_CAPABILITY_OmniTekAudioExtract (0x0202) /* OmniTek Audio Extract */
#define FPGA_CAPABILITY_OmniTekAudioEmbed (0x0203) /* OmniTek Audio Embed */
#define FPGA_CAPABILITY_OmniTekAncExtract (0x0204) /* OmniTek Ancillary Extract */
#define FPGA_CAPABILITY_OmniTekAncEmbed (0x0205) /* OmniTek Ancillary Embed */
/* Missing name for 0x0206 = MPEG Video Decoder */
#define FPGA_CAPABILITY_OmniTekI2cController (0x0208) /* I2C Controller */
/* Missing name for 0x0209 = Memory Page Controller */
/* Missing name for 0x020a = Altera Avalon Video Switch */
/* Missing name for 0x020b = Altera Video Resizer */
/* Missing name for 0x020c = Altera Video Combiner */
#define FPGA_CAPABILITY_Intel16550Uart (0x020d) /* Intel 16550 Compatible UART */
#define FPGA_CAPABILITY_IntelI2CMaster (0x020e) /* Intel Avalon I2C (Master) */
#define FPGA_CAPABILITY_IntelSPICtrl (0x020f) /* Intel SPI (3 Wire Serial) */
#define FPGA_CAPABILITY_IntelParallelIO (0x0210) /* Intel PIO (Parallel I/O) */
#define FPGA_CAPABILITY_IntelSerialFlash (0x0211) /* Intel Generic Serial Flash Interface */
#define FPGA_CAPABILITY_IntelAddressSpanExtCtrl (0x0212) /* Intel Address Span Extender Control Interface */
#define FPGA_CAPABILITY_IntelAddressSpanExtMem (0x0213) /* Intel Address Span Extender Memory Interface */
#define FPGA_CAPABILITY_OmniIntelHDMI20Rx (0x0214) /* Omni Intel HDMI 2.0 Rx Core */
#define FPGA_CAPABILITY_OmniIntelHDMI20Tx (0x0215) /* Omni Intel HDMI 2.0 Tx Core */
#define FPGA_CAPABILITY_OmniIntelHDMI20RxPhy (0x0216) /* Omni Intel HDMI 2.0 Rx PHY */
#define FPGA_CAPABILITY_OmniIntelHDMI20TxPhy (0x0217) /* Omni Intel HDMI 2.0 Tx PHY */
#define FPGA_CAPABILITY_alt_vip_cl_2dfir (0x0218) /* 2D-FIR II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_clp (0x0219) /* Clipper II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_crs  (0x021A) /* Chroma Resampler II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_csc (0x021B) /* Color Space Converter II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_cvi (0x021C) /* Clocked Video Input II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_cvo (0x021D) /* Clocked Video Output II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_dil (0x021E) /* Deinterlacer II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_fb_switch (0x021F) /* Frame Buffer Shuffle Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_gamma_corrector (0x0220) /* Gamma Corrector II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_guard_bands (0x0221) /* Configurable Guard Bands Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_interlacer (0x0222) /* Interlacer II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_mixer  (0x0223) /* Mixer II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_packet_closer (0x0224) /* Packet Timeout Controller Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_scl (0x0225) /* Scaler II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_stream_cleaner (0x0226) /* Avalon-ST Video Stream Cleaner Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_swi (0x0227) /* Switch II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_tpg (0x0228) /* Test Pattern Generator II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_vfb (0x0229) /* Frame Buffer II Intel FPGA IP */
#define FPGA_CAPABILITY_alt_vip_cl_warp  (0x022A) /* Warp Lite Intel FPGA IP */
#define FPGA_CAPABILITY_intel_vvp_2d_fir (0x022C) /* Intel VVP 2D-Fir Filter */
#define FPGA_CAPABILITY_intel_vvp_clipper (0x022D) /* Intel VVP Clipper */
#define FPGA_CAPABILITY_intel_vvp_chroma_resampler (0x022E) /* Intel VVP Chroma Resampler */
#define FPGA_CAPABILITY_intel_vvp_color_space_conv (0x022F) /* Intel VVP Color Space Converter */
#define FPGA_CAPABILITY_intel_vvp_gamma_corrector (0x0230) /* Intel VVP Gamma Corrector */
#define FPGA_CAPABILITY_intel_vvp_guard_bands (0x0231) /* Intel VVP Configurable Guard Bands */
#define FPGA_CAPABILITY_intel_vvp_interlacer (0x0232) /* Intel VVP Interlacer */
#define FPGA_CAPABILITY_intel_vvp_mixer (0x0233) /* Intel VVP Mixer */
#define FPGA_CAPABILITY_intel_vvp_scaler (0x0234) /* Intel VVP Scaler */
#define FPGA_CAPABILITY_intel_vvp_switch (0x0235) /* Intel VVP Switch */
#define FPGA_CAPABILITY_intel_vvp_test_pattern_gen (0x0236) /* Intel VVP Test Pattern Generator */
#define FPGA_CAPABILITY_intel_vvp_frame_buffer (0x0237) /* Intel VVP Frame Buffer */
#define FPGA_CAPABILITY_altera_avalon_i2c (0x0238) /* Avalon I2C (Master) Intel FPGA IP */
#define FPGA_CAPABILITY_intel_vvp_pip_conv (0x0239) /* Intel VVP Pixels in Parallel Converter */
#define FPGA_CAPABILITY_intel_vvp_deinterlacer (0x023A) /* Intel VVP Deinterlacer */
#define FPGA_CAPABILITY_intel_vvp_cpm (0x023B) /* Intel VVP Color Plane Manager */
#define FPGA_CAPABILITY_intel_vvp_fifo (0x023C) /* Intel VVP Fifo */
#define FPGA_CAPABILITY_intel_vvp_protocol_conv (0x023D) /* Intel VVP Protocol converter */
#define FPGA_CAPABILITY_intel_vvp_cleaner (0x023E) /* Intel VVP Cleaner */
#define FPGA_CAPABILITY_intel_vvp_chroma_key (0x023F) /* Intel VVP Chroma Key */
#define FPGA_CAPABILITY_intel_vvp_cv2fr (0x0240) /* Intel VVP CV 2 FR */
#define FPGA_CAPABILITY_intel_vvp_fr2cv (0x0241) /* Intel VVP FR 2 CV */
#define FPGA_CAPABILITY_intel_vvp_fr2lite (0x0242) /* Intel VVP FR 2 LITE */
#define FPGA_CAPABILITY_intel_vvp_vtiming (0x0243) /* Intel VVP VTIMING */
#define FPGA_CAPABILITY_intel_vvp_cvo (0x0244) /* Intel VVP CVO */
#define FPGA_CAPABILITY_intel_vvp_remosaic (0x0245) /* Intel VVP Remosaic */
#define FPGA_CAPABILITY_intel_vvp_demosaic (0x0246) /* Intel VVP Demosaic */
#define FPGA_CAPABILITY_intel_vvp_genlock_controller (0x0247) /* Intel VVP Genlock Controller */
#define FPGA_CAPABILITY_intel_vvp_snoop (0x0248) /* Intel VVP Snoop */
#define FPGA_CAPABILITY_intel_vvp_vfw (0x0249) /* Intel VVP Frame Writer */
#define FPGA_CAPABILITY_intel_vvp_vfr (0x024A) /* Intel VVP Frame Reader */
#define FPGA_CAPABILITY_intel_vvp_timeout (0x024B) /* Intel VVP Timeout */
#define FPGA_CAPABILITY_intel_vvp_pixel_adapter (0x024C) /* Intel VVP Bits Per Color Sample Adapter */
#define FPGA_CAPABILITY_intel_aps_audio2axi (0x024D) /* Intel APS Audio to Axi4Stream Converter */
#define FPGA_CAPABILITY_intel_aps_axi2audio (0x024E) /* Intel APS Axi4Stream to Audio Converter */
#define FPGA_CAPABILITY_intel_aps_atpg (0x024F) /* Intel APS audio test pattern generator */
#define FPGA_CAPABILITY_intel_aps_i2s (0x0250) /* Intel APS I2S */
#define FPGA_CAPABILITY_intel_aps_volume_control (0x0251) /* Intel APS Volume Control */
#define FPGA_CAPABILITY_intel_vvp_adv_tpg (0x0252) /* Intel VVP Advanced Test Pattern Generator */
#define FPGA_CAPABILITY_intel_vvp_metapacket_inserter (0x0253) /* Intel VVP Metapacket Inserter */
#define FPGA_CAPABILITY_intel_vvp_frame_buffer_shuffler (0x0254) /* Intel VVP Frame Buffer Shuffler */
#define FPGA_CAPABILITY_intel_vvp_exposure_fusion (0x0255) /* Intel VVP Exposure Fusion */
#define FPGA_CAPABILITY_HDMI_Rx (0x0300) /* Legacy name for: OmniTek HDMI Rx Input (XSVI) V2 */
#define FPGA_CAPABILITY_HDMI_Tx (0x0301) /* Legacy name for: OmniTek HDMI Tx Output (XSVI) V2 */
#define FPGA_CAPABILITY_SDI_Rx (0x0302) /* Legacy name for: OmniTek SDI Rx Decoder (XSVI) V3 */
#define FPGA_CAPABILITY_SDI_Tx (0x0303) /* Legacy name for: OmniTek SDI Tx Encoder (XSVI) V2 */
/* Missing name for 0x0304 = OmniTek AXI4-Streaming Cropper */
/* Missing name for 0x0305 = OmniTek AXI4-Streaming Video 2D-LUT */
#define FPGA_CAPABILITY_OmniTekMPVDMA (0x0306) /* OmniTek AXI4 Multi-Ported Video DMA V3 */
#define FPGA_CAPABILITY_OSVP (0x0307) /* Legacy name for: OmniTek AXI4 OSVP */
/* Missing name for 0x0308 = OmniTek AXI4 Deinterlacer */
#define FPGA_CAPABILITY_OmniTekStreamingVideoResizer (0x0309) /* OmniTek AXI4-Streaming Video Resizer */
/* Missing name for 0x030a = OmniTek AXI4 Generic Reset/IRQ Controller */
#define FPGA_CAPABILITY_AXI_CSC (0x030b) /* Legacy name for: OmniTek AXI4-Streaming Colourspace Converter V2 */
#define FPGA_CAPABILITY_Overlay (0x030c) /* Legacy name for: OmniTek AXI4-Streaming Video Overlay Generator */
#define FPGA_CAPABILITY_XPoint (0x030d) /* Legacy name for: OmniTek XSVI to AXIS Crosspoint video switch V2 */
#define FPGA_CAPABILITY_XSVI_CSC (0x030e) /* Legacy name for: OmniTek XSVI Colourspace converter */
#define FPGA_CAPABILITY_VTiming (0x030f) /* Legacy name for: OmniTek Video Timebase Generator */
#define FPGA_CAPABILITY_OmniLinePatternGenerator (0x0310) /* OmniTek Generic Line Pattern Generator */
/* Missing name for 0x0311 = OmniTek AXI4S Video Timing/Data Merger */
#define FPGA_CAPABILITY_SDI_Analyzer (0x0312) /* Legacy name for: OmniTek XSVI SDI Analyzer V3 */
/* Missing name for 0x0313 = OmniTek MSVC Multi-Stream-Video-Cropper */
/* Missing name for 0x0314 = OmniTek 4K-Video Interleaver */
#define FPGA_CAPABILITY_OmniXpnt (0x0315) /* Legacy name for: OmniTek AXI4S video crosspoint V2 */
#define FPGA_CAPABILITY_JitterMeasure (0x0316) /* Legacy name for: OmniTek Jitter Measurement Core V2 */
#define FPGA_CAPABILITY_JitterInsert (0x0317) /* Legacy name for: OmniTek Jitter Inserter Core */
#define FPGA_CAPABILITY_FrameSyncSelect (0x0318) /* Legacy name for: OmniTek Framesync System Crosspoint */
#define FPGA_CAPABILITY_Combiner (0x0319) /* Legacy name for: OmniTek 16 Channel Video Combiner V4 */
/* Missing name for 0x031a = OmniTek 2k to 4k pixel doubler/stretcher (Row interleaved) */
#define FPGA_CAPABILITY_Phy_insert (0x031b) /* Legacy name for: OmniTek SDI Physical Generator */
#define FPGA_CAPABILITY_SDI_Unpacker (0x031c) /* Legacy name for: OmniTek SDI RVF Unpacker */
#define FPGA_CAPABILITY_SDI_Packer (0x031d) /* Legacy name for: OmniTek SDI RVF Packer */
#define FPGA_CAPABILITY_VideoEffects (0x031e) /* Legacy name for: OmniTek Ultra Video Effects */
#define FPGA_CAPABILITY_VideoAnalyzer (0x031f) /* Legacy name for: OmniTek Video Analyzer V3 */
#define FPGA_CAPABILITY_Generator (0x0320) /* Legacy name for: OmniTek Video Generator V3 */
#define FPGA_CAPABILITY_MST_Ctrl (0x0321) /* Legacy name for: OmniTek AXI-S Splitter (for Display Port MST mode) */
/* Missing name for 0x0322 = OmniTek Chroma 422 to 444 Upsampler */
#define FPGA_CAPABILITY_OmniInterlacer (0x0323) /* Legacy name for: OmniTek Interlacer */
/* Missing name for 0x0324 = OmniTek Noise Filter */
/* Missing name for 0x0325 = OmniTek Vid2DP (converts XSVI to Display Port MST Mode) */
#define FPGA_CAPABILITY_MMCM (0x0326) /* Legacy name for: OmniTek Generic MMCM controller */
/* Missing name for 0x0327 = OmniTek Gamma LUT */
/* Missing name for 0x0328 = OmniTek AXIS n to m pixel/clk converter */
/* Missing name for 0x0329 = OmniTek AXIS fifo monitor */
#define FPGA_CAPABILITY_OmniChromaDown (0x032a) /* Legacy name for: OmniTek Chroma 444 to 422 Downsampler */
#define FPGA_CAPABILITY_OmniVersion (0x032b) /* Legacy name for: OmniTek Generic FPGA Version Identifier */
#define FPGA_CAPABILITY_OmniSPIController (0x032c) /* OmniTek SPI Controller */
#define FPGA_CAPABILITY_OmniFrameBuffer (0x032d) /* Legacy name for: OmniTek Generic Video Frame Buffer V3 */
#define FPGA_CAPABILITY_OmniFan (0x032e) /* Legacy name for: OmniTek External Fan Control and Sensor */
#define FPGA_CAPABILITY_OmniCursor (0x032f) /* Legacy name for: OmniTek Video Cursor */
#define FPGA_CAPABILITY_OmniTestPattern (0x0330) /* Legacy name for: OmniTek Test Pattern Generator */
#define FPGA_CAPABILITY_OmniOverlay2 (0x0331) /* Legacy name for: OmniTek Video Overlay II */
#define FPGA_CAPABILITY_OmniGenlock (0x0332) /* Legacy name for: OmniTek Genlock Router */
#define FPGA_CAPABILITY_OmniTekGTXDebug (0x0333) /* OmniTek GTX Debug */
#define FPGA_CAPABILITY_OmniDownScaler4k2k (0x0334) /* Legacy name for: OmniTek DownScaler 4k2k */
#define FPGA_CAPABILITY_OmniDPEDID (0x0335) /* Legacy name for: OmniTek DP EDID */
#define FPGA_CAPABILITY_OmniWfm (0x0336) /* Legacy name for: OmniTek Waveforms */
#define FPGA_CAPABILITY_OmniTekOSWP (0x0337) /* Legacy name for: OmniTek Scalable Warp Processor */
#define FPGA_CAPABILITY_OmniTekWarpRegs (0x0338) /* Legacy name for: OmniTek Warp Regs */
#define FPGA_CAPABILITY_OmniTekMiniPic (0x0339) /* Legacy name for: OmniTek Minipic Generator */
#define FPGA_CAPABILITY_OmniTekAudioCrossPoint (0x033a) /* Legacy name for: OmniTek Audio Crosspoint V2 */
#define FPGA_CAPABILITY_OmniTekAXISCleanSwitch (0x033b) /* OmniTek AXIS Clean Switch */
#define FPGA_CAPABILITY_OmniTekAxisRepacker (0x033c) /* OmniTek AXIS Repacker */
#define FPGA_CAPABILITY_OmniTekRVFUnpacker (0x033d) /* OmniTek RVF AXIS Unpacker */
#define FPGA_CAPABILITY_OmniTekSDIDeskew (0x033e) /* OmniTek SDI RVF-Axis Deskewer */
#define FPGA_CAPABILITY_OmniTekAXISequencer (0x033f) /* OmniTek AXI-Sequencer */
#define FPGA_CAPABILITY_OmniTekVx1Tx (0x0340) /* OmniTek V-by-1 Tx */
#define FPGA_CAPABILITY_OmniTekVx1Rx (0x0341) /* OmniTek V-by-1 Rx */
#define FPGA_CAPABILITY_OmniTekVx1PHY (0x0342) /* OmniTek V-by-1 PHY */
/* Missing name for 0x0344 = OmniTek LVDS Transmitter */
/* Missing name for 0x0345 = OmniTek LVDS Receiver */
#define FPGA_CAPABILITY_OmniLVDSMerge (0x0346) /* OmniTek LVDS Merge */
#define FPGA_CAPABILITY_OmniLVDSUnpacker (0x0347) /* OmniTek LVDS Unpacker */
/* Missing name for 0x0348 = OmniTek DP Tx */
/* Missing name for 0x0349 = OmniTek DP Rx */
/* Missing name for 0x034a = OmniTek DP PHY */
#define FPGA_CAPABILITY_OmniISP (0x034c) /* OmniTek Image Signal Processor (ISP) */
#define FPGA_CAPABILITY_OmniProjectorBlend (0x034d) /* OmniTek Projector Blend */
#define FPGA_CAPABILITY_OmniFPGAConfigurationController (0x034e) /* OmniTek FPGA Configuration Controller */
#define FPGA_CAPABILITY_OmniTekLicense (0x034f) /* OmniTek License */
/* Missing name for 0x0350 = OmniTek LMH1981 */
#define FPGA_CAPABILITY_OmniTekWarpGenlock (0x0351) /* OmniTek Warp Genlock */
#define FPGA_CAPABILITY_OmniTekWarpDebug (0x0352) /* OmniTek Warp Debug */
/* Missing name for 0x0353 = OmniTek Page Controller */
#define FPGA_CAPABILITY_OmniTekUltrascaleGTHDebug (0x0354) /* OmniTek Ultrascale GTH Debug */
#define FPGA_CAPABILITY_OmniAxisText (0x0355) /* Omnitek Text Overlay */
#define FPGA_CAPABILITY_OmniRFC4175Tx (0x0356) /* Omnitek RFC4175 Axis to Ethernet TX */
#define FPGA_CAPABILITY_OmniRFC4175Rx (0x0357) /* Omnitek RFC4175 Ethernet RX to Axis */
#define FPGA_CAPABILITY_XIL_AXI_1G_Ethernet (0x0358) /* Legacy name for: Xilinx Owned AXI_1G_Ethernet_Subsystem */
/* Missing name for 0x0359 = Omnitek Warp I2C Fix */
/* Missing name for 0x035a = OmniTek HDLC Tx */
/* Missing name for 0x035b = OmniTek HDLC Rx */
#define FPGA_CAPABILITY_OmniLicenseMux (0x035c) /* Omnitek License Mux */
/* Missing name for 0x035d = Omnitek Mapped Memory */
#define FPGA_CAPABILITY_OmniProjectorTPG (0x035e) /* Omnitek Projector Test Pattern Generator */
/* Missing name for 0x035f = Omnitek I2C Master */
#define FPGA_CAPABILITY_OmnitekWarpOSD (0x0360) /* Legacy name for: Omnitek Warp OSD */
#define FPGA_CAPABILITY_OmniSplanarEncoder (0x0362) /* Omnitek MPVDMA VCU encoder video formatter */
#define FPGA_CAPABILITY_OmniSplanarDecoder (0x0363) /* Omnitek MPVDMA VCU decoder video formatter */
#define FPGA_CAPABILITY_OmniI2STx (0x0364) /* Omnitek I2S Tx */
#define FPGA_CAPABILITY_OmniI2SRx (0x0365) /* Omnitek I2S Rx */
/* Missing name for 0x0366 = Omnitek I2C Repeater */
/* Missing name for 0x0367 = Omnitek Wireframe */
/* Missing name for 0x0368 = Omnitek 3D LUT */
/* Missing name for 0x0369 = Omnitek Warp Mesh */
#define FPGA_CAPABILITY_OmniChromaDown422to420 (0x0370) /* Omnitek Chroma Down-Sampler 422 to 420 */
#define FPGA_CAPABILITY_OmniChromaUp420to422 (0x0372) /* Omnitek Chroma Up-Sampler 420 to 422 */
#define FPGA_CAPABILITY_OmniTMO (0x0375) /* OmniTek Contrast Enhancement Engine */
#define FPGA_CAPABILITY_OmniExtFsyncGen (0x0381) /* Omnitek external fsync generator */
#define FPGA_CAPABILITY_omnisoftgenlock (0x0382) /* Omnitek Soft Genlock */
#define FPGA_CAPABILITY_OmniAudioExtract (0x0383) /* OmniTek Audio Extract */
#define FPGA_CAPABILITY_OmniAudioEmbed (0x0384) /* OmniTek Audio Embed */
#define FPGA_CAPABILITY_OmniVbyOneTX (0x0386) /* OmniTek VbyOne TX output shim */
#define FPGA_CAPABILITY_OmniPPMs (0x0388) /* Legacy name for: OmniTek PPMs */
#define FPGA_CAPABILITY_OmniDemosaic (0x0389) /* Legacy name for: OmniTek Demosaic Filter */
#define FPGA_CAPABILITY_OmniMailbox (0x038a) /* Legacy name for: OmniTek Mailbox */
#define FPGA_CAPABILITY_JitterInsertExt (0x038c) /* Legacy name for: OmniTek Jitter Inserter (External IC) Core */
/* Missing name for 0x038d = OmniTek AXIS Stall-Protection */
/* Missing name for 0x038e = OmniTek sync generator */
#define FPGA_CAPABILITY_OmniWipeGen (0x0390) /* OmniTek Wipe Generator */
#define FPGA_CAPABILITY_OmniHDMI20Tx (0x0391) /* Legacy name for: Omnitek HDMI 2.0 Tx */
#define FPGA_CAPABILITY_OmniStreamCombiner (0x0392) /* Legacy name for: OmniTek Stream Combiner */
#define FPGA_CAPABILITY_OmniSpiVideoDecoder (0x0394) /* Legacy name for: OmniTek SPI to Video */
#define FPGA_CAPABILITY_OmniHDMI20Rx (0x0395) /* Legacy name for: OmniTek HDMI 2.0 Rx Core */
#define FPGA_CAPABILITY_OmniHDMI20RX (0x0395) /* OmniTek HDMI 2.0 Rx Core */
#define FPGA_CAPABILITY_OmniHDMI20Phy (0x0396) /* Legacy name for: OmniTek HDMI 2.0 Phy V2 */
#define FPGA_CAPABILITY_OmniHDMI20PHY (0x0396) /* OmniTek HDMI 2.0 Phy V2 */
#define FPGA_CAPABILITY_OmniLineByLine (0x0398) /* Omni Line By Line */
#define FPGA_CAPABILITY_OmniDisparityAjust (0x039d) /* OmniTek Disparity Adjust */
#define FPGA_CAPABILITY_OmniHDAController (0x039e) /* OmniTek HDA Controller */
#define FPGA_CAPABILITY_OmniAxisDebug (0x039f) /* OmniTek axis debug */
#define FPGA_CAPABILITY_OmniTUserDelta (0x03a0) /* OmniTek tuser delta */
#define FPGA_CAPABILITY_OmniLumaLut (0x03a1) /* Omnitek Luma LUT */
#define FPGA_CAPABILITY_OmniDPU (0x03a2) /* Omnitek DPU */
#define FPGA_CAPABILITY_OmniAxisLatency (0x03a3) /* Omnitek Axis Latency */
#define FPGA_CAPABILITY_OmniMsgMailbox (0x03a4) /* Omnitek Message Mailbox */
#define FPGA_CAPABILITY_OmniMadiTx (0x03a5) /* Omnitek MADI Tx */
#define FPGA_CAPABILITY_OmniMadiRx (0x03a6) /* Omnitek MADI Rx */
#define FPGA_CAPABILITY_OmniAudioDMA (0x03a7) /* Omnitek Audio DMA */
#define FPGA_CAPABILITY_OmniBayerTPG (0x03a8) /* Omnitek Bayer TPG */
#define FPGA_CAPABILITY_OmniAES3Tx (0x03a9) /* Omnitek AES3 Tx */
#define FPGA_CAPABILITY_OmniAES3Rx (0x03aa) /* Omnitek AES3 Rx */
#define FPGA_CAPABILITY_OmniAudioVol (0x03ab) /* Omnitek Audio Volume */
#define FPGA_CAPABILITY_OmniCtlDPRAM (0x03ac) /* Omnitek Control DPRAM */
#define FPGA_CAPABILITY_OmniFlashCtrl (0x03ad) /* Omnitek Flash Controller */
#define FPGA_CAPABILITY_OmniAudioClkGen (0x03ae) /* Omnitek Audio Clock Generator */
#define FPGA_CAPABILITY_OmniX2NonlinearResize (0x03b0) /* OmniTek X2 Non-linear Resize */
#define FPGA_CAPABILITY_OmniPtrCtrl (0x03b1) /* Omnitek MPVDMA pointer control */
#define FPGA_CAPABILITY_OmniFrameCleaner (0x03b2) /* Omnitek Frame Cleaner */
#define FPGA_CAPABILITY_IntelCoreDLA (0x03b5) /* Intel coreDLA */
#define FPGA_CAPABILITY_IntelCoreDLALayoutTransform (0x03b6) /* Intel CoreDLA Layout Transform */
#define FPGA_CAPABILITY_IntelCoreDLAStreamController (0x03bb) /* Intel CoreDLA Stream Controller */
#define FPGA_CAPABILITY_IntelFSyncGen (0x03bc) /* Intel FSync Generator */
#define FPGA_CAPABILITY_OmniAxi4s2CV (0x03bd) /* Omnitek Axis to CV Converter */
#define FPGA_CAPABILITY_Omni_CV_to_CV (0x03be) /* Omnitek Low Latency CV to CV module */
#define FPGA_CAPABILITY_OmniSideBySide (0x03c3) /* Omnitek Pixel Interleaver used for 3D Side By Side Display */
#define FPGA_CAPABILITY_OmniChromaKey (0x03c5) /* Omnitek Chroma Key */
#define FPGA_CAPABILITY_OmniVcxoControl (0x03c6) /* Omnitek VCXO Control */
#define FPGA_CAPABILITY_OmniAxiGpio (0x03c7) /* Omnitek Axi GPIO */
#define FPGA_CAPABILITY_OmniAxiThrottle (0x03c8) /* Omnitek Axi Throttle */
#define FPGA_CAPABILITY_OmniFpgaStatus (0x03cc) /* Omnitek FPGA Status */
#define FPGA_CAPABILITY_IntelMailboxSender (0x03e8) /* Intel Simple Mailbox Sender */
#define FPGA_CAPABILITY_IntelMailboxReceiver (0x03e9) /* Intel Simple Mailbox Receiver */
#define FPGA_CAPABILITY_IntelOnChipMemII (0x03eC) /* Intel On-Chip Memory II (RAM or ROM) */
/* Missing name for 0x0400 = Xilinx Owned AXI_OSD (on-screen-display) */
/* Missing name for 0x0401 = Xilinx Owned AXI_VTC (video timing generator) */
#define FPGA_CAPABILITY_Xil_VDMA (0x0402) /* Legacy name for: Xilinx Owned AXI_VDMA (video dma engine) */
#define FPGA_CAPABILITY_DisplayPort_Tx (0x0403) /* Legacy name for: Xilinx Owned DisplayPort Tx SubSystem */
#define FPGA_CAPABILITY_DisplayPort_Rx (0x0404) /* Legacy name for: Xilinx Owned DisplayPort Rx SubSystem */
#define FPGA_CAPABILITY_Xil_GPIO (0x0405) /* Legacy name for: Xilinx Owned AXI_GPIO */
#define FPGA_CAPABILITY_Xil_IIC (0x0406) /* Legacy name for: Xilinx Owned AXI_IIC Controller */
#define FPGA_CAPABILITY_OmniPixelDoubler (0x0407) /* Legacy name for: OmniTek Pixel Doubler */
/* Missing name for 0x0408 = Xilinx Owned HDMI 2.0 Rx Decoder */
/* Missing name for 0x0409 = Xilinx Owned HDMI 2.0 Tx Encoder */
/* Missing name for 0x040a = Xilinx Owned HDMI 2.0 GT */
/* Missing name for 0x040b = Xilinx Owned HDMI 2.0 VPG */
/* Missing name for 0x040c = Xilinx Owned HDMI 2.0 audio pattern generator */
/* Missing name for 0x040d = Xilinx Owned general clock wizard with AXI port */
/* Missing name for 0x040e = Xilinx Owned HDMI 2.0 ACR control */
/* Missing name for 0x040f = Xilinx Owned microblaze interrupt controller */
#define FPGA_CAPABILITY_OmniROI (0x0410) /* Legacy name for: OmniTek ROI */
#define FPGA_CAPABILITY_Xil_SPI (0x0411) /* Legacy name for: Xilinx Owned AXI_SPI controller */
#define FPGA_CAPABILITY_Xil_AXI_UARTLITE (0x0412) /* Legacy name for: Xilinx Owned AXI_UARTLITE controller */
#define FPGA_CAPABILITY_Xil_VPHY (0x0413) /* Legacy name for: Xilinx Owned DisplayPort PHY (video phy) */
#define FPGA_CAPABILITY_Xil_AXI_UART16550 (0x0414) /* Legacy name for: Xilinx Owned AXI_UART16550 controller */
#define FPGA_CAPABILITY_DP_EDID (0x0415) /* Legacy name for: Xilinx Owned DP EDID controller */
#define FPGA_CAPABILITY_XADC_Controller (0x0416) /* Legacy name for: Xilinx Owned XADC controller */
#define FPGA_CAPABILITY_IntelHDMI21Rx (0x0450) /* Intel HDMI 2.1 Rx Core */
#define FPGA_CAPABILITY_IntelHDMI21Tx (0x0451) /* Intel HDMI 2.1 Tx Core */
#define FPGA_CAPABILITY_IntelHDMI21RxPhy (0x0452) /* Intel HDMI 2.1 Rx PHY */
#define FPGA_CAPABILITY_IntelHDMI21TxPhy (0x0453) /* Intel HDMI 2.1 Tx PHY */
#define FPGA_CAPABILITY_IntelHDMI20Rx (0x0454) /* Intel HDMI 2.0 Rx Core */
#define FPGA_CAPABILITY_IntelHDMI20Tx (0x0455) /* Intel HDMI 2.0 Tx Core */
#define FPGA_CAPABILITY_IntelHDMI20RxPhy (0x0456) /* Intel HDMI 2.0 Rx PHY */
#define FPGA_CAPABILITY_IntelHDMI20TxPhy (0x0457) /* Intel HDMI 2.0 Tx PHY */
#define FPGA_CAPABILITY_IntelHDMI20TiI2c (0x0458) /* Intel HDMI 2.0 I2C */

#endif /* FPGATYPES_H_ */

