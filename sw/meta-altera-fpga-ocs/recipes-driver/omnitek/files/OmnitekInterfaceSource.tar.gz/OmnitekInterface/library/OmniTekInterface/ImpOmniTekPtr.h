/*******************************************************************************
Copyright (C) Altera Corporation
 
This code and the related documents are Altera copyrighted materials and your
use of them is governed by the express license under which they were provided to
you ("License"). This code and the related documents are provided as is, with no
express or implied warranties other than those that are expressly stated in the
License.
*******************************************************************************/

#pragma once
#include "IOmniTekTypes.h"
#ifndef __linux__
#include "stdio.h"
//#include "stdbool.h"
#endif
#include "EAutoLock.h"

namespace OmniTek
{
#ifdef __linux__

struct RefCounter
{
	RefCounter()
	{
		_refCount = 0; // Clear to zero at start-up
	}
	inline ot_uint32_t InterlockedIncrement()
	{
//		ot_uint32_t saveCount = GetRefCount();
		ot_uint32_t lockCount = __sync_add_and_fetch(&_refCount, 1);
//		printf("InterlockedIncrement - Old Count %d, New %d\n", saveCount, lockCount);
		return lockCount;
	}
	inline ot_uint32_t InterlockedDecrement()
	{
//		ot_uint32_t saveCount = GetRefCount();
		ot_uint32_t lockCount = __sync_sub_and_fetch(&_refCount, 1);
//		printf("InterlockedDecrement - Old Count %d, New %d\n", saveCount, lockCount);
		return lockCount;
	}
	inline ot_uint32_t GetRefCount()
	{
		return  __sync_fetch_and_add(&_refCount, 0);
	}
private:
	volatile ot_uint32_t _refCount;
};
#else

struct RefCounter
{
	RefCounter()
		: _refCount(0)
	{
	};

	inline ot_uint32_t InterlockedIncrement()
	{
		return ::InterlockedIncrement(&_refCount);
	}
	inline ot_uint32_t InterlockedDecrement()
	{
		return ::InterlockedDecrement(&_refCount);
	}
	inline ot_uint32_t GetRefCount()
	{
		return _refCount;
	}
private:
	ot_uint32_t	_refCount;
};
#endif
#include "IOmniTekPtr.h"

class OTParentTracker
{
public:
	virtual ~OTParentTracker(){};
	virtual void AddParentRef() = 0;
	virtual void ReleaseParentRef() = 0;

	virtual bool bSafeToRelease() = 0;
};

class ImpOmniTekBasePtr 
{
public:
	ImpOmniTekBasePtr(OTParentTracker *pParent = NULL)
		: _refCounter()
		, _pParent(pParent)
		, _bInEarlyRelease(false)
	{
	};

	virtual ~ImpOmniTekBasePtr()
	{
	};

	virtual ot_uint32_t AddRef()
	{
		ot_uint32_t lockCount = _refCounter.InterlockedIncrement();

//		printf("%p, Add Ref, lockCount %d\n", this, lockCount);
		if( lockCount > 1 ) // If we've taken more than one reference we should let the template class know
		{
			if( _pParent )
				_pParent->AddParentRef();
		}
		return lockCount;
	};

	virtual ot_uint32_t Release()
	{
		ot_uint32_t lockCount = 0;
		lockCount = _refCounter.InterlockedDecrement();
//		printf("%p, Release , lockCount %d\n", this, lockCount);
		if( lockCount > 0 ) // We should release template class if this is not the last reference
		{
			if( _pParent )
				_pParent->ReleaseParentRef();
		}
		return lockCount;
	};

	virtual ot_uint32_t GetRefCount()
	{
//		printf("%p, GetRefCount %d\n", this, _refCount);
		return _refCounter.GetRefCount();
	};

	OTParentTracker*	GetParentTracker() {return _pParent;};

	bool				bInEarlyRelease() {return _bInEarlyRelease;};
	void				SetInEarlyRelease(bool bEnable) {_bInEarlyRelease = bEnable;};
	ECritSec&			GetLock() {return _lock;};
private:
	RefCounter		 _refCounter;
	OTParentTracker* _pParent;

	ECritSec		_lock;
	bool			_bInEarlyRelease;
};

/// Declaration for Smart Pointer Implementation code
#define DECLARE_IMP_OMNITEK_PTR \
	virtual ::OmniTek::ot_uint32_t AddRef() \
	{ \
		return ImpOmniTekBasePtr::AddRef(); \
	} \
	virtual ::OmniTek::ot_uint32_t Release() \
	{ \
		return ImpOmniTekBasePtr::Release(); \
	} \
	virtual ::OmniTek::ot_uint32_t GetRefCount() \
	{ \
		return ImpOmniTekBasePtr::GetRefCount(); \
	}

/// Declaration for Smart Pointer Implementation code with client implementing an early release of the object.
/// Useful if you need to release a circular reference count to another smart pointer object
/// Caller needs to implement "void _EarlyReleaseCount();"
#define DECLARE_IMP_OMNITEK_PTR_WITH_EARLY_RELEASE(EarlyReleaseCount) \
	virtual ::OmniTek::ot_uint32_t AddRef() \
	{ \
		return ImpOmniTekBasePtr::AddRef(); \
	} \
	virtual ::OmniTek::ot_uint32_t Release() \
	{ \
		EAutoLock lock(ImpOmniTekBasePtr::GetLock()); \
		::OmniTek::ot_uint32_t lockCount = ImpOmniTekBasePtr::Release(); \
		if( !ImpOmniTekBasePtr::bInEarlyRelease() && (lockCount == EarlyReleaseCount) ) \
		{ \
			ImpOmniTekBasePtr::SetInEarlyRelease(true); \
			_EarlyReleaseCount(); \
			ImpOmniTekBasePtr::SetInEarlyRelease(false); \
		} \
		if( ImpOmniTekBasePtr::bInEarlyRelease() ) \
			return 1; \
		else \
			return ImpOmniTekBasePtr::GetRefCount(); \
	} \
	virtual ::OmniTek::ot_uint32_t GetRefCount() \
	{ \
		return ImpOmniTekBasePtr::GetRefCount(); \
	}

}
