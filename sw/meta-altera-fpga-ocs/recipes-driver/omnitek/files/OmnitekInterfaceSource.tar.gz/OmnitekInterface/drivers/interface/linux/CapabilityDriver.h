/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef CAPABILITYDRIVER_H_
#define CAPABILITYDRIVER_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"

/**
 * @brief Basic container for all Linx capability drivers
 *
 * Under linux we need a container to registering driver behaviour for our custom bus,
 * this is that container.

 * As this is a virtual driver this will be used by all capability drivers
 *
 * Private data would be stored in a specific structure for a driver...
 *
 * struct _RegDriver
 *
 * {
 *
 *   OmniTekCapabilityDriver CapDriver;
 *
 *   int some_private_data;
 *
 *   char some_more_private_data;
 *
 * };
 *
 * \#define GetRegDriver(capDriver) container_of(capDriver, struct _RegDriver, CapDriver);
 *
 *  As this is likely to be created in a static context FriendlyName can be a pointer
 *  without needing to care about allocating memory ( will be statically accessible... )
 */
typedef struct _OmniTekCapabilityDriver
{
    char *FriendlyName; //!< some sort of description.... device_driver already has a name so do we needs this?
    const DriverMatchId *IdTable; //!< The lookup table the bus uses to pick if this driver is ok to use a device. we could put a size element in or just make sure there is an empty elm?...
    struct device_driver Driver; //!< actual linux driver object
} OmniTekCapabilityDriver;

typedef OmniTekCapabilityDriver *POmniTekCapabilityDriver; //!< Pointer to OmniTekCapabilityDriver

/**
 * @brief given a normal device_driver get the full OmniTekCapabilityDriver instance
 */
#define ToOmniTekCapabilityDriver(drv) container_of(drv, OmniTekCapabilityDriver, Driver);

/** @}*/

#endif /* CAPABILITYDRIVER_H_ */
