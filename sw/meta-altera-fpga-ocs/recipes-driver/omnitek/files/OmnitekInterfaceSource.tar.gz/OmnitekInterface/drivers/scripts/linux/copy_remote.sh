#! /bin/bash

# Copyright (C) Altera Corporation
#
# SPDX-License-Identifier: GPL-2.0-only

IP="bus-test-linux"
USR=user
P="~/otb/"

if [ $# -eq 3 ]
then
	USR="${1}"
	IP="${2}"
	P="${3}"
elif [ $# -ne 0 ]
then
	echo $0 "[user host path]"
	exit
fi


BINS="RegisterAccess OmniTekBus testApp MDMA VideoFDMA OmniTekFPGADebug MemMap RTVE EventFDMA EyeScanDMA QueryInfo"
cd ../../
BIN_LOCS=""
for B in $BINS
do
	for F in `find -name $B`
	do
		file "$F" | grep -q ELF
		if [ $? == 0 ]
		then
			BIN_LOCS="${BIN_LOCS} ${F}" 
		fi
	done
done

scp ${BIN_LOCS} `find -name \*.ko` `find -name \*.so` ${USR}@${IP}:${P}
