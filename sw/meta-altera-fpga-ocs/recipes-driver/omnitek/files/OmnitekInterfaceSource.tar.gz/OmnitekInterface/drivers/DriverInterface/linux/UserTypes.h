/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef _LINUX_USER_TYPES_H
#define _LINUX_USER_TYPES_H

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef BUILDTYPE
#error "Do not include this file directly"
#endif
#ifdef BT_KERNEL
#error "Cannot include this file when building a User Mode module"
#endif

#include <stdint.h>
#include <stdbool.h>

/** @}*/

#endif  //_LINUX_USER_TYPES_H
