/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef OTCAPABILITYTYPES_H_
#define OTCAPABILITYTYPES_H_

/** \addtogroup UserlandInterface
 *  @{
 */


/**
 * @brief Capability Header Types
 * Valid values for capabilities this system will parse.
 */
typedef enum
{
    InterruptCap = 0xff, //!< Interrupt Capability
    RegisterCap = 0xfe, //!< Register Capability
    OffsetCap = 0xfd, //!< Offset Capability
    MemMapCap = 0xfc, //!< Memory Map Capability
    GroupingCap = 0xfb, //!< Grouping Capability
} CapabilityTypes;

/**
 * @brief DMA type values
 * Register and Offset Capabilities type having a base of 0x100 and the bits 3:2
 * pertaining to the following values means that it is a dma of some type.
 */
typedef enum
{
    DMAType_MDMA = 0,//!< Memory DMA
    DMAType_FDMA = 1, //!< FIFO (Streaming) DMA
    DMAType_Target = 2, //!< Remote FPGA DMA Sendee
    DMAType_Peer = 3, //!< Remote FPGA DMA Sender
} DMAType_t;

/**
 * @brief DMA direction values
 * Register and Offset Capabilities type having a base of 0x100 and the bits 1:0
 * pertaining to the following values giving a direction to a dma type.
 */
typedef enum
{
    DMADirection_Input = 0, //!< DMA is from FPGA to host
    DMADirection_Output = 1, //!< DMA is from host to FPGA
    DMADirection_BiDirectional = 2, //!< DMA is bi-directional
} DMADirection_t;

/**
 * @brief DMA content values
 * Register and Offset Capabilities type having a base of 0x100 and the bits 5:4
 * pertaining to the following values giving a data type to a dma type.
 */
typedef enum
{
    DMAContentType_Data = 0, //!< DMA content is raw data
    DMAContentType_Video, //!< DMA content is video
    DMAContentType_Audio, //!< DMA content is audio
    DMAContentType_Packet //!< DMA content is packet based data
} DMAContentType_t;

/**
 * @brief Start value of all dma type register capabilities
 */
#define RegCap_DMA_Base	(0x100)

/**
 * @brief Bit shift for dma content type within a capability id
 */
#define OmDmaContentTypeShift				(4)

/**
 * @brief Mask for dma content type within a capability id
 */
#define OmDmaContentTypeMask				(0x3<<OmDmaContentTypeShift)

/**
 * @brief Set the dma content type within a dma capability id
 */
#define OmDmaSetContentType(ContentType)	((ContentType<<OmDmaContentTypeShift)&OmDmaContentTypeMask)

/**
 * @brief Get the dma content type from a dma capability id
 */
#define OmDmaGetContentType(RegCap)			(DMAContentType_t)((RegCap&OmDmaContentTypeMask)>>OmDmaContentTypeShift)

/**
 * @brief Bit shift for dma type within a capability id
 */
#define OmDmaTypeShift					(2)

/**
 * @brief Mask for dma type within a capability id
 */
#define OmDmaTypeMask					(0x3<<OmDmaTypeShift)

/**
 * @brief Set the dma type within a dma capability id
 */
#define OmDmaSetType(Type)				((Type<<OmDmaTypeShift)&OmDmaTypeMask)

/**
 * @brief Get the dma type from a dma capability id
 */
#define OmDmaGetType(RegCap)			(DMAType_t)((RegCap&OmDmaTypeMask)>>OmDmaTypeShift)

/**
 * @brief Bit shift for dma direction type within a capability id
 */
#define OmDmaDirectionShift				(0)

/**
 * @brief Mask for dma direction within a capability id
 */
#define OmDmaDirectionMask				(0x3<<OmDmaDirectionShift)

/**
 * @brief Set the required direction within a dma capability id
 */
#define OmDmaSetDirection(Type)			((Type<<OmDmaDirectionShift)&OmDmaDirectionMask)

/**
 * @brief Get the direction flag from a dma capability id
 */
#define OmDmaGetDirection(RegCap)		(DMADirection_t)((RegCap&OmDmaDirectionMask)>>OmDmaDirectionShift)

/**
 * @brief Test to see if the capability type is within the legal range for dmas
 */
#define OmIsDmaCap(RegCap)				((RegCap & ~(OmDmaContentTypeMask | OmDmaTypeMask | OmDmaDirectionMask))==RegCap_DMA_Base)

/**
 * @brief Get the dma component of a capability id
 */
#define OmDmaFunctionMask(RegCap)		(RegCap & (OmDmaContentTypeMask | OmDmaTypeMask | OmDmaDirectionMask))


/**
 * @brief Standard Register and Offset Capability Types
 */
typedef enum
{
    RegCap_WildCard = 0x0, //!< This is not a valid capability, it is used as a global catch all for fallback drivers
    RegCap_FPGA = 0x1, //!< FPGA Capability, currently Altera only
    RegCap_VideoIO = 0x02, //!< VideoIO Capability
    RegCap_Timer = 0x10, //!< Timer Capability

    RegCap_DMA_DataInMDMA      = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_DataOutMDMA     = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_DataBiMDMA      = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_BiDirectional ), //!< A Bi-Directional Data MDMA
    RegCap_DMA_VideoInMDMA     = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_VideoOutMDMA    = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_VideoBiMDMA     = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_AudioInMDMA     = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_AudioOutMDMA    = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_AudioBiMDMA     = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_PacketInMDMA    = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_PacketOutMDMA   = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_PacketBiMDMA    = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_MDMA << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet

    RegCap_DMA_DataInFDMA      = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_DataOutFDMA     = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_DataBiFDMA      = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_VideoInFDMA     = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_Input ), //!< A video stream reading dma
    RegCap_DMA_VideoOutFDMA    = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_Output ), //!< A video stream writing dma
    RegCap_DMA_VideoBiFDMA     = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_AudioInFDMA     = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_AudioOutFDMA    = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_AudioBiFDMA     = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_PacketInFDMA    = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_PacketOutFDMA   = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_PacketBiFDMA    = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_FDMA << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet

    RegCap_DMA_DataInTarget    = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_DataOutTarget   = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_DataBiTarget    = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_VideoInTarget   = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_VideoOutTarget  = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_VideoBiTarget   = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_AudioInTarget   = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_AudioOutTarget  = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_AudioBiTarget   = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_PacketInTarget  = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_PacketOutTarget = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_PacketBiTarget  = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_Target << 2 ) | ( DMADirection_BiDirectional ), //!< Not valid as yet

    RegCap_DMA_DataInPeer      = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_DataOutPeer     = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_DataBiPeer      = 0x100 | ( DMAContentType_Data   << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_VideoInPeer     = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_VideoOutPeer    = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_VideoBiPeer     = 0x100 | ( DMAContentType_Video  << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_AudioInPeer     = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_AudioOutPeer    = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_AudioBiPeer     = 0x100 | ( DMAContentType_Audio  << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet
    RegCap_DMA_PacketInPeer    = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_Input ), //!< Not valid as yet
    RegCap_DMA_PacketOutPeer   = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_Output ), //!< Not valid as yet
    RegCap_DMA_PacketBiPeer    = 0x100 | ( DMAContentType_Packet << 4 ) | ( DMAType_Peer << 2 )   | ( DMADirection_BiDirectional ), //!< Not valid as yet

    RegCap_AlteraClockedVideoInput  = 0x200, //!< Altera Clocked Video Input. Refer to http://www.altera.com/literature/ug/ug_vip.pdf Table 10-10
    RegCap_AlteraClockedVideoOutput, //!< Altera Clocked Video Out. Refer to http://www.altera.com/literature/ug/ug_vip.pdf Table 11-8
    RegCap_AudioExtract, //!< Audio Extract Capability
    RegCap_AudioEmbed, //!< Audio Embed Capability
    RegCap_AncillaryExtract, //!< Ancillary Extract Capability
    RegCap_AncillaryEmbed, //!< Ancillary Embed Capability
} RegCap_t;

/**
 * @brief Memory Map Capability types
 * Enum of values for the Type field in the Capabilities structure
 */
typedef enum
{
    BarRegion = 0, //!< PCIe BAR
    MemMapRegion = 1, //!< General memory map
    CapMapRegion = 2, //!< Memory area with more capability structures
    WildcardRegion = 0xffffffff //!< General catch all used for matching ONLY.....
} MemMapTypes;

/** @}*/

#endif /* OTCAPABILITYTYPES_H_ */
