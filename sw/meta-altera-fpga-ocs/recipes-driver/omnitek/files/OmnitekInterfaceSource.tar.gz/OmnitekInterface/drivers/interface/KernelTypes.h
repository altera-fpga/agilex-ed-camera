/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef _INTERFACE_TYPES_H_
#define _INTERFACE_TYPES_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"
#include "Common.h"

/**
 * @brief Common return codes for this system.
 *
 * Others include any standard windows / linux error codes.
 * Should endeavour to use the IsSuccess and IsFailure macros
 * to check the return from function
 */
typedef enum
{
    SUCCESS = 0, //!< Operation succeed
    GENERAL_ERROR = -1, //!< Non-specific error condition
    ALLOC_FAIL = -2, //!< could not continue as we could not allocate more memory. System will probably be in an inconsistent state...
    NULL_ARG_1 = -3, //!< an argument was null when its unacceptable ( first )
    NULL_ARG_2 = -4, //!< an argument was null when its unacceptable ( second )
    NULL_ARG_3 = -5, //!< an argument was null when its unacceptable ( third )
    NULL_ARG_4 = -6, //!< an argument was null when its unacceptable ( fourth )
    INVALID_ARG_1 = -7, //!< something was invalid with an arg ( first )
    INVALID_ARG_2 = -8, //!< something was invalid with an arg ( second )
    INVALID_ARG_3 = -9, //!< something was invalid with an arg ( third )
    INVALID_ARG_4 = -10, //!< something was invalid with an arg ( fourth )
    RANGE_ERROR = -11, //!< index out of bounds esk error
    GENERAL_WARNING = -12, //!< we still completed the request but the result may be wrong as something erroneous happened
} OT_ErrorCodes;

/* Platform dependent include */
#if BUILDTYPE == BT_LINUX
#include "linux/KernelTypes.h"
#endif

#if BUILDTYPE == BT_WINDOWS
#include "windows/KernelTypes.h"
#endif

/** @}*/

#endif /* TYPES_H_ */
