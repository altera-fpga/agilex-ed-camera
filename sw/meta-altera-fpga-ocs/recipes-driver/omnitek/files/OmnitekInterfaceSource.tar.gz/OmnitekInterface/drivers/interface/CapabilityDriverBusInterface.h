/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef CAPABILITYDRIVERBUSINTERFACE_H_
#define CAPABILITYDRIVERBUSINTERFACE_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

/*
 * This file lists the interfaces that the Capability Drivers should use to interact with the bus.
 */


#include "global_defs.h"
#include "Common.h"
#include "CapabilityTypes.h"
#include "CapabilityDevice.h"


/**
 * @brief Callback signature for interrupts into device drivers on the bus
 * @param[in] context The device that is being notified.
 * @param[in] isrTime If the host controller has a timer this will be the time when the isr fired
 * @return TRUE if handled FALSE otherwise
 */
typedef bool (*BusISRCB)( POmniTekCapabilityDevice context, uint64_t isrTime );

/**
 * @brief Callback signature for registering a callback for interrupts for a specific device instance
 * @param[in] context The device instance wanting to register an interrupt handler
 * @param[in] cb The callback that should be used when a matching interrupt occurs
 * @return See Types.h
 */
typedef uint32_t (*RegISRCallback)( POmniTekCapabilityDevice context, BusISRCB cb );

/**
 * @brief Callback signature for deregistering a callback for interrupts for a specific device instance
 * @param[in] context The device instance wanting to deregister an interrupt handler
 */
typedef void (*DeRegISRCallback)( POmniTekCapabilityDevice context );

/**
 * @brief Callback signature for reading capability devices register
 *
 * Allow a device to read a register. The register block does not need to be within the capability of the passed device ( although this should
 * be the normal case )
 * @param[in] context The device instance asking for the read. Needed to obtain bus / host controller information
 * @param[in] block The capability block to read from
 * @param[in] reg The register within the block to read from
 * @param[out] readValue Where to read the value goes into
 * @return See Types.h
 */
typedef uint32_t (*ReadRegCap)( POmniTekCapabilityDevice context, PRegisterBlock cap, const RegCount_t reg, uint32_t *readValue );

/**
 * @brief Callback signature for writing to a capability devices register
 *
 * Allow a device to write a register. The register block does not need to be within the capability of the passed device ( although this should
 * be the normal case )
 * @param[in] context The device instance asking for the write. Needed to obtain bus / host controller information
 * @param[in] block The capability block to write to
 * @param[in] reg The register within the block to write to
 * @param[in] writeValue The value to write into the selected register
 * @return See Types.h
 */
typedef uint32_t (*WriteRegCap)( POmniTekCapabilityDevice context, PRegisterBlock cap, const RegCount_t reg, const uint32_t writeValue );

/**
 * @brief Callback signature for reading capability devices shadow register
 *
 * Allow a device to read a shadow register. The register block does not need to be within the capability of the passed device ( although this should
 * be the normal case )
 * @param[in] context The device instance asking for the read. Needed to obtain bus / host controller information
 * @param[in] block The capability block to read from
 * @param[in] reg The register within the block to read from
 * @param[out] readValue Where to read the value goes into
 * @return See Types.h
 */
typedef uint32_t (*ReadShadowRegCap)( POmniTekCapabilityDevice context, PRegisterBlock cap, const RegCount_t reg, uint32_t *readValue );

/**
 * @brief Callback signature for obtaining a host controllers timer frequency
 * Some host controllers supply a timer, when present it can be used for high resolution timing.
 * To convert the time value from the timer you need the frequency of the timer. To convert a time to
 * milliseconds use the following: ( (double)time / (double)hertz ) * 1000.0
 *
 * @param[in] context The capability device we are wanting to get the associated host controllers timer frequency
 * @param[out] hertz pointer where the returned frequency will be placed in.
 * @return true if the host controller has a timer and we managed to place the value in hertz, false otherwise
 */
typedef bool (*TimerGetFrequencyCB)( POmniTekCapabilityDevice context, uint32_t * hertz );

/**
 * @brief Callback signature for obtaining a host controllers timer current value
 * Some host controllers supply a timer, when present it can be used for high resolution timing.
 * To convert the time value from the timer you need the frequency of the timer. To convert a time to
 * milliseconds use the following: ( (double)time / (double)hertz ) * 1000.0
 *
 * @param[in] context The capability device we are wanting to get the associated host controllers timer value
 * @param[out] time pointer where to place the current value
 * @return true if the host controller has a timer and we managed to place the value in time, false otherwise
 */
typedef bool (*TimerGetTimeCB)( POmniTekCapabilityDevice context, uint64_t * time );

// include platform dependent headers
#if BUILDTYPE == BT_WINDOWS
#include "windows/CapabilityDriverBusInterface.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/CapabilityDriverBusInterface.h"
#endif

/**
 * @brief Remote interface for all capability devices communication with the bus
 */
typedef struct _CapabilityDeviceInterface
{
#if BUILDTYPE == BT_WINDOWS
    INTERFACE InterfaceHeader; //!< standard interface header needed for communication
    SetCapDevGIUDCB SetGUID; //!< Set the exposed driver guid
    SetForceDetachCB SetForceDetach; //!< Set the detach callback
    WDFDEVICE HostControllerDevice; //!< The host controller this capability uses needed for DMA functions
#endif
#if BUILDTYPE == BT_LINUX
    struct device *HostControllerDevice; //!< The host controller this capability uses needed for DMA functions
#endif
    RegISRCallback RegisterISRCallback; //!< Register your ISR
    DeRegISRCallback DeRegisterISRCallback; //!< DeRegister your ISR
    ReadRegCap ReadRegisterCap; //!< Perform a register read
    WriteRegCap WriteRegisterCap; //!< Perform a register write
    ReadShadowRegCap ReadShadowRegisterCap; //!< Perform a shadow register read
    POmniTekCapabilityDevice Device; //!< Device instance needed for callbacks exposed
    TimerGetFrequencyCB TimerGetFrequency; //!< Get the associated host controllers timer frequency
    TimerGetTimeCB TimerGetTime; //!< get the associated host controllers timer value
} CapabilityDeviceInterface;
typedef CapabilityDeviceInterface *PCapabilityDeviceInterface; //!< Pointer to CapabilityDeviceInterface


/** @}*/

#endif /* CAPABILITYDRIVERBUSINTERFACE_H_ */
