/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "global_defs.h"

#ifndef MEMORY_H_
#define MEMORY_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

/**
 * AllocateMemory / DeleteMemory functions per platform.
 */

#if BUILDTYPE == BT_WINDOWS
#include "windows/Memory.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/Memory.h"
#endif

/** @}*/

#endif /* MEMORY_H_ */
