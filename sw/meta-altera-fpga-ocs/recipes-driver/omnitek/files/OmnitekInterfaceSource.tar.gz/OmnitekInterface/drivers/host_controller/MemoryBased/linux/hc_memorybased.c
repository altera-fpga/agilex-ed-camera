/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/mod_devicetable.h>
#include <linux/slab.h>

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/dma-mapping.h>


#include "HostController.h"
#include "HostControllerInterface.h"
#include "HostControllerBusInterface.h"

#include "../hc_memorybased_common.h"
#include "../../hccommon.h"

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_WARNING;

#define FromDevToDID( dev ) container_of( dev, DriverInstanceData, pdev );
#define FromHCToDID( hstc ) container_of( hstc, DriverInstanceData, hc );

static struct file_operations OT_HC_MemoryBased_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = NULL,
};

void OT_HC_MemoryBased_BusExit( POmniTekHostController context )
{
    DriverInstanceData *fdoData = container_of( context, DriverInstanceData, hc );
    if ( fdoData->BusInterface.DeRegisterHostController != NULL )
    {
        fdoData->BusInterface.DeRegisterHostController( context );
    }
    context->BusISR = NULL;
    context->SlotId = 0;
}

extern struct device_attribute dev_attr_debuglevel;

int OT_HC_MemoryBased_probe( struct platform_device *pdev )
{
    int status = 0;
    DriverInstanceData *did = NULL;
    char nameBuf[MAX_FILEPATH_LEN];

    did = kzalloc( sizeof( DriverInstanceData ), GFP_KERNEL );
    if( did == NULL )
        return -ENOMEM;

    status = device_create_file( &pdev->dev, &dev_attr_debuglevel );
    if( status )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_MemoryBased, "can't create sysfs debuglevel file!!!\n" );
        return status;
    }

    MANUF_FUNC( _GetInterfaceHCInterface )( &did->hc, &did->BusInterface );

    did->BusInterface.INIT_OmniTekHostControllerInterface( &did->hci );
    did->hci.NotifyBusExit = OT_HC_MemoryBased_BusExit;

    snprintf( did->hc.InstanceName, MAX_NAME_LEN, "%s:%d", pdev->name, pdev->id );
    snprintf( did->hc.TypeName, MAX_NAME_LEN, MANUF_DEV("_HC_MemoryBased") );
    did->hc.Uuid = UUID_USERINTERFACE_HC_MEMORYBASED;
    did->hc.Device = &pdev->dev;
    did->memSize = MS;
    did->pdev = pdev; // incase we need to go from a host controller back to a pdev...

    status = did->BusInterface.RegisterHostController( &did->hc, &did->hci );
    if ( status != SUCCESS )
    {
        kfree( did );
        return status;
    }

    // start char dev code
    snprintf( nameBuf, MAX_FILEPATH_LEN, MANUF_DEV("_HC_MemoryBased_%02d"), did->hc.SlotId );
    status = alloc_chrdev_region( &( did->Major ), 0, 1, nameBuf );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_MemoryBased, "Error %d alloc_chrdev_region\n", status );
        kfree( did );
        return status;
    }
    did->Minor = MKDEV( MAJOR( did->Major ), MINOR( did->Major ) );

    cdev_init( &( did->CDev ), &OT_HC_MemoryBased_fops );
    did->CDev.owner = THIS_MODULE;

    status = cdev_add( &( did->CDev ), did->Minor, 1 );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_MemoryBased, "Error %d cdev_add\n", status );
        kfree( did );
        return status;
    }

    if ( NULL == device_create( MANUF_FUNC(_GetClass)(), &pdev->dev, did->Minor, NULL, nameBuf ) )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_MemoryBased,  "Failed to create bus dev entry\n" );
    }
    else
    {
        snprintf( did->hc.DeviceAccessName, MAX_FILEPATH_LEN, "/dev/%s", nameBuf );
    }
    // end char dev code

    status = dma_set_mask_and_coherent( &pdev->dev, DMA_BIT_MASK( 64 ) );
    if( status )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, HC_MemoryBased, "Couldn't set 64 bit DMA mask, attempting 32\n" );
        status = dma_set_mask_and_coherent( &pdev->dev, DMA_BIT_MASK( 32 ) );
        if( status )
        {
            KernelTraceNA( TRACE_LEVEL_ERROR, HC_LocalFPGA, "Couldn't set DMA mask\n" );
            return status;
        }
    }

    platform_set_drvdata( pdev, did );

    OT_HC_MemoryBased_FillInTest( did->mem );

    OT_HC_MemoryBased_Enumerate( did );

    return 0;
}

int OT_HC_MemoryBased_remove( struct platform_device *pdev )
{
    DriverInstanceData *did = NULL;

    did = platform_get_drvdata( pdev );
    if ( did != NULL )
    {
        did->BusInterface.DeRegisterHostController( &did->hc );

        device_remove_file( &pdev->dev, &dev_attr_debuglevel );

        device_destroy( MANUF_FUNC(_GetClass)(), did->Minor );

        cdev_del( &( did->CDev ) );
        unregister_chrdev_region( did->Major, 1 );


        kfree( did );
        platform_set_drvdata( pdev, NULL );
    }

    return 0;
}

void OT_HC_MemoryBased_device_release( struct device *dev )
{
}

static struct platform_device_id OT_HC_MemoryBased_id_table[ ] = {
    {  MANUF_DEV("-hc-memorybased"), 0 },
    { },
};
MODULE_DEVICE_TABLE( platform, OT_HC_MemoryBased_id_table );

static struct platform_driver OT_HC_MemoryBased_driver = {
    .driver = {
        .name = MANUF_DEV("-hc-memorybased"),
        .owner = THIS_MODULE,
    },
    .probe = OT_HC_MemoryBased_probe,
    .remove = OT_HC_MemoryBased_remove,
    .id_table = OT_HC_MemoryBased_id_table,
};

static struct platform_device OT_HC_MemoryBased_device = {
    .name = MANUF_DEV("-hc-memorybased"),
    .id = 0,
    .dev = {
        .release = OT_HC_MemoryBased_device_release,
    },
};

int OT_HC_MemoryBased_init( void )
{
    int result = 0;
    result = platform_driver_register( &OT_HC_MemoryBased_driver );
    if( result != 0 )
    {
        return result;
    }

    result = platform_device_register( &OT_HC_MemoryBased_device );

    return result;
}

void OT_HC_MemoryBased_cleanup( void )
{
    platform_device_unregister( &OT_HC_MemoryBased_device );

    platform_driver_unregister( &OT_HC_MemoryBased_driver );
}

module_init( OT_HC_MemoryBased_init );
module_exit( OT_HC_MemoryBased_cleanup );
