/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HCCOMMON_H_
#define HCCOMMON_H_

#include "HostController.h"
#include "OTCapabilityTypes.h"
#define HeaderVersion 1
#define HeaderSize 3

#define w64( a, i, v ) \
    a[ i ]   = ( uint32_t )( v & 0xffffffff ); \
    a[ i + 1 ] = ( uint32_t )( ( ( uint64_t ) v >> 32 ) & 0xffffffff );

#define wHdr( a, i, v, t, s ) \
    a[ i ] = ( ( ( s & 0xff ) << 24 ) | ( ( v & 0xff ) << 8 ) | ( t & 0xff ) ); \
    w64( a, ( i + 1 ), ( ( i + s ) << 2 ) );

#define MemMapCapSize ( HeaderSize + 5 )

#define wPCIBarMemMapR( a, i, bn, mms, mmo ) \
    wHdr( a, i, HeaderVersion, MemMapCap, MemMapCapSize ); \
    a[ i + HeaderSize ] = ( ( ( bn & 0xff ) << 8 ) | ( 0 ) ); \
    w64( a, ( i + HeaderSize + 1 ), mms ); \
    w64( a, ( i + HeaderSize + 3 ), mmo );

#define wMemMapR( a, i, mms, mmo ) \
    wHdr( a, i, HeaderVersion, MemMapCap, MemMapCapSize ); \
    a[ i + HeaderSize ] = 1; \
    w64( a, ( i + HeaderSize + 1 ), mms ); \
    w64( a, ( i + HeaderSize + 3 ), mmo );

#define wCapMemR( a, i, mms, mmo ) \
    wHdr( a, i, HeaderVersion, MemMapCap, MemMapCapSize ); \
    a[ i + HeaderSize ] = 2; \
    w64( a, ( i + HeaderSize + 1 ), mms ); \
    w64( a, ( i + HeaderSize + 3 ), mmo );

#define InterruptCapSize( nsr ) ( HeaderSize + ( nsr * 2 ) + 1 )

#define wInterruptCap( a, i, nsr, iid, ibl ) \
    wHdr( a, i, HeaderVersion, InterruptCap, InterruptCapSize( nsr ) ); \
    a[ i + HeaderSize ] = ( ( ( nsr & 0xff ) << 16 ) | ( ( iid & 0xff ) << 8 ) | ( ibl & 0xff ) );

#define RegSize( numRegs ) ( HeaderSize + 2 + numRegs )

#define RegSize2( numRegs ) ( HeaderSize + 3 + numRegs )

#define wRegCap( a, i, capT, capV, irl, assocId, compId, numRegs ) \
    wHdr( a, i, HeaderVersion, RegisterCap, RegSize( numRegs ) ); \
    a[ i + HeaderSize ] = ( ( ( capT & 0xffff ) << 16 ) | ( ( capV & 0xff ) << 8 ) | ( irl & 0xff ) ); \
    a[ i + HeaderSize + 1 ] = ( ( ( assocId & 0xffff ) << 16 ) | ( compId & 0xffff ) ); \

#define wRegCap2( a, i, capT, capV, irl, assocId, compId, numRegs, IRQStatusRegister, IRQEnableRegister ) \
    wHdr( a, i, 2, RegisterCap, RegSize2( numRegs ) ); \
    a[ i + HeaderSize ] = ( ( ( capT & 0xffff ) << 16 ) | ( ( capV & 0xff ) << 8 ) | ( irl & 0xff ) ); \
    a[ i + HeaderSize + 1 ] = ( ( ( assocId & 0xffff ) << 16 ) | ( compId & 0xffff ) ); \
    a[ i + HeaderSize + 2 ] = ( ( 0x1 << 31 ) | ( ( IRQStatusRegister & 0x7fff ) << 16 ) | ( 0x1 << 15 ) | ( IRQEnableRegister & 0x7fff ) );

#endif /* HCCOMMON_H_ */
