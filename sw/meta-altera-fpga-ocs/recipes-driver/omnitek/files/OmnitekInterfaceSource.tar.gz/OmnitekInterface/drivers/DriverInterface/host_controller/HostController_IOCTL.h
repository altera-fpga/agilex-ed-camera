/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HOSTCONTROLLER_IOCTL_H_
#define HOSTCONTROLLER_IOCTL_H_

/** \addtogroup UserlandInterface
 *  @{
 */

#include "global_defs.h"

/** \cond */
#define HC_IOC_MAGIC (0)
/** \endcond */


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/** \cond */
enum
{
    HC_IOCTL_NUM_GetNumRegions		= OT_IOCTL_NUMBER(HC_IOC_MAGIC, 1), //!< HC_GetNumRegions_IOCTL
    // cannot use value 2 for some unknown reason...
    HC_IOCTL_NUM_GetRegion			= OT_IOCTL_NUMBER(HC_IOC_MAGIC, 3), //!< HC_GetRegion_IOCTL
	HC_IOCTL_NUM_GetPlatformInfo	= OT_IOCTL_NUMBER(HC_IOC_MAGIC, 4), //!< HC_GetPlatformInfo_IOCTL
	HC_IOCTL_NUM_ReadPciConfig		= OT_IOCTL_NUMBER(HC_IOC_MAGIC, 5) //!<HC_ReadPciConfig_IOCTL
};
/** \endcond */

#pragma pack(push,4)

/**
 * @brief Structure used to bridge 32/64 bit apps and drivers for data transfer
 */
typedef union
{
	struct {
		uint32_t PointerLow;
		uint32_t PointerHigh;
	};
	void *pVa; //!< Virtual Address of buffer on PC, is converted to 64bit value for cross between 32bit app and 64bit driver
} HC_VirtualPointer;

/**
 * @brief IOCTL container for #HC_GetNumRegions_IOCTL
 *
 * Version must be #HC_IOCTL_GetNumRegions_Version
 * Returns The number of regions containing capabilities
 *
 */
typedef struct
{
    uint32_t Version; //!< see the description for more information
    uint32_t NumRegions; //!< refer to the capability specification document
} HC_GetNumRegions_IOCTL;

/**
 * @brief IOCTL container for #HC_GetRegion_IOCTL
 *
 * Version must be #HC_IOCTL_GetRegion_Version
 * Index to the required region
 * Client buffer to receive the region
 * size of the client buffer
 * Returns Copies the region to the client buffer, bufferSize is updated with size copied.
 *
 */
typedef struct
{
    uint32_t 			Version; //!< see the description for more information
    uint32_t 			Idx; //!< refer to the capability specification document
    HC_VirtualPointer 	Buffer; //!< Client buffer to receive the region. Note the virtual address must be aligned to MEMORY_ALLOCATION_ALIGNMENT
    uint32_t 			Size; //!< Size of the virtual address pointed to by pVa, set to zero to get the total size of the region
    uint32_t			Offset; //!< Offset into the region for the region read
} HC_GetRegion_IOCTL;

/**
 * @brief Types of host controller
 */
typedef enum
{
	HC_PlatformInfoUnknown = 0, //!< Unknown type of host controller
	HC_PlatformInfoPCIe = 1, //!< PCIe host controller
	HC_PlatformInfoSoc = 2, //!< SoC host controller
}HC_PlatformInfoType;

/**
 * @brief IOCTL container for #HC_IOCTL_GetPlatformInfo
 */
typedef struct
{
    uint32_t Version; //!< must be #HC_IOCTL_GetPlatformInfo_Version
    HC_PlatformInfoType type; //!< Host controller type
} HC_GetPlatformInfo_IOCTL;

/**
 * @brief IOCTL container for #HC_IOCTL_ReadPciConfig
 *
 * Version must be #HC_IOCTL_ReadPciConfig_Version
 * Returns The platform structure
 *
 */
typedef struct
{
	uint32_t Version; 			//!< see the description for more information
	uint32_t Offset; 			//!< Offset for the Config Read
	uint32_t Size; 				//!< Size of the Config Read
    HC_VirtualPointer buffer;	//!< Output Read Buffer pointer. Note the virtual address must be aligned to MEMORY_ALLOCATION_ALIGNMENT
}HC_ReadPciConfig;

#pragma pack(pop)

/* Include the platform specific headers  */
#if BUILDTYPE == BT_WINDOWS
#include "windows/HostController_IOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/HostController_IOCTL.h"
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/

#endif /* HOSTCONTROLLER_IOCTL_H_ */
