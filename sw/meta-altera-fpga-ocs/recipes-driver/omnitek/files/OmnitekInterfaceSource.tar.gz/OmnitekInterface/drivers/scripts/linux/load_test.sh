#! /bin/bash

# Copyright (C) Altera Corporation
#
# SPDX-License-Identifier: GPL-2.0-only

sudo insmod OmniTekFPGABus.ko
sudo insmod OT_HC_MemoryBased.ko

sudo insmod OT_Cap_MDMA.ko
sudo insmod OT_Cap_VideoFDMA.ko
sudo insmod OT_Cap_OmniFB.ko

sudo insmod OT_Cap_RegisterAccess.ko
