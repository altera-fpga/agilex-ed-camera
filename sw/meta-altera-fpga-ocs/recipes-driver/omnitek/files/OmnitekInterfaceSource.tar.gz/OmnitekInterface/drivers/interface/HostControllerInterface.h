/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HOSTCONTROLLERINTERFACE_H_
#define HOSTCONTROLLERINTERFACE_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"
#include "CapabilityTypes.h"
#include "HostController.h"

/**
 * @brief Read a hardware dependent region for this controller.
 * @param[in] base VA of the starting location
 * @param[in] offset Offset into base
 * @return Read value
 */
typedef uint32_t (*HCReadHW)( uint32_t *base, const uint64_t offset );

/**
 * @brief Write a hardware dependent region for this controller.
 * @param[in] base VA of the starting location
 * @param[in] offset Offset into base
 * @param[in] writeValue The value to write
 */
typedef void (*HCWriteHW)( uint32_t *base, const uint64_t offset, const uint32_t writeValue );

/**
 * @brief Standard callback for any bus notification upon a host controller.
 *
 * The exact meaning is dependent on what the callback was registered for
 * @param[in] context The host controller specific instance that is being notified
 */
typedef void (*HCContextCB)( POmniTekHostController context );

/**
 * @brief Callback the bus should use to register its interest in receiving ISR notification
 * @param[in] context The host controller specific instance that is being notified
 * @param[in] isr The bus callback to trigger when the given host controller receives an interrupt
 */
typedef void (*HCRegisterISR)( POmniTekHostController context, HCISRCB isr );

// Platform required header
#if BUILDTYPE == BT_LINUX
#include "linux/HostControllerInterface.h"
#endif

/**
 * @brief Main context structure for a host controller interface
 */
typedef struct _OmniTekHostControllerInterface
{
    HCReadHW ReadHW; //!< For capability setup / debug probe
    HCWriteHW WriteHW; //!< For capability setup / debug probe
    HCRegisterISR RegisterISR; //!< For registration of callback for isr.
    HCContextCB DeRegisterISR; //!< For deregistration of callback for isr.
    HCContextCB EnableInterrupts; //!< Turn on interrupts.
    HCContextCB DisableInterrupts; //!< Turn off interrupts.
    HCContextCB NotifyBusExit; //!< To tell that the bus is going away...
} OmniTekHostControllerInterface;
typedef OmniTekHostControllerInterface * POmniTekHostControllerInterface; //!< Pointer to a OmniTekHostControllerInterface

/** @}*/

#endif /* HOSTCONTROLLERINTERFACE_H_ */
