/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "linux/GPUDirect.h"

#include "Common.h"

#include <linux/mutex.h>
#include <linux/sched.h>  /* Required by linux/wait.h but not included by it */
#include <linux/wait.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/ratelimit.h> /* Required by linux/printk.h for ratelimited macros, but not included by it */
#include <linux/printk.h>

#define GPU_ALIGNMENT_BITS  16
#define GPU_MISALIGNMENT_MASK ((1 << GPU_ALIGNMENT_BITS) - 1)

struct BufferState
{
    uint16_t generation;
    bool inUse;
};

static DEFINE_MUTEX(gBufferStateMutex);
static DECLARE_WAIT_QUEUE_HEAD(gBufferStateEvent);
static struct BufferState gBufferStates[MAX_GPU_BUFFERS];

#define GPU_MAKE_TOKEN(index, generation) (uintptr_t)( (((uintptr_t)(index) & 0xFFFF) << 16) | ((uintptr_t)(generation) & 0xFFFF) )
#define GPU_INVALID_TOKEN  GPU_MAKE_TOKEN(0xFFFF, 0)

#define GPU_TOKEN_INDEX(token) (((token) >> 16) & 0xFFFF)
#define GPU_TOKEN_GENERATION(token) ((token) & 0xFFFF)
#define GPU_TOKEN_IS_VALID(token) (GPU_TOKEN_INDEX(token) < MAX_GPU_BUFFERS)

static struct BufferState* GpuDirectGetBufferState(uintptr_t token)
{
    struct BufferState* pBufferState = NULL;

    if (GPU_TOKEN_IS_VALID(token))
    {
        pBufferState = &gBufferStates[GPU_TOKEN_INDEX(token)];
    }

    return pBufferState;
}

static uintptr_t GpuDirectAllocateToken(void)
{
    uint16_t index;

    mutex_lock(&gBufferStateMutex);

    for (index = 0; index < MAX_GPU_BUFFERS; index++)
    {
        struct BufferState* pBufferState = &gBufferStates[index];
        if (!pBufferState->inUse)
        {
            uintptr_t token = GPU_MAKE_TOKEN(index, pBufferState->generation);

            pBufferState->inUse = true;

            mutex_unlock(&gBufferStateMutex);
            return token;
        }
    }

    mutex_unlock(&gBufferStateMutex);
    return GPU_INVALID_TOKEN;
}

static void GpuDirectReleaseToken(uintptr_t* pToken)
{
    struct BufferState* pBufferState = GpuDirectGetBufferState(*pToken);
    if (pBufferState)
    {
        mutex_lock(&gBufferStateMutex);
        pBufferState->inUse = false;
        pBufferState->generation++;
        mutex_unlock(&gBufferStateMutex);

        wake_up(&gBufferStateEvent);

        *pToken = GPU_INVALID_TOKEN;
    }
}

static void GpuDirectCheckForLiveTransaction(uintptr_t token)
{
    struct BufferState* pBufferState = GpuDirectGetBufferState(token);
    if (pBufferState)
    {
        uint16_t tokenGeneration = GPU_TOKEN_GENERATION(token);
        bool isLive = false;

        mutex_lock(&gBufferStateMutex);
        isLive = (pBufferState->generation == tokenGeneration);
        mutex_unlock(&gBufferStateMutex);

        if (isLive)
        {
            pr_warn_ratelimited("WARNING: GPU pages released while in use for DMA, errors may occur."
                                " Please ensure all transactions are completed or cancelled before releasing memory.");
        }

    }
}

/* Called by GPU driver on its own thread */
static void GpuDirectFreeCallback(void* context)
{
    uintptr_t token = (uintptr_t)context;

    GpuDirectCheckForLiveTransaction(token);
}

static GpuDirectMappedPage* GpuDirectLastMappedPage( struct GpuDirectPages* pPages )
{
    nvidia_p2p_dma_mapping_t* pMap = pPages->pMapping;
    return pMap->dma_addresses + pMap->entries - 1;
}

int GpuDirectPinPages( void* pGpuVirtualAddress, size_t size, struct GpuDirectPages* pPages )
{
    if (!pPages)
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "NULL pages\n" );
        return -EINVAL;
    }

    if (!pGpuVirtualAddress)
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "NULL buffer\n" );
        return -EINVAL;
    }

    if (size == 0)
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "Zero size\n" );
        return -EINVAL;
    }

    if (pPages->pPageTable)
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "Pinning pages when already pinned\n" );
        return -EIO;
    }

    pPages->bufferLengthBytes = size;

    // Require GPU pages to be aligned, sufficient for current use cases - could improve this by aligning and managing an offset
    pPages->virtualAddress = (uint64_t)pGpuVirtualAddress;
    if (pPages->virtualAddress & GPU_MISALIGNMENT_MASK)
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "GPU pages does not have 64KB alignment, not supported\n" );
        return -ENOTSUPP;
    }

    pPages->token = GpuDirectAllocateToken();

    if (!GPU_TOKEN_IS_VALID(pPages->token))
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "Too many GPU buffers in use\n" );
        return -ENOMEM;
    }

    return nvidia_p2p_get_pages(0, 0, pPages->virtualAddress, size, &pPages->pPageTable,
                                GpuDirectFreeCallback, (void*)(pPages->token));
}

void GpuDirectUnpinPages( struct GpuDirectPages* pPages )
{
    if (!pPages)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, DMACommon, "Not unpinning, NULL pages pointer\n" );
        return;
    }

    if (!pPages->pPageTable)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, DMACommon, "Not unpinning, NULL page table pointer\n" );
        return;
    }

    if (!pPages->virtualAddress)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, DMACommon, "Not unpinning, zero virtual address\n" );
        return;
    }

    if (pPages->pMapping)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, DMACommon, "Unpinning pages when they are still mapped for DMA\n" );
    }

    {
        int result = 0;

        result = nvidia_p2p_put_pages(0, 0, pPages->virtualAddress, pPages->pPageTable);
        if (result != 0)
        {
            KernelTrace( TRACE_LEVEL_ERROR, DMACommon, "Failed to unpin GPU pages - error %i\n", result );
        }

        pPages->pPageTable = NULL;
        pPages->virtualAddress = 0;

        GpuDirectReleaseToken(&pPages->token);
    }
}

size_t GpuDirectGetPinnedPageCount( struct GpuDirectPages* pPages )
{
    if (pPages && pPages->pPageTable)
    {
        return pPages->pPageTable->entries;
    }

    return 0;
}

int GpuDirectMapPages( struct GpuDirectPages* pPages, struct pci_dev* pPciDevice )
{
    if (!pPages)
    {
        return -EINVAL;
    }

    if (!pPciDevice)
    {
        return -EINVAL;
    }

    if (!pPages->pPageTable)
    {
        return -ENOMEM;
    }

    if (pPages->pMapping)
    {
        return -EIO;
    }

    pPages->pPciDevice = pPciDevice;
    return nvidia_p2p_dma_map_pages( pPciDevice, pPages->pPageTable, &pPages->pMapping );
}

void GpuDirectUnmapPages( struct GpuDirectPages* pPages )
{
    if (!pPages)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, DMACommon, "Not unmapping, NULL pages pointer\n" );
        return;
    }

    if (!pPages->pPageTable)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, DMACommon, "Not unmapping, NULL page table pointer\n" );
        return;
    }

    if (!pPages->pMapping)
    {
        /* Verbose level as this is common when shutting down and does not indicate an error */
        KernelTraceNA( TRACE_LEVEL_VERBOSE, DMACommon, "Not unmapping, NULL page mapping pointer\n" );
        return;
    }

    if (!pPages->pPciDevice)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, DMACommon, "Not unmapping, NULL PCI device pointer\n" );
        return;
    }

    {
        int result = nvidia_p2p_dma_unmap_pages(pPages->pPciDevice, pPages->pPageTable, pPages->pMapping);
        if (result != 0)
        {
            KernelTrace( TRACE_LEVEL_ERROR, DMACommon, "Failed to unmap GPU pages - error %i\n", result );
        }

        pPages->pMapping = NULL;
        pPages->pPciDevice = NULL;
    }
}

size_t GpuDirectGetMappedPageCount( struct GpuDirectPages* pPages )
{
    if (pPages && pPages->pMapping)
    {
        return pPages->pMapping->entries;
    }

    return 0;
}

GpuDirectMappedPage* GpuDirectMappedPageFirst( struct GpuDirectPages* pPages )
{
    if (pPages && pPages->pMapping)
    {
        return pPages->pMapping->dma_addresses;
    }

    return NULL;
}

GpuDirectMappedPage* GpuDirectMappedPageNext( struct GpuDirectPages* pPages, GpuDirectMappedPage* pCurrentPage )
{
    if (pPages && pPages->pMapping && pCurrentPage)
    {
        nvidia_p2p_dma_mapping_t* pMap = pPages->pMapping;
        GpuDirectMappedPage* pLast = GpuDirectLastMappedPage( pPages );
        if ((pCurrentPage >= pMap->dma_addresses) && (pCurrentPage < pLast))
        {
            return pCurrentPage + 1;
        }
    }

    return NULL;
}

dma_addr_t GpuDirectMappedPageAddress( struct GpuDirectPages* pPages, GpuDirectMappedPage* pPage )
{
    (void)pPages;

    return pPage ? *pPage : 0;
}

size_t GpuDirectMappedPageLength( struct GpuDirectPages* pPages, GpuDirectMappedPage* pPage )
{
    size_t pageLength = 0;

    (void)pPage;

    if (pPages && pPages->pMapping && pPage)
    {
        nvidia_p2p_dma_mapping_t* pMap = pPages->pMapping;

        switch(pMap->page_size_type)
        {
            case NVIDIA_P2P_PAGE_SIZE_4KB:
                pageLength = 4 * 1024;
                break;

            case NVIDIA_P2P_PAGE_SIZE_64KB:
                pageLength = 64 * 1024;
                break;

            case NVIDIA_P2P_PAGE_SIZE_128KB:
                pageLength = 128 * 1024;
                break;

            default:
                KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "Unsupported GPUDirect DMA page size\n" );
                return 0;
        }

        if (pPage == GpuDirectLastMappedPage( pPages ))
        {
            // Last page may be shorter if buffer is not a whole number of pages
            size_t remainder = pPages->bufferLengthBytes % pageLength;
            if (remainder > 0)
            {
                pageLength = remainder;
            }
        }
    }

    return pageLength;
}
