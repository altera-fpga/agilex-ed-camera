/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/module.h>
#include <linux/slab.h>

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/interrupt.h>

#include <linux/pci.h>
#include <asm/io.h>

#include "host_controller/HostController_IOCTL.h"
#include "HostController.h"
#include "HostControllerInterface.h"
#include "HostControllerBusInterface.h"

#include "../../hccommon.h"
#include "../hc_omnitek_common.h"

#include "../pciConfigCommon.h"

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif

#ifndef CONFIG_PCI
#error "NO PCI SUPPORT!!!!"
#endif

#define FromDevToDID( dev ) container_of( dev, DriverInstanceData, pdev );
#define FromHCToDID( hstc ) container_of( hstc, DriverInstanceData, hc );

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_WARNING;

void OT_HC_OmniTek_BusExit( POmniTekHostController context )
{
    DriverInstanceData *fdoData = container_of( context, DriverInstanceData, hc );
    if ( fdoData->BusInterface.DeRegisterHostController != NULL )
    {
        fdoData->BusInterface.DeRegisterHostController( context );
    }
    context->BusISR = NULL;
    context->SlotId = 0;
}

void OT_HC_OmniTek_BusRegisterISR( POmniTekHostController context, HCISRCB busISR )
{
    unsigned long flags;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    KernelTraceNA( TRACE_LEVEL_VERBOSE, HC_OmniTek, "Request to add isr\n");
    spin_lock_irqsave( &(did->IrqLock), flags );
    did->BusISR = busISR;
    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}

void OT_HC_OmniTek_BusDeRegisterISR( POmniTekHostController context )
{
    unsigned long flags;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    KernelTraceNA( TRACE_LEVEL_VERBOSE, HC_OmniTek, "Request to remove isr\n");
    spin_lock_irqsave( &(did->IrqLock), flags );
    did->BusISR = NULL;
    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}


#define ReadChannelCSR( did, index ) ReadHWValue( did, did->DmaCap->Bar, did->DmaCap->Offset + ( ( ( index * 0x40 ) + 0x40 + 0x20 ) / 4 ) )
#define WriteChannelCSR( did, index, value ) WriteHWValue( did, did->DmaCap->Bar, did->DmaCap->Offset + ( ( ( index * 0x40 ) + 0x40 + 0x20 ) / 4 ), value )


#define OMNITEK_DMACHANNEL_INTERRUPT_MASK 0x60
irqreturn_t OT_HC_OmniTek_ISR( int irq, void * dev_id )
{
    DriverInstanceData *did = (DriverInstanceData *)dev_id;
    unsigned long flags;
    irqreturn_t irq_return = IRQ_NONE;

    uint32_t i;
    uint32_t j;
    uint32_t status = 0;
    bool ret = FALSE;

    spin_lock_irqsave( &(did->IrqLock), flags );

    if( did->BusISR != NULL && did->Interrupts != NULL )
    {
        for ( i = 0; i < did->NumInterrupts; i++)
        {
            for ( j = 0; j < did->Interrupts[i]->StatusRegisters.Count; j++ )
            {
                status = ReadHWValue( did->Interrupts[i]->StatusRegisters.VA, j );
                if ( status != 0 )
                {
                    ret |= did->BusISR( &did->hc, &did->hci, did->Interrupts[i], j );
                }
            }
        }
    }

    if ( ret )
        irq_return = IRQ_HANDLED;

    spin_unlock_irqrestore( &( did->IrqLock ), flags );

    return irq_return;
}

long OT_HC_OmniTek_unlocked_ioctl( struct file *flip, unsigned int cmd, unsigned long arg )
{
	long retval = -ENOTTY;
	DriverInstanceData *pDid = NULL;

	pDid = container_of( flip->f_path.dentry->d_inode->i_cdev, DriverInstanceData, CDev );
	if( pDid )
	{
		switch( cmd )
		{
			case HC_IOCTL_GetPlatformInfo:
				{
					HC_GetPlatformInfo_IOCTL *ioctlReturn = (HC_GetPlatformInfo_IOCTL*)arg;
					if( omnitek_access_ok(VERIFY_WRITE, arg, sizeof(HC_GetPlatformInfo_IOCTL) ) )
					{
						uint32_t versionIn = HC_IOCTL_GetPlatformInfo_Version;
						get_user( versionIn, &(ioctlReturn->Version));
						switch( versionIn )
						{
							case 0:
								{
									put_user(HC_IOCTL_GetPlatformInfo_Version, &(ioctlReturn->Version));
									put_user(HC_PlatformInfoPCIe, &(ioctlReturn->type));
									retval = 0;
								}
								break;
							default:
								{
			                        put_user( HC_IOCTL_GetPlatformInfo_Version, &( ioctlReturn->Version ) );
			                        retval = -ENOTTY;
			                        KernelTrace( TRACE_LEVEL_WARNING, HC_OmniTek, "IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
								}
								break;
						}
					}
				}
				break;
			case HC_IOCTL_GetNumRegions:
				{
					uint32_t versionIn;
					HC_GetNumRegions_IOCTL *ioctlReturn = (HC_GetNumRegions_IOCTL*)arg;
					if( omnitek_access_ok(VERIFY_WRITE, arg, sizeof(HC_GetNumRegions_IOCTL)) )
					{
						get_user( versionIn, &(ioctlReturn->Version) );
						switch( versionIn )
						{
							case 0:
								{
									put_user( HC_IOCTL_GetNumRegions_Version, &(ioctlReturn->Version) );
									put_user( pDid->nBars, &(ioctlReturn->NumRegions) );
									retval = 0;
								}
								break;
							default:
								{
			                        put_user( HC_IOCTL_GetNumRegions_Version, &( ioctlReturn->Version ) );
			                        retval = -ENOTTY;
			                        KernelTrace( TRACE_LEVEL_WARNING, HC_OmniTek, "IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
								}
								break;
						}
					}
				}
				break;
			case HC_IOCTL_GetRegion:
				{
					uint32_t versionIn;
					HC_GetRegion_IOCTL *ioctlReturn = (HC_GetRegion_IOCTL*)arg;
					if( omnitek_access_ok(VERIFY_WRITE, arg, sizeof(HC_GetRegion_IOCTL)) )
					{
						get_user( versionIn, &(ioctlReturn->Version) );

						// Set the version number for the return
						put_user(HC_IOCTL_GetRegion_Version, &(ioctlReturn->Version));
						switch(versionIn)
						{
							case 0:
								{
									uint32_t regionIdx;
									get_user( regionIdx, &(ioctlReturn->Idx) );
									if( regionIdx < pDid->nBars )
									{
										uint32_t bufferSize;
										uint32_t offset;
										get_user( bufferSize, &(ioctlReturn->Size));
										get_user( offset, &(ioctlReturn->Offset));

										// Check that the return buffer is big enough
										if( (pDid->MemBar[regionIdx].Size==0) || (bufferSize==0) || ((bufferSize + offset) > pDid->MemBar[regionIdx].Size) )
										{
											put_user( pDid->MemBar[regionIdx].Size, &(ioctlReturn->Size));
											retval = -ENOMEM;
											KernelTrace( TRACE_LEVEL_WARNING, HC_OmniTek, "HC_IOCTL_GetRegion. Buffer to small %x, offset %x, required %x\n", bufferSize, offset, pDid->MemBar[regionIdx].Size);
										}
										else // Copy the buffer
										{
											void* returnPtr;
											get_user(returnPtr, &(ioctlReturn->Buffer.pVa));
											if( omnitek_access_ok(VERIFY_WRITE, returnPtr, bufferSize) )
											{
												uint32_t bytesFailed = 0;
												if( (bytesFailed=copy_to_user(returnPtr, (((void*)pDid->MemBar[regionIdx].pVa) + offset), bufferSize)) == 0 )
												{
													put_user(bufferSize, &(ioctlReturn->Size));
													retval = 0;
												}
												else
												{
													put_user(0, &(ioctlReturn->Size));
													retval = -ENOMEM;
													KernelTrace( TRACE_LEVEL_ERROR, HC_OmniTek, "HC_IOCTL_GetRegion. failed to copy Region. 0x%x\n", bytesFailed);
												}
											}
											else
											{
												put_user( pDid->MemBar[regionIdx].Size, &(ioctlReturn->Size));
												retval = -ENOMEM;
												KernelTraceNA( TRACE_LEVEL_ERROR, HC_OmniTek, "HC_IOCTL_GetRegion. access_ok failed on return buffer\n");
											}
										}
									}
									else
									{
										retval = -EINVAL;
										KernelTrace( TRACE_LEVEL_WARNING, HC_OmniTek, "HC_IOCTL_GetRegion. Invalid Region Idx %d [Max %d]\n", regionIdx, pDid->nBars);
									}
								}
								break;
							default:
								{
			                        retval = -ENOTTY;
			                        KernelTrace( TRACE_LEVEL_WARNING, HC_OmniTek, "IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
								}
								break;
						}
					}
				}
				break;
			case HC_IOCTL_ReadPciConfig:
				{
					uint32_t versionIn;
					HC_ReadPciConfig *ioctlReturn = (HC_ReadPciConfig*)arg;
					if( omnitek_access_ok(VERIFY_WRITE, arg, sizeof(HC_ReadPciConfig)) )
					{
						get_user( versionIn, &(ioctlReturn->Version) );

						// Set the version number for the return
						put_user(HC_IOCTL_ReadPciConfig_Version, &(ioctlReturn->Version));
						switch(versionIn)
						{
							default:
								{
									retval = -ENOTTY;
									KernelTrace( TRACE_LEVEL_WARNING, HC_OmniTek, "IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
								}
								break;
							case 0:
								{
									void *pPtr = NULL;
									uint32_t readSize;
									uint32_t offset;
									get_user( pPtr, &(ioctlReturn->buffer.pVa));
									get_user( readSize, &(ioctlReturn->Size));
									get_user( offset, &(ioctlReturn->Offset));

									// Check that we can access the users buffer
									if( readSize && omnitek_access_ok(VERIFY_WRITE, pPtr, readSize) )
									{
										uint32_t bytesRead = ReadPciConfig(pDid, offset, pPtr, readSize);
										put_user(bytesRead, &(ioctlReturn->Size));
										retval = 0;
									}
									else
									{
										retval = -ENOMEM;
										KernelTraceNA( TRACE_LEVEL_ERROR, HC_OmniTek, "HC_IOCTL_ReadPciConfig. Unable to access return buffer\n" );
									}
								}
								break;
						}
					}
				}
				break;
		}
	}
	return retval;
}

static struct file_operations OT_HC_OmniTek_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = OT_HC_OmniTek_unlocked_ioctl,
};


void OT_HC_OmniTek_EnableInterrupts( POmniTekHostController context )
{
    int status;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );

    status = pci_enable_msi(did->pdev);
    if( status )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "pci_enable_msi %d!\n",status);
    }

    status = request_threaded_irq( did->pdev->irq, &OT_HC_OmniTek_ISR, NULL, IRQF_SHARED, "OmniTek Device", did );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_ERROR, HC_OmniTek, "Couldn't request IRQ line - error %d!\n",status);
    }
}

void OT_HC_OmniTek_DisableInterrupts( POmniTekHostController context )
{
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );

    free_irq( did->pdev->irq, did );

    pci_disable_msi( did->pdev );
}

extern struct device_attribute dev_attr_debuglevel;

int OT_HC_OmniTek_probe( struct pci_dev * pdev, const struct pci_device_id * id )
{
    int status = 0;
    DriverInstanceData *did = NULL;
    uint32_t i;
    uint32_t BarIndex = 0;
    char nameBuf[MAX_FILEPATH_LEN];

    status = pci_enable_device( pdev );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_ERROR, HC_OmniTek, "pci_enable device failed with status: %x\n", status );
        goto probe_err;
    }

    did = kzalloc( sizeof( DriverInstanceData ), GFP_KERNEL );
    if( did == NULL )
    {
        status = -ENOMEM;
        goto probe_err_pci_enable_device;
    }

    status = device_create_file( &pdev->dev, &dev_attr_debuglevel );
    if( status )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_OmniTek, "can't create sysfs debuglevel file!!!\n" );
        goto probe_err_kzalloc;
    }

    MANUF_FUNC( _GetInterfaceHCInterface )( &did->hc, &did->BusInterface );

    did->BusInterface.INIT_OmniTekHostControllerInterface( &did->hci );
    did->hci.NotifyBusExit = OT_HC_OmniTek_BusExit;
    did->hci.RegisterISR = OT_HC_OmniTek_BusRegisterISR;
    did->hci.DeRegisterISR = OT_HC_OmniTek_BusDeRegisterISR;
    did->hci.EnableInterrupts = OT_HC_OmniTek_EnableInterrupts;
    did->hci.DisableInterrupts = OT_HC_OmniTek_DisableInterrupts;

    snprintf( did->hc.InstanceName, MAX_NAME_LEN, "%s", pci_name( pdev ) );
    snprintf( did->hc.TypeName, MAX_NAME_LEN, MANUF_DEV("_HC_OmniTek") );
    did->hc.Uuid = UUID_USERINTERFACE_HC_OMNITEK;
    did->hc.Device = &pdev->dev;
    did->pdev = pdev; // incase we need to go from a host controller back to a pdev...

    // as BusRegisterISR is called on register and the IrqLock is taken we need to init is now...
    spin_lock_init(&(did->IrqLock));
    status = did->BusInterface.RegisterHostController( &did->hc, &did->hci );
    if ( status != SUCCESS )
        goto probe_err_device_create_file;

    // start char dev code
    snprintf( nameBuf, MAX_FILEPATH_LEN, MANUF_DEV("_HC_OmniTek_%02d"), did->hc.SlotId );
    status = alloc_chrdev_region( &( did->Major ), 0, 1, nameBuf );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_OmniTek, "Error %d alloc_chrdev_region\n", status );
        goto probe_err_RegisterHostController;
    }

    did->Minor = MKDEV( MAJOR( did->Major ), MINOR( did->Major ) );
    cdev_init( &( did->CDev ), &OT_HC_OmniTek_fops );
    did->CDev.owner = THIS_MODULE;
    status = cdev_add( &( did->CDev ), did->Minor, 1 );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_OmniTek, "Error %d cdev_add\n", status );
        goto probe_err_alloc_chrdev_region;
    }

    if ( NULL == device_create( MANUF_FUNC(_GetClass)(), &pdev->dev, did->Minor, NULL, nameBuf ) )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_OmniTek, "Failed to create host controller dev entry\n" );
        status = -1;
        goto probe_err_cdev_add;
    }
    else
    {
        snprintf( did->hc.DeviceAccessName, MAX_FILEPATH_LEN, "/dev/%s", nameBuf );
    }
    // end char dev code

    pci_set_drvdata( pdev, did );
    status = pci_request_regions( pdev, "OT HC OmniTek" );
    if( status != 0 )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_OmniTek, "Request PCI BAR Regions Failed, error: %x\n", status );
        goto probe_err_device_create;
    }
    else
    {
        pci_set_master( pdev );
        status = dma_set_mask( &pdev->dev, DMA_BIT_MASK( 64 ) );
        if( status )
        {
            KernelTraceNA( TRACE_LEVEL_WARNING, HC_OmniTek, "Couldn't set 64 bit DMA mask, attempting 32\n" );
			status = dma_set_mask( &pdev->dev, DMA_BIT_MASK( 32 ) );
        }

        if( status )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_OmniTek, "Couldn't set DMA mask\n" );
            goto probe_err_pci_request_regions;
        }

        for( i = 0; i < PCI_NUM_BARS && BarIndex < MAX_NUM_MEM_BARS; i++ )
        {
            ot_phys_addr_t start = 0;
            ot_phys_addr_t end = 0;
            unsigned long flags = 0;
            unsigned long len = 0;
            int status = -EBUSY;
            uint32_t * bar_addr = 0;

            start = pci_resource_start(pdev,i);
            end = pci_resource_end(pdev,i);
            flags = pci_resource_flags(pdev,i);
            len = pci_resource_len(pdev,i);

            KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "Bar %d, start: 0x%"OTPSxphys" - end: 0x%"OTPSxphys", size: 0x%"OTPSxphys", flags: 0x%lX\n", i, start, end, end - start, flags );
            if( flags & IORESOURCE_IO )
                KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "Bar %d is IO Mapped\n", i );
            if( flags & IORESOURCE_MEM )
                KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "Bar %d is MEM Mapped\n", i );
            if( flags & IORESOURCE_PREFETCH )
                KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "Bar %d is Prefetchable\n", i );
            if( flags & IORESOURCE_READONLY )
                KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "Bar %d is Read Only!\n", i );

            /* If the BAR is zero length then we can ignore */
            if( len != 0 )
            {
                bar_addr = ioremap( start, len );
                KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "Remapped BAR %d to %p\n", i, bar_addr );

                if( !bar_addr )
                {
                    KernelTrace( TRACE_LEVEL_CRITICAL, HC_OmniTek, "Request PCI BAR %d failed, got zero address - status: %d\n", i, status );
                }
                else
                {
                    did->MemBar[ BarIndex ].Physical = start;
                    did->MemBar[ BarIndex ].Size = len;
                    did->MemBar[ BarIndex ].pVa = bar_addr;

                    BarIndex++ ;
                }
            }
            
            if( IORESOURCE_MEM_64 & flags )
            {
                KernelTraceNA( TRACE_LEVEL_VERBOSE, HC_OmniTek, "PCI BAR is 64 bit, so skipping next BAR\n" );
                i++ ;
            }
        }

        did->nInterruptStatus = 0;
    }
    KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "%d PCI BARs allocated\n", BarIndex );
    did->nBars = BarIndex;

    status = OT_HC_OmniTek_Enumerate( did );
    if ( status != SUCCESS )
        goto probe_err_ioremap;

    return 0;

//probe_err_Enumerate:
//    if ( did->Interrupts != NULL )
//    {
//        did->Interrupts = NULL;
//        DeleteMemory( &did->InterruptsMem );
//    }
probe_err_ioremap:
    for( i = 0; i < did->nBars; i++ )
    {
        iounmap( did->MemBar[ i ].pVa );
    }
probe_err_pci_request_regions:
    pci_release_regions( pdev );
probe_err_device_create:
    device_destroy( MANUF_FUNC(_GetClass)(), did->Minor );
probe_err_cdev_add:
    cdev_del( &( did->CDev ) );
probe_err_alloc_chrdev_region:
    unregister_chrdev_region( did->Major, 1 );
probe_err_RegisterHostController:
    did->BusInterface.DeRegisterHostController( &did->hc );
probe_err_device_create_file:
    device_remove_file( &pdev->dev, &dev_attr_debuglevel );
probe_err_kzalloc:
    kfree( did );
    pci_set_drvdata( pdev, NULL );
probe_err_pci_enable_device:
    pci_disable_device( pdev );
probe_err:
    return status;
}

void OT_HC_OmniTek_remove( struct pci_dev * pdev )
{
    DriverInstanceData *did = NULL;
    uint32_t i = 0;

    did = pci_get_drvdata( pdev );
    if ( did != NULL )
    {
        did->BusInterface.DeRegisterHostController( &did->hc );

        if ( did->Interrupts != NULL )
        {
            did->Interrupts = NULL;
            DeleteMemory( &did->InterruptsMem );
        }
        for( i = 0; i < did->nBars; i++ )
        {
            iounmap( did->MemBar[ i ].pVa );
        }
        pci_release_regions( pdev );
        device_destroy( MANUF_FUNC(_GetClass)(), did->Minor );
        cdev_del( &( did->CDev ) );
        unregister_chrdev_region( did->Major, 1 );
        device_remove_file( &pdev->dev, &dev_attr_debuglevel );
        kfree( did );
        pci_set_drvdata( pdev, NULL );
        pci_disable_device( pdev );
    }
}

static struct pci_device_id ids[ ] =
{
        { PCI_DEVICE(0x1AA3, 0x0010), },
        { PCI_DEVICE(0x1AA3, 0x0011), },
        { PCI_DEVICE(0x1AA3, 0x0020), },
    { 0, }
};

struct pci_driver OT_HC_OmniTek_driver = {
    .name = MANUF_DEV("_HC_OmniTek"),
    .id_table = ids,
    .probe = OT_HC_OmniTek_probe,
    .remove = OT_HC_OmniTek_remove,
};

int OT_HC_OmniTek_init( void )
{
    return pci_register_driver( &OT_HC_OmniTek_driver );
}

void OT_HC_OmniTek_cleanup( void )
{
    pci_unregister_driver( &OT_HC_OmniTek_driver );
}

module_init( OT_HC_OmniTek_init );
module_exit( OT_HC_OmniTek_cleanup );
