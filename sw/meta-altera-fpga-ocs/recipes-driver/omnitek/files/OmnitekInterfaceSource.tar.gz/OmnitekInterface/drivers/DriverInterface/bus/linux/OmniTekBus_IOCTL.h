/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef OMNITEKBUS_IOCTL_H_
#error "Do not include this directly."
#endif

#include <linux/ioctl.h>

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/**
 * @brief Current #OTBUS_IOCTL_GetNumSlots OTBus_Slots::Version number to use
 */
#define OTBUS_IOCTL_GetNumSlots_Version 0

/**
 * @brief Current #OTBUS_IOCTL_GetSlot OTBus_SlotInfo::Version version number to use
 */
#define OTBUS_IOCTL_GetSlot_Version 0

/**
 * @brief IOCTL on OmniTekBus for obtaining the number of slots / HostControllers
 * Passed and received data type is OTBus_Slots
 */
#define OTBUS_IOCTL_GetNumSlots   _IOWR( OTBUS_IOC_MAGIC, OTBUS_IOCTL_NUM_GetNumSlots, OTBus_Slots * )

/**
 * @brief IOCTL on OmniTekBus for obtaining information about capabilities on a slot / HostController
 * Passed and received data type is OTBus_SlotInfo
 */
#define OTBUS_IOCTL_GetSlot       _IOWR( OTBUS_IOC_MAGIC, OTBUS_IOCTL_NUM_GetSlot, OTBus_SlotInfo * )

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/
