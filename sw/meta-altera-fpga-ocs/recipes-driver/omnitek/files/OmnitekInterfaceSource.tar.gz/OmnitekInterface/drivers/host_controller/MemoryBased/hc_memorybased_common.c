/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "hccommon.h"
#include "hc_memorybased_common.h"
#include "DMACommon.h"

#ifdef USE_WPP
#include "trace.h"
#include "AUTOGEN.hc_memorybased_common.tmh"
#endif

void OT_HC_MemoryBased_Enumerate( DriverInstanceData * did )
{
    OmniTekCollection * capList = NULL;
//    Capability *cap = NULL;
//    uint32_t i;
    int status;
//    uint32_t interruptNum = 0;

//    did->NumInterrupts = 0;

    capList = did->BusInterface.DiscoverCapabilities( &did->hc, did->mem, did->memSize, 0 );

    if( capList == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, HC_MemoryBased, "DiscoverCapabilities: NULL\n" );
    }
    else
    {
        did->BusInterface.PrintCapabilities( capList );

//        for ( i = 0; i < CollectionCount( capList ); i++ )
//        {
//            cap = did->BusInterface.GetCapabilityAt( capList, i );
//            if ( cap->Type == InterruptCap )
//                did->NumInterrupts++;
//        }
//
//        if ( did->NumInterrupts > 0 )
//        {
//            did->Interrupts = AllocateMemory( sizeof(PCapInterrupt) * did->NumInterrupts, &did->InterruptsMem );
//            if ( did->Interrupts == NULL )
//            {
//                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Could not allocate memory for interrupts...\n" );
//                did->NumInterrupts = 0;
//            }
//        }
//
//        for ( i = 0; i < CollectionCount( capList ); i++ )
//        {
//            cap = did->BusInterface.GetCapabilityAt( capList, i );
//if ( cap->Type == InterruptCap && did->Interrupts != NULL )
//            {
//                did->Interrupts[ interruptNum++ ] = &cap->Ext.Interrupt;
//            }
//        }
    }
    status = did->BusInterface.FinaliseCapabilities( &did->hc );
    KernelTrace( TRACE_LEVEL_VERBOSE, HC_MemoryBased, "FinaliseCapabilities: %d\n", status );
}


void OT_HC_MemoryBased_FillInTest( uint32_t *mem )
{
    uint32_t offset = 0;

    // start dummy capabilities
    
    // MDMA
    wRegCap( mem, offset, RegCap_DMA_DataBiMDMA, 3, 0, 0, 0, NumDMARegisters ); // NOTE: version 3 is minimum for driver
    offset += RegSize( NumDMARegisters );

    // OmniFB
    wRegCap2( mem, offset, 0x32d, 1, 0, 0, 0, 0x506, 0, 1 ); // NOTE: using version 2
    // Enabling OmniFB features
    // Bit 16 : Colourspace converter
    // Bit 20 : Resizer
    // Bit 21 : Cursor
    // Bit 23 : Chroma key
    mem[offset + RegSize2(1)] |= ((0x1 << 16) | (0x1 << 20) | (0x1 << 21) | (0x1 << 23));
    offset += RegSize2( 0x506 );

    // RegisterAccess
    wRegCap2( mem, offset, 0xabc, 0, 0, 0, 0, 75, 0, 1 );
    offset += RegSize2( 75 );

    // VideoFDMA
    wRegCap( mem, offset, RegCap_DMA_DataOutFDMA, 3, 0, 0, 0, NumDMARegisters ); // NOTE: version 3 is minimum for driver
    offset += RegSize( NumDMARegisters );
}
