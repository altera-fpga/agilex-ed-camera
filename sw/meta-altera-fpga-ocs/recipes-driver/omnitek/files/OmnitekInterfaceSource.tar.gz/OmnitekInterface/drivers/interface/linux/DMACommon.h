/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef DMACOMMON_H_
#error "Do not include this file directly"
#endif

#include <linux/scatterlist.h>
#include <linux/types.h>
#include "../CapabilityDriverBusInterface.h"
#include "capability/Common_IOCTL.h"
#include "capability/IOCTL_DMACommon.h"
#include "linux/UserBuffer.h"

#ifdef OT_GPUDIRECT
#include "GPUDirect.h"
#endif

/**
 * @brief Wrapper for accessing the bottom 32 bits of a 64bit number and to make it the same as windows
 */
#define LowPart( x ) ( (u64)(x) & 0xffffffff )

/**
 * @brief Wrapper for accessing the top 32 bits of a 64bit number and to make it the same as windows
 */
#define HighPart( x ) ( (u64)(x) >> 32 )

/**
 * @brief Wrapper for accessing the full 64bit number and to make it the same as windows
 */
#define QuadPart( x ) x

#define STATUS_BAD_DMA_CHANNEL             0xA1000028

#define DMAWriteReg( channel, reg, val ) (channel)->Platform.BusInterface->WriteRegisterCap( (channel)->Platform.BusInterface->Device, (channel)->Platform.RegMap[reg].Block, (channel)->Platform.RegMap[reg].Reg, val  )
#define DMAReadReg( channel, reg, val ) (channel)->Platform.BusInterface->ReadRegisterCap( (channel)->Platform.BusInterface->Device, (channel)->Platform.RegMap[reg].Block, (channel)->Platform.RegMap[reg].Reg, val  )

/**
 * @brief Flags for use with flags argument of DMAPreForwardEnhanced()
 */
#define DMA_FLAGS_NONE        0x00000000
#define DMA_FLAGS_GPUDIRECT   0x00000001

typedef struct _DMASGLBuffer
{
    void *pVa; //!< user pointer to PhysAddr
    dma_addr_t PhysAddr; //!< an aligned physical address for the buffer
    uint32_t Size;
    uint32_t NumElements;
    struct sg_table SGTable; //!< not used for GPUDirect transfers
} DMASGLBuffer;

typedef struct _DMAChannelPlatform
{
    PCapabilityDeviceInterface BusInterface;
    RegMapping RegMap[NumDMARegisters];

    Allocateable SGLBuffersMemory;
} DMAChannelPlatform;


typedef struct _DMAChannel
{
    DMAChannelPlatform Platform; //!< Platform specific data

    uint8_t Has64BitLADR; //!< does this channel support 64bit LADR
    uint8_t Has64BitPADR; //!< does this channel support 64bit PADR
    uint8_t HasSGCount; //!< If v5+ we have sgcount field

    bool IsRunning;

    uint32_t MaxSingleHWTransfer; //!< this is a misnomer, really is min transfer if all page entries are 4k only...
    uint32_t MaxTargets;
    uint32_t MaxQueueLength;
    uint32_t MinQueueDepth;
    uint32_t MaxFragmentSize;
    uint32_t MaxSGLElements;

    uint64_t PreviousISRTime;


    DMASGLBuffer *SGLBuffers;
} DMAChannel;


typedef struct _DMA64BitSGLEntry
{
    union
    {
        struct
        {
            uint32_t PADR_LOW;
            uint32_t PADR_HIGH;
            uint32_t LADR_LOW;
            uint32_t LADR_HIGH;
            uint32_t DPR_LOW;
            uint32_t DPR_HIGH;
            uint32_t SIZE_LOW;
            uint32_t SIZE_HIGH;
        };
        struct
        {
            uint64_t PADR;
            uint64_t LADR;
            uint64_t DPR;
            uint64_t SIZE;
        };
    };
} DMA64BitSGLEntry;
typedef DMA64BitSGLEntry* PDMA64BitSGLEntry;


struct _CapDevFDOData;

typedef struct _DMATx
{
    uint32_t Flags;

    union
    {
        struct
        {
            CommonTransferContext MDL; //!< CPU memory descriptor list, for use when (Flags & DMA_FLAGS_GPUDIRECT) is false
            int NumSGMapped; //!< the amount of entries we asked to be mapped
            int NumActualSGMapped; //!< the amount of entries to actually look at...
        };

#ifdef OT_GPUDIRECT
        struct GpuDirectPages GpuPages; //!< GPU memory descriptor list, for use when (Flags & DMA_FLAGS_GPUDIRECT) is true
#endif
    };

    uint32_t LocalAddr; //!< Local address relative to the fpga
    uint32_t Size; //!< Size of the transfer
    uint32_t NextPageIndex;
    bool WriteDirection;

    bool Completed;

    DMASGLBuffer *SGLBuffer;
    uint32_t TargetId;
    uint8_t bNoSync; //!< Should we play with the sync controls. Introduced in V1 for FDMAs
} DMATx, *PDMATx;

typedef struct
{
    struct _CapDevFDOData * ChannelFDO;

    DMATx *Txs;
    uint32_t NumTxs;
    struct list_head Next; /*!< Request Queue object */

    uint64_t EventId;
    CommonTransferContext *ioctlContext;
    uint64_t StartTime;
    uint64_t EndTime;
    bool Deleted;
    bool Active;
    struct file * FilePointer;
} GroupedDMATx;


void DMAAbortChannel( DMAChannel * channel );
void DMAJoinSgl( DMASGLBuffer *previous, DMASGLBuffer *next, bool shouldInterrupt, bool adjustSync );
void DMATransactionStart( DMAChannel * channel, uint32_t nElements, bool Write, uint64_t StartAddress );
int DMAPreForward( GroupedDMATx **ppTransaction, DMATransaction_IOCTL *inDmaTransfer );
int DMAPreForwardEnhanced( GroupedDMATx **ppTransaction, DMATransaction_IOCTL *inDmaTransfer, uint32_t flags );
void DMAGroupedDMATxCleanup( GroupedDMATx * pTransaction, struct device * hcd );


/** @}*/
