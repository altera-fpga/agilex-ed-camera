/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/eventfd.h>
#include <linux/fb.h>
#include <linux/dma-mapping.h>
#include <linux/spinlock.h>
#include <linux/wait.h>

#include "Common.h"
#include "CapabilityDriverBusInterface.h"
#include "CapabilityDevice.h"

#include "capability/RegisterAccess_IOCTL.h"
#include "capability/Common_IOCTL.h"
#include "CapabilityBaseIOCTL.h"
#include "OTCapabilityTypes.h"

#include "capability/OmniFB_IOCTL.h"

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif

#define NoForcedId 0xffffffff
static ulong forced_component_id = NoForcedId;
module_param(forced_component_id, ulong, S_IRUGO);
MODULE_PARM_DESC( forced_component_id, "Specific component / unique id to bind framebuffer to." );

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_WARNING;
extern struct device_attribute dev_attr_debuglevel;

enum
{
    Register_Global_Control = 0x0,
    Register_Global_Info0,
    Register_Global_Info1,
    Register_InterruptControl,
    Register_Status,
    Register_Global_Info2, // Added in version 2
    Register_Version_Info, // Added in version 2

    Register_DMA_Control = 0x100,
    Register_DMA_Screen0,
    Register_DMA_Screen1,
    Register_DMA_XControl,
    Register_DMA_YControl,
    Register_DMA_CacheControl,

    Register_ChromaKey_Control, // Added v2.01

    Register_CSC_First = 0x200,
    Register_CSC_Last = 0x20F,

    // FIXME: find out how to program the palette
    Register_Palette_ = 0x300,

    Register_VTiming_UpdateTimingGen = 0x400,
    Register_VTiming_DataFifoStartAddress,
    Register_VTiming_DataFifo,
    Register_VTiming_OutputPolarity,
    Register_VTiming_IRQStatus,
    Register_VTiming_IRQEnable,
    Register_VTiming_Features,
    Register_VTiming_Genlock_TotalPixels = 0x408,
    Register_VTiming_Genlock_Offsets,
    Register_VTiming_Genlock_Control,

    Register_Cursor_GlobalControl = 0x500,
    Register_Cursor_ScreenSize,
    Register_Cursor_XYControl,
    Register_Cursor_BitMapRAM,
    Register_Cursor_PaletteAddress,
    Register_Cursor_PaletteData,
    Register_Cursor_HotSpot
};

enum
{
    V1_Global_Info0_ColourPlaneDepth_Shift = ( 0 ), // deprecated in version 2
    V1_Global_Info0_ColourPlaneDepth_Mask = ( 0xf << V1_Global_Info0_ColourPlaneDepth_Shift ), // deprecated in version 2
    V1_Global_Info0_ColourPlanes_Shift = ( 4 ), // deprecated in version 2
    V1_Global_Info0_ColourPlanes_Mask = ( 0xf << V1_Global_Info0_ColourPlanes_Shift ), // deprecated in version 2
    Global_Info0_InternalDataPathPlaneDepth_Shift = ( 8 ), // Added in version 2
    Global_Info0_InternalDataPathPlaneDepth_Mask = ( 0xf << Global_Info0_InternalDataPathPlaneDepth_Shift ), // Added in version 2
    Global_Info0_InternalDataPathPlanes_Shift = ( 12 ), // Added in version 2
    Global_Info0_InternalDataPathPlanes_Mask = ( 0xf << Global_Info0_InternalDataPathPlanes_Shift ), // Added in version 2
    Global_Info0_CSC_Exists_Shift = ( 16 ),
    Global_Info0_CSC_Exists_Mask = ( 0x1 << Global_Info0_CSC_Exists_Shift ),
    Global_Info0_LUT_Exists_Shift = ( 17 ),
    Global_Info0_LUT_Exists_Mask = ( 0x1 << Global_Info0_LUT_Exists_Shift ),
    Global_Info0_VTiming_Exists_Shift = ( 18 ),
    Global_Info0_VTiming_Exists_Mask = ( 0x1 << Global_Info0_VTiming_Exists_Shift ),
    Global_Info0_VTiming_GenLock_Shift = ( 19 ),
    Global_Info0_VTiming_GenLock_Mask = ( 0x1 << Global_Info0_VTiming_GenLock_Shift ),
    Global_Info0_Resizer_Exists_Shift = ( 20 ),
    Global_Info0_Resizer_Exists_Mask = ( 0x1 << Global_Info0_Resizer_Exists_Shift ),
    Global_Info0_Cursor_Exists_Shift = ( 21 ),
    Global_Info0_Cursor_Exists_Mask = ( 0x1 << Global_Info0_Cursor_Exists_Shift ),

    // Since Version 2 Capability
    Global_Info0_ChromaKey_Exists_Shift = ( 23 ),
    Global_Info0_ChromaKey_Exists_Mask = ( 0x1 << Global_Info0_ChromaKey_Exists_Shift ),

    Global_Info1_AXISStreamID_Shift = ( 0 ),
    Global_Info1_AXISStreamID_Mask = ( 0xff << Global_Info1_AXISStreamID_Shift ),
    Global_Info1_AXISStreamPixelsPerClock_Shift = ( 8 ),
    Global_Info1_AXISStreamPixelsPerClock_Mask = ( 0xf << Global_Info1_AXISStreamPixelsPerClock_Shift ),
    Global_Info1_AXISStreamPixelDepthPerColourStream_Shift = ( 12 ),
    Global_Info1_AXISStreamPixelDepthPerColourStream_Mask = ( 0xf << Global_Info1_AXISStreamPixelDepthPerColourStream_Shift ),
    Global_Info1_AXISStreams_Shift = ( 16 ),
    Global_Info1_AXISStreams_Mask = ( 0xf << Global_Info1_AXISStreams_Shift ),

    Global_Control_Reset_Shift = ( 0 ),
    Global_Control_Reset_Mask = ( 0x1 << Global_Control_Reset_Shift ),
    Global_Control_DiscardAlpha_Shift = ( 1 ),
    Global_Control_DiscardAlpha_Mask = ( 0x1 << Global_Control_DiscardAlpha_Shift ),
    Global_Control_2K4KResizerEnable_Shift = ( 2 ),
    Global_Control_2K4KResizerEnable_Mask = ( 0x1 << Global_Control_2K4KResizerEnable_Shift ),
    Global_Control_ColourPlane0Select_Shift = ( 8 ),
    Global_Control_ColourPlane0Select_Mask = ( 0x3 << Global_Control_ColourPlane0Select_Shift ),
    Global_Control_ColourPlane1Select_Shift = ( 10 ),
    Global_Control_ColourPlane1Select_Mask = ( 0x3 << Global_Control_ColourPlane1Select_Shift ),
    Global_Control_ColourPlane2Select_Shift = ( 12 ),
    Global_Control_ColourPlane2Select_Mask = ( 0x3 << Global_Control_ColourPlane2Select_Shift ),
    Global_Control_ColourPlane3Select_Shift = ( 14 ),
    Global_Control_ColourPlane3Select_Mask = ( 0x3 << Global_Control_ColourPlane3Select_Shift ),

    // Applies to both Interrupt Control and Interrupt Status registers
    Interrupt_FrameStart_Shift = ( 0 ),
    Interrupt_FrameStart_Mask = ( 1 << Interrupt_FrameStart_Shift ),
    Interrupt_FrameEnd_Shift = ( 1 ),
    Interrupt_FrameEnd_Mask = ( 1 << Interrupt_FrameEnd_Shift ),

    // Since Version 2
    Global_Info2_Plane0BitsPerPixel_Shift = ( 0 ),
    Global_Info2_Plane0BitsPerPixel_Mask = ( 0xf << Global_Info2_Plane0BitsPerPixel_Shift ),
    Global_Info2_Plane1BitsPerPixel_Shift = ( 4 ),
    Global_Info2_Plane1BitsPerPixel_Mask = ( 0xf << Global_Info2_Plane1BitsPerPixel_Shift ),
    Global_Info2_Plane2BitsPerPixel_Shift = ( 8 ),
    Global_Info2_Plane2BitsPerPixel_Mask = ( 0xf << Global_Info2_Plane2BitsPerPixel_Shift ),
    Global_Info2_PlaneAlphaBitsPerPixel_Shift = ( 12 ),
    Global_Info2_PlaneAlphaBitsPerPixel_Mask = ( 0xf << Global_Info2_PlaneAlphaBitsPerPixel_Shift ),

    // Since v2.01
    Version_Info_Version_Shift = ( 0 ),
    Version_Info_Version_Mask = ( 0xff << Version_Info_Version_Shift ),
    Version_Info_MinorVersion_Shift = ( 0 ),
    Version_Info_MinorVersion_Mask = ( 0xf << Version_Info_MinorVersion_Shift ),
    Version_Info_MajorVersion_Shift = ( 4 ),
    Version_Info_MajorVersion_Mask = ( 0xf << Version_Info_MajorVersion_Shift ),

    // Since v2.01
    ChromaKey_Control_Colour_Shift = ( 0 ),
    ChromaKey_Control_Colour_Mask = ( 0x7fffffff << ChromaKey_Control_Colour_Shift ),
    ChromaKey_Control_Enable_Shift = ( 31 ),
    ChromaKey_Control_Enable_Mask = ( 0x1 << ChromaKey_Control_Enable_Shift ),
};

enum
{
    DMA_Control_Reset_Shift = ( 0 ),
    DMA_Control_Reset_Mask = ( 0x1 << DMA_Control_Reset_Shift ),
    DMA_Control_Screen_Select_Shift = ( 1 ),
    DMA_Control_Screen_Select_Mask = ( 0x1 << DMA_Control_Screen_Select_Shift ),
    DMA_Control_Active_Screen_Shift = ( 3 ),
    DMA_Control_Active_Screen_Mask = ( 0x1 << DMA_Control_Active_Screen_Shift ),

    DMA_XControl_XSize_Shift = ( 0 ),
    DMA_XControl_XSize_Mask = ( 0xffff << DMA_XControl_XSize_Shift ),
    DMA_XControl_XStride_Shift = ( 16 ),
    DMA_XControl_XStride_Mask = ( 0xffff << DMA_XControl_XStride_Shift ),

    DMA_YControl_YSize_Shift = ( 0 ),
    DMA_YControl_YSize_Mask = ( 0xffff << DMA_YControl_YSize_Shift ),

    DMA_CacheControl_NoCache = 0x00000000,
    DMA_CacheControl_FullCache = 0x00000333,
};

enum
{
    VTiming_Genlock_TotalPixels_Shift = ( 0 ),
    VTiming_Genlock_TotalPixels_Mask = ( 0xFFFFFF << VTiming_Genlock_TotalPixels_Shift ),

    VTiming_Genlock_Offsets_X_Shift = ( 0 ),
    VTiming_Genlock_Offsets_X_Mask = ( 0xffff << VTiming_Genlock_Offsets_X_Shift ),
    VTiming_Genlock_Offsets_Y_Shift = ( 16 ),
    VTiming_Genlock_Offsets_Y_Mask = ( 0xffff << VTiming_Genlock_Offsets_Y_Shift ),

    VTiming_Genlock_Control_Enable_Shift = ( 0 ),
    VTiming_Genlock_Control_Enable_Mask = ( 0x1 << VTiming_Genlock_Control_Enable_Shift ),
    VTiming_Genlock_Control_OneShot_Shift = ( 1 ),
    VTiming_Genlock_Control_OneShot_Mask = ( 0x1 << VTiming_Genlock_Control_OneShot_Shift ),
    VTiming_Genlock_Control_NoWindow_Shift = ( 2 ),
    VTiming_Genlock_Control_NoWindow_Mask = ( 0x1 << VTiming_Genlock_Control_NoWindow_Shift ),
};

enum
{
    Cursor_GlobalControl_Enable_Shift = ( 0 ),
    Cursor_GlobalControl_Enable_Mask = ( 0x1 << Cursor_GlobalControl_Enable_Shift ),
    Cursor_GlobalControl_SOFMode_Shift = ( 1 ),
    Cursor_GlobalControl_SOFMode_Mask = ( 0x1 << Cursor_GlobalControl_SOFMode_Shift ),
    Cursor_GlobalControl_CursorOnly_Shift = ( 2 ),
    Cursor_GlobalControl_CursorOnly_Mask = ( 0x1 << Cursor_GlobalControl_CursorOnly_Shift ),
    Cursor_GlobalControl_Depth_Shift = ( 4 ),
    Cursor_GlobalControl_Depth_Mask = ( 0xf << Cursor_GlobalControl_Depth_Shift ),
    Cursor_GlobalControl_Streams_Shift = ( 8 ),
    Cursor_GlobalControl_Streams_Mask = ( 0xf << Cursor_GlobalControl_Streams_Shift ),
    Cursor_GlobalControl_PixelsPerClock_Shift = ( 12 ),
    Cursor_GlobalControl_PixelsPerClock_Mask = ( 0xf << Cursor_GlobalControl_PixelsPerClock_Shift ),
    Cursor_GlobalControl_CursorHeight_Shift = ( 16 ),
    Cursor_GlobalControl_CursorHeight_Mask = ( 0xff << Cursor_GlobalControl_CursorHeight_Shift ),
    Cursor_GlobalControl_CursorWidth_Shift = ( 24 ),
    Cursor_GlobalControl_CursorWidth_Mask = ( 0xff << Cursor_GlobalControl_CursorWidth_Shift ),

    Cursor_ScreenSize_Width_Shift = ( 0 ),
    Cursor_ScreenSize_Width_Mask  = ( 0xffff << Cursor_ScreenSize_Width_Shift ),
    Cursor_ScreenSize_Height_Shift = ( 16 ),
    Cursor_ScreenSize_Height_Mask  = ( 0xffff << Cursor_ScreenSize_Height_Shift ),

    Cursor_XYControl_TopLeftX_Shift = ( 0 ),
    Cursor_XYControl_TopLeftX_Mask = ( 0xffff << Cursor_XYControl_TopLeftX_Shift ),
    Cursor_XYControl_TopLeftY_Shift = ( 16 ),
    Cursor_XYControl_TopLeftY_Mask = ( 0xffff << Cursor_XYControl_TopLeftY_Shift ),

    Cursor_BitMapRAM_XAddr_Shift = ( 0 ),
    Cursor_BitMapRAM_XAddr_Mask = ( 0x3f << Cursor_BitMapRAM_XAddr_Shift ),
    Cursor_BitMapRAM_YAddr_Shift = ( 8 ),
    Cursor_BitMapRAM_YAddr_Mask = ( 0x3f << Cursor_BitMapRAM_YAddr_Shift ),
    Cursor_BitMapRAM_Value_Shift = ( 16 ),
    Cursor_BitMapRAM_Value_Mask = ( 0xf << Cursor_BitMapRAM_Value_Shift ),

    Cursor_PaletteAddress_RAMAddr_Shift = ( 0 ),
    Cursor_PaletteAddress_RAMAddr_Mask = ( 0xf << Cursor_PaletteAddress_RAMAddr_Shift ),

    Cursor_PaletteData_Value_Shift = ( 0 ),
    Cursor_PaletteData_Value_Mask = ( 0xffffffff << Cursor_PaletteData_Value_Shift ),

    Cursor_HotSpot_CursorX_Shift = ( 0 ),
    Cursor_HotSpot_CursorX_Mask = ( 0xff << Cursor_HotSpot_CursorX_Shift ),
    Cursor_HotSpot_CursorY_Shift = ( 8 ),
    Cursor_HotSpot_CursorY_Mask = ( 0xff << Cursor_HotSpot_CursorY_Shift ),
};

#define ExtractValue( x, val ) ( ( ( val ) & x##_Mask ) >> x##_Shift )
#define SetValue( x, val ) ( ( ( val ) << x##_Shift ) & x##_Mask )
#define RMWValue( x, regVal, val ) ({  regVal &= ~x##_Mask; regVal |= SetValue( x, val ); })

#define Cursor_XYControl_Pack( x, y ) ( SetValue( Cursor_XYControl_TopLeftX, x ) | SetValue( Cursor_XYControl_TopLeftY, y )  )
#define Cursor_ScreenSize_Pack( w, h ) ( SetValue( Cursor_ScreenSize_Width, w ) | SetValue( Cursor_ScreenSize_Height, h )  )
#define Cursor_BitMapRAM_Pack( x, y, v ) ( SetValue( Cursor_BitMapRAM_XAddr, x ) | SetValue( Cursor_BitMapRAM_YAddr, y ) | SetValue( Cursor_BitMapRAM_Value, v  ) )
#define Cursor_PaletteData_Pack( a, r, g, b ) ( ( ( ( a ) && 0xff ) << 24 ) | ( ( ( r ) && 0xff ) << 16 ) | ( ( ( g ) && 0xff ) << 8 ) | ( ( ( b ) && 0xff ) << 0 ) )
#define Cursor_HotSpot_Pack( x, y ) ( SetValue( Cursor_HotSpot_CursorX, x ) | SetValue( Cursor_HotSpot_CursorY, y )  )

enum
{
    Global_Control_DefaultColourPlaneSelect = ( SetValue( Global_Control_ColourPlane0Select, 0 ) | SetValue( Global_Control_ColourPlane1Select, 1 ) | SetValue( Global_Control_ColourPlane2Select, 2 ) | SetValue( Global_Control_ColourPlane3Select, 3 ) )
};

enum
{
    Cursor_BitMap_MaxWidth = OT_Cap_OmniFB_Cursor_BitMap_MaxWidth,
    Cursor_BitMap_MaxHeight = OT_Cap_OmniFB_Cursor_BitMap_MaxHeight,
    Cursor_Palette_MaxEntries = OT_Cap_OmniFB_Cursor_Palette_MaxEntries,
};
typedef OT_Cap_OmniFB_Cursor_BitMap CursorBitMap;
typedef OT_Cap_OmniFB_Cursor_Palette CursorPalette;

enum
{
     VTiming_Entry_HTotal = 0,         //  0
     VTiming_Entry_VTotal,             //  1
     VTiming_Entry_HActiveStart,       //  2
     VTiming_Entry_V1BlankStart,       //  3
     VTiming_Entry_V1BlankEnd,         //  4
     VTiming_Entry_V2BlankStart,       //  5
     VTiming_Entry_V2BlankEnd,         //  6
     VTiming_Entry_F1Start,            //  7
     VTiming_Entry_F2Start,            //  8
     VTiming_Entry_HSyncStartPos,      //  9
     VTiming_Entry_HSyncEndPos,        // 10
     VTiming_Entry_V1SyncStartLine,    // 11
     VTiming_Entry_V1SyncStartHPos,    // 12
     VTiming_Entry_V1SyncEndLine,      // 13
     VTiming_Entry_V1SyncEndHPos,      // 14
     VTiming_Entry_V2SyncStartLine,    // 15
     VTiming_Entry_V2SyncStartHPos,    // 16
     VTiming_Entry_V2SyncEndLine,      // 17
     VTiming_Entry_V2SyncEndHPos,      // 18
     VTiming_Entry_HIRQ,               // 19
     VTiming_Entry_VIRQ,               // 20
     VTiming_Entry_Sof1_Delay,         // 21
     VTiming_Entry_Sof2_Delay,         // 22
     VTiming_Entry_Sof1,               // 23
     VTiming_Entry_Sof2,               // 24
     VTiming_Entry_NumEntries
};

enum
{
    VTiming_Std_1080p60,
    VTiming_Std_Total
};

typedef struct
{
    uint32_t S352M;
    uint32_t PixelsPerClock;
    uint32_t Entries[ VTiming_Entry_NumEntries ];
} Omni_VTiming_Data;

static const Omni_VTiming_Data VTiming_Table[ VTiming_Std_Total ] = {
    { // VTiming_Std_1080p60
      .S352M = 0x89CB0001,
      .PixelsPerClock = 1,
      .Entries = { 2200, 1125,    280,   41,   1121,   9999, 9999,    0, 9999, 10,   40,  1124,   10,   4,    10,   9999, 9999, 9999, 9999 ,   0,   0,   4,   4,   1,   1 }
    },
};

static const uint32_t CSC_Table[ OT_Cap_OmniFB_CSC_NumEntries ] =  { // CSC_Entry_RGB_to_YUVHD
     0x0000097d, 0x0000378c, 0xfffffa92, 0x0,
     0x00004cd8, 0xffffd561, 0xffffd1aa, 0x0,
     0x00001746, 0xfffff313, 0x000033c4, 0x0,
     0x00001000, 0x00008000, 0x00008000, 0x0
};

typedef struct
{
    uint8_t HasCSC;
    uint8_t HasLUT;
    uint8_t HasVTiming;
    uint8_t HasVTimingGenLock;
    uint8_t HasResizer;
    uint8_t HasCursor;
    uint8_t HasChromaKey;
    uint8_t ColourPlane0Bits;
    uint8_t ColourPlane1Bits;
    uint8_t ColourPlane2Bits;
    uint8_t ColourPlaneAlphaBits;
} OT_Cap_OmniFB_GlobalInfo;

typedef struct
{
    OmniTekCapabilityDriver Driver;
} OT_Cap_OmniFBDriver;

#define PALETTE_ENTRIES_NO  256 /* passed to fb_alloc_cmap() */



#define DEFAULT_FB_WIDTH       (1920)
#define DEFAULT_FB_HEIGHT      (1080)

#define MAX_VIRTUAL_FB_WIDTH   DEFAULT_FB_WIDTH

#ifdef OMNI_FB_DOUBLEBUFFER
#define MAX_VIRTUAL_FB_HEIGHT  (DEFAULT_FB_HEIGHT * 2)
#else
#define MAX_VIRTUAL_FB_HEIGHT  DEFAULT_FB_HEIGHT
#endif

struct OT_Cap_OmniFBVsync
{
    bool Supported;
    uint32_t Count; /* Number of vertical sync interrupts */
    wait_queue_head_t Wait;
    spinlock_t Lock;
};

#define LOCK_VSYNC(vsync, flags)  spin_lock_irqsave(&((vsync)->Lock), flags)
#define UNLOCK_VSYNC(vsync, flags)  spin_unlock_irqrestore(&((vsync)->Lock), flags)

#define VSYNC_TIMEOUT (HZ / 10)

typedef struct
{
    struct cdev CharDev;
    CapabilityDeviceInterface BusInterface;

    uint16_t CoreVersion;
    OT_Cap_OmniFB_GlobalInfo GlobalInfo;

    struct fb_info  FBInfo;/* FB driver info record */
    void          * FBVirt;   /* virt. address of the frame buffer */
    dma_addr_t      FBPhys;    /* phys. address of the frame buffer */
    uint32_t        FBAllocatedBytes;
    uint32_t        FBPseudoPalette[PALETTE_ENTRIES_NO]; /* Fake palette of 16 colors */

    struct OT_Cap_OmniFBVsync Vsync;
} OT_Cap_OmniFBDevice;

#define ToCapDev( fdoData ) ((fdoData)->BusInterface.Device)
#define ToCapInfo( fdoData ) ((fdoData)->BusInterface.Device->CapInfo)
#define ToRegCap( fdoData ) ((fdoData)->BusInterface.Device->CapInfo->Ext.Register)

static int OT_Cap_OmniFB_driver_probe( struct device * dev );
static int OT_Cap_OmniFB_driver_remove( struct device *dev );

static const DriverMatchId matchIdsTable[ ] = {
    { RegisterCap, 0x032d, 0 },
    { OffsetCap, 0x032d, 0 },
    { }
};

static OT_Cap_OmniFBDriver OT_Cap_OmniFB_driver = {
    .Driver = {
        .FriendlyName = MANUF_DEV("_Cap_OmniFB"),
        .IdTable = matchIdsTable,
        .Driver = {
            .name = MANUF_DEV("_Cap_OmniFB"),
            .probe = OT_Cap_OmniFB_driver_probe,
            .remove = OT_Cap_OmniFB_driver_remove,
        },
    },
};

#define WriteReg( busInterface, offset, value ) ({ (busInterface)->WriteRegisterCap( (busInterface)->Device, &(busInterface)->Device->CapInfo->Ext.Register.Blocks[ 0 ], ( offset ), ( value ) );  })
//#define WriteReg( busInterface, offset, value )  ({ (busInterface)->WriteRegisterCap( (busInterface)->Device, &(busInterface)->Device->CapInfo->Ext.Register.Blocks[ 0 ], ( offset ), ( value ) ); printk("WriteReg: 0x%08x, 0x%08x\n" , offset * 4, value  ); })

#define ReadReg( busInterface, offset, value ) ({ (busInterface)->ReadRegisterCap( (busInterface)->Device, &(busInterface)->Device->CapInfo->Ext.Register.Blocks[ 0 ], ( offset ), value );  })

void OT_Cap_OmniFB_Program_Cursor_HideShow( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, const uint32_t enable )
{
    uint32_t regVal = 0;
    if ( !globalInfo->HasCursor )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No Cursor block\n" );
        return;
    }

    ReadReg( busInterface, Register_Cursor_GlobalControl, &regVal );
    RMWValue( Cursor_GlobalControl_Enable, regVal, enable );

    WriteReg( busInterface, Register_Cursor_GlobalControl, regVal );
}

// this will disable the cursor!
void OT_Cap_OmniFB_Program_Cursor_Configure( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, const uint32_t screenWidth, const uint32_t screenHeight )
{
    if ( !globalInfo->HasCursor )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No Cursor block\n" );
        return;
    }
    WriteReg( busInterface, Register_Cursor_GlobalControl, SetValue( Cursor_GlobalControl_Enable, 0 ) );
    WriteReg( busInterface, Register_Cursor_ScreenSize, Cursor_ScreenSize_Pack( screenWidth, screenHeight ) );
}

void OT_Cap_OmniFB_Program_Cursor_SetPosition( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, const uint32_t x, const uint32_t y )
{
    if ( !globalInfo->HasCursor )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No Cursor block\n" );
        return;
    }

    WriteReg( busInterface, Register_Cursor_XYControl, Cursor_XYControl_Pack( x, y ) );
}

uint8_t OT_Cap_OmniFB_Program_Cursor_BitMap( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, CursorBitMap cursorData, const uint32_t dataWidth, const uint32_t dataHeight, const uint32_t hotSpotX, const uint32_t hotSpotY )
{
    uint32_t x = 0;
    uint32_t y = 0;
    uint32_t regVal = 0;

    uint32_t isEnabled = 0;
    uint32_t currentWidth = 0;
    uint32_t currentHeight = 0;
    uint32_t sizeChanged = 0;

    if ( !globalInfo->HasCursor )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No Cursor block\n" );
        return 1;
    }
    if ( dataWidth < 1 || dataWidth > Cursor_BitMap_MaxWidth || dataHeight < 1 || dataHeight > Cursor_BitMap_MaxHeight )
    {
        KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Cursor set bitmap: invalid dimensions. Given (%u, %u), min is (1 , 1), max is (%u, %u)\n", dataWidth, dataHeight, Cursor_BitMap_MaxWidth, Cursor_BitMap_MaxHeight );
        return 1;
    }
    if ( hotSpotX >= dataWidth || hotSpotY >= dataHeight )
    {
        KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Cursor hotspot invalid. Given (%u, %u), max is (%u, %u)\n", hotSpotX, hotSpotY, dataWidth - 1, dataHeight - 1 );
        return 1;
    }

    ReadReg( busInterface, Register_Cursor_GlobalControl, &regVal );
    isEnabled = ExtractValue( Cursor_GlobalControl_Enable, regVal );
    currentWidth = ExtractValue( Cursor_GlobalControl_CursorWidth, regVal );
    currentHeight = ExtractValue( Cursor_GlobalControl_CursorHeight, regVal );

    if( ( currentHeight != dataHeight ) || ( currentWidth != dataWidth ) )
    { // has the cursors size changed?
        sizeChanged = 1;
        if ( isEnabled )
        { // was it on? if set, turn it off
            RMWValue( Cursor_GlobalControl_Enable, regVal, 0 );
            WriteReg( busInterface, Register_Cursor_GlobalControl, regVal );
        }
        // remove the current size information
        RMWValue( Cursor_GlobalControl_CursorWidth, regVal, 0 );
        RMWValue( Cursor_GlobalControl_CursorHeight, regVal, 0 );
    }

    // set the actual data
    for( x = 0; x < dataWidth && x < Cursor_BitMap_MaxWidth; x++ )
    {
        for( y = 0; y < dataWidth && y < Cursor_BitMap_MaxWidth; y++ )
        {
            WriteReg( busInterface, Register_Cursor_BitMapRAM, Cursor_BitMapRAM_Pack( x, y, cursorData[ x ][ y ] ) );
        }
    }

    // set the hotspot
    WriteReg( busInterface, Register_Cursor_HotSpot, Cursor_HotSpot_Pack( hotSpotX, hotSpotY ) );

    if  ( sizeChanged )
    { // set new size and potentially enable
        regVal |= SetValue( Cursor_GlobalControl_Enable, isEnabled );
        regVal |= SetValue( Cursor_GlobalControl_CursorWidth, dataWidth );
        regVal |= SetValue( Cursor_GlobalControl_CursorHeight, dataHeight );

        WriteReg( busInterface, Register_Cursor_GlobalControl, regVal );
    }

    return 0;
}

void OT_Cap_OmniFB_Program_Cursor_Palette( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, const CursorPalette data )
{
    uint32_t i;
    if ( !globalInfo->HasCursor )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No Cursor block\n" );
        return;
    }

    WriteReg( busInterface, Register_Cursor_PaletteAddress, 0 );
    for( i = 0; i < Cursor_Palette_MaxEntries; i++ )
        WriteReg( busInterface, Register_Cursor_PaletteData, data[ i ] );
}


void OT_Cap_OmniFB_Program_CSC( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, const uint32_t data[ OT_Cap_OmniFB_CSC_NumEntries ] )
{
    uint32_t i;

    if ( ! globalInfo->HasCSC )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No CSC block\n" );
        return;
    }

    for ( i = 0 ; i < OT_Cap_OmniFB_CSC_NumEntries; i++ )
        WriteReg( busInterface, Register_CSC_First + i, data[ i ] );
}

void OT_Cap_OmniFB_Program_ChromaKey( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, const uint32_t isEnabled, const uint32_t colour )
{
    uint32_t regVal = 0;

    if ( ! globalInfo->HasChromaKey )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No ChromaKey block\n" );
        return;
    }

    regVal |= SetValue( ChromaKey_Control_Enable, isEnabled );
    regVal |= SetValue( ChromaKey_Control_Colour, colour );

    WriteReg( busInterface, Register_ChromaKey_Control, regVal );
}

void OT_Cap_OmniFB_Read_ChromaKey( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, uint32_t *isEnabled, uint32_t *colour )
{
    uint32_t regVal = 0;

    if ( ! globalInfo->HasChromaKey )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No ChromaKey block\n" );
        return;
    }

    ReadReg( busInterface, Register_ChromaKey_Control, &regVal );

    if ( isEnabled )
        *isEnabled = ExtractValue( ChromaKey_Control_Enable, regVal );

    if ( colour )
        *colour = ExtractValue( ChromaKey_Control_Colour, regVal );
}

void OT_Cap_OmniFB_Program_VTiming( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, const uint32_t stdIndex )
{
    const Omni_VTiming_Data * entryData = &VTiming_Table[ stdIndex ];
    uint32_t i;

    if ( ! globalInfo->HasVTiming )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "No VTiming block\n" );
        return;
    }

    if ( stdIndex >= VTiming_Std_Total )
    {
        KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Invalid VTiming standard index: %u\n", stdIndex );
        return;
    }
    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "Setting timing to: 0x%08x\n", entryData->S352M );

    // Set the FIFO start address
    WriteReg( busInterface, Register_VTiming_DataFifoStartAddress, 0 );
    // Write the timing entries
    for ( i = 0; i < VTiming_Entry_NumEntries; i++ )
        WriteReg( busInterface, Register_VTiming_DataFifo, entryData->Entries[ i ] );
    // Tell the VTC to update the timing info
    WriteReg( busInterface, Register_VTiming_UpdateTimingGen, 0 );
    // Set the Polarity information
    WriteReg( busInterface, Register_VTiming_OutputPolarity, entryData->PixelsPerClock << 8 );

    if ( globalInfo->HasVTimingGenLock )
    { // setup the genlock..
        const uint32_t totalPixels = entryData->Entries[ VTiming_Entry_VTotal ] * entryData->Entries[ VTiming_Entry_HTotal ] - 1;

        WriteReg( busInterface, Register_VTiming_Genlock_TotalPixels, totalPixels );
        WriteReg( busInterface, Register_VTiming_Genlock_Offsets, 0 );
        WriteReg( busInterface, Register_VTiming_Genlock_Control, SetValue( VTiming_Genlock_Control_NoWindow, 1 ) );
    }
}

void OT_Cap_OmniFB_Program_DMA( OT_Cap_OmniFB_GlobalInfo *globalInfo, CapabilityDeviceInterface *busInterface, const uint32_t x, const uint32_t y, const uint32_t s, const dma_addr_t screen0, const dma_addr_t screen1, const uint32_t cache )
{
    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "DMA_SCREEN: %pad, x: %u, y: %u, stride: %u, cache: 0x%04x\n", &screen0, x, y, s, cache  );

    // put the dma in reset
    WriteReg( busInterface, Register_DMA_Control, SetValue( DMA_Control_Reset, 1 ) );

    // program the screen locations
    WriteReg( busInterface, Register_DMA_Screen0, screen0 );
    WriteReg( busInterface, Register_DMA_Screen1, screen1 );

    // set width, stride and height
    WriteReg( busInterface, Register_DMA_XControl, SetValue( DMA_XControl_XSize, x ) | SetValue( DMA_XControl_XStride, s ) );
    WriteReg( busInterface, Register_DMA_YControl, SetValue( DMA_YControl_YSize, y ) );

    // set the caching type
    WriteReg( busInterface, Register_DMA_CacheControl, cache );

    // tell the dma to not be in reset
    WriteReg( busInterface, Register_DMA_Control, SetValue( DMA_Control_Reset, 0 ) );
}

int OT_Cap_OmniFB_Wait_Vsync(struct OT_Cap_OmniFBVsync* vsync)
{
    unsigned long irqFlags;
    uint32_t count;
    uint32_t delta;

    if (!vsync->Supported)
    {
        KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_OmniFB, "Wait for vsync - not supported by hardware" );
        return -EINVAL;
    }

    LOCK_VSYNC(vsync, irqFlags);

    count = vsync->Count;

    do
    {
        UNLOCK_VSYNC(vsync, irqFlags);

        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_OmniFB, "Waiting for vsync, count = %u\n", count );

        if(wait_event_interruptible_timeout(vsync->Wait, count != vsync->Count, VSYNC_TIMEOUT) == 0)
        {
            KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "Timeout waiting for vsync" );
            return -ETIMEDOUT;
        }

        LOCK_VSYNC(vsync, irqFlags);

        /* Check again and loop as we could be woken up by other events such as signals */
    } while(count == vsync->Count);

    delta = vsync->Count - count;

    UNLOCK_VSYNC(vsync, irqFlags);

    if (delta > 1)
    {
        KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Wait Vsync skipped %u frame(s)", delta - 1);
    }
    else
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_OmniFB, "Vsync wait complete, count = %u, delta = %u\n", count, delta );
    }

    return 0;
}

bool OT_Cap_OmniFB_ISR( POmniTekCapabilityDevice context, uint64_t isrTime )
{
    OT_Cap_OmniFBDevice* fdoData = dev_get_drvdata( &(context->Device) );
    uint32_t irqStatus;
    bool frameEnd;

    if ( unlikely( fdoData == NULL ) )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Could not get full info!!!\n");
        return false;
    }

    /* Read and clear interrupt status */
    ReadReg(  &fdoData->BusInterface, ToRegCap(fdoData).IRQStatusRegister, &irqStatus );
    WriteReg( &fdoData->BusInterface, ToRegCap(fdoData).IRQStatusRegister, irqStatus );

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_OmniFB, "ISR status %u\n", irqStatus);

    frameEnd = ExtractValue( Interrupt_FrameEnd, irqStatus );
    RMWValue(Interrupt_FrameEnd, irqStatus, 0);

    if (frameEnd)
    {
        struct OT_Cap_OmniFBVsync* vsync = &fdoData->Vsync;
        unsigned long irqFlags;

        LOCK_VSYNC(vsync, irqFlags);
        vsync->Count++;
        UNLOCK_VSYNC(vsync, irqFlags);

        wake_up_interruptible(&vsync->Wait);
    }

    if (irqStatus)
    {
        KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Unhandled interrupt status bits: %u\n", irqStatus);
    }

    return true;
}

void OT_Cap_OmniFB_Program_Vsync(OT_Cap_OmniFBDevice* fdoData)
{
    if ( ToRegCap(fdoData).IRQStatusRegister == 0xffffffff )
    {
        KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_OmniFB, "Wait Vsync not supported - interrupt not defined by capability\n");
        fdoData->Vsync.Supported = false;
    }
    else
    {
        uint32_t interruptEnable;

        /* Disable Frame End interrupt */
        ReadReg( &fdoData->BusInterface, ToRegCap(fdoData).IRQEnableRegister, &interruptEnable );
        RMWValue(Interrupt_FrameEnd, interruptEnable, 0);
        WriteReg( &fdoData->BusInterface, ToRegCap(fdoData).IRQEnableRegister, interruptEnable );

        /* Initialise */
        init_waitqueue_head( &fdoData->Vsync.Wait );
        spin_lock_init(&fdoData->Vsync.Lock);
        fdoData->Vsync.Count = 0;

        /* Clear frame end interrupt */
        WriteReg( &fdoData->BusInterface, ToRegCap(fdoData).IRQStatusRegister, SetValue(Interrupt_FrameEnd, 1) );

        /* Register callback and enable interrupt */
        if (fdoData->BusInterface.RegisterISRCallback( ToCapDev(fdoData), OT_Cap_OmniFB_ISR ) == SUCCESS)
        {
            RMWValue(Interrupt_FrameEnd, interruptEnable, 1);
            WriteReg( &fdoData->BusInterface, ToRegCap(fdoData).IRQEnableRegister, interruptEnable );

            fdoData->Vsync.Supported = true;
            KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_OmniFB, "Wait Vsync support initialised\n");
        }
        else
        {
            fdoData->Vsync.Supported = false;
            KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_OmniFB, "Wait Vsync not supported - failed to register interrupt\n");
        }
    }
}

int OT_Cap_OmniFB_common_ioctl( unsigned int cmd, unsigned long arg, OT_Cap_OmniFBDevice *fdoData )
{
    int retval = -ENOTTY;
    if( fdoData != NULL )
    {
        switch( cmd )
        {
            case CAP_OMNIFB_IOCTL_SetColourMatrix:
            {
                CapOmniFB_SetColourMatrix_IOCTL inData;
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }
                    if ( !fdoData->GlobalInfo.HasCSC )
                    {
                        KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No colour space converter\n");
                        retval = -EPERM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_SetColourMatrix_Version
                        {
                            retval = 0;

                            OT_Cap_OmniFB_Program_CSC( &fdoData->GlobalInfo, &fdoData->BusInterface, inData.Data );

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_SetColourMatrix_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }
            case CAP_OMNIFB_IOCTL_GetBusConfig:
            {
                CapOmniFB_GetBusConfig_IOCTL inData;
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_GetBusConfig_Version
                        {
                            uint32_t registerVal = 0;
                            ReadReg( (&fdoData->BusInterface), Register_Global_Info1, &registerVal );

                            retval = 0;

                            inData.StreamID = ExtractValue( Global_Info1_AXISStreamID, registerVal );
                            inData.PixelsPerClock = ExtractValue( Global_Info1_AXISStreamPixelsPerClock, registerVal );
                            inData.PixelDepth = ExtractValue( Global_Info1_AXISStreamPixelDepthPerColourStream, registerVal );
                            inData.NumStreams = ExtractValue( Global_Info1_AXISStreams, registerVal );

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_GetBusConfig_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }
            case CAP_OMNIFB_IOCTL_GetComponents:
            {
                uint32_t versionNumber = 0xffffffff;
                if( ( !omnitek_access_ok( VERIFY_WRITE, arg, sizeof(versionNumber) ) ) || ( copy_from_user( &versionNumber, ( void * )arg, sizeof( versionNumber ) ) != 0 ) ) 
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "Failed to read version number\n");
                    retval = -ENOMEM;
                    break;
                }
                
                switch ( versionNumber )
                {
                    case CAP_OMNIFB_IOCTL_GetComponents_Version1:
                    {
                        CapOmniFB_GetComponents_V1_IOCTL inData;
                        if( ( !omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) ) || ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 ) )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "Failed to read IOCTL data\n");
                            retval = -ENOMEM;
                            break;
                        }
                        retval = 0;
                        inData.HasCSC = fdoData->GlobalInfo.HasCSC;
                        inData.HasLUT = fdoData->GlobalInfo.HasLUT;
                        inData.HasVTiming = fdoData->GlobalInfo.HasVTiming;
                        inData.HasVTimingGenLock = fdoData->GlobalInfo.HasVTimingGenLock;
                        inData.HasResizer = fdoData->GlobalInfo.HasResizer;
                        inData.HasCursor = fdoData->GlobalInfo.HasCursor;

                        if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                            retval = -ENOMEM;
                        }

                        break;
                    }
                    case CAP_OMNIFB_IOCTL_GetComponents_Version2:
                    {
                        CapOmniFB_GetComponents_V2_IOCTL inData;
                        if( ( !omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) ) || ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 ) )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "Failed to read IOCTL data\n");
                            retval = -ENOMEM;
                            break;
                        }
                        retval = 0;
                        inData.HasCSC = fdoData->GlobalInfo.HasCSC;
                        inData.HasLUT = fdoData->GlobalInfo.HasLUT;
                        inData.HasVTiming = fdoData->GlobalInfo.HasVTiming;
                        inData.HasVTimingGenLock = fdoData->GlobalInfo.HasVTimingGenLock;
                        inData.HasResizer = fdoData->GlobalInfo.HasResizer;
                        inData.HasCursor = fdoData->GlobalInfo.HasCursor;
                        inData.HasChromaKey = fdoData->GlobalInfo.HasChromaKey;

                        if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                            retval = -ENOMEM;
                        }
                        
                        break;
                    }
                    default:
                    {
                        KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), versionNumber );
                        versionNumber = CAP_OMNIFB_IOCTL_GetComponents_Version2;
                        if ( copy_to_user( ( void * )arg, &versionNumber, sizeof( versionNumber ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                            retval = -ENOMEM;
                        }
                        break;
                    }
                }
                break;
            }
            case CAP_OMNIFB_IOCTL_CursorEnable:
            {
                CapOmniFB_CursorEnable_IOCTL inData;

                if ( !fdoData->GlobalInfo.HasCursor )
                {
                    KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No cursor\n");
                    retval = -EPERM;
                    break;
                }
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_CursorEnable_Version
                        {
                            retval = 0;

                            OT_Cap_OmniFB_Program_Cursor_HideShow( &fdoData->GlobalInfo, &fdoData->BusInterface, inData.Enabled );

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_CursorEnable_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }
            case CAP_OMNIFB_IOCTL_CursorMove:
            {
                CapOmniFB_CursorPosition_IOCTL inData;

                if ( !fdoData->GlobalInfo.HasCursor )
                {
                    KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No cursor\n");
                    retval = -EPERM;
                    break;
                }
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_CursorMove_Version
                        {
                            retval = 0;

                            OT_Cap_OmniFB_Program_Cursor_SetPosition( &fdoData->GlobalInfo, &fdoData->BusInterface, inData.X, inData.Y );

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_CursorMove_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }
            case CAP_OMNIFB_IOCTL_CursorSetPalette:
            {
                CapOmniFB_CursorPalette_IOCTL inData;

                if ( !fdoData->GlobalInfo.HasCursor )
                {
                    KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No cursor\n");
                    retval = -EPERM;
                    break;
                }
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_CursorSetPalette_Version
                        {
                            retval = 0;

                            OT_Cap_OmniFB_Program_Cursor_Palette( &fdoData->GlobalInfo, &fdoData->BusInterface, inData.Data );

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_CursorSetPalette_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }
            case CAP_OMNIFB_IOCTL_CursorSetImage:
            {
                CapOmniFB_CursorImage_IOCTL *inData = NULL;

                if ( !fdoData->GlobalInfo.HasCursor )
                {
                    KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No cursor\n");
                    retval = -EPERM;
                    break;
                }
                inData = kzalloc( sizeof(*inData), GFP_KERNEL );
                if ( inData == NULL )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "Failed to allocate buffer for IOCTL data\n");
                    retval = -ENOMEM;
                    break;
                }

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( inData, ( void * )arg, sizeof(*inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        kfree( inData );
                        break;
                    }

                    switch ( inData->Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_CursorSetImage_Version
                        {
                            retval = 0;

                            if ( OT_Cap_OmniFB_Program_Cursor_BitMap( &fdoData->GlobalInfo, &fdoData->BusInterface, inData->Data, inData->DataWidth, inData->DataHeight, inData->HotSpotX, inData->HotSpotY ) != 0 )
                                retval = -EINVAL;
                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData->Version );
                            inData->Version = CAP_OMNIFB_IOCTL_CursorSetImage_Version;
                            if ( copy_to_user( ( void * )arg, inData, sizeof( *inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                    kfree( inData );
                }
                else
                {
                    kfree( inData );
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }

            case CAP_OMNIFB_IOCTL_DiscardAlpha:
            {
                CapOmniFB_DiscardAlpha_IOCTL inData;

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_DiscardAlpha_Version
                        {
                            uint32_t regVal = 0;
                            retval = 0;

                            ReadReg( &fdoData->BusInterface, Register_Global_Control, &regVal );
                            RMWValue( Global_Control_DiscardAlpha, regVal, inData.Discard );
                            WriteReg( &fdoData->BusInterface, Register_Global_Control, regVal );

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_DiscardAlpha_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }

            case CAP_OMNIFB_IOCTL_GetResizerEnabled:
            {
                CapOmniFB_Resizer_IOCTL inData;

                if ( !fdoData->GlobalInfo.HasResizer )
                {
                    KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No Resizer\n");
                    retval = -EPERM;
                    break;
                }

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_GetResizerEnabled_Version
                        {
                            uint32_t regVal = 0;
                            retval = 0;

                            ReadReg( &fdoData->BusInterface, Register_Global_Control, &regVal );

                            inData.Enabled = ExtractValue( Global_Control_2K4KResizerEnable, regVal );

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_GetResizerEnabled_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }

            case CAP_OMNIFB_IOCTL_SetResizerEnabled:
            {
                CapOmniFB_Resizer_IOCTL inData;

                if ( !fdoData->GlobalInfo.HasResizer )
                {
                    KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No Resizer\n");
                    retval = -EPERM;
                    break;
                }

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_SetResizerEnabled_Version
                        {
                            uint32_t regVal = 0;
                            retval = 0;

                            ReadReg( &fdoData->BusInterface, Register_Global_Control, &regVal );
                            RMWValue( Global_Control_2K4KResizerEnable, regVal, inData.Enabled );
                            WriteReg( &fdoData->BusInterface, Register_Global_Control, regVal );

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_SetResizerEnabled_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }

            case CAP_OMNIFB_IOCTL_GetChromaKey:
            {
                CapOmniFB_ChromaKey_IOCTL inData;

                if ( !fdoData->GlobalInfo.HasChromaKey )
                {
                    KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No ChromaKey\n");
                    retval = -EPERM;
                    break;
                }

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_GetChromaKey_Version
                        {
                            OT_Cap_OmniFB_Read_ChromaKey( &fdoData->GlobalInfo, &fdoData->BusInterface, &inData.Enabled, &inData.Colour );
                            retval = 0;

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_GetChromaKey_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }

            case CAP_OMNIFB_IOCTL_SetChromaKey:
            {
                CapOmniFB_ChromaKey_IOCTL inData;

                if ( !fdoData->GlobalInfo.HasChromaKey )
                {
                    KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "No ChromaKey\n");
                    retval = -EPERM;
                    break;
                }

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_OMNIFB_IOCTL_SetChromaKey_Version
                        {
                            OT_Cap_OmniFB_Program_ChromaKey( &fdoData->GlobalInfo, &fdoData->BusInterface, inData.Enabled, inData.Colour );
                            retval = 0;

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_OMNIFB_IOCTL_SetChromaKey_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                break;
            }

            case FBIO_WAITFORVSYNC:
            {
                KernelTraceNA(TRACE_LEVEL_VERBOSE, Cap_OmniFB,"FBIO_WAITFORVSYNC called\n");
                retval = OT_Cap_OmniFB_Wait_Vsync(&fdoData->Vsync);
                break;
            }

            default:
                KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unhandled in switch\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                break;
        }
    }
    else
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Device Not Found!!!\n" );
    }
    return retval;
}

int OT_Cap_OmniFB_fb_ioctl(struct fb_info *info, unsigned int cmd, unsigned long arg)
{
    OT_Cap_OmniFBDevice * fdoData = NULL;
    fdoData = dev_get_drvdata( info->device );
    return OT_Cap_OmniFB_common_ioctl( cmd, arg, fdoData );
}

long OT_Cap_OmniFB_unlocked_ioctl( struct file *filp, unsigned int cmd, unsigned long arg )
{
    int retval = -ENOTTY;
    OT_Cap_OmniFBDevice *fdoData = NULL;

    fdoData = container_of( filp->f_path.dentry->d_inode->i_cdev, OT_Cap_OmniFBDevice, CharDev );
    if( fdoData != NULL )
    {
        switch( cmd )
        {
            case CAP_RA_IOCTL_GetBlockCount:
            case CAP_RA_IOCTL_GetRegisterCount:
            case CAP_RA_IOCTL_RegisterRead:
            case CAP_RA_IOCTL_RegisterShadowRead:
            case CAP_RA_IOCTL_RegisterWrite:
            case CAP_RA_IOCTL_GetMetaData:
                retval =  ProcessCapabilityBaseIOCTL( &ToRegCap(fdoData), &fdoData->BusInterface, arg, cmd );
                break;
            case CAP_COMMON_IOCTL_QueryInfo:
            {
                CapCommon_QueryInfo_IOCTL inData;
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_COMMON_IOCTL_QueryInfo_Version
                        {
                            retval = 0;
                            switch ( inData.Key )
                            {
                                case QueryInfo_CapabilityId:
                                    inData.Value = ToCapDev(fdoData)->Id;
                                    break;
                                case QueryInfo_RegisterUniqueID:
                                case QueryInfo_RegisterAssociationID:
                                case QueryInfo_RegisterVersionId:
                                case QueryInfo_TimerGetTime:
                                case QueryInfo_TimerGetFrequency:
                                case QueryInfo_RegisterPhysAddr:
                                    retval = ProcessCommon_QueryInfo_Register( fdoData->BusInterface.Device->CapInfo, &fdoData->BusInterface, &inData );
                                    break;
                                default:
                                    retval = -EINVAL;
                                    break;
                            }

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_COMMON_IOCTL_QueryInfo_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_OmniFB, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            case CAP_OMNIFB_IOCTL_SetColourMatrix:
            case CAP_OMNIFB_IOCTL_GetBusConfig:
            case CAP_OMNIFB_IOCTL_GetComponents:
            case CAP_OMNIFB_IOCTL_CursorEnable:
            case CAP_OMNIFB_IOCTL_CursorMove:
            case CAP_OMNIFB_IOCTL_CursorSetPalette:
            case CAP_OMNIFB_IOCTL_CursorSetImage:
            case CAP_OMNIFB_IOCTL_DiscardAlpha:
            case CAP_OMNIFB_IOCTL_GetResizerEnabled:
            case CAP_OMNIFB_IOCTL_SetResizerEnabled:
            case CAP_OMNIFB_IOCTL_GetChromaKey:
            case CAP_OMNIFB_IOCTL_SetChromaKey:
                retval = OT_Cap_OmniFB_common_ioctl( cmd, arg, fdoData );
                break;
            default:
                KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unhandled in switch\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                break;
        }
    }
    else
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Device Not Found!!!\n" );
    }
    return retval;
}

static int OT_Cap_OmniFB_fb_pan_display(struct fb_var_screeninfo *var, struct fb_info *info)
{
    int result = -EINVAL;

    unsigned int xoffset = var->xoffset;
    unsigned int yoffset = var->yoffset;
    OT_Cap_OmniFBDevice * fdoData = NULL;

    fdoData = dev_get_drvdata( info->device );

    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, " %s Offset: x=%u, y=%u\n", __FUNCTION__, xoffset, yoffset );

    if ((xoffset + info->var.xres) > info->var.xres_virtual)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "Attempt to pan beyond virtual X resolution\n");
    }
    else if ((yoffset + info->var.yres) > info->var.yres_virtual)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "Attempt to pan beyond virtual Y resolution\n");
    }
    else
    {
        unsigned int active_screen;
        unsigned int target_screen;
        unsigned int dma_control;
        unsigned int address_offset = fdoData->FBPhys + (yoffset * info->fix.line_length) + xoffset;

        ReadReg( &fdoData->BusInterface, Register_DMA_Control, &dma_control );
        active_screen = (dma_control & DMA_Control_Active_Screen_Mask) >> DMA_Control_Active_Screen_Shift;

        if (var->activate & FB_ACTIVATE_VBL)
        {
            target_screen = !active_screen; // For synchronised change
        }
        else
        {
            target_screen = active_screen; // For immediate change
        }

        if(target_screen == 1)
        {
            WriteReg( &fdoData->BusInterface, Register_DMA_Screen1, address_offset);
        }
        else
        {
            WriteReg( &fdoData->BusInterface, Register_DMA_Screen0, address_offset);
        }

        if (target_screen != active_screen)
        {
            // Change active screen - will take effect at next vertical blank
            RMWValue( DMA_Control_Screen_Select, dma_control, target_screen );
            WriteReg( &fdoData->BusInterface, Register_DMA_Control, dma_control);
        }

        result = 0;
    }

    return result;
}

static int OT_Cap_OmniFB_fb_check_var(struct fb_var_screeninfo *var, struct fb_info *info)
{
    unsigned int xres = var->xres;  /* visible resolution        */
    unsigned int yres = var->yres;
    unsigned int xres_virtual = var->xres_virtual; /* virtual resolution        */
    unsigned int yres_virtual = var->yres_virtual;
    unsigned int xoffset = var->xoffset;  /* offset from virtual to visible */
    unsigned int yoffset = var->yoffset;

    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, " %s xres: %d\n", __FUNCTION__, xres );
    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, " %s yres: %d\n", __FUNCTION__, yres );
    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, " %s xres_virtual: %d\n", __FUNCTION__, xres_virtual );
    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, " %s yres_virtual: %d\n", __FUNCTION__, yres_virtual );
    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, " %s xoffset: %d\n", __FUNCTION__, xoffset );
    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, " %s yoffset: %d\n", __FUNCTION__, yoffset );
    
    if (yres_virtual > MAX_VIRTUAL_FB_HEIGHT)
    {
          KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "yres_virtual beyond Max FB Height(%d)\n", MAX_VIRTUAL_FB_HEIGHT);
          return -EINVAL;
    }
    if (xres_virtual > MAX_VIRTUAL_FB_WIDTH)
    {
          KernelTrace( TRACE_LEVEL_WARNING, Cap_OmniFB, "xres_virtual beyond beyond Max FB width(%d)\n", MAX_VIRTUAL_FB_HEIGHT);
          return -EINVAL;
    }

    if(xres == 0)
    {
          KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "xres not set\n");
          return -EINVAL;
    }

    if(yres == 0)
    {
          KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "yres not set\n");
          return -EINVAL;
    }

    if((yoffset + yres) > yres_virtual)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "yres + yoffset beyond yres_virtual\n");
        return -EINVAL;
    }
    if((xoffset + xres) > xres_virtual)
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, Cap_OmniFB, "xres + xoffset beyond xres_virtual\n");
        return -EINVAL;
    }

    return 0;
}

static int OT_Cap_OmniFB_fb_set_par(struct fb_info *info)
{
    OT_Cap_OmniFBDevice * fdoData = NULL;

    uint32_t stride = 0;
    uint32_t bytesPerPixel = 0;
    uint32_t bitsPerPixel = 0;

    fdoData = dev_get_drvdata( info->device );

    bitsPerPixel = ( fdoData->GlobalInfo.ColourPlane0Bits + fdoData->GlobalInfo.ColourPlane1Bits + fdoData->GlobalInfo.ColourPlane2Bits + fdoData->GlobalInfo.ColourPlaneAlphaBits );
    bytesPerPixel = ( ( bitsPerPixel + 7 ) / 8 );

    stride = DEFAULT_FB_WIDTH;
    if ( ToRegCap( fdoData ).Version > 1 )
        stride *= bytesPerPixel;

    OT_Cap_OmniFB_Program_DMA( &fdoData->GlobalInfo,
                                &fdoData->BusInterface,
                                fdoData->FBInfo.var.xres,
                                fdoData->FBInfo.var.yres,
                                stride,
                                fdoData->FBPhys,
                                fdoData->FBPhys,
                                DMA_CacheControl_NoCache );

    // Caller may also have changed panning
    OT_Cap_OmniFB_fb_pan_display(&info->var, info);

    return 0;
}

const struct file_operations OT_Cap_OmniFB_device_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = OT_Cap_OmniFB_unlocked_ioctl,
};

static struct fb_ops OT_Cap_OmniFB_fbops = {
    .owner      = THIS_MODULE,
//    .fb_open    = xxxfb_open,
//    .fb_read    = xxxfb_read,
//    .fb_write   = xxxfb_write,
//    .fb_release = xxxfb_release,
    .fb_check_var   = OT_Cap_OmniFB_fb_check_var,
    .fb_set_par     = OT_Cap_OmniFB_fb_set_par,
//    .fb_setcolreg   = xxxfb_setcolreg,
//    .fb_blank   = xxxfb_blank, //!< this is to turn off the display...
    .fb_pan_display = OT_Cap_OmniFB_fb_pan_display, //!< seems this is used as a way to double buffer...
    .fb_fillrect    = cfb_fillrect, //!< possibly add hw accell
    .fb_copyarea    = cfb_copyarea, //!< possibly add hw accell
    .fb_imageblit   = cfb_imageblit, //!< possibly add hw accell
//    .fb_cursor  = xxxfb_cursor, //!< possibly add hw accell
//    .fb_rotate  = xxxfb_rotate,
//    .fb_sync    = xxxfb_sync, // !< this is basically a wait for vblank...
    .fb_ioctl       = OT_Cap_OmniFB_fb_ioctl,
//    .fb_mmap    = xxxfb_mmap,
};

static struct fb_fix_screeninfo OT_Cap_OmniFB_fb_fix_screeninfo = {
    .id =       "OmniTek",
    .type =     FB_TYPE_PACKED_PIXELS,
    .visual =   FB_VISUAL_TRUECOLOR,
    .accel =    FB_ACCEL_NONE
};

static int OT_Cap_OmniFB_driver_probe( struct device * dev )
{
    uint32_t registerVal = 0;
    uint32_t stride = 0;
    POmniTekCapabilityDevice capDev = NULL;
    OT_Cap_OmniFBDevice *fdoData = NULL;
    int result = 0;
    struct device * hostControllerDevice = NULL;

    capDev = ToOmniTekCapabilityDevice( dev );

    fdoData = kzalloc( sizeof(OT_Cap_OmniFBDevice), GFP_KERNEL );
    if( fdoData )
    {
        //uint32_t fbWidth = 1920;
        //uint32_t fbHeight = 1080;
        uint32_t bytesPerPixel = 0;
        uint32_t bitsPerPixel = 0;

        result = MANUF_FUNC(_GetInterfaceForCapDriver)( capDev, &fdoData->BusInterface );
        if (result != 0 )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Could not Get interface: %d\n", result );
            goto probe_failure_OmniTek_GetInterfaceForCapDriver;
        }
        hostControllerDevice = fdoData->BusInterface.HostControllerDevice;

        if ( ( forced_component_id != NoForcedId ) && ( fdoData->BusInterface.Device->CapInfo->Ext.Register.ComponentId != forced_component_id ) )
        {
            KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "Not creating this device as forced id has been set\n" );
            result = -EPERM;
            goto probe_failure_device_create_file;
        }

        if ( ToRegCap( fdoData ).Version == 1 )
        {
            fdoData->GlobalInfo.ColourPlane0Bits = 8;
            fdoData->GlobalInfo.ColourPlane1Bits = 8;
            fdoData->GlobalInfo.ColourPlane2Bits = 8;
            fdoData->GlobalInfo.ColourPlaneAlphaBits = 8;
        }
        else
        {
            ReadReg( (&fdoData->BusInterface), Register_Global_Info2, &registerVal );
            fdoData->GlobalInfo.ColourPlane0Bits = ExtractValue( Global_Info2_Plane0BitsPerPixel, registerVal );
            fdoData->GlobalInfo.ColourPlane1Bits = ExtractValue( Global_Info2_Plane1BitsPerPixel, registerVal );
            fdoData->GlobalInfo.ColourPlane2Bits = ExtractValue( Global_Info2_Plane2BitsPerPixel, registerVal );
            fdoData->GlobalInfo.ColourPlaneAlphaBits = ExtractValue( Global_Info2_PlaneAlphaBitsPerPixel, registerVal );
        }

        bitsPerPixel = ( fdoData->GlobalInfo.ColourPlane0Bits + fdoData->GlobalInfo.ColourPlane1Bits + fdoData->GlobalInfo.ColourPlane2Bits + fdoData->GlobalInfo.ColourPlaneAlphaBits );
        bytesPerPixel = ( ( bitsPerPixel + 7 ) / 8 );

        stride = DEFAULT_FB_WIDTH;
        if ( ToRegCap( fdoData ).Version > 1 )
            stride *= bytesPerPixel;

        ReadReg( (&fdoData->BusInterface), Register_Global_Info0, &registerVal );
        fdoData->GlobalInfo.HasCSC = ExtractValue( Global_Info0_CSC_Exists, registerVal );
        fdoData->GlobalInfo.HasLUT = ExtractValue( Global_Info0_LUT_Exists, registerVal );
        fdoData->GlobalInfo.HasVTiming = ExtractValue( Global_Info0_VTiming_Exists, registerVal );
        fdoData->GlobalInfo.HasVTimingGenLock = ExtractValue( Global_Info0_VTiming_GenLock, registerVal );
        fdoData->GlobalInfo.HasResizer = ExtractValue( Global_Info0_Resizer_Exists, registerVal );
        fdoData->GlobalInfo.HasCursor = ExtractValue( Global_Info0_Cursor_Exists, registerVal );
        fdoData->GlobalInfo.HasChromaKey = ExtractValue( Global_Info0_ChromaKey_Exists, registerVal );

        fdoData->CoreVersion = 0x10;
        if ( ToRegCap( fdoData ).Version > 1 )
        {
            ReadReg( (&fdoData->BusInterface), Register_Version_Info, &registerVal );
            if ( registerVal == 0 )
                fdoData->CoreVersion = 0x20;
            else
                fdoData->CoreVersion = ExtractValue( Version_Info_Version, registerVal );
        }

        result = device_create_file( dev, &dev_attr_debuglevel );
        if( result )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "can't create sysfs debuglevel file!!!\n" );
            goto probe_failure_device_create_file;
        }

        // Initialise a char device
        cdev_init( &( fdoData->CharDev ), &OT_Cap_OmniFB_device_fops );
        fdoData->CharDev.owner = THIS_MODULE;

        // actually add the char device
        result = cdev_add( &fdoData->CharDev, fdoData->BusInterface.Device->CharDevNum, 1 );
        if( result )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Could not create char device. code: %d\n", result);
            goto probe_failure_cdev_add;
        }

        if ( NULL == device_create( MANUF_FUNC(_GetClass)(), dev, fdoData->BusInterface.Device->CharDevNum, NULL, MANUF_DEV("_Cap_OmniFB_%02d_%03d"), SlotIdFromChildId( capDev->Id ) , BasicChildId( capDev->Id ) ) )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Failed to create dev entry\n" );
            result = -ENOMEM;
            goto probe_failure_device_create;
        }
        snprintf( capDev->DeviceAccessName, MAX_FILEPATH_LEN, "/dev/"MANUF_DEV("_Cap_OmniFB_%02d_%03d"), SlotIdFromChildId( capDev->Id ) , BasicChildId( capDev->Id ) );

        fdoData->FBAllocatedBytes = MAX_VIRTUAL_FB_WIDTH * bytesPerPixel * MAX_VIRTUAL_FB_HEIGHT;
        fdoData->FBVirt = dma_alloc_coherent( hostControllerDevice, fdoData->FBAllocatedBytes, &(fdoData->FBPhys), GFP_KERNEL );
        if( fdoData->FBVirt == NULL )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Failed to allocate memory\n" );
            result = -ENOMEM;
            goto probe_failure_dma_alloc_coherent;
        }
        /* Clear (turn to black) the framebuffer */
        memset_io( ( void __iomem * )fdoData->FBVirt, 0, fdoData->FBAllocatedBytes );

        fdoData->FBInfo.device = dev;
        fdoData->FBInfo.pseudo_palette = fdoData->FBPseudoPalette;
        fdoData->FBInfo.screen_base = ( void __iomem * )fdoData->FBVirt;
        fdoData->FBInfo.fbops = &OT_Cap_OmniFB_fbops;
        fdoData->FBInfo.fix = OT_Cap_OmniFB_fb_fix_screeninfo;
        fdoData->FBInfo.fix.smem_start = fdoData->FBPhys;
        fdoData->FBInfo.fix.smem_len = fdoData->FBAllocatedBytes;
        fdoData->FBInfo.fix.line_length = DEFAULT_FB_WIDTH * bytesPerPixel;
        fdoData->FBInfo.fix.ypanstep = 1;

        /* Allocate a colour map */
        result = fb_alloc_cmap( &fdoData->FBInfo.cmap, PALETTE_ENTRIES_NO, 0 );
        if( result )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Fail to allocate cmap (%d entries)\n", PALETTE_ENTRIES_NO );
            goto probe_failure_fb_alloc_cmap;
        }
        // could use fb_find_mode  but its doesnt seem to buy us much...
        fdoData->FBInfo.var.xres = DEFAULT_FB_WIDTH;
        fdoData->FBInfo.var.yres = DEFAULT_FB_HEIGHT;
        fdoData->FBInfo.var.xres_virtual = MAX_VIRTUAL_FB_WIDTH;
        fdoData->FBInfo.var.yres_virtual = MAX_VIRTUAL_FB_HEIGHT;

        fdoData->FBInfo.var.bits_per_pixel = bitsPerPixel;
        fdoData->FBInfo.var.blue.offset = 0;
        fdoData->FBInfo.var.blue.length = fdoData->GlobalInfo.ColourPlane0Bits;
        fdoData->FBInfo.var.blue.msb_right = 0;
        fdoData->FBInfo.var.green.offset = fdoData->GlobalInfo.ColourPlane0Bits;
        fdoData->FBInfo.var.green.length = fdoData->GlobalInfo.ColourPlane1Bits;
        fdoData->FBInfo.var.green.msb_right = 0;
        fdoData->FBInfo.var.red.offset = fdoData->GlobalInfo.ColourPlane0Bits + fdoData->GlobalInfo.ColourPlane1Bits;
        fdoData->FBInfo.var.red.length = fdoData->GlobalInfo.ColourPlane2Bits;
        fdoData->FBInfo.var.red.msb_right = 0;
        fdoData->FBInfo.var.transp.offset = fdoData->GlobalInfo.ColourPlane0Bits + fdoData->GlobalInfo.ColourPlane1Bits + fdoData->GlobalInfo.ColourPlane2Bits;
        fdoData->FBInfo.var.transp.length = fdoData->GlobalInfo.ColourPlaneAlphaBits;
        fdoData->FBInfo.var.transp.msb_right = 0;


        dev_set_drvdata( dev, fdoData );

        WriteReg( &fdoData->BusInterface, Register_Global_Control, SetValue( Global_Control_Reset, 1 ) );

        OT_Cap_OmniFB_Program_DMA( &fdoData->GlobalInfo, &fdoData->BusInterface, fdoData->FBInfo.var.xres, fdoData->FBInfo.var.yres, stride, fdoData->FBPhys, fdoData->FBPhys, DMA_CacheControl_NoCache );

        OT_Cap_OmniFB_Program_CSC( &fdoData->GlobalInfo, &fdoData->BusInterface, CSC_Table );

        OT_Cap_OmniFB_Program_VTiming( &fdoData->GlobalInfo, &fdoData->BusInterface, VTiming_Std_1080p60 );

        OT_Cap_OmniFB_Program_Cursor_Configure( &fdoData->GlobalInfo, &fdoData->BusInterface, DEFAULT_FB_WIDTH, DEFAULT_FB_HEIGHT );

        OT_Cap_OmniFB_Program_ChromaKey( &fdoData->GlobalInfo, &fdoData->BusInterface, false, 0 );

        WriteReg( &fdoData->BusInterface, Register_Global_Control, SetValue( Global_Control_Reset, 0 ) | SetValue( Global_Control_DiscardAlpha, 1 ) | Global_Control_DefaultColourPlaneSelect );

        OT_Cap_OmniFB_Program_Vsync( fdoData );

        /* Register new frame buffer */
        result = register_framebuffer( &fdoData->FBInfo );
        if (result) {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Fail to register_framebuffer: %d\n", result );
            goto probe_failure_register_framebuffer;
        }

        KernelTrace( TRACE_LEVEL_INFORMATION, Cap_OmniFB, "FrameBuffer Created (x2 buffering)!!!  phys=%llx, virt=%p\n", (unsigned long long)fdoData->FBPhys, fdoData->FBVirt );

    }
    else
    {
        result = -ENOMEM;
    }
    goto probe_success;

//probe_failure_xxx:
//    unregister_framebuffer( &fdoData->fb_info );

probe_failure_register_framebuffer:
    fb_dealloc_cmap( &fdoData->FBInfo.cmap );

probe_failure_fb_alloc_cmap:
    if ( fdoData->FBVirt != NULL )
    {
        dma_free_coherent( dev, fdoData->FBAllocatedBytes, fdoData->FBVirt, fdoData->FBPhys );
        fdoData->FBVirt = NULL;
    }

probe_failure_dma_alloc_coherent:
    device_destroy( MANUF_FUNC(_GetClass)(), fdoData->BusInterface.Device->CharDevNum );

probe_failure_device_create:
    cdev_del( &fdoData->CharDev );

probe_failure_cdev_add:
    device_remove_file( dev, &dev_attr_debuglevel );

probe_failure_device_create_file:
probe_failure_OmniTek_GetInterfaceForCapDriver:
    kfree( fdoData );

probe_success:
    return result;
}

static int OT_Cap_OmniFB_driver_remove( struct device *dev )
{
    OT_Cap_OmniFBDevice * fdoData = NULL;

    fdoData = dev_get_drvdata( dev );
    if( fdoData != NULL )
    {
        device_remove_file( dev, &dev_attr_debuglevel );
        device_destroy( MANUF_FUNC(_GetClass)(), fdoData->BusInterface.Device->CharDevNum );

        dev_set_drvdata( dev, NULL );
        cdev_del( &fdoData->CharDev );

        // Disable Cursor
        WriteReg( &fdoData->BusInterface, Register_Cursor_GlobalControl, SetValue( Cursor_GlobalControl_Enable, 0 ) );
        // Disable DMA
        WriteReg( &fdoData->BusInterface, Register_DMA_Control, SetValue( DMA_Control_Reset, 1 ) );
        // Disable overall FB
        WriteReg( &fdoData->BusInterface, Register_Global_Control, SetValue( Global_Control_Reset, 1 ) );

        if ( fdoData->FBVirt != NULL )
        {
            unregister_framebuffer( &fdoData->FBInfo );

            fb_dealloc_cmap( &fdoData->FBInfo.cmap );

            dma_free_coherent( dev, fdoData->FBAllocatedBytes, fdoData->FBVirt, fdoData->FBPhys );
            fdoData->FBVirt = NULL;
        }

        kfree( fdoData );
        return 0;
    }
    return -1;
}

int OT_Cap_OmniFB_init( void )
{
    int result = 0;

    // tell the bus that we exist and will control some devices
    result = MANUF_FUNC(_capability_driver_register)( &OT_Cap_OmniFB_driver.Driver );
    if ( result )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, Cap_OmniFB, "Error %d RegisterCapabilityDriver", result);
    }

    return result;
}

void OT_Cap_OmniFB_cleanup( void )
{
    // tell the bus that this driver is gone
    MANUF_FUNC(_capability_driver_unregister)( &OT_Cap_OmniFB_driver.Driver );
}

module_init( OT_Cap_OmniFB_init );
module_exit( OT_Cap_OmniFB_cleanup );
