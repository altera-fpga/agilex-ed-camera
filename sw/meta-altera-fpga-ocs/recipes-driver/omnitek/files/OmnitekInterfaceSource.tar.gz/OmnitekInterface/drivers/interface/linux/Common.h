/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef COMMON_H_
#error "Do not include this directly."
#endif

#include <linux/types.h>
#include <linux/version.h>

#include "Customise.h"

/** \cond */
#ifndef false
#define false 0
#endif

#ifndef true
#define true 1
#endif

#ifndef FALSE
#define FALSE               0
#endif

#ifndef TRUE
#define TRUE                1
#endif

/**
 * @brief should driver print statements be allowed
 */
#define ENABLE_DEBUG_PRINT		1

// standard method of extracting just the filename from gcc under linux
#define FILE (strrchr(__FILE__, '/') ? strrchr(__FILE__, '/') + 1 : __FILE__)
/** \endcond */

/**
 * @brief Wrapper for os specific success codes
 */
#define IsSuccess( x ) ( x == 0 )

/**
 * @brief Wrapper for os specific failure codes
 */
#define IsFailure( x ) ( x != 0 )

// directly ripped from windows drivers so we can have consistent logging levels
#define TRACE_LEVEL_NONE        0   //!< Tracing is not on
#define TRACE_LEVEL_CRITICAL    1   //!< Abnormal exit or termination
#define TRACE_LEVEL_FATAL       1   //!< Deprecated name for Abnormal exit or termination
#define TRACE_LEVEL_ERROR       2   //!< Severe errors that need logging
#define TRACE_LEVEL_WARNING     3   //!< Warnings such as allocation failure
#define TRACE_LEVEL_INFORMATION 4   //!< Includes non-error cases(e.g.,Entry-Exit)
#define TRACE_LEVEL_VERBOSE     5   //!< Detailed traces from intermediate steps
#define TRACE_LEVEL_RESERVED6   6 //!< Undefined, higher verbosity than #TRACE_LEVEL_VERBOSE
#define TRACE_LEVEL_RESERVED7   7 //!< Undefined, higher verbosity than #TRACE_LEVEL_RESERVED6
#define TRACE_LEVEL_RESERVED8   8 //!< Undefined, higher verbosity than #TRACE_LEVEL_RESERVED7
#define TRACE_LEVEL_RESERVED9   9 //!< Undefined, higher verbosity than #TRACE_LEVEL_RESERVED8

/**
 * @brief Macro similar to WPP tracing macros for defining unique trace message class ids
 */
#define WPP_DEFINE_BIT( X ) WPP_TRACE_##X

/**
 * @brief Current available "trace bits" mimic what we use in windows
 */
enum
{
    WPP_DEFINE_BIT(OmniTekBus) = 1, //!< Trace for Bus ONLY

    WPP_DEFINE_BIT(HC_LocalFPGA), //!< Trace for Local FPGA Host Controller
    WPP_DEFINE_BIT(HC_OmniTek), //!< Trace for PCIe Host Controller
    WPP_DEFINE_BIT(HC_MemoryBased), //!< Trace for "memory based" test Host Controller

    WPP_DEFINE_BIT(Cap_RegisterAccess), //!< Trace for generic Register Capability
    WPP_DEFINE_BIT(Cap_MDMA), //!< Trace for MDMA Capability
    WPP_DEFINE_BIT(Cap_VideoFDMA), //!< Trace for Streaming FDMA Capability
    WPP_DEFINE_BIT(Cap_EyeScanDMA), //!< Trace for Eye Scan DMA Capability
    WPP_DEFINE_BIT(Cap_MemMapBar), //!< Trace for Memory Map Capability
    WPP_DEFINE_BIT(Cap_FPGA), //!< Trace for test FPGA Capability

    WPP_DEFINE_BIT(DMACommon), //!< Trace for common DMA functionality
    WPP_DEFINE_BIT(UserBuffer), //!< Trace for user buffer functionality
    WPP_DEFINE_BIT(PciConfig), //!< Trace for PCI Config functionality
    WPP_DEFINE_BIT(IOCTLCommon), //!< Trace for common IOCTL processing functionality

    WPP_DEFINE_BIT(Cap_OmniFB), //!< Trace for OmniFB Capability

    WPP_DEFINE_BIT(Cap_xDisplayPort), //!< Trace for xDisplayPort Capability

    WPP_DEFINE_BIT(Cap_Mailbox), //!< Trace for OmniMsg Mailbox Capability

    WPP_DEFINE_BIT(HC_MFD_FPGA), //!< Trace for MFD FPGA Host Controller
};

/*
 * Kernel version compatibilty functions
 */
#if     LINUX_VERSION_CODE < KERNEL_VERSION(5,0,0)
#define	VERIFY_WRITE	1
#define	omnitek_access_ok(op, addr, size)	access_ok(op, (void*)addr, size)
#else
#define	omnitek_access_ok(op, addr, size)	access_ok((void*)addr, size)
#endif

#if ENABLE_DEBUG_PRINT
/**
 * @brief Current debug level for a driver
 */
extern int OT_DebugLevel;
#endif
/**
 * @brief Wrapper for standard logging, should use #KernelTrace instead
 * @param[in] x a parenthesised expression that you would normally send to printf
 */
#if ENABLE_DEBUG_PRINT
#define KernelPrint( x ) { printk( "%s @ %d: ", __FUNCTION__, __LINE__ ) ; printk x ;}
#else
#define KernelPrint( x )
#endif
/**
 * @brief Wrapper for standard logging without any prefix information, should use #KernelTrace instead
 * @param[in] x a parenthesised expression that you would normally send to printf
 */
#if ENABLE_DEBUG_PRINT
#define KernelPrintPlain( x ) printk x
#else
#define KernelPrintPlain( x )
#endif
/**
 * @brief Write some logging with traceability
 */
#if ENABLE_DEBUG_PRINT
#define KernelTrace( Severity, Source, Format, ... ) ({ if ( Severity <= OT_DebugLevel && WPP_DEFINE_BIT(Source) ) printk( #Severity " - " #Source ": %s - %s @ %d: " Format, FILE, __FUNCTION__, __LINE__, __VA_ARGS__  );})
#else
#define KernelTrace( Severity, Source, Format, ... )
#endif
/**
 * @brief Write some logging with traceability but not arguments
 */
#if ENABLE_DEBUG_PRINT
#define KernelTraceNA( Severity, Source, Format, ... ) ({ if ( Severity <= OT_DebugLevel && WPP_DEFINE_BIT(Source) ) printk( #Severity " - " #Source ": %s - %s @ %d: " Format, FILE, __FUNCTION__, __LINE__ );})
#else
#define KernelTraceNA( Severity, Source, Format, ... )
#endif
/**
 * @brief Get the linux class that we will use for all our custom devices
 * @return pointer to the class structure
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,4,0)
const struct class * MANUF_FUNC(_GetClass)( void );
#else
struct class * MANUF_FUNC(_GetClass)( void );
#endif

/**
 * @brief Wrapper for os specific spinlock locking
 */
#define SpinLockAcquire( spinLock ) spin_lock( &(spinLock) )

/**
 * @brief Wrapper for os specific spinlock unlocking
 */
#define SpinLockRelease( spinLock )  spin_unlock( &(spinLock) )

/**
 * @brief Wrapper for os specific spinlock initialisation
 */
#define SpinLockInit( spinlock ) spin_lock_init( spinlock )

/**
 * @brief Wrapper for os specific spinlock cleanup
 */
#define SpinLockDelete( spinlock ) while( 0 )

/** @}*/
