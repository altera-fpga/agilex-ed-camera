/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "hc_omnitek_common.h"
#include "hccommon.h"
#include "Container.h"

#ifdef USE_WPP
#include "trace.h"
#include "AUTOGEN.hc_omnitek_common.tmh"
#endif

int OT_HC_OmniTek_Enumerate( DriverInstanceData * did )
{
    OmniTekCollection * capList = NULL;
    Capability *cap = NULL;
    uint32_t i;
    uint32_t capIdx;
    int status;
    uint32_t interruptNum = 0;

    did->NumInterrupts = 0;

    for( i = 0; i < did->nBars; i++ )
    {
        capList = did->BusInterface.DiscoverCapabilities( &did->hc, did->MemBar[i].pVa, did->MemBar[i].Size, did->MemBar[i].Physical );
        if( capList == NULL )
        {
            KernelTraceNA( TRACE_LEVEL_ERROR, HC_OmniTek, "DiscoverCapabilities: NULL\n" );
        }
        else
        {
            for ( capIdx= 0; capIdx< CollectionCount( capList ); capIdx++ )
            {
                cap = did->BusInterface.GetCapabilityAt( capList, capIdx );
                if( cap->Type == MemMapCap && cap->Ext.MemMap.Type == BarRegion && i == cap->Ext.MemMap.Bar - 1 )
                { // skip a bar if its a memory cap....
                    i++;
                }
            }
        }
    }

    if( capList == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, HC_OmniTek, "DiscoverCapabilities: NULL\n" );
    }
    else
    {
        for ( i = 0; i < CollectionCount( capList ); i++ )
        {
            cap = did->BusInterface.GetCapabilityAt( capList, i );
            if ( cap->Type == InterruptCap )
                did->NumInterrupts++;
        }

        if ( did->NumInterrupts > 0 )
        {
            did->Interrupts = AllocateMemory( sizeof(PCapInterrupt) * did->NumInterrupts, &did->InterruptsMem );
            if ( did->Interrupts == NULL )
            {
                KernelTraceNA( TRACE_LEVEL_ERROR, HC_OmniTek, "Could not allocate memory for interrupts...\n" );
                did->NumInterrupts = 0;
                status = -1;
                return status;
            }
        }

        for ( i = 0; i < CollectionCount( capList ); i++ )
        {
            cap = did->BusInterface.GetCapabilityAt( capList, i );
            if( cap->Type == MemMapCap && cap->Ext.MemMap.Type == BarRegion )
            {
                if ( cap->Ext.MemMap.Bar < did->nBars )
                { // map the kernel virtual address into the memory map structure....
                    cap->Ext.MemMap.VA = did->MemBar[ cap->Ext.MemMap.Bar ].pVa;
                    cap->SupressDriver = FALSE;
                }
            }
            if ( cap->Type == InterruptCap && did->Interrupts != NULL )
            {
                did->Interrupts[ interruptNum++ ] = &cap->Ext.Interrupt;
            }
        }
    }
    status = did->BusInterface.FinaliseCapabilities( &did->hc );
    if ( status != 0 )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, HC_OmniTek, "FinaliseCapabilities: %d\n", status );

        if ( did->Interrupts != NULL )
        {
            did->Interrupts = NULL;
            DeleteMemory( &did->InterruptsMem );
        }
    }
    return status;
}
