/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef CAPABILITYDRIVERBUSINTERFACE_H_
#error "Do not include this file directly"
#endif

#include "CapabilityDriver.h"
#include "Customise.h"


/** \cond */
struct _CapabilityDeviceInterface;
/** \endcond */

/**
 * @brief Get the remove interface on the bus for this capability device
 * To provide a consistent OS independent driver communication model and to reduce
 * Linux kernel namespace pollution this interface fetcher is used for the bulk
 * of capability driver -> bus -> host controller communications
 * @param[in] context The requestee for the interface
 * @param[in,out] interface Pointer to an interface instance that will be filled in by the bus
 * @return 0 on success. -1 on null arguments, -2 on failure to obtain the associated host controller
 */
__must_check int MANUF_FUNC(_GetInterfaceForCapDriver)( POmniTekCapabilityDevice context, struct _CapabilityDeviceInterface * interface );


/*
 * Under linux to inform the kernel that we are able to handle
 * devices on the omnitek bus we need to register our driver
 * as on that bus. So the following 2 functions are required.
 */


/**
 * @brief Attach to OmniTekBus and register with the kernel
 * @param[in, out] capDriver context of the driver we want to register
 * @return return of register_driver kernel call
 */
__must_check int MANUF_FUNC(_capability_driver_register)( POmniTekCapabilityDriver capDriver );

/**
 * @brief Cleanup and detach any bus specific data and unregister from the kernel
 * @param[in, out] capDriver context of the driver to detach
 */
void MANUF_FUNC(_capability_driver_unregister)( POmniTekCapabilityDriver capDriver );

/** @}*/
