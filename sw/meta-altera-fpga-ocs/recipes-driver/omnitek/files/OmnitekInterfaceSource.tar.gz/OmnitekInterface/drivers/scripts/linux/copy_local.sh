#! /bin/bash

# Copyright (C) Altera Corporation
#
# SPDX-License-Identifier: GPL-2.0-only

BINS="RegisterAccess OmniTekBus testApp MDMA VideoFDMA OmniTekFPGADebug MemMap RTVE EventFDMA EyeScanDMA QueryInfo"

DEST=.
if [ $# -eq 1 ]
then
	DEST="${1}"
fi

cp `find ../../ -name \*.ko` "${DEST}"
cp `find ../../ -name \*.so` "${DEST}"

for B in $BINS
do
	for F in `find ../../ -name $B`
	do
		file "$F" | grep -q ELF
		if [ $? == 0 ]
		then
			cp "$F" "${DEST}"
		fi
	done

done
