/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/interrupt.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/scatterlist.h>
#include <linux/dma-mapping.h>


#include "CapabilityDriverBusInterface.h"
#include "CapabilityDevice.h"

#include "capability/RegisterAccess_IOCTL.h"
#include "CapabilityBaseIOCTL.h"

#include "capability/MDMA_IOCTL.h"

#include "OTCapabilityTypes.h"
#include "linux/Event.h"
#include "linux/UserBuffer.h"

#include "DMACommon.h"

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_WARNING;
extern struct device_attribute dev_attr_debuglevel;

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif






void OT_Cap_MDMA_StartNext( struct _CapDevFDOData *fdoData );


#define DefaultMaxTargets 4


#if defined(__arm__) && !defined( CONFIG_ARCH_HAS_SG_CHAIN ) && !defined( ARCH_HAS_SG_CHAIN )
#define DefaultMaxSingleHWTransfer  0xf0000
#else
#if defined(__arm__)
#define DefaultMaxSingleHWTransfer  0x1000000
#else
#define DefaultMaxSingleHWTransfer  0x2000000
#endif
#endif

typedef struct
{
    OmniTekCapabilityDriver Driver;
} OT_Cap_MDMADriver;

typedef struct _CapDevFDOData
{
    POmniTekCapabilityDevice CapDev;
    CapabilityDeviceInterface BusInterface;
    struct cdev CharDev;

    DMAChannel Channel;
    spinlock_t RequestLock;
    GroupedDMATx *ActiveRequest;
    struct list_head PendingQueue;

    struct workqueue_struct *DPCQueue;
    EventList AsyncEvents;
} OT_Cap_MDMADevice;

typedef struct
{
    struct work_struct my_work; // i believe this is not needed for manual manipulation...
    OT_Cap_MDMADevice * fdo;
    uint8_t InterruptSG;
    uint64_t Time;
} DPCData_t;

static int OT_Cap_MDMA_driver_probe( struct device * dev );
static int OT_Cap_MDMA_driver_remove( struct device *dev );

static const DriverMatchId matchIdsTable[ ] = {
    { RegisterCap, RegCap_DMA_DataBiMDMA, 0 },
    { OffsetCap, RegCap_DMA_DataBiMDMA, 0 },
    { }
};

static OT_Cap_MDMADriver OT_Cap_MDMA_driver = {
    .Driver = {
        .FriendlyName = MANUF_DEV("_Cap_MDMA"),
        .IdTable = matchIdsTable,
        .Driver = {
            .name = MANUF_DEV("_Cap_MDMA"),
            .probe = OT_Cap_MDMA_driver_probe,
            .remove = OT_Cap_MDMA_driver_remove,
        },
    },
};

enum
{
    EventTag_DMATransfer = 2,
};


void OT_Cap_MDMA_AbortCleanupChannel( OT_Cap_MDMADevice *fdoData )
{
    GroupedDMATx * request;
    DMAAbortChannel( &fdoData->Channel );

    SpinLockAcquire( fdoData->RequestLock );
    // cleanup pending transactions....
    while( ! list_empty( &fdoData->PendingQueue ) )
    {
        request = list_first_entry( &fdoData->PendingQueue, GroupedDMATx, Next );
        list_del( &request->Next );
        request->Deleted = true;
        SpinLockRelease( fdoData->RequestLock );
        EventCancel( &fdoData->AsyncEvents, request->EventId );
        SpinLockAcquire( fdoData->RequestLock );
    }

    if ( fdoData->ActiveRequest != NULL )
    { // cleanup an active transaction
        request = fdoData->ActiveRequest;
        SpinLockRelease( fdoData->RequestLock );
        EventCancel( &fdoData->AsyncEvents, request->EventId );
        SpinLockAcquire( fdoData->RequestLock );
    }
    SpinLockRelease( fdoData->RequestLock );

}

bool OT_Cap_MDMA_ProgramDMA( DMAChannel *channel, DMATx *pContext )
{
    uint32_t pageIdx;
    int numFragments = 0;
    const uint32_t MaxFragment = channel->MaxFragmentSize;
    const uint32_t MaxSGLElements = channel->MaxSGLElements;
//    const bool Has64BitPADR = channel->Has64BitPADR;
    DMA64BitSGLEntry *sglEntry = ( DMA64BitSGLEntry * )( pContext->SGLBuffer->pVa );
    struct page * thisPage = NULL;
    unsigned int page_len;
    unsigned int page_offset;
    struct scatterlist * cur_scatter = pContext->SGLBuffer->SGTable.sgl;
    dma_addr_t valPADR;
    unsigned int valSIZE;
    uint32_t valLADR = pContext->LocalAddr;
    uint32_t valDPRCtrl = ( ( pContext->WriteDirection == FALSE ) ? DPR_Direction : 0 );
    dma_addr_t valDPRAddr = pContext->SGLBuffer->PhysAddr;

    unsigned int remaining_len = pContext->Size;

    if ( pContext->NextPageIndex > 0 )
    {
        remaining_len -= ( ( 1 << PAGE_SHIFT ) - pContext->MDL.FirstOffset );
        remaining_len -= ( ( 1 << PAGE_SHIFT ) * ( pContext->NextPageIndex - 1 ) );
    }

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Remaining data: 0x%08x\n", remaining_len );

    if ( pContext->NextPageIndex > 0 )
    { // this is a multipart transfer, we need to unmap the previous pages first...
        // we need to tell the unmap routine how many we said we where going to map last time...
        //numFragments = pContext->NumSGMapped;

        // FIXME: Does not unmap any pages. Warning message added to confirm if this ever happens. See ER #83870.
        pr_err_ratelimited("MDMA Multipart Transfer not fully implemented - see ER #83870");
        dma_unmap_sg( channel->Platform.BusInterface->HostControllerDevice, pContext->SGLBuffer->SGTable.sgl, numFragments, pContext->WriteDirection ? DMA_TO_DEVICE : DMA_FROM_DEVICE );
    }

    pageIdx = pContext->NextPageIndex;
    // map the pages we need into the scatterlist;
    for_each_sg( pContext->SGLBuffer->SGTable.sgl, cur_scatter, MaxSGLElements, numFragments )
    {
        thisPage = pContext->MDL.Pages[ pageIdx ];
        page_offset = 0;
        if( pageIdx == 0 )
            page_offset = pContext->MDL.FirstOffset;

        page_len = ( 1 << PAGE_SHIFT ) - page_offset;
        if (remaining_len < page_len)
        {
            page_len = remaining_len;
        }
        remaining_len -= page_len;

        sg_set_page( cur_scatter, thisPage, page_len, page_offset );

        pageIdx++;
        if ( remaining_len == 0  )
        {
            numFragments++;
            break;
        }
    }

    pContext->SGLBuffer->NumElements = 0;
    pContext->NumSGMapped = 0;
    pContext->NumActualSGMapped = dma_map_sg( channel->Platform.BusInterface->HostControllerDevice, pContext->SGLBuffer->SGTable.sgl, numFragments, pContext->WriteDirection ? DMA_TO_DEVICE : DMA_FROM_DEVICE );
    if( pContext->NumActualSGMapped < 0 )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "dma_map_sg failed. code 0x%08x\n", pContext->NumActualSGMapped );
        // TODO: blow up somehow.
        return FALSE;
    }
    pContext->NumSGMapped = numFragments;

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Expected fragments %u, mapped %u\n", pContext->NumSGMapped, pContext->NumActualSGMapped );

    cur_scatter = (pContext->SGLBuffer->SGTable.sgl);
    valPADR = sg_dma_address( cur_scatter );
    valSIZE = sg_dma_len( cur_scatter );
//    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "sgl %u. address: 0x%016x, len: 0x%08x\n", 0, valPADR, valSIZE );

    // now create the sgl for the hardware
    // even thought each original entry is no more than 1 page, the dma_map_sg may override this and give use huge contigious segments

    for ( numFragments = 0; numFragments < (pContext->NumActualSGMapped); )
    {
        if ( pContext->SGLBuffer->NumElements >= MaxSGLElements )
        {
            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "Failed to create sgl, too many elements\n" );
            return FALSE;
        }

        // update where the next sgl entry would be
        valDPRAddr += sizeof(DMA64BitSGLEntry);

        sglEntry->PADR = valPADR;

        if( numFragments == ( pContext->NumActualSGMapped - 1 ) && valSIZE <= MaxFragment )
        { // end of chain...
            valDPRCtrl |= DPR_EndOfChain | DPR_InterruptAfterTransfer; // Last entry - mark as last and interrupt
        }

        sglEntry->DPR = valDPRAddr;
        sglEntry->DPR_LOW |= valDPRCtrl;

        sglEntry->LADR_LOW = valLADR;
        sglEntry->LADR_HIGH = 0;

        sglEntry->SIZE_HIGH = 0;
        sglEntry->SIZE_LOW = valSIZE;
        if ( valSIZE > MaxFragment )
            sglEntry->SIZE_LOW = MaxFragment;

        if( pContext->SGLBuffer->NumElements == 0 || ( numFragments == ( pContext->NumActualSGMapped - 1 ) && valSIZE <= MaxFragment ) )
            KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "SGL[%d]. PADR: %08x%08x, LADR: %08x%08x, DPR: %08x%08x, SIZE: %08x%08x\n", pContext->SGLBuffer->NumElements, sglEntry->PADR_HIGH, sglEntry->PADR_LOW, sglEntry->LADR_HIGH, sglEntry->LADR_LOW, sglEntry->DPR_HIGH, sglEntry->DPR_LOW, sglEntry->SIZE_HIGH, sglEntry->SIZE_LOW);

        if ( valSIZE > MaxFragment )
        {
            valLADR+= MaxFragment;
            valSIZE -= MaxFragment;
            valPADR += MaxFragment;
            KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_MDMA, "this fragment is bigger than the largest we allow so use previouse info\n" );
        }
        else
        {
            valLADR += valSIZE;
            numFragments++;
            cur_scatter = sg_next(cur_scatter);

            if ( numFragments < pContext->NumActualSGMapped )
            {
                valPADR = sg_dma_address( cur_scatter );
                valSIZE = sg_dma_len( cur_scatter );
            }
        }

        pContext->SGLBuffer->NumElements++;
        sglEntry++;
    }
    // next time we need to start from somewhere else....
    pContext->NextPageIndex = pageIdx;
    // update the ladr too...
    pContext->LocalAddr = valLADR;

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Total Elements %u\n", pContext->SGLBuffer->NumElements );

    return TRUE;
}

void OT_Cap_MDMA_CleanupChannel( OT_Cap_MDMADevice *fdoData )
{
    uint32_t i;
    DMASGLBuffer *sglBuf = NULL;
    DMAChannel *channel = &fdoData->Channel;
    struct device * hcd = channel->Platform.BusInterface->HostControllerDevice;

    OT_Cap_MDMA_AbortCleanupChannel( fdoData );

    if ( channel->SGLBuffers != NULL )
    {
        for ( i = 0; i < channel->MaxTargets; i++ )
        {
            sglBuf = &channel->SGLBuffers[i];

            sg_free_table( &sglBuf->SGTable );
            if ( sglBuf->pVa != NULL )
            {
                dma_free_coherent( hcd, sglBuf->Size, sglBuf->pVa, sglBuf->PhysAddr );
                sglBuf->pVa = NULL;
            }
        }
        DeleteMemory( &channel->Platform.SGLBuffersMemory );
        channel->SGLBuffers = NULL;
    }
}


int OT_Cap_MDMA_InitChannel( OT_Cap_MDMADevice *fdoData, struct device * device )
{
    uint32_t i;
    uint32_t Cap = 0;
    DMASGLBuffer *sglBuf = NULL;
    int status=0;
    DMAChannel *channel = &fdoData->Channel;
    struct device * hcd = channel->Platform.BusInterface->HostControllerDevice;

    channel->MaxFragmentSize = 0x7FFFF8;

    // determine what type of dma we are using, is it 32 bit, part 64 or full 64 bit.
    channel->Has64BitPADR = false;
    channel->Has64BitLADR = false;
    if( GetRegCap( fdoData->BusInterface.Device->CapInfo ).Version < 3 )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "DMA core is too old, we don't support it\n");
        return STATUS_BAD_DMA_CHANNEL;
    }

    DMAAbortChannel( channel );

    DMAReadReg( channel, DMACapReg, &Cap );
    if( Cap & CapReg_64BitPADR )
    {
        KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Channel reports 64 Bit PADR/DPR\n");
        channel->Has64BitPADR = true;
    }
    if( Cap & CapReg_64BitLADR )
    {
        KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Channel reports 64 Bit LADR - not supported yet...\n");
        channel->Has64BitLADR = true;
    }

    // TODO: make this able to be set via a param...
    channel->MaxSingleHWTransfer = DefaultMaxSingleHWTransfer;
    channel->MaxTargets = DefaultMaxTargets;

    fdoData->ActiveRequest = NULL;
    INIT_LIST_HEAD( &fdoData->PendingQueue );

    channel->SGLBuffers = AllocateMemory( sizeof( DMASGLBuffer ) * channel->MaxTargets, &channel->Platform.SGLBuffersMemory );
    if ( channel->SGLBuffers == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_FATAL, Cap_MDMA, "AllocateMemory failed to allocate array for common buffers\n" );
        return -ENOMEM;
    }

    // need the +1 as the first page may not be aligned...
    channel->MaxSGLElements = ( channel->MaxSingleHWTransfer / PAGE_SIZE ) + 1;

    // create a common buffer PER possible target
    for ( i = 0; status == 0  && i < channel->MaxTargets; i++ )
    {
        sglBuf = &channel->SGLBuffers[i];
        sglBuf->Size = channel->MaxSGLElements * sizeof( DMA64BitSGLEntry );

        // allocate the linux sg_table now so that we need not care on each transaction. we can just keep using this...
        status = sg_alloc_table( &sglBuf->SGTable, channel->MaxSGLElements, GFP_KERNEL );
        if ( status != 0 )
        {
            KernelTrace( TRACE_LEVEL_FATAL, Cap_MDMA, "We cannot create a sg_table to allow for %u pages\n", channel->MaxSGLElements );
            continue;
        }

        // now actually allocate memory for the hardware sg list
        sglBuf->pVa = dma_alloc_coherent( hcd, sglBuf->Size, &( sglBuf->PhysAddr ), GFP_KERNEL );
        if( channel->SGLBuffers[i].pVa == NULL )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_MDMA, "dma_alloc_coherent failed (size %#x)\n", sglBuf->Size );
            status = -ENOMEM;
        }
    }

    if ( status != 0 )
    {
        for ( i = 0; i < channel->MaxTargets; i++ )
        {
            sglBuf = &channel->SGLBuffers[i];

            sg_free_table( &sglBuf->SGTable );
            if ( sglBuf->pVa != NULL )
            {
                dma_free_coherent( hcd, sglBuf->Size, sglBuf->pVa, sglBuf->PhysAddr );
                sglBuf->pVa = NULL;
            }
        }
        DeleteMemory( &channel->Platform.SGLBuffersMemory );
        channel->SGLBuffers = NULL;
    }
    return 0;
}

void OT_Cap_MDMA_ProcessChannelInterrupt( OT_Cap_MDMADevice *fdoData, uint64_t isrTime )
{
    uint32_t i;
    GroupedDMATx *request;
    bool CompleteRequest = TRUE;
    uint32_t TotalElements = 0;
    uint32_t firstIndex = fdoData->Channel.MaxTargets;
    uint32_t prevIndex = 0;
    bool writeDir = FALSE;

    SpinLockAcquire( fdoData->RequestLock );
    request = fdoData->ActiveRequest;

    KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_MDMA, "INTERRUPT\n" );

    if ( request != NULL )
    {
        for ( i = 0; i < request->NumTxs; i++ )
        {
            KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Tx target %u previously completed ? %s\n", request->Txs[i].TargetId, request->Txs[i].Completed ? "Yes" : "No" );

            if ( ! request->Txs[i].Completed )
            {
                KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "NextPageIndex: %u, NumPages: %u\n", request->Txs[i].NextPageIndex , request->Txs[i].MDL.NumPages );
                if ( request->Txs[i].NextPageIndex == request->Txs[i].MDL.NumPages )
                {
                    // this one is done!
                    request->Txs[i].Completed = TRUE;
                    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Tx target %u completed...\n", request->Txs[i].TargetId );
                }
                else
                {
                    CompleteRequest = FALSE;
                    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Tx target %u still data pending...\n", request->Txs[i].TargetId );
                }
            }
        }


        if( ! CompleteRequest )
        {
            for ( i = 0; i < request->NumTxs; i++ )
            {
                if ( ! request->Txs[i].Completed )
                {
                    if ( OT_Cap_MDMA_ProgramDMA( &fdoData->Channel, &request->Txs[i] ) == FALSE )
                    {
                        pr_err_ratelimited("MDMA failed to program DMA after interrupt - see ER #83872");
                    }
                    else
                    {
                        TotalElements+= request->Txs[i].SGLBuffer->NumElements;
                        if ( firstIndex != fdoData->Channel.MaxTargets )
                        {
                            KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Joining %u to %u\n", prevIndex, i );
                            DMAJoinSgl( &fdoData->Channel.SGLBuffers[prevIndex], request->Txs[i].SGLBuffer, FALSE, FALSE );
                        }
                        else
                        {
                            firstIndex = request->Txs[i].TargetId;
                            writeDir = request->Txs[i].WriteDirection;
                        }
                        prevIndex = request->Txs[i].TargetId;
                    }
                }
            }

            DMATransactionStart( &fdoData->Channel, TotalElements, writeDir , fdoData->Channel.SGLBuffers[firstIndex].PhysAddr );
            SpinLockRelease( fdoData->RequestLock );
        }
        else
        {
            fdoData->ActiveRequest = NULL;
            SpinLockRelease( fdoData->RequestLock );

            request->EndTime = isrTime;
            EventComplete( &fdoData->AsyncEvents, request->EventId, NULL, false );

            OT_Cap_MDMA_StartNext( fdoData );
        }
    }
    else
    {
        SpinLockRelease( fdoData->RequestLock );
    }

    fdoData->Channel.PreviousISRTime = isrTime;
}

void OT_Cap_MDMA_EventComplete_DMATransfer( void * context, void *secondContext, bool fromUserContext )
{
    GroupedDMATx *pTransaction = context;
    struct _CapDevFDOData * fdoData  = pTransaction->ChannelFDO;

    KernelTraceNA( TRACE_LEVEL_INFORMATION, DMACommon, "Transaction completed\n" );

    CopyToUserPages( pTransaction->ioctlContext, &pTransaction->StartTime, sizeof( pTransaction->StartTime ), offsetof( DMATransaction_IOCTL_Linux, IOCTLInfo.Dma.StartTime ), fromUserContext );
    CopyToUserPages( pTransaction->ioctlContext, &pTransaction->EndTime, sizeof( pTransaction->EndTime ), offsetof( DMATransaction_IOCTL_Linux, IOCTLInfo.Dma.EndTime ), fromUserContext );

    CleanUserPages( pTransaction->ioctlContext );
    kfree( pTransaction->ioctlContext );
    DMAGroupedDMATxCleanup( pTransaction, fdoData->BusInterface.HostControllerDevice );
}

void OT_Cap_MDMA_EventCancel_DMATransfer( void * context )
{
    GroupedDMATx *pTransaction = context;
    struct _CapDevFDOData * fdoData  = pTransaction->ChannelFDO;

    KernelTraceNA( TRACE_LEVEL_INFORMATION, DMACommon, "Cancel \n" );

    SpinLockAcquire( fdoData->RequestLock );
    if ( fdoData->ActiveRequest == pTransaction )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, DMACommon, "Cancel - was active \n" );
        DMAAbortChannel( &fdoData->Channel );
        fdoData->ActiveRequest = NULL;
        SpinLockRelease( fdoData->RequestLock );
        OT_Cap_MDMA_StartNext( fdoData );
    }
    else
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, DMACommon, "Cancel - Was in queue\n" );

        if ( ! pTransaction->Deleted )
            list_del( &pTransaction->Next );
        pTransaction->Deleted = true;
        SpinLockRelease( fdoData->RequestLock );
    }

    CleanUserPages( pTransaction->ioctlContext );
    kfree( pTransaction->ioctlContext );
    DMAGroupedDMATxCleanup( pTransaction, fdoData->BusInterface.HostControllerDevice );
}




void OT_Cap_MDMA_StartNext( OT_Cap_MDMADevice *fdoData )
{
    uint32_t i;
    uint32_t totalElements = 0;

    SpinLockAcquire( fdoData->RequestLock );

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Active TX? 0x%p\n", fdoData->ActiveRequest );
    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Pending queue empty? %s\n", list_empty( &fdoData->PendingQueue )  ? "Yes" : "No" );

    if ( ( fdoData->ActiveRequest == NULL ) && ( ! list_empty( &fdoData->PendingQueue ) ) )
    {
        // get next time
        GroupedDMATx *request = list_first_entry( &fdoData->PendingQueue, GroupedDMATx, Next );
        // remove from list
        if ( !request->Deleted )
            list_del( &request->Next );
        request->Deleted = true;
        // set as active
        fdoData->ActiveRequest = request;
        request->Active = true;

        // set the sgl buffers and program the first chunks
        for ( i = 0; i < request->NumTxs; i++ )
        {
           request->Txs[i].SGLBuffer = &fdoData->Channel.SGLBuffers[i];
           request->Txs[i].TargetId = i;

           KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Assigned target %u to sgl %u\n", i, i );

           if ( OT_Cap_MDMA_ProgramDMA( &fdoData->Channel, &request->Txs[i] ) == FALSE )
           {
               pr_err_ratelimited("MDMA failed to program DMA - see ER #83872");
           }

           totalElements+= request->Txs[i].SGLBuffer->NumElements;

           if ( i != 0 )
           { // must be a group of targets, lets join them
               KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Joining %u to %u\n", i-1, i );
               DMAJoinSgl( request->Txs[i-1].SGLBuffer, request->Txs[i].SGLBuffer, FALSE, FALSE );
           }
        }

        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Total elements to transfer %u\n", totalElements );

        // hit the go button!!!
        fdoData->BusInterface.TimerGetTime( fdoData->BusInterface.Device, &request->StartTime );
        DMATransactionStart( &fdoData->Channel, totalElements, request->Txs[0].WriteDirection, fdoData->Channel.SGLBuffers[0].PhysAddr );
    }
    SpinLockRelease( fdoData->RequestLock );
}

long OT_Cap_MDMA_unlocked_ioctl( struct file *filp, unsigned int cmd, unsigned long arg )
{
    long retval = -ENOTTY;
    OT_Cap_MDMADevice *fdoData = container_of( filp->f_path.dentry->d_inode->i_cdev, OT_Cap_MDMADevice, CharDev );
    if( fdoData != NULL )
    {
        switch( cmd )
        {
            case CAP_RA_IOCTL_GetBlockCount:
            case CAP_RA_IOCTL_GetRegisterCount:
            case CAP_RA_IOCTL_RegisterRead:
            case CAP_RA_IOCTL_RegisterShadowRead:
            case CAP_RA_IOCTL_RegisterWrite:
            case CAP_RA_IOCTL_GetMetaData:
                retval =  ProcessCapabilityBaseIOCTL( &GetRegCap( fdoData->CapDev->CapInfo ), &fdoData->BusInterface, arg, cmd );
                break;
            case CAP_COMMON_IOCTL_QueryInfo:
            {
                CapCommon_QueryInfo_IOCTL inData;
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_COMMON_IOCTL_QueryInfo_Version
                        {
                            retval = 0;
                            switch ( inData.Key )
                            {
                                case QueryInfo_CapabilityId:
                                    inData.Value = fdoData->CapDev->Id;
                                    break;
                                case QueryInfo_RegisterUniqueID:
                                case QueryInfo_RegisterAssociationID:
                                case QueryInfo_RegisterVersionId:
                                case QueryInfo_TimerGetTime:
                                case QueryInfo_TimerGetFrequency:
                                case QueryInfo_RegisterPhysAddr:
                                    retval = ProcessCommon_QueryInfo_Register( fdoData->CapDev->CapInfo, &fdoData->BusInterface, &inData );
                                    break;
                                case QueryInfo_DMASupported:
                                	inData.Value = DmaType_Standard;
                                	break;
                                case QueryInfo_DMADirectionRead:
                                case QueryInfo_DMADirectionWrite:
                                    inData.Value = true;
                                    break;
                                case QueryInfo_DMAEventsSupported:
                                    inData.Value = false;
                                    break;
                                case QueryInfo_DMAMaxSingleHWTransfer:
                                    inData.Value = fdoData->Channel.MaxSingleHWTransfer;
                                    break;
                                case QueryInfo_DMAMaxTargets:
                                    inData.Value = fdoData->Channel.MaxTargets;
                                    break;
                                case QueryInfo_DMAMinTransferBytes: // this will be used....
                                default:
                                    retval = -EINVAL;
                                    break;
                            }

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_MDMA, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_COMMON_IOCTL_QueryInfo_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_MDMA, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            case CAP_MDMA_IOCTL_Transfer:
            {
                unsigned long dataSize = sizeof( DMATransaction_IOCTL_Linux );
                DMATransaction_IOCTL_Linux *ioctlData = kzalloc( dataSize, GFP_KERNEL );
                if ( ioctlData == NULL )
                {
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_MDMA, "kzalloc  failed with size: 0x%08lx\n", dataSize );
                    retval = -ENOMEM;
                    break;
                }

                if( omnitek_access_ok( VERIFY_WRITE, arg, dataSize ) )
                {
                    if ( copy_from_user( ioctlData, ( void * )arg, dataSize ) != 0 )
                    {
                        kfree( ioctlData );
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_from_user failed with size: 0x%08lx\n", dataSize );
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( ioctlData->IOCTLInfo.Version )
                    {
                        case CAP_MDMA_IOCTL_Transfer_Version0:
                        {
                            CommonTransferContext *ioctlContext = NULL;
                            EventItem * newEvent = NULL;
                            // now we can get the rest of the data....
                            dataSize += ( ioctlData->IOCTLInfo.Dma.nTargets * sizeof( DmaTarget ) );

                            if ( ioctlData->IOCTLInfo.Dma.nTargets < 1 || ioctlData->IOCTLInfo.Dma.nTargets > fdoData->Channel.MaxTargets )
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_MDMA, "Invalid number of targets. Given %u, min %u, max %u\n", ioctlData->IOCTLInfo.Dma.nTargets, 1, fdoData->Channel.MaxTargets );
                                retval = -EACCES;
                                kfree( ioctlData );
                                break;
                            }

                            kfree( ioctlData );
                            ioctlData = kzalloc( dataSize, GFP_KERNEL );
                            if ( ioctlData == NULL )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_MDMA, "kzalloc  failed with size: 0x%08lx\n", dataSize );
                                retval = -ENOMEM;
                                break;
                            }

                            if ( copy_from_user( ioctlData, ( void * )arg, dataSize ) != 0 )
                            {
                                kfree( ioctlData );
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_from_user failed with size: 0x%08lx\n", dataSize );
                                retval = -ENOMEM;
                                break;
                            }

                            /* Repeated check in case initial part of ioctlData changed since last time */
                            if ( ioctlData->IOCTLInfo.Dma.nTargets < 1 || ioctlData->IOCTLInfo.Dma.nTargets > fdoData->Channel.MaxTargets )
                            {
                                KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_MDMA, "Invalid number of targets, unexpected change of user data\n" );
                                retval = -EACCES;
                                kfree( ioctlData );
                                break;
                            }

                            ioctlContext = kzalloc( sizeof(CommonTransferContext), GFP_KERNEL );
                            if ( ioctlContext == NULL )
                            {
                                kfree( ioctlData );
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA,"Couldn't allocate transaction context\n" );
                                retval = -ENOMEM;
                                break;
                            }

                            retval = MapUserPages( arg, dataSize, ioctlContext );
                            if ( retval != 0 )
                            {
                                CleanUserPages( ioctlContext );
                                kfree( ioctlContext );
                                kfree( ioctlData );
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA,"Couldn't map user ioctl pages\n" );
                                break;
                            }

                            KernelTrace( TRACE_LEVEL_INFORMATION, Cap_MDMA, "nTargets: %d, Targets[0].pVa: %p, Targets[0].Size: 0x%08x\n", ioctlData->IOCTLInfo.Dma.nTargets, ioctlData->IOCTLInfo.Dma.Targets[0].DUMMYUNIONNAME.pVa, ioctlData->IOCTLInfo.Dma.Targets[0].Size );

                            newEvent = EventPrepare( &(fdoData->AsyncEvents), &(ioctlData->EventInfo), EventTag_DMATransfer, NULL, OT_Cap_MDMA_EventComplete_DMATransfer, OT_Cap_MDMA_EventCancel_DMATransfer );
                            if ( newEvent != NULL )
                            {
                                GroupedDMATx *pTransaction = NULL;
                                int result = 0;

                                // Disable the nosync from the streaming dma's
                                int targetNum = 0;
                                for( targetNum = 0; targetNum < ioctlData->IOCTLInfo.Dma.nTargets; targetNum++ )
                                    ioctlData->IOCTLInfo.Dma.Targets[ targetNum ].bNoSync = 0;

                                KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_MDMA,"Creating transaction\n" );

                                result = DMAPreForward( &pTransaction, &ioctlData->IOCTLInfo );
                                if( unlikely(result) )
                                {
                                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA,"Couldn't create transaction!\n" );
                                    EventCleanAllocated( newEvent );
                                    retval = -EAGAIN;
                                }
                                else
                                {
                                    newEvent->IOCTLContext = (void *)pTransaction;
                                    EventAddAllocated( &(fdoData->AsyncEvents), newEvent );

                                    pTransaction->EventId = newEvent->Id;
                                    pTransaction->ioctlContext = ioctlContext;
                                    pTransaction->ChannelFDO = fdoData;
                                    pTransaction->FilePointer = filp;

                                    SpinLockAcquire( fdoData->RequestLock );
                                    list_add_tail( &pTransaction->Next, &fdoData->PendingQueue );
                                    SpinLockRelease( fdoData->RequestLock );

                                    retval = 0;
                                    if ( copy_to_user( ( void * )arg, ioctlData, dataSize ) != 0 )
                                    {
                                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_to_user failed\n");
                                        retval = -ENOMEM;
                                        list_del( &pTransaction->Next );
                                        CleanUserPages( ioctlContext );
                                        kfree( ioctlContext );
                                        ioctlContext = NULL;
                                        kfree( ioctlData );
                                        ioctlData = NULL;
                                        break;
                                    }

                                    OT_Cap_MDMA_StartNext( fdoData );
                                }
                            }
                            else
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "Failed to create a new event...\n");
                                retval = -ENOMEM;
                            }

                            if ( retval != 0 && ioctlContext != NULL )
                            {
                                KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Failed in some other way...\n");
                                CleanUserPages( ioctlContext );
                                kfree( ioctlContext );
                                ioctlContext = NULL;
                            }
                            kfree( ioctlData );

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_MDMA,  "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), ioctlData->IOCTLInfo.Version );
                            ioctlData->IOCTLInfo.Version = CAP_MDMA_IOCTL_Transfer_Version0;
                            if ( copy_to_user( ( void * )arg, ioctlData, sizeof( DMATransaction_IOCTL_Linux ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                            kfree( ioctlData );
                        }
                    }
                }
                else
                {
                    kfree( ioctlData );
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_MDMA, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                    break;
                }
                break;
            }
            case CAP_COMMON_IOCTL_Cancel:
            {
                CapGeneral_Cancel_IOCTL inData;

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( CapGeneral_Cancel_IOCTL * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_COMMON_IOCTL_Cancel_Version
                        {
                            if ( EventCancel( &(fdoData->AsyncEvents), inData.EventInfo.EventID ) )
                            {
                                retval = 0;
                                KernelTrace( TRACE_LEVEL_VERBOSE, Cap_MDMA, "Canceled event 0x%016llx\n", inData.EventInfo.EventID );
                            }
                            else
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_MDMA, "Failed to cancel event 0x%016llx\n", inData.EventInfo.EventID);
                                retval = -ENOMEM;
                            }
                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_MDMA, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_COMMON_IOCTL_Cancel_Version;
                            if ( copy_to_user( ( CapGeneral_Cancel_IOCTL * )arg, &inData, sizeof( CapGeneral_Cancel_IOCTL ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_MDMA, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_MDMA, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            default:
                KernelTrace( TRACE_LEVEL_WARNING, Cap_MDMA, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unhandled in switch\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                break;
        }
    }
    else
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_MDMA, "Device Not Found!!!\n" );
    }
    return retval;
}

int OT_Cap_MDMA_FileClosed(struct inode * node, struct file * filp)
{
    GroupedDMATx * request = NULL;
    struct list_head *list = NULL;
    struct list_head cancelQueue;
    OT_Cap_MDMADevice *fdoData = container_of( filp->f_path.dentry->d_inode->i_cdev, OT_Cap_MDMADevice, CharDev );
    INIT_LIST_HEAD( &(cancelQueue) );

    SpinLockAcquire( fdoData->RequestLock );
    list_for_each( list, &(fdoData->PendingQueue) )
    {
        request = list_entry( list, GroupedDMATx, Next );
        if( request->FilePointer == filp )
        {
            request->Deleted = true;
            list_del( &request->Next );
            list_add( &request->Next, &cancelQueue );
        }
    }
    SpinLockRelease( fdoData->RequestLock );

    list_for_each( list, &(cancelQueue) )
    {
        request = list_entry( list, GroupedDMATx, Next );
        EventCancel( &fdoData->AsyncEvents, request->EventId );
    }

    SpinLockAcquire( fdoData->RequestLock );
    if ( ( fdoData->ActiveRequest != NULL ) && ( fdoData->ActiveRequest->FilePointer == filp )  )
    { // cleanup an active transaction
        request = fdoData->ActiveRequest;
        SpinLockRelease( fdoData->RequestLock );
        EventCancel( &fdoData->AsyncEvents, request->EventId );
    }
    else
    {
        SpinLockRelease( fdoData->RequestLock );
    }

    return 0;
}

const struct file_operations OT_Cap_MDMA_device_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = OT_Cap_MDMA_unlocked_ioctl,
    .release = OT_Cap_MDMA_FileClosed,
};

static void OT_Cap_MDMA_DPC( struct work_struct *work )
{
    DPCData_t * dpcData = (DPCData_t *)work;
    OT_Cap_MDMADevice *fdoData = dpcData->fdo;

    if ( dpcData->InterruptSG > 0 )
    {
        OT_Cap_MDMA_ProcessChannelInterrupt( fdoData, dpcData->Time );
    }

    kfree( work );
}

bool OT_Cap_MDMA_ISR( POmniTekCapabilityDevice context, uint64_t isrTime )
{
    uint32_t readValue = 0;
    OT_Cap_MDMADevice *fdoData = NULL;
    fdoData = dev_get_drvdata( &(context->Device) );

    if ( unlikely( fdoData == NULL ) )
    {
        return false;
    }

    DMAReadReg( &fdoData->Channel, DMACSR, &readValue );
    if ( readValue & CSR_SGInterruptStatus )
    {
        DPCData_t * work = (DPCData_t *)kmalloc(sizeof(DPCData_t), GFP_ATOMIC);
        if ( work == NULL )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_MDMA, "Could not allocate memory for DPC!!!\n");
        }
        else
        {
            INIT_WORK( (struct work_struct *)work, OT_Cap_MDMA_DPC );
            work->fdo = fdoData;
            work->InterruptSG = 1;
            work->Time = isrTime;
            queue_work( fdoData->DPCQueue, (struct work_struct *)work );
        }

        DMAWriteReg( &fdoData->Channel, DMACSR, readValue );

        return true;
    }
    return false;
}

static int OT_Cap_MDMA_driver_probe( struct device * dev )
{
    POmniTekCapabilityDevice fullDev = NULL;
    OT_Cap_MDMADevice *fdoData = NULL;
    int result = 0;
    u32 k;
    u32 block;
    u32 reg;
    char wqName[10] = {0,};

    fullDev = ToOmniTekCapabilityDevice( dev );

    fdoData = kzalloc( sizeof(OT_Cap_MDMADevice), GFP_KERNEL );
    if( fdoData )
    {
        fdoData->CapDev = fullDev;
        result = MANUF_FUNC(_GetInterfaceForCapDriver)( fdoData->CapDev, &fdoData->BusInterface );
        if (result != 0 )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_MDMA, "Could not Get interface: %d\n", result );
            goto probe_failure_OmniTek_GetInterfaceForCapDriver;
        }

        result = device_create_file( dev, &dev_attr_debuglevel );
        if( result )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_MDMA, "can't create sysfs debuglevel file!!!\n" );
            goto probe_failure_device_create_file;
        }

        SpinLockInit( &fdoData->RequestLock );

        EventListInit( &fdoData->AsyncEvents );

        // Initialise a char device
        cdev_init( &( fdoData->CharDev ), &OT_Cap_MDMA_device_fops );
        fdoData->CharDev.owner = THIS_MODULE;

        // actually add the char device
        result = cdev_add( &fdoData->CharDev, fdoData->BusInterface.Device->CharDevNum, 1 );
        if( result )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_MDMA, "Could not create char device. code: %d\n", result);
            goto probe_failure_cdev_add;
        }

        if ( NULL == device_create( MANUF_FUNC(_GetClass)(), dev, fdoData->BusInterface.Device->CharDevNum, NULL, MANUF_DEV("_Cap_MDMA_%02d_%03d"), SlotIdFromChildId( fullDev->Id ) , BasicChildId( fullDev->Id ) ) )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_MDMA, "Failed to create dev entry\n" );
            result = -ENOMEM;
            goto probe_failure_device_create;
        }
        snprintf( fullDev->DeviceAccessName, MAX_FILEPATH_LEN, "/dev/"MANUF_DEV("_Cap_MDMA_%02d_%03d"), SlotIdFromChildId( fullDev->Id ) , BasicChildId( fullDev->Id ) );

        k = 0;
        for ( block = 0; block < GetRegCap( fullDev->CapInfo ).NumBlocks && k < NumDMARegisters; block++ )
        {
            for ( reg = 0; reg < GetRegCap( fullDev->CapInfo ).Blocks[block].Count && k < NumDMARegisters; reg++ )
            {
                fdoData->Channel.Platform.RegMap[k].Block = &(GetRegCap( fullDev->CapInfo ).Blocks[block]);
                fdoData->Channel.Platform.RegMap[k++].Reg = reg;
            }
        }

        snprintf( wqName, 10, MANUF_DEV("%02d%03d"), SlotIdFromChildId( fullDev->Id ) , BasicChildId( fullDev->Id ) );
        fdoData->DPCQueue = create_singlethread_workqueue( wqName );
        if( fdoData->DPCQueue == NULL )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_MDMA, "create_singlethread_workqueue failure\n");
            goto probe_failure_create_singlethread_workqueue;
        }

        fdoData->Channel.Platform.BusInterface = &fdoData->BusInterface;
        result = OT_Cap_MDMA_InitChannel( fdoData, dev );
        if ( result != 0 )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_MDMA, "DmaInit. code: %d\n", result);
            goto probe_failure_InitChannel;
        }
        fdoData->BusInterface.RegisterISRCallback( fullDev, OT_Cap_MDMA_ISR );
        dev_set_drvdata( dev, fdoData );
    }
    else
    {
        result = -ENOMEM;
    }
    goto probe_success;


probe_failure_InitChannel:
    destroy_workqueue( fdoData->DPCQueue );

probe_failure_create_singlethread_workqueue:
    device_destroy( MANUF_FUNC(_GetClass)(), fdoData->BusInterface.Device->CharDevNum );

probe_failure_device_create:
    cdev_del( &fdoData->CharDev );

probe_failure_cdev_add:
device_remove_file( dev, &dev_attr_debuglevel );
probe_failure_device_create_file:
probe_failure_OmniTek_GetInterfaceForCapDriver:
    kfree( fdoData );

probe_success:
    return result;
}

static int OT_Cap_MDMA_driver_remove( struct device *dev )
{
    OT_Cap_MDMADevice * fdoData = NULL;

    fdoData = dev_get_drvdata( dev );
    if( fdoData != NULL )
    {
        fdoData->BusInterface.DeRegisterISRCallback( fdoData->CapDev );

        OT_Cap_MDMA_CleanupChannel( fdoData );

        EventListClean( &fdoData->AsyncEvents );

        if ( fdoData->DPCQueue != NULL )
        {
            flush_workqueue( fdoData->DPCQueue );
            destroy_workqueue( fdoData->DPCQueue );
        }

        device_remove_file( dev, &dev_attr_debuglevel );
        device_destroy( MANUF_FUNC(_GetClass)(), fdoData->BusInterface.Device->CharDevNum );

        dev_set_drvdata( dev, NULL );
        cdev_del( &fdoData->CharDev );
        kfree( fdoData );
        return 0;
    }
    return -1;
}

int OT_Cap_MDMA_init( void )
{
    int result = 0;

    // tell the bus that we exist and will control some devices
    result = MANUF_FUNC(_capability_driver_register)( &OT_Cap_MDMA_driver.Driver );

    return result;
}

void OT_Cap_MDMA_cleanup( void )
{
    // tell the bus that this driver is gone
    MANUF_FUNC(_capability_driver_unregister)( &OT_Cap_MDMA_driver.Driver );
}

module_init( OT_Cap_MDMA_init );
module_exit( OT_Cap_MDMA_cleanup );
