/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef REGISTERACCESS_IOCTL_H_
#error "Do not include this directly."
#endif

#include <linux/ioctl.h>

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/**
 * @brief Current #CAP_RA_IOCTL_GetRegisterCount CapRA_Count_IOCTL::Version number to use
 */
#define CAP_RA_IOCTL_GetRegisterCount_Version 0

/**
 * @brief Current #CAP_RA_IOCTL_GetBlockCount CapRA_Count_IOCTL::Version number to use
 */
#define CAP_RA_IOCTL_GetBlockCount_Version 0

/**
 * @brief Current #CAP_RA_IOCTL_RegisterRead CapRA_Register_IOCTL::Version number to use
 */
#define CAP_RA_IOCTL_RegisterRead_Version 0

/**
 * @brief Current #CAP_RA_IOCTL_RegisterWrite CapRA_Register_IOCTL::Version number to use
 */
#define CAP_RA_IOCTL_RegisterWrite_Version 0

/**
 * @brief Current #CAP_RA_IOCTL_RegisterShadowRead CapRA_Register_IOCTL::Version number to use
 */
#define CAP_RA_IOCTL_RegisterShadowRead_Version 0

/**
 * @brief Current #CAP_RA_IOCTL_GetMetaData CapRA_GetMetaData_IOCTL::Version number to use
 */
#define CAP_RA_IOCTL_GetMetaData_Version 0


/**
 * @brief IOCTL on OT_Cap_RegisterAccess devices for obtaining the number of registers within a block
 * Passed and received data type is CapRA_Count_IOCTL
 */
#define CAP_RA_IOCTL_GetRegisterCount   _IOWR( CAP_RA_IOC_MAGIC, CAP_RA_IOCTL_NUM_GetRegisterCount, CapRA_Count_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_RegisterAccess devices for obtaining the number of register blocks
 * Passed and received data type is CapRA_Count_IOCTL
 */
#define CAP_RA_IOCTL_GetBlockCount      _IOWR( CAP_RA_IOC_MAGIC, CAP_RA_IOCTL_NUM_GetBlockCount, CapRA_Count_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_RegisterAccess devices for reading from a register
 * Passed and received data type is CapRA_Register_IOCTL
 */
#define CAP_RA_IOCTL_RegisterRead       _IOWR( CAP_RA_IOC_MAGIC, CAP_RA_IOCTL_NUM_RegisterRead, CapRA_Register_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_RegisterAccess devices for writing to a register
 * Passed and received data type is CapRA_Register_IOCTL
 */
#define CAP_RA_IOCTL_RegisterWrite      _IOWR( CAP_RA_IOC_MAGIC, CAP_RA_IOCTL_NUM_RegisterWrite, CapRA_Register_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_RegisterAccess devices for reading a shadow of a register
 * Passed and received data type is CapRA_Register_IOCTL
 */
#define CAP_RA_IOCTL_RegisterShadowRead _IOWR( CAP_RA_IOC_MAGIC, CAP_RA_IOCTL_NUM_RegisterShadowRead, CapRA_Register_IOCTL * )

/**
 * @brief IOCTL on OT_Cap_RegisterAccess devices for getting meta data about them
 * Passed and received data type is CapRA_MetaData_IOCTL
 */
#define CAP_RA_IOCTL_GetMetaData       _IOWR( CAP_RA_IOC_MAGIC, CAP_RA_IOCTL_NUM_GetMetaData, CapRA_MetaData_IOCTL * )


#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/
