/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "linux/UserBuffer.h"
#include <linux/mm.h>
#include <linux/pagemap.h>
#include <linux/slab.h>
#include <linux/version.h>

int MapUserPages( unsigned long arg, unsigned int size, CommonTransferContext *ctx )
{
    unsigned long startPage = PFN_DOWN(arg) << PAGE_SHIFT;
    unsigned long lastPage = PFN_DOWN(arg+size-1) << PAGE_SHIFT;
    int mappedPages = 0;
    ctx->NumPages = ( lastPage >> PAGE_SHIFT ) - ( startPage >> PAGE_SHIFT ) + 1;
    ctx->FirstOffset = arg & ~PAGE_MASK;

    //KernelTrace( TRACE_LEVEL_INFO, UserBuffer, "startPage: %u, lastPage: %u, NumPages: %u, FirstOffset: %u\n", startPage, lastPage, ctx->NumPages, ctx->FirstOffset );

    ctx->Pages = kzalloc( (ctx->NumPages) * sizeof(struct page *), GFP_KERNEL );
    if ( ctx->Pages != NULL )
    {
        mappedPages = get_user_pages_fast( startPage, ctx->NumPages, 1, ctx->Pages );

        if( mappedPages <= 0 )
        {
            KernelTrace( TRACE_LEVEL_ERROR, UserBuffer, "Failed to map %u pages. Error: %d\n", ctx->NumPages, mappedPages );
            kfree( ctx->Pages );
            ctx->Pages = NULL;
            return mappedPages;
        }
        else if ( (unsigned long)mappedPages < ctx->NumPages )
        {
            KernelTrace( TRACE_LEVEL_WARNING, UserBuffer, "Mapped less pages (%d) than expected (%u)\n", mappedPages, ctx->NumPages );
            ctx->NumPages = mappedPages;
        }

        ctx->Context = (void *)arg;

        return 0;
    }
    return -ENOMEM;
}

void CleanUserPages( CommonTransferContext *ctx )
{
    unsigned int i;
    if ( ctx->Pages != NULL )
    {
        for( i = 0; i < ctx->NumPages; i++ )
        {
            if( ctx->Pages[i] != NULL )
            {
                if( !PageReserved( ctx->Pages[i] ) )
                {
                    set_page_dirty( ctx->Pages[i] );
                }
				/* Changed to put_page as this is required for kernel 4.6 onwards */
				/* This should be safe for kernels 2.6.23.0 onwards */
                /* page_cache_release( ctx->Pages[i] ); */
				put_page( ctx->Pages[i] );
            }
        }
        kfree( ctx->Pages );
        ctx->Pages = NULL;
    }
    ctx->FirstOffset = 0;
    ctx->NumPages = 0;
}

bool CopyToUserPages( CommonTransferContext *ctx, void *dataBuffer, uint32_t dataCount, uint32_t memberFirstOffset, bool userContext )
{
    bool success = true;
    int bytesNotWritten;
    uint32_t i;
    uint32_t copyAmount = 0;
    void *adjustedAddress;
    void *vadd;
    uint32_t firstPageOffset;
    uint32_t firstPage;


    if ( userContext )
    {
        bytesNotWritten = copy_to_user( ctx->Context + memberFirstOffset, dataBuffer, dataCount );
        if ( bytesNotWritten != 0 )
        {
            KernelTrace(  TRACE_LEVEL_ERROR, UserBuffer, "Bytes not written: %d\n", bytesNotWritten );
            success = false;
        }
        return success;
    }

    // as we may not be in the first page and the buffer it probably not aligned to 0 get the offset...
    firstPageOffset = ( ctx->FirstOffset + memberFirstOffset ) % PAGE_SIZE;
    // we only care about the buffer, so find which page it starts on....
    firstPage = ( ctx->FirstOffset + memberFirstOffset ) / PAGE_SIZE;

    //KernelTrace( TRACE_LEVEL_VERBOSE, UserBuffer, "firstPage: 0x%08x, firstPageOffset: 0x%08x, ctx->FirstOffset: 0x%08x, memberFirstOffset: 0x%08x\n", firstPage, firstPageOffset, ctx->FirstOffset, memberFirstOffset );

    for( i = firstPage ; i < ctx->NumPages && dataCount > 0; i++ )
    {
        // each pass we can only copy upto a page
        copyAmount = ( dataCount < PAGE_SIZE ) ? dataCount : PAGE_SIZE;
        // get the base virt address of the page
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,4,0)
        vadd = kmap_atomic( ctx->Pages[i]);
#else
        vadd = kmap_atomic( ctx->Pages[i], KM_IRQ0);
#endif
        // use vadd as the basis of our copy...
        adjustedAddress = vadd;
        if ( i == firstPage )
        {
            // first page's data is potentially not at the beginning of the mapped area
            adjustedAddress += firstPageOffset;
            if( ( PAGE_SIZE - firstPageOffset ) < copyAmount )
                copyAmount = ( PAGE_SIZE - firstPageOffset );
        }

        //KernelTrace( TRACE_LEVEL_VERBOSE, UserBuffer, "dataCount: 0x%02x, copyAmount: 0x%02x, vadd: %p, adjustedAddress: %p \n", dataCount, copyAmount, vadd, adjustedAddress );

        // now copy to the kernel mapped user buffer...
        memcpy( adjustedAddress, dataBuffer, copyAmount );

        // unmap the page....
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,4,0)
        kunmap_atomic( vadd);
#else
        kunmap_atomic( vadd , KM_IRQ0);
#endif

        dataCount -= copyAmount;
        dataBuffer += copyAmount;
    }

    return (dataCount == 0) && success;
}
