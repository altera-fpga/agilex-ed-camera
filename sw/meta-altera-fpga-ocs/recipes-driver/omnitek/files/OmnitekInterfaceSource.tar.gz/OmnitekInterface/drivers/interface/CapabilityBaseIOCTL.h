/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef CAPABILITYBASEIOCTL_H_
#define CAPABILITYBASEIOCTL_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"
#include "Common.h"
#include "KernelTypes.h"
#include "CapabilityTypes.h"

#if BUILDTYPE == BT_WINDOWS
#include "windows/PlatformCapabilityBaseIOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/PlatformCapabilityBaseIOCTL.h"
#endif

/** @}*/

#endif /* CAPABILITYBASEIOCTL_H_ */
