/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "CapabilityBaseIOCTL.h"
#include "capability/RegisterAccess_IOCTL.h"
#include "capability/Common_IOCTL.h"
#include "CapabilityDriverBusInterface.h"

#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>


long ProcessCapabilityBaseIOCTL( CapRegister *RegisterCap, CapabilityDeviceInterface *interface, unsigned long Request, unsigned int IoControlCode )
{
    int retval = -ENOTTY;
    switch( IoControlCode )
    {
        case CAP_RA_IOCTL_GetBlockCount:
        {
            uint32_t versionIn;
            CapRA_Count_IOCTL *ioctlReturn = ( CapRA_Count_IOCTL * )Request;
            if( omnitek_access_ok( VERIFY_WRITE, Request, sizeof(CapRA_Count_IOCTL) ) )
            {
                get_user( versionIn, &( ioctlReturn->Version ) );

                switch ( versionIn )
                {
                    case 0: //!< CAP_RA_IOCTL_GetBlockCount_Version
                    {
                        put_user( versionIn, &( ioctlReturn->Version ) );
                        put_user( RegisterCap->NumBlocks,  &( ioctlReturn->Count ) );
                        retval = 0;
                        break;
                    }
                    default:
                    {
                        put_user( CAP_RA_IOCTL_GetBlockCount_Version, &( ioctlReturn->Version ) );
                        retval = -ENOTTY;
                        KernelTrace( TRACE_LEVEL_WARNING, IOCTLCommon, "IoControlCode:%d. Unsupported version: %d\n", IoControlCode, versionIn );
                        break;
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "IoControlCode:%d. Access failure\n", IoControlCode );
            }

            break;
        }
        case CAP_RA_IOCTL_GetRegisterCount:
        {
            uint32_t versionIn;
            uint32_t blockNum = 0;
            CapRA_Count_IOCTL *ioctlReturn = ( CapRA_Count_IOCTL * )Request;
            if( omnitek_access_ok( VERIFY_WRITE, Request, sizeof(CapRA_Count_IOCTL) ) )
            {
                get_user( versionIn, &( ioctlReturn->Version ) );
                get_user( blockNum, &(ioctlReturn->Count) );
                switch ( versionIn )
                {
                    case 0: //!< CAP_RA_IOCTL_GetBlockCount_Version
                    {
                        put_user( versionIn, &( ioctlReturn->Version ) );
                        if( blockNum < RegisterCap->NumBlocks )
                        {
                            put_user( RegisterCap->Blocks[ blockNum ].Count, &( ioctlReturn->Count ) );
                            retval = 0;
                        }
                        else
                            retval = -ENOTTY;
                        break;
                    }
                    default:
                    {
                        put_user( CAP_RA_IOCTL_GetRegisterCount_Version, &( ioctlReturn->Version ) );
                        retval = -ENOTTY;
                        KernelTrace( TRACE_LEVEL_WARNING, IOCTLCommon, "IoControlCode:%d. Unsupported version: %d\n", IoControlCode, versionIn );
                        break;
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "IoControlCode:%d. Access failure\n", IoControlCode );
            }

            break;
        }
        case CAP_RA_IOCTL_GetMetaData:
        {
            uint32_t versionIn;
            CapRA_MetaData_IOCTL *ioctlReturn = ( CapRA_MetaData_IOCTL * )Request;
            if( omnitek_access_ok( VERIFY_WRITE, Request, sizeof(CapRA_MetaData_IOCTL) ) )
            {
                get_user( versionIn, &( ioctlReturn->Version ) );
                switch ( versionIn )
                {
                    case 0: //!< CAP_RA_IOCTL_GetMetaData_Version
                    {
                        put_user( versionIn, &( ioctlReturn->Version ) );
                        put_user( RegisterCap->AssociationId, &( ioctlReturn->AssociationId ) );
                        put_user( RegisterCap->ComponentId, &( ioctlReturn->UniqueComponentId ) );

                        retval = 0;
                        break;
                    }
                    default:
                    {
                        put_user( CAP_RA_IOCTL_GetMetaData_Version, &( ioctlReturn->Version ) );
                        retval = -ENOTTY;
                        KernelTrace( TRACE_LEVEL_WARNING, IOCTLCommon, "IoControlCode:%d. Unsupported version: %d\n", IoControlCode, versionIn );
                        break;
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "IoControlCode:%d. Access failure\n", IoControlCode );
            }


            break;
        }
        case CAP_RA_IOCTL_RegisterRead:
        case CAP_RA_IOCTL_RegisterShadowRead:
        case CAP_RA_IOCTL_RegisterWrite:
        {
            uint32_t versionIn;
            uint32_t blockNum = 0;
            uint32_t regNum = 0;
            uint32_t val = 0;
            CapRA_Register_IOCTL *ioctlReturn = ( CapRA_Register_IOCTL * )Request;

            if( omnitek_access_ok( VERIFY_WRITE, Request, sizeof(CapRA_Register_IOCTL) ) )
            {
                get_user( versionIn, &( ioctlReturn->Version ) );

                switch( versionIn )
                {
                    case 0:
                    {
                        get_user( blockNum, &( ioctlReturn->BlockNum ) );
                        get_user( regNum, &( ioctlReturn->RegNum ) );
                        get_user( val, &( ioctlReturn->Value ) );

                        if( blockNum < RegisterCap->NumBlocks )
                        {
                            if ( IoControlCode == CAP_RA_IOCTL_RegisterRead )
                            {
                                retval = interface->ReadRegisterCap( interface->Device, &RegisterCap->Blocks[ blockNum ], regNum, &val );
                                if( retval != 0 )
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "FAILURE - RegisterRead - %s - BlockNum: %u, RegNum: %u\n", interface->Device->DeviceAccessName, blockNum, regNum );
                                }
                            }
                            else if ( IoControlCode == CAP_RA_IOCTL_RegisterShadowRead )
                            {
                                retval = interface->ReadShadowRegisterCap( interface->Device, &RegisterCap->Blocks[ blockNum ], regNum, &val );
                                if( retval != 0 )
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "FAILURE - RegisterShadowRead - %s - BlockNum: %u, RegNum: %u\n", interface->Device->DeviceAccessName, blockNum, regNum );
                                }
                            }
                            else if ( IoControlCode == CAP_RA_IOCTL_RegisterWrite )
                            {
                                retval = interface->WriteRegisterCap( interface->Device, &RegisterCap->Blocks[ blockNum ], regNum, val );
                                if( retval != 0 )
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "FAILURE - RegisterWrite - %s - BlockNum: %u, RegNum: %u, Value: 0x%08X\n", interface->Device->DeviceAccessName, blockNum, regNum, val );
                                }
                            }

                            if( retval == 0 )
                            {
                                put_user( val, &( ioctlReturn->Value ) );
                            }
                            else
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "IoControlCode:%u. Command Failure: %d\n", IoControlCode, retval );
                            }
                        }
                        else
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, IOCTLCommon, "IoControlCode:%d. Block not in range\n", IoControlCode );
                        }
                        put_user( versionIn, &( ioctlReturn->Version ) );
                        break;
                    }
                    default:
                    {
                        if ( IoControlCode == CAP_RA_IOCTL_RegisterRead )
                        {
                            put_user( CAP_RA_IOCTL_RegisterRead_Version, &( ioctlReturn->Version ) );
                        }
                        else if ( IoControlCode == CAP_RA_IOCTL_RegisterShadowRead )
                        {
                            put_user( CAP_RA_IOCTL_RegisterShadowRead_Version, &( ioctlReturn->Version ) );
                        }
                        else if ( IoControlCode == CAP_RA_IOCTL_RegisterWrite )
                        {
                            put_user( CAP_RA_IOCTL_RegisterWrite_Version, &( ioctlReturn->Version ) );
                        }
                        retval = -ENOTTY;
                        KernelTrace( TRACE_LEVEL_WARNING, IOCTLCommon, "IoControlCode:%d. Unsupported version: %d\n", IoControlCode, versionIn );
                        break;
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "IoControlCode:%d. Access failure\n", IoControlCode );
            }

            break;
        }
        default:
            KernelTrace( TRACE_LEVEL_ERROR, IOCTLCommon, "IoControlCode:%d. Unhandled in switch\n", IoControlCode );
            break;
    }
    return retval;
}

long ProcessCommon_QueryInfo_Register( Capability *cap, struct _CapabilityDeviceInterface *interface, CapCommon_QueryInfo_IOCTL * data )
{
    long retval = 0;
    CapRegister *regCap = &cap->Ext.Register;

    switch( data->Key )
    {
        case QueryInfo_RegisterPhysAddr:
            if( data->Value < regCap->NumBlocks )
                data->Value = regCap->Blocks[ data->Value ].PhysicalAddress;
            else
                retval = -EINVAL;
            break;
        case QueryInfo_RegisterUniqueID:
            data->Value = regCap->ComponentId;
            break;
        case QueryInfo_RegisterAssociationID:
            data->Value = regCap->AssociationId;
            break;
        case QueryInfo_RegisterVersionId:
            data->Value = regCap->Version;
            break;
        case QueryInfo_TimerGetTime:
            if( !interface->TimerGetTime( interface->Device, &data->Value ) )
                retval = -EINVAL;
            break;
        case QueryInfo_TimerGetFrequency:
        {
            uint32_t hertz = 0;
            if( interface->TimerGetFrequency( interface->Device, &hertz ) )
                data->Value = hertz;
            else
                retval = -EINVAL;

            break;
        }
        default:
            retval = -EINVAL;
            break;
    }

    return retval;
}
