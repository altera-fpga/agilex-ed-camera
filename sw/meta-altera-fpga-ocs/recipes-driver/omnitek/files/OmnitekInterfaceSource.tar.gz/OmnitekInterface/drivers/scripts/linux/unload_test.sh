#! /bin/bash

# Copyright (C) Altera Corporation
#
# SPDX-License-Identifier: GPL-2.0-only

sudo rmmod OT_Cap_RegisterAccess.ko

sudo rmmod OT_Cap_OmniFB.ko
sudo rmmod OT_Cap_VideoFDMA.ko
sudo rmmod OT_Cap_MDMA.ko

sudo rmmod OT_HC_MemoryBased.ko
sudo rmmod OmniTekFPGABus.ko
