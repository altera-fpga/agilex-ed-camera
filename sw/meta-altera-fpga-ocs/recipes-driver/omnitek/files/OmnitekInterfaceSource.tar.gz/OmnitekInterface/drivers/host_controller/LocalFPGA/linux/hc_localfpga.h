/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HC_LOCALFPGA_H_
#define HC_LOCALFPGA_H_

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#include "Common.h"
#include "HostController.h"
#include "HostControllerBusInterface.h"

typedef struct
{
    void * CapMemory;
    ot_phys_addr_t CapAddress;
    uint32_t CapLength;
}CapRegion;
#define MAX_CAPABILITY_REGIONS (1)

typedef struct
{
    PCapInterrupt Info;
    unsigned int IRQ;
} LinuxInterruptInfo;

typedef struct
{
    // common to all platforms
    OmniTekHostController hc;
    OmniTekHostControllerInterface hci;
    HCBusInterface BusInterface;

    // if we had interrupts we would need this
    HCISRCB BusISR;
    uint32_t NumInterrupts; //!< total children created.
    LinuxInterruptInfo *Interrupts;
    Allocateable InterruptsMem; //!< needed for cross platform allocations...

    // hardware specific device
    struct platform_device *pdev;

    CapRegion CapRegions[MAX_CAPABILITY_REGIONS];

    // for char interface for ioctls
    dev_t Major;
    dev_t Minor;
    struct cdev CDev;

    spinlock_t IrqLock; /*!< SpinLock used to disable interrupts (on current processor) */
//    u32 nInterruptStatus; /*!< Interrupt status for this device */
//    u32 nDmaStatus; /*!< Channels that are flagging an interrupt */
} DriverInstanceData;

// {94E7DE60-71AB-431e-9F11-83CDE32CD6EE}
DEFINE_UUID( UUID_USERINTERFACE_HC_LOCALFPGA, 0x636f2a4e, 0xc008, 0x4200, 0x93, 0x9c, 0x1, 0xf7, 0x3, 0x3c, 0xe1, 0x7c );

#endif /* HC_LOCALFPGA_H_ */
