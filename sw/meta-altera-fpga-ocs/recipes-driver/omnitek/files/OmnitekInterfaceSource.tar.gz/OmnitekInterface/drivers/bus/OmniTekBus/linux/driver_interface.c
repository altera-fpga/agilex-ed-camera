/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/module.h>
#include "omnitekbus.h"
#include "Customise.h"

int MANUF_FUNC(_GetInterfaceForCapDriver)( POmniTekCapabilityDevice context, struct _CapabilityDeviceInterface * interface )
{
    DeviceLookupData *lookup = NULL;
    if (context == NULL || interface == NULL || context->BusData == NULL )
        return -1;

    lookup = context->BusData;

    interface->HostControllerDevice = FromVirtualBusItem( lookup->VirtualBusHandle )->Controller->Device;
    if( interface->HostControllerDevice == NULL )
        return -2;

    interface->Device = context;

    interface->DeRegisterISRCallback = DeRegisterISRCallback;
    interface->RegisterISRCallback = RegisterISRCallback;
    interface->ReadRegisterCap = ReadRegisterCap;
    interface->ReadShadowRegisterCap = ReadShadowRegisterCap;
    interface->WriteRegisterCap = WriteRegisterCap;
    interface->TimerGetFrequency = TimerGetFrequency;
    interface->TimerGetTime = TimerGetTime;
    return 0;
}
MANUF_EXPORT( _GetInterfaceForCapDriver );

int MANUF_FUNC(_capability_driver_register)( POmniTekCapabilityDriver capDriver )
{
    capDriver->Driver.bus = &omnitekbus;
    return driver_register( &capDriver->Driver );
}
MANUF_EXPORT( _capability_driver_register );

void MANUF_FUNC(_capability_driver_unregister)( POmniTekCapabilityDriver capDriver )
{
    driver_unregister( &capDriver->Driver );
}
MANUF_EXPORT( _capability_driver_unregister );
