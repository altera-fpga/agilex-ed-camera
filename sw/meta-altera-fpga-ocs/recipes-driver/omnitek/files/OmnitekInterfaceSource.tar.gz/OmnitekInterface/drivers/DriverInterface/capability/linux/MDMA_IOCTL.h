/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef MDMA_IOCTL_H_
#error "Do not include this directly."
#endif

#include "../Common_IOCTL.h"
#include "../IOCTL_DMACommon.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/**
 * @brief Current #CAP_MDMA_IOCTL_Transfer ::DMATransaction_IOCTL::Version number to use
 */
#define CAP_MDMA_IOCTL_Transfer_Version0 0
// v1 was skipped....
#define CAP_MDMA_IOCTL_Transfer_Version2 2
#define CAP_MDMA_IOCTL_Transfer_Version CAP_MDMA_IOCTL_Transfer_Version0

/**
 * @brief IOCTL on OT_Cap_MDMA devices for performing
 * Passed and received data type is ::DMATransaction_IOCTL_Linux
 */
#define CAP_MDMA_IOCTL_Transfer   _IOWR( CAP_MDMA_IOC_MAGIC, CAP_MDMA_IOCTL_NUM_Transfer, DMATransaction_IOCTL_Linux * )


#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/
