/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef MEMORY_H_
#error "Do not include this directly."
#endif

#include <linux/slab.h>
#include "../Common.h"

typedef void *Allocateable; //!< Abstraction for allocateable memory

/**
 * @brief General memory allocation.
 * @param[in] size Number of bytes you want to allocate
 * @param[in,out] allocateable The container that will hold the rights to the memory block
 * @return pointer to the new data zeroed OR NULL if memory allocation fails
 */
static inline void * AllocateMemory( uint32_t size, Allocateable *allocateable )
{
    *allocateable = kzalloc( size, GFP_KERNEL );
    return *allocateable;
}

/**
 * @brief Release previously allocated memory
 * @param[in] allocateable The memory reference / block to release back to the system
 */
static inline void DeleteMemory( Allocateable * allocateable )
{
    kfree( *allocateable );
}

/** @}*/
