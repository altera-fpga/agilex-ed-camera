/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef HOSTCONTROLLERINTERFACE_H_
#error "Do not include this file directly"
#endif

/** @}*/
