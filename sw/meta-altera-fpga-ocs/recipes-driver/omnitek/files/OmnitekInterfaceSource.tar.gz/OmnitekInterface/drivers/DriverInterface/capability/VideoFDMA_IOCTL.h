/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef VIDEOFDMA_IOCTL_H_
#define VIDEOFDMA_IOCTL_H_

/** \addtogroup UserlandInterface
 *  @{
 */

#include "global_defs.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#include "RegisterAccess_IOCTL.h"

/** \cond */
#define CAP_VIDEOFDMA_IOC_MAGIC (2)
/** \endcond */

/** \cond */
enum
{
	CAP_VIDEOFDMA_IOCTL_NUM_Transfer	      = OT_IOCTL_NUMBER(CAP_VIDEOFDMA_IOC_MAGIC, 1), //!< DMATransaction_IOCTL
    CAP_VIDEOFDMA_IOCTL_NUM_TransferGpuDirect = OT_IOCTL_NUMBER(CAP_VIDEOFDMA_IOC_MAGIC, 2), //!< DMATransaction_IOCTL
    CAP_VIDEOFDMA_IOCTL_NUM_Start		      = OT_IOCTL_NUMBER(CAP_VIDEOFDMA_IOC_MAGIC, 3), //!< CapVideoFDMA_VersionOnly_IOCTL
    CAP_VIDEOFDMA_IOCTL_NUM_Stop		      = OT_IOCTL_NUMBER(CAP_VIDEOFDMA_IOC_MAGIC, 4), //!< CapVideoFDMA_VersionOnly_IOCTL
    CAP_DATAFDMA_IOCTL_NUM_Event              = OT_IOCTL_NUMBER(CAP_VIDEOFDMA_IOC_MAGIC, 5), //!< CapDataFDMA_Event_IOCTL. Linux uses the _Linux postfix version
};
/** \endcond */

#pragma pack(push,4)
/**
 * @brief IOCTL container to use for #CAP_VIDEOFDMA_IOCTL_Start and #CAP_VIDEOFDMA_IOCTL_Stop
 *
 * For #CAP_VIDEOFDMA_IOCTL_Start Version must be CAP_VIDEOFDMA_IOCTL_Start_Version
 *
 * For CAP_VIDEOFDMA_IOCTL_Stop Version must be CAP_VIDEOFDMA_IOCTL_Stop_Version
 *
 */
typedef struct
{
    uint32_t Version; //!< See description
} CapVideoFDMA_VersionOnly_IOCTL;

/**
 * @brief IOCTL container for #CAP_DATAFDMA_IOCTL_Event
 *
 * Version must be  #CAP_DATAFDMA_IOCTL_Event_Version
 */
typedef struct
{
    uint32_t Version; //!< See description
    uint64_t BytesTransfered; //!< The number of bytes consumed / generated for this event
    uint64_t StartTime; //!< if we have a timer, this is either the previous isr time OR start dma time
    uint64_t EndTime; //!< if we have a timer, this is the isr time of completion
} CapDataFDMA_Event_IOCTL;


#pragma pack(pop)

/* Include the platform specific headers  */
#if BUILDTYPE == BT_WINDOWS
#include "windows/VideoFDMA_IOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/VideoFDMA_IOCTL.h"
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/

#endif /* VIDEOFDMA_IOCTL_H_ */
