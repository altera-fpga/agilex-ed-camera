/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef OMNIFB_IOCTL_H_
#define OMNIFB_IOCTL_H_

/** \addtogroup UserlandInterface
 *  @{
 */

#include "global_defs.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/** \cond */
#define CAP_OMNIFB_IOC_MAGIC (7)
/** \endcond */

/** \cond */
enum
{
    CAP_OMNIFB_IOCTL_NUM_SetColourMatrix    = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 10 ), //!< CapOmniFB_SetColourMatrix_IOCTL

    CAP_OMNIFB_IOCTL_NUM_GetBusConfig       = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 11 ), //!< CapOmniFB_GetBusConfig_IOCTL
    CAP_OMNIFB_IOCTL_NUM_GetComponents      = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 12 ), //!< CapOmniFB_GetComponents_IOCTL

    CAP_OMNIFB_IOCTL_NUM_CursorEnable       = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 13 ), //!< CapOmniFB_CursorEnable_IOCTL
    CAP_OMNIFB_IOCTL_NUM_CursorMove         = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 14 ), //!< CapOmniFB_CursorMove_IOCTL
    CAP_OMNIFB_IOCTL_NUM_CursorSetPalette   = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 15 ), //!< CapOmniFB_CursorPalette_IOCTL
    CAP_OMNIFB_IOCTL_NUM_CursorSetImage     = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 16 ), //!< CapOmniFB_CursorImage_IOCTL

    CAP_OMNIFB_IOCTL_NUM_DiscardAlpha       = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 17 ), //!< CapOmniFB_DiscardAlpha_IOCTL

    CAP_OMNIFB_IOCTL_NUM_GetResizerEnabled  = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 18 ), //!< CapOmniFB_Resizer_IOCTL
    CAP_OMNIFB_IOCTL_NUM_SetResizerEnabled  = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 19 ), //!< CapOmniFB_Resizer_IOCTL

    CAP_OMNIFB_IOCTL_NUM_GetChromaKey       = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 20 ), //!< CapOmniFB_ChromaKey_IOCTL
    CAP_OMNIFB_IOCTL_NUM_SetChromaKey       = OT_IOCTL_NUMBER(CAP_OMNIFB_IOC_MAGIC, 21 ), //!< CapOmniFB_ChromaKey_IOCTL
};
/** \endcond */

#pragma pack(push,4)

/** \cond */
#define OT_Cap_OmniFB_CSC_NumEntries 16

#define OT_Cap_OmniFB_Cursor_BitMap_MaxWidth 64
#define OT_Cap_OmniFB_Cursor_BitMap_MaxHeight 64
#define OT_Cap_OmniFB_Cursor_Palette_MaxEntries 16

typedef uint16_t OT_Cap_OmniFB_Cursor_BitMap[ OT_Cap_OmniFB_Cursor_BitMap_MaxWidth ][ OT_Cap_OmniFB_Cursor_BitMap_MaxHeight ];
typedef uint32_t OT_Cap_OmniFB_Cursor_Palette[ OT_Cap_OmniFB_Cursor_Palette_MaxEntries ];
/** \endcond */

typedef struct
{
    uint32_t Version; //!< See description
    uint32_t Data[ OT_Cap_OmniFB_CSC_NumEntries ]; //!< The colour matrix
} CapOmniFB_SetColourMatrix_IOCTL;

typedef struct
{
    uint32_t Version; //!< See description
    uint32_t StreamID; //!< AXIS Stream ID
    uint32_t PixelsPerClock; //!< AXIS Stream Pixels Per Clock
    uint32_t PixelDepth; //!< AXIS Stream Pixel Depth Per colour stream
    uint32_t NumStreams; //!< AXIS Streams
} CapOmniFB_GetBusConfig_IOCTL;

typedef struct
{
    uint32_t Version; //!< Must be CAP_OMNIFB_IOCTL_GetComponents_Version1
    uint8_t HasCSC;
    uint8_t HasLUT;
    uint8_t HasVTiming;
    uint8_t HasVTimingGenLock;
    uint8_t HasResizer;
    uint8_t HasCursor;
} CapOmniFB_GetComponents_V1_IOCTL;
// Typedef for backwards compatibility
typedef CapOmniFB_GetComponents_V1_IOCTL CapOmniFB_GetComponents_IOCTL;

typedef struct
{
    uint32_t Version; //!< Must be CAP_OMNIFB_IOCTL_GetComponents_Version2
    uint8_t HasCSC;
    uint8_t HasLUT;
    uint8_t HasVTiming;
    uint8_t HasVTimingGenLock;
    uint8_t HasResizer;
    uint8_t HasCursor;
    uint8_t HasChromaKey;
} CapOmniFB_GetComponents_V2_IOCTL;

typedef struct
{
    uint32_t Version; //!< See description
    uint8_t Enabled; //!< 1 == enable, 0 == disable
}  CapOmniFB_CursorEnable_IOCTL;

typedef struct
{
    uint32_t Version; //!< See description
    uint32_t X;
    uint32_t Y;
}  CapOmniFB_CursorPosition_IOCTL;

typedef struct
{
    uint32_t Version; //!< See description
    OT_Cap_OmniFB_Cursor_Palette Data;
}  CapOmniFB_CursorPalette_IOCTL;

typedef struct
{
    uint32_t Version; //!< See description
    uint8_t DataWidth; //!< actual used data width
    uint8_t DataHeight; //!< actual used data height
    uint8_t HotSpotX; //!<
    uint8_t HotSpotY; //!<
    OT_Cap_OmniFB_Cursor_BitMap Data;
} CapOmniFB_CursorImage_IOCTL;

typedef struct
{
    uint32_t Version; //!< See description
    uint32_t Discard; //!< 1 == Discard. 0 == keep,
} CapOmniFB_DiscardAlpha_IOCTL;

typedef struct
{
    uint32_t Version; //!< See description
    uint32_t Enabled; //!< 1 == 2k-4k resizer enabled, 0 == not enabled
} CapOmniFB_Resizer_IOCTL;

typedef struct
{
    uint32_t Version; //!< See description
    uint32_t Enabled; //!< 1 == enabled, 0 == not enabled
    uint32_t Colour; //!< pixel colour to make transparent
} CapOmniFB_ChromaKey_IOCTL;

#pragma pack(pop)

/* Include the platform specific headers  */
#if BUILDTYPE == BT_WINDOWS
//#include "windows/OmniFB_IOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/OmniFB_IOCTL.h"
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/



#endif
