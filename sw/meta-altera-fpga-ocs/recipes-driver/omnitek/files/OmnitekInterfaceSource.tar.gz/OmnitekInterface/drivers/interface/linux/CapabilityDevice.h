/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef CAPABILITYDEVICE_H_
#error "Do not include this file directly"
#endif

#include <linux/types.h>
#include <linux/device.h>
#include <linux/kernel.h>

/**
 * @brief Given a linux device instance get the full OmniTekCapabilityDevice instance
 */
#define ToOmniTekCapabilityDevice( dev ) container_of( dev, OmniTekCapabilityDevice, Device );

/** @}*/
