/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef CONTAINER_H_
#define CONTAINER_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"

/*
 * Platform specific definitions for macros and functions to generate our collection functions.
 * Generally speaking the following will be defined...
 *
 * typedefed MemoryPoolType;
 * FreeMemoryPool( MemoryPoolType instance );
 * MakeMemoryPool( MemoryPoolType instance, type_of_stored_data );
 *
 * typedefed OmniTekCollection;
 * count CollectionCount( OmniTekCollection );
 * Platform specific return, some sort of int.
 *
 * Per specialised Collection
 *
 * t == first param to the ITER_TYPE_* family of macros. This is basic data to be stored.
 * name == Second param to the ITER_TYPE_* family of macros. The name has no bearing on the data
 * but needs to be unique across the compile base.
 *
 * typedefed struct name##Item;
 * This is needed so we can store the same object in multiple containers. Reference counted.
 *
 * typedefed struct name##Entry;
 * This is teh actual Entry in a collection.
 *
 * t *From##name##Entry( name##Entry * e );
 * Take a name##Entry instance and get a point to the basic data stored.
 * Assuming e is valid then the return will never be NULL
 *
 * t *From##name##Item( name##Item * i );
 * Take an name##Item instance and get a point to the basic data stored.
 * Assuming i is valid then the return will never be NULL
 *
 * name##Item * New##name##Item( MemoryPoolType pool );
 * Create a new object of type name##Item from the given pool that has been preinitialised to the correct storage type.
 * Return will be null if we could not allocate memory for some reason. Check the platform error console for more information
 *
 * void Release##name##Item( MemoryPoolType pool, name##Item * item, void (*PreRelease)( name##Item *item ) );
 * Free the given item into the pool supplied. Optionally perform an extra cleanup operation before you do ( PreRelease )
 *
 * uint32_t CollectionAdd##name##Item( OmniTekCollection * col, name##Item * item );
 * Add an item into a collection. This needs to specialised as it creates a name##Entry instance.
 * See Types.h for information about the return value.
 *
 * name##Item * CollectionRemove##name##Entry( OmniTekCollection * col, name##Entry * entry );
 * Remove the given entry from the collection and return the associated typed Item for your cleanup needs.
 * Should never return NULL, more likely to cause a system "bug check" instead.
 *
 * name##Entry * CollectionGet##name##Entry( OmniTekCollection * col, uint32_t idx );
 * Get the typed instance at the given index. NULL if not found.
 *
 * name##Entry * CollectionGetFirst##name##Entry( OmniTekCollection * col );
 * Get the first entry for the collection. NULL if empty.
 *
 * name##Entry * CollectionGetLast##name##Entry( OmniTekCollection * col );
 * Get the last entry from the collection. NULL if empty.
 *
 * __must_check uint32_t CollectionCreate##name( OmniTekCollection * col, const char * poolName );
 * Initialise the passed collection for use. Name is only needed under linux, but has no harm under windows.
 * See Types.h for return values.
 *
 * void CollectionClean##name( OmniTekCollection * col, MemoryPoolType pool, void (*PreRelease)( name##Item *item ) );
 * Remove all items from the collection and free the associated items. Call PreRelease ( if supplied ) for each item
 * to cleanup extra allocated data / unmap memory that has not been automatically created for you.
 *
 * void CollectionEmpty##name( OmniTekCollection * col );
 * Remove all items from the collection. Does not free the memory associated with each Item!
 *
 * void ClobberCollection##name( OmniTekCollection * col, MemoryPoolType pool, void (*PreRelease)( name##Item *item ) );
 * Same as CollectionClean but also frees the collection pool at the end. So this is the standard cleanup for a collection
 * assuming that you want to kill off everything. If you want to empty and then kill the collection object please do a
 * CollectionEmpty##name first.
 */

#if BUILDTYPE == BT_WINDOWS
#include "windows/Container.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/Container.h"
#endif

/** @}*/

#endif /* CONTAINER_H_ */
