/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef DMACOMMON_H_
#define DMACOMMON_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"
#include "KernelTypes.h"
#include "Common.h"
#include "CapabilityTypes.h"

/**
 * @brief Register location for all DMA types
 */
enum
{
    DMACapReg = 0,
    DMAChannelConf,
    DMAReserved0,
    DMAPADRLower,
    DMAPADRUpper,
    DMALADRLower,
    DMALADRUpper,
    DMADPRLower,
    DMADPRUpper,
    DMASize,
    DMAReserved1,
    DMACSR,
    DMAReserved2,
    DMABytesTransfered,
    DMASGBackLog,
    NumDMARegisters
};

/**
 * @brief Check to see if a dma channel supports 64 bit PADR
 */
#define CapReg_64BitPADR ( 1 << 8 )

/**
 * @brief Check to see if a dma channel supports 64 bit LADR
 */
#define CapReg_64BitLADR ( 1 << 9 )

/**
 * @brief Flags in the CS Register
 */
enum
{
    CSR_DMAEnable = ( 1 << 0 ),
    CSR_DMAStart = ( 1 << 1 ),
    CSR_DMAAbort = ( 1 << 2 ),
    CSR_DMADone = ( 1 << 4 ),
    CSR_SGInterruptStatus = ( 1 << 5 ),
    CSR_EventInterruptStatus = ( 1 << 6 ),
    CSR_SGMode = ( 1 << 8 ),
    CSR_DisableSyncControl = ( 1 << 9 ),
    CSR_EventInterruptEnable = ( 1 << 10 ),
};

/**
 * @brief Flags in the DP Register
 */
enum
{
    DPR_EndOfChain = ( 1 << 1 ),
    DPR_InterruptAfterTransfer = ( 1 << 2 ),
    DPR_Direction = ( 1 << 3 ),
};

#if BUILDTYPE == BT_WINDOWS
#include "windows/DMACommon.h"
#endif
#if BUILDTYPE == BT_LINUX
#include "linux/DMACommon.h"
#endif

/** @}*/

#endif /* DMACOMMON_H_ */
