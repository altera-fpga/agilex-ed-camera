/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HC_OMNITEK_COMMON_H_
#define HC_OMNITEK_COMMON_H_

#include "Container.h"
#include "HostController.h"
#include "HostControllerBusInterface.h"

#if BUILDTYPE == BT_LINUX
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#endif

#define FPGA_OFFSET_ICR ( 0x10 / 4 )
#define FPGA_OFFSET_ISR ( 0x10 / 4 )
#define FPGA_MASK_ISR 0xffff0000
#define FPGA_MASK_ICR 0x0000ffff
#define FPGA_FLAG_ICR_TEST ( 1 << 0 )
#define FPGA_FLAG_ICR_DMA ( 1 << 1 )
#define FPGA_FLAG_ICR_TXFRAME ( 1 << 2 )
#define FPGA_FLAG_ICR_RXFRAME ( 1 << 3 )

#define FPGA_FLAG_ISR_TEST ( 1 << 16 )
#define FPGA_FLAG_ISR_DMA ( 1 << 17 )
#define FPGA_FLAG_ISR_TXFRAME ( 1 << 18 )
#define FPGA_FLAG_ISR_RXFRAME ( 1 << 19 )

#define DMA_OFFSET_ISR ( 0x08 / 4 )
#define DMA_OFFSET_EICR ( 0x10 / 4 )
#define DMA_OFFSET_EISR ( 0x14 / 4 )

// {8CAC9118-C06F-479c-9BF7-CE6BBEC26836}
DEFINE_UUID( UUID_USERINTERFACE_HC_OMNITEK, 0x8cac9118, 0xc06f, 0x479c, 0x9b, 0xf7, 0xce, 0x6b, 0xbe, 0xc2, 0x68, 0x36);

#define PCI_NUM_BARS                    7
#define MAX_NUM_MEM_BARS                3

#define ReadBarHWValue( did, b, r)  *(volatile unsigned int *)((did)->MemBar[(b)].pVa + (r))
#define WriteBarHWValue( did, b, r, Val) *(volatile unsigned int *)((did)->MemBar[(b)].pVa + (r)) = (Val)

#define ReadHWValue( va, r)  *(volatile unsigned int *)( va + r )
#define WriteHWValue( va, r, Val) *(volatile unsigned int *)( va + r ) = (Val)

typedef struct _PCI_BAR_INFO
{
    uint32_t *pVa; /*!< BAR Kernel Virtual Address */
    ot_phys_addr_t Physical; /*!< BAR Physical Address */
    uint32_t Size; /*!< BAR size */
} PCI_BAR_INFO;

typedef struct
{
    OmniTekHostController hc;
    OmniTekHostControllerInterface hci;
    HCBusInterface       BusInterface;

    HCISRCB BusISR;
    uint32_t NumInterrupts; //!< total children created.
    PCapInterrupt *Interrupts;
    Allocateable InterruptsMem; //!< needed for cross platform allocations...

    PCI_BAR_INFO          MemBar[MAX_NUM_MEM_BARS];
    uint32_t              nBars;

#if BUILDTYPE == BT_WINDOWS
    WDFSTRING            BusInstanceString;
    PVOID                NotificationHandle;
    WDFINTERRUPT         WdfInterrupt;

    BUS_INTERFACE_STANDARD	BusInterfaceStandard;
    PBUS_INTERFACE_STANDARD pBusInterfaceStandard;
#endif
#if BUILDTYPE == BT_LINUX
    struct pci_dev *pdev;
    dev_t Major;
    dev_t Minor;
    struct cdev CDev;
    spinlock_t IrqLock; /*!< SpinLock used to disable interrupts (on current processor) */
    u32 nInterruptStatus; /*!< Interrupt status for this device */
    u32 nDmaStatus; /*!< Channels that are flagging an interrupt */
#endif
} DriverInstanceData;

int OT_HC_OmniTek_Enumerate( DriverInstanceData * did );

#endif /* HC_OMNITEK_COMMON_H_ */
