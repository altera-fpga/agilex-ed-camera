/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef CONTAINER_H_
#error "Do not include this directly."
#endif

#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/list.h>
#include <linux/slab.h>
#include <linux/module.h>
#include "../Common.h"

/**
 * @brief Wrapper for deleting memory pools under different platforms
 */
#define FreeMemoryPool( x ) kmem_cache_destroy( x )

typedef struct kmem_cache * MemoryPoolType;  //!< Redefined memory pool type

/**
 * @brief Wrapper for creating memory pools
 * @param[out] pool the MemoryPoolType pointer to initialise
 * @param[in] t The type of memory pool being created
 */
#define MakeMemoryPool( pool, t ) \
do\
{\
	pool = kmem_cache_create( #t, sizeof( t ), 0, 0, 0);\
} while( 0 )

/**
 * @brief A wrapper for collections
 */
typedef struct
{
	struct list_head Head; //!< The actual collection of items
	MemoryPoolType   ResourcePool; //!< The pool to allocate new items from
} OmniTekCollection;

/**
 * @brief Type and function definitions for a custom OmniTekCollection
 * @param[in] t The basic type of data contained in the OmniTekCollection
 * @param[in] name A name to be used to differentiate the generated functions from other automatically generated ones
 */
#define ITER_TYPE_DEFS( t, name ) \
typedef struct \
{ \
    t Data; \
    uint32_t Cnt; \
} name##Item;\
typedef struct \
{ \
    struct list_head List; \
    name##Item * Item; \
} name##Entry;\
t *From##name##Entry( name##Entry * e ); \
t *From##name##Item( name##Item * i ); \
name##Item * New##name##Item( MemoryPoolType pool ); \
void Release##name##Item( MemoryPoolType pool, name##Item * item, void (*PreRelease)( name##Item *item ) ); \
uint32_t CollectionAdd##name##Item( OmniTekCollection * col, name##Item * item ); \
name##Item * CollectionRemove##name##Entry( OmniTekCollection * col, name##Entry * entry ); \
name##Entry * CollectionGet##name##Entry( OmniTekCollection * col, uint32_t idx ); \
name##Entry * CollectionGetFirst##name##Entry( OmniTekCollection * col ); \
name##Entry * CollectionGetLast##name##Entry( OmniTekCollection * col ); \
__must_check uint32_t CollectionCreate##name( OmniTekCollection * col, const char * poolName ); \
void CollectionClean##name( OmniTekCollection * col, MemoryPoolType pool, void (*PreRelease)( name##Item *item ) ); \
void CollectionEmpty##name( OmniTekCollection * col ); \
void ClobberCollection##name( OmniTekCollection * col, MemoryPoolType pool, void (*PreRelease)( name##Item *item ) );

/**
 * @brief Implementation of functions previously defined by a call to #ITER_TYPE_DEFS
 * @param[in] t The basic type of data contained in the OmniTekCollection
 * @param[in] name A name to be used to differentiate the generated functions from other automatically generated ones
 */
#define ITER_TYPE_IMPL( t, name ) \
t *From##name##Entry( name##Entry * e ) \
{ \
	return &e->Item->Data; \
}\
\
t *From##name##Item( name##Item * i ) \
{ \
	return &i->Data; \
}\
\
name##Item * New##name##Item( MemoryPoolType pool ) \
{ \
	name##Item *item = kmem_cache_zalloc( pool, GFP_KERNEL ); \
	if ( item ) \
	{\
		item->Cnt = 0; \
	}\
	return item;\
}\
\
void Release##name##Item( MemoryPoolType pool, name##Item * item, void (*PreRelease)( name##Item *item ) ) \
{ \
	if ( item ) \
	{ \
	    if ( PreRelease != NULL ) PreRelease( item ); \
		kmem_cache_free( pool, item ); \
	} \
}\
\
uint32_t CollectionAdd##name##Item( OmniTekCollection * col, name##Item * item ) \
{ \
	name##Entry * newEntry = kmem_cache_zalloc( col->ResourcePool, GFP_KERNEL );\
	if ( ! newEntry )\
	{\
		return 1;\
	}\
	newEntry->Item = item; \
	item->Cnt++; \
	list_add_tail( &newEntry->List, &col->Head );\
	return 0;\
}\
\
name##Item * CollectionRemove##name##Entry( OmniTekCollection * col, name##Entry * entry ) \
{ \
	name##Item * item = entry->Item; \
	list_del( &entry->List );\
	kmem_cache_free( col->ResourcePool, entry ); \
	item->Cnt--; \
	return item; \
} \
\
name##Entry * CollectionGet##name##Entry( OmniTekCollection * col, uint32_t idx )\
{ \
	struct list_head * entry; \
	uint32_t i = 0; \
	list_for_each( entry, &col->Head ) \
	{ \
		if ( i == idx ) \
		{\
			return list_entry( entry, name##Entry, List ); \
		}\
		i++; \
	} \
	return NULL; \
} \
\
name##Entry * CollectionGetFirst##name##Entry( OmniTekCollection * col ) \
{ \
	if ( col->Head.next == &col->Head ) \
	{\
		return NULL; \
	}\
	return list_entry( col->Head.next, name##Entry, List ); \
} \
\
name##Entry * CollectionGetLast##name##Entry( OmniTekCollection * col ) \
{ \
	if ( col->Head.prev == &col->Head ) \
	{\
		return NULL; \
	}\
	return list_entry( col->Head.prev, name##Entry, List ); \
}\
\
uint32_t CollectionCreate##name( OmniTekCollection * col, const char * poolName ) \
{ \
	INIT_LIST_HEAD( &col->Head );\
	col->ResourcePool = kmem_cache_create( poolName, sizeof( name##Entry ), 0, 0, 0);\
	return ( col->ResourcePool == NULL );\
}\
\
void CollectionClean##name( OmniTekCollection * col, MemoryPoolType pool, void (*PreRelease)( name##Item *item ) )\
{ \
    name##Entry *entry = NULL; \
    name##Item *item = NULL; \
    if( col != NULL ) \
    { \
        while( CollectionCount( col ) > 0 ) \
        { \
            entry = CollectionGetFirst##name##Entry( col ); \
            item = CollectionRemove##name##Entry( col, entry ); \
            if ( item != NULL ) \
            { \
                Release##name##Item( pool, item, PreRelease ); \
            } \
        } \
    } \
} \
\
void CollectionEmpty##name( OmniTekCollection * col )\
{ \
    name##Entry *entry = NULL; \
    if( col != NULL ) \
    { \
        while( CollectionCount( col ) > 0 ) \
        { \
            entry = CollectionGetFirst##name##Entry( col ); \
            CollectionRemove##name##Entry( col, entry ); \
        } \
    } \
} \
void ClobberCollection##name( OmniTekCollection * col, MemoryPoolType pool, void (*PreRelease)( name##Item *item ) ) \
{ \
    CollectionClean##name( col, pool, PreRelease ); \
    FreeMemoryPool( col->ResourcePool ); \
}

/**
 * @brief Get the number of items in a collection
 * @param[in] col the collection to count
 * @return the number of elements in collection
 */
static inline uint32_t CollectionCount( OmniTekCollection * col )
{
	struct list_head * entry;
	uint32_t cnt = 0;
	list_for_each( entry, &col->Head )
	{
		cnt++;
	}
	return cnt;
}

/** @}*/
