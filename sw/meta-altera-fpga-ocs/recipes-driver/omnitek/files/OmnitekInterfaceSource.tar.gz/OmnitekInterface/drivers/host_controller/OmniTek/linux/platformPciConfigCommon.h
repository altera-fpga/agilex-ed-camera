/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef PLATFORM_PCICONFIGCOMMON_H_
#define PLATFORM_PCICONFIGCOMMON_H_
#include "hc_omnitek_common.h"
#include "Customise.h"

extern uint32_t MANUF_FUNC(_PlatformReadPciConfig)(DriverInstanceData *pDeviceInstance, uint32_t Offset, void *pBuffer, uint32_t ReadSize);

#define PlatformReadPciConfig MANUF_FUNC(_PlatformReadPciConfig)

#endif /* PLATFORM_PCICONFIGCOMMON_H_ */
