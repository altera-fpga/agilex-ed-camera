/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef EVENT_H_
#define EVENT_H_

#include "capability/Common_IOCTL.h"
#include <linux/eventfd.h>


typedef void (*EventCancelCB)( void * );
typedef void (*EventCompleteCB)( void *, void *, bool /* from user context? */ );

typedef struct _EventList
{
    struct list_head Head;
    spinlock_t Lock;
    uint64_t LastEventId;
} EventList;

typedef struct _EventItem
{
    struct list_head     List;
    uint64_t             Id;
    uint64_t             Tag;
    struct eventfd_ctx * KernelContext;
    EventCancelCB        Cancel;
    EventCompleteCB      Complete;
    void *               IOCTLContext;
    bool Added;
} EventItem;

void EventListInit( EventList *eventList );
void EventListClean( EventList *eventList );
EventItem * EventPrepare( EventList *eventList, CapGeneral_EventCtx_IOCTL *userCtx, uint64_t tag, void * eventIOCTLContext, EventCompleteCB eventComplete, EventCancelCB eventCancel );
bool EventAddAllocated( EventList *eventList, EventItem * eventItem );
// this must be called before it has been added to the list.....
bool EventCleanAllocated( EventItem * eventItem );
bool EventAdd( EventList *eventList, CapGeneral_EventCtx_IOCTL *userCtx, uint64_t tag, void * eventIOCTLContext, EventCompleteCB eventComplete, EventCancelCB eventCancel );
bool EventCancel( EventList *eventList, uint64_t eventId );
bool EventComplete( EventList *eventList, uint64_t eventId, void *completeContext, bool fromUserContext );
bool EventCompleteNextByTag( EventList *eventList, uint64_t eventTag, void *completeContext, bool fromUserContext );
bool _EventComplete( EventList *eventList, EventItem * eventItem, bool cancel, void *secondContext, bool fromUserContext );
EventItem * _EventFind( EventList *eventList, uint64_t eventId, bool isId );
bool EventListIsEmpty( EventList *eventList );

#endif /* EVENT_H_ */
