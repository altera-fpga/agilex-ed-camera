/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "Common.h"
#include <linux/device.h>
#include <linux/stat.h>
#include <linux/kernel.h>

static ssize_t ot_global_show_debuglevel(struct device *dev, struct device_attribute *attr, char *buf )
{
    switch ( OT_DebugLevel )
    {
        case TRACE_LEVEL_NONE:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_NONE: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_CRITICAL:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_CRITICAL: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_ERROR:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_ERROR: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_WARNING:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_WARNING: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_INFORMATION:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_INFORMATION: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_VERBOSE:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_VERBOSE: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_RESERVED6:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_RESERVED6: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_RESERVED7:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_RESERVED7: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_RESERVED8:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_RESERVED8: %d\n", OT_DebugLevel );
        case TRACE_LEVEL_RESERVED9:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_RESERVED9: %d\n", OT_DebugLevel );
        default:
            return scnprintf(buf, PAGE_SIZE, "TRACE_LEVEL_UNKNOWN: %d\n", OT_DebugLevel );
    }
}

static ssize_t ot_global_store_debuglevel(struct device *dev, struct device_attribute *attr, const char *buf, size_t count)
{
    int newLevel = 0;
    if( sscanf( buf, "%01d", &newLevel ) == 1 && newLevel != LONG_MIN && newLevel != LONG_MAX && newLevel >= TRACE_LEVEL_NONE && newLevel<= TRACE_LEVEL_RESERVED9 )
    {
        OT_DebugLevel = newLevel;
        return count;
    }
    return -EPERM;
}

DEVICE_ATTR( debuglevel, S_IRUGO | S_IWUSR|S_IWGRP, ot_global_show_debuglevel, ot_global_store_debuglevel );
