/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef USERBUFFER_H_
#define USERBUFFER_H_

#include "global_defs.h"
#include <linux/types.h>
#include <linux/mm.h>


typedef struct _CommonTransferContext
{
    uint32_t NumPages;
    uint32_t FirstOffset;
    struct page ** Pages;
    void *Context;
} CommonTransferContext;



int __must_check MapUserPages( unsigned long arg, unsigned int size, CommonTransferContext *ctx );
void CleanUserPages( CommonTransferContext *ctx );
bool CopyToUserPages( CommonTransferContext *ctx, void *dataBuffer, uint32_t dataCount, uint32_t memberFirstOffset, bool userContext );

#endif /* USERBUFFER_H_ */
