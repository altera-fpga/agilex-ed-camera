/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "DMACommon.h"
#include <linux/dma-mapping.h>

void DMAAbortChannel( DMAChannel * channel )
{
    uint32_t CsrWord = 0;

    DMAReadReg( channel, DMACSR, &CsrWord );

    CsrWord &= ~(CSR_DMAStart | CSR_DMAEnable);
    CsrWord |= CSR_DMAAbort;
    CsrWord |= CSR_DMAEnable;

    DMAWriteReg( channel, DMACSR, CsrWord );

    channel->IsRunning = FALSE;
    // fixme: need to wait for done bit
}

void DMAJoinSgl( DMASGLBuffer *previous, DMASGLBuffer *next, bool shouldInterrupt, bool adjustSync )
{
    PDMA64BitSGLEntry pLargeBuffer = ( PDMA64BitSGLEntry )( previous->pVa ) + previous->NumElements - 1;

    if ( adjustSync )
    {
        /*
         * We are being asked to remove the magic sync commands on the previous SGL tail
         * and on the head of the new SGL. We need only remove the previous tail IF it is marked
         * as the end sync.
         */
        PDMA64BitSGLEntry pNextBuffer = ( PDMA64BitSGLEntry )( next->pVa );
        if ( pLargeBuffer->LADR_LOW == 0x22222222 )
        {
            pLargeBuffer->LADR_LOW = 0;
        }
        pNextBuffer->LADR_LOW = 0;
    }

    pLargeBuffer->DPR = ( pLargeBuffer->DPR & ( DPR_Direction ) ) | ( next->PhysAddr & ~( DPR_InterruptAfterTransfer | DPR_EndOfChain ) );
    if( shouldInterrupt == TRUE )
        pLargeBuffer->DPR |= DPR_InterruptAfterTransfer;
}

void DMATransactionStart( DMAChannel * channel, uint32_t nElements, bool Write, uint64_t StartAddress )
{
    uint32_t CtrlWord = ( ( Write == false ) ? DPR_Direction : 0 );
    uint32_t CsrWord = 0;

    if( nElements == 1 )
        CtrlWord |= DPR_InterruptAfterTransfer | DPR_EndOfChain;

    // Set physical address of descriptor of First chunk
    DMAReadReg( channel, DMACSR, &CsrWord );

    KernelTrace( TRACE_LEVEL_VERBOSE, DMACommon, "start address: 0x%016llx\n", StartAddress );
    KernelTrace( TRACE_LEVEL_VERBOSE, DMACommon, "CSR was 0x%08x\n", CsrWord );

    DMAWriteReg( channel, DMADPRLower, cpu_to_le32( LowPart( StartAddress ) & 0xFFFFFFE0) | CtrlWord );
    if ( channel->Has64BitPADR )
        DMAWriteReg( channel, DMADPRUpper, cpu_to_le32( HighPart( StartAddress ) ) );
    else
        DMAWriteReg( channel, DMADPRUpper, 0 );

    // Enable DMA and start
    CsrWord |= CSR_DMAStart | CSR_DMAEnable | CSR_SGMode /*| CSR_EventInterruptEnable, Enable in the specific DMA controller*/;
    DMAWriteReg( channel, DMACSR,  CsrWord);
    KernelTrace( TRACE_LEVEL_VERBOSE, DMACommon, "CSR now 0x%08x\n", CsrWord );
}

int DMAPreForward( GroupedDMATx **ppTransaction, DMATransaction_IOCTL *inDmaTransfer )
{
    return DMAPreForwardEnhanced( ppTransaction, inDmaTransfer, DMA_FLAGS_NONE );
}

int DMAPreForwardEnhanced( GroupedDMATx **ppTransaction, DMATransaction_IOCTL *inDmaTransfer, uint32_t flags )
{
    uint32_t i;
    int result = -EBUSY;
    GroupedDMATx *pTransaction = NULL;
    DMATx *thisTx = NULL;

    if ( ppTransaction == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "NULL parameter\n" );
        return -EINVAL;
    }

    pTransaction = kzalloc( sizeof(GroupedDMATx), GFP_ATOMIC );
    if ( pTransaction == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, DMACommon, "Couldn't allocate memory for transaction!\n" );
        return -ENOMEM;
    }
    pTransaction->NumTxs = inDmaTransfer->Dma.nTargets;
    pTransaction->Txs = kzalloc( sizeof(DMATx) * pTransaction->NumTxs, GFP_ATOMIC );
    if ( pTransaction->Txs == NULL )
    {
        KernelTrace( TRACE_LEVEL_ERROR, DMACommon, "Couldn't allocate memory for all %u transactions!\n", pTransaction->NumTxs );
        kfree( pTransaction );
        return -ENOMEM;
    }
    INIT_LIST_HEAD( &(pTransaction->Next) );

    for ( i = 0 ; i < pTransaction->NumTxs; i++ )
    {
        thisTx = &pTransaction->Txs[i];
        thisTx->WriteDirection = inDmaTransfer->Dma.Write;
        thisTx->Flags = flags;

#ifdef OT_GPUDIRECT
        if (flags & DMA_FLAGS_GPUDIRECT)
        {
            result = GpuDirectPinPages( inDmaTransfer->Dma.Targets[i].DUMMYUNIONNAME.pVa, inDmaTransfer->Dma.Targets[i].Size, &thisTx->GpuPages );
        }
        else
#endif
        {
            result = MapUserPages( (unsigned long int)(inDmaTransfer->Dma.Targets[i].DUMMYUNIONNAME.pVa), inDmaTransfer->Dma.Targets[i].Size, &thisTx->MDL );
        }

        if ( 0 != result )
        {
            KernelTrace( TRACE_LEVEL_ERROR, DMACommon, "Failed to pin pages for target %u\n", i );
            break;
        }
        thisTx->LocalAddr = inDmaTransfer->Dma.Targets[i].LocalAddr;
        thisTx->Size = inDmaTransfer->Dma.Targets[i].Size;
        thisTx->bNoSync = inDmaTransfer->Dma.Targets[i].bNoSync;
    }

    if ( result != 0 )
    { // something went wrong, cleaning up
        for ( i = 0 ; i < pTransaction->NumTxs; i++ )
        {
            thisTx = &pTransaction->Txs[i];
#ifdef OT_GPUDIRECT
            if (flags & DMA_FLAGS_GPUDIRECT)
            {
                GpuDirectUnpinPages( &thisTx->GpuPages );
            }
            else
#endif
            {
                if ( thisTx->MDL.Pages != NULL )
                {
                    CleanUserPages( &thisTx->MDL );
                }
            }
        }

        kfree( pTransaction->Txs );
        kfree( pTransaction );
        pTransaction = NULL;
    }

    *ppTransaction = pTransaction;

    return result;
}

void DMAGroupedDMATxCleanup( GroupedDMATx * pTransaction, struct device * hcd )
{
    uint32_t i;
    DMATx *thisTx = NULL;

    for ( i = 0 ; i < pTransaction->NumTxs; i++ )
    {
        thisTx = &pTransaction->Txs[i];
#ifdef OT_GPUDIRECT
        if (thisTx->Flags & DMA_FLAGS_GPUDIRECT)
        {
            GpuDirectUnmapPages( &thisTx->GpuPages );
            GpuDirectUnpinPages( &thisTx->GpuPages );
        }
        else
#endif
        {
            if ( thisTx->MDL.Pages != NULL )
            {
                if ( thisTx->NumSGMapped > 0 )
                    dma_unmap_sg( hcd, thisTx->SGLBuffer->SGTable.sgl, thisTx->NumSGMapped, thisTx->WriteDirection ? DMA_TO_DEVICE : DMA_FROM_DEVICE );
                CleanUserPages( &thisTx->MDL );
            }
        }
    }

    kfree( pTransaction->Txs );
    kfree( pTransaction );
}


