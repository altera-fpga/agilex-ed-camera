/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef HOSTCONTROLLER_IOCTL_H_
#error "Do not include this directly."
#endif

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/**
 * @brief Current #HC_IOCTL_GetNumRegions HC_GetNumRegions_IOCTL::Version number to use
 */
#define HC_IOCTL_GetNumRegions_Version 0

/**
 * @brief Current #HC_IOCTL_GetRegion HC_GetRegion_IOCTL::Version number to use
 */
#define HC_IOCTL_GetRegion_Version 0

/**
 * @brief Current #HC_IOCTL_GetPlatformInfo HC_GetPlatformInfo_IOCTL::Version number to use
 */
#define HC_IOCTL_GetPlatformInfo_Version 0

/**
 * @brief Current #HC_IOCTL_ReadPciConfig HC_ReadPciConfig_IOCTL::Version number to use
 */
#define HC_IOCTL_ReadPciConfig_Version 0

/**
 * @brief IOCTL on OT_Host_Controller devices for obtaining the number of Capability Regions on a device
 */
#define HC_IOCTL_GetNumRegions   _IOWR( HC_IOC_MAGIC, HC_IOCTL_NUM_GetNumRegions, HC_GetNumRegions_IOCTL *)

/**
 * @brief IOCTL on OT_Host_Controller devices for reading a capability region
 */
#define HC_IOCTL_GetRegion      _IOWR( HC_IOC_MAGIC, HC_IOCTL_NUM_GetRegion, HC_GetRegion_IOCTL * )

/**
 * @brief IOCTL on OT_Host_Controller devices for reading the platform info
 */
#define HC_IOCTL_GetPlatformInfo      _IOWR( HC_IOC_MAGIC, HC_IOCTL_NUM_GetPlatformInfo, HC_PlatformInfoType * )

/**
 * @brief IOCTL on OT_Host_Controller devices for reading PCI Config Space
 */
#define HC_IOCTL_ReadPciConfig      _IOWR( HC_IOC_MAGIC, HC_IOCTL_NUM_ReadPciConfig, HC_ReadPciConfig * )

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/
