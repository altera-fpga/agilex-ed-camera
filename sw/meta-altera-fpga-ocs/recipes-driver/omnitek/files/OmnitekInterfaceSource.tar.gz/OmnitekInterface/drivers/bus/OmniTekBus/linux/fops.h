/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef FOPS_H_
#define FOPS_H_

#include <linux/fs.h>
#include "BusPrivate.h"

extern struct file_operations omnitekbus_fops;

long omnitekbus_fops_unlocked_ioctl( struct file *filp, unsigned int cmd, unsigned long arg );

int omnitekbus_fops_init( void * module, PBusDevice busData, struct device * dev );
void omnitekbus_fops_deinit( void );

#endif /* FOPS_H_ */
