/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef PLATFORMCAPABILITYBASEIOCTL_H_
#define PLATFORMCAPABILITYBASEIOCTL_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef CAPABILITYBASEIOCTL_H_
#error "Do not include this directly."
#endif

#include "../CapabilityDevice.h"
struct _CapabilityDeviceInterface;

/**
 * @brief Standard process routine for IOCTL on register based devices
 *
 * Valid IoControlCodes are #CAP_RA_IOCTL_GetRegisterCount,
 *  #CAP_RA_IOCTL_GetBlockCount, #CAP_RA_IOCTL_RegisterRead,
 *  #CAP_RA_IOCTL_RegisterWrite, #CAP_RA_IOCTL_RegisterShadowRead and
 *  #CAP_RA_IOCTL_GetMetaData
 * @param[in] RegCap CapRegister instance to process the request with respect to
 * @param[in] Request The address of the request information
 * @param[in] IoControlCode the IOCTL code for this request
 * @return Any return code that could be generated in an IOCTL routine under Linux
 */
long ProcessCapabilityBaseIOCTL( CapRegister *RegCap, struct _CapabilityDeviceInterface *interface, unsigned long Request, unsigned int IoControlCode );

struct _CapCommon_QueryInfo_IOCTL;
long ProcessCommon_QueryInfo_Register( Capability *cap, struct _CapabilityDeviceInterface *interface, struct _CapCommon_QueryInfo_IOCTL * data );

/** @}*/

#endif /* PLATFORMCAPABILITYBASEIOCTL_H_ */
