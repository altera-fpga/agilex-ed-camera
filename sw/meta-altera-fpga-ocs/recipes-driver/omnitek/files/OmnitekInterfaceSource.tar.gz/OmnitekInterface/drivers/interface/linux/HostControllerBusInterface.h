/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef HOSTCONTROLLERBUSINTERFACE_H_
#error "Do not include this file directly"
#endif

#include "Customise.h"

struct _HCBusInterface;

int MANUF_FUNC( _GetInterfaceHCInterface )( POmniTekHostController hc, struct _HCBusInterface * interface );

/** @}*/
