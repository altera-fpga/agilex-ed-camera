/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

// FIXME: make the linux bus capable of multiple instances. currently restricted to one and only one

#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/version.h>

#include "Customise.h"
#include "BusPrivate.h"
#include "HostControllerBusInterface.h"
#include "Types.h"
#include "omnitekbus.h"
#include "fops.h"

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif

#include "OTCapabilityTypes.h"

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_WARNING;

BusDevice _private_bus_data;
struct device omnitekbus_device;


void omnitekbus_capdevice_release( struct device *dev )
{
    POmniTekCapabilityDevice capdev = NULL;
    capdev = ToOmniTekCapabilityDevice( dev );
}

void RemoveBusChildren( VirtualBus *vb )
{
    uint32_t i = 0;
    for( i = 0; i < vb->NumChildren; i++ )
    {
        // not sure if i actually need this first......
        device_release_driver( &vb->Children[ i ].Device );
        // now remove the device from the system
        device_unregister( &vb->Children[ i ].Device );
    }
}

int32_t AddCapabilityDevice( POmniTekCapabilityDevice capDev, PVirtualBus vb )
{
    PBusDevice privateBusData = NULL;

    privateBusData = vb->Controller->BusContext;

    capDev->CharDevNum = MKDEV( MAJOR( privateBusData->CapabilitiesMajorDev ), MINOR( privateBusData->CapabilitiesMajorDev ) + CDEV_MINOR( capDev->Id ) );

    capDev->Device.bus = &omnitekbus;
    capDev->Device.parent = &omnitekbus_device;
    capDev->Device.release = omnitekbus_capdevice_release; //!< not sure why this is needed as we clean up elsewhere....
    dev_set_name( &capDev->Device, capDev->FriendlyName );

    return device_register( &capDev->Device );
}


int MANUF_FUNC( _GetInterfaceHCInterface )( POmniTekHostController hc, struct _HCBusInterface * interface )
{
    if ( hc == NULL || interface == NULL )
        return -1;

    hc->BusContext = &_private_bus_data;

    interface->ClearCapabilities = ClearCapabilities;
    interface->DeRegisterHostController = DeRegisterHostController;
    interface->DiscoverCapabilities = DiscoverCapabilities;
    interface->FinaliseCapabilities = FinaliseCapabilities;
    interface->INIT_OmniTekHostControllerInterface = INIT_OmniTekHostControllerInterface;
    interface->PrintCapabilities = PrintCapabilities;
    interface->RegisterHostController = RegisterHostController;
    interface->GetCapabilityAt = GetCapabilityAt;
    return 0;
}
MANUF_EXPORT( _GetInterfaceHCInterface );



// we only have one bus so what we do below is acceptable
static void omnitekbus_device_release( struct device *dev )
{
    VirtualBusEntry *vbe = NULL;
    VirtualBus *vb = NULL;
    uint32_t lastCount = 0;
    while( CollectionCount( &_private_bus_data.VirtualBusList ) > 0 )
    {
        lastCount = CollectionCount( &_private_bus_data.VirtualBusList );

        vbe = CollectionGetFirstVirtualBusEntry( &_private_bus_data.VirtualBusList );
        vb = FromVirtualBusEntry( vbe );

        vb->Interface.NotifyBusExit( vb->Controller );
        if( CollectionCount( &_private_bus_data.VirtualBusList ) == lastCount )
        { // the remove call did nothing manually remove it!
            KernelTrace( TRACE_LEVEL_WARNING, OmniTekBus, "HostController @ %p did not detach when requested, manually removing\n", vb->Controller );
            DeRegisterHostController( vb->Controller );
        }
    }
}

/**
 * This gets called upon new device(s) being added without an assigned device_driver.
 * It also gets called when a new device_driver is added to the bus for each device
 * that does not yet have a device_driver attached!!!
 * If it returns 1 is will temporarily attach the device_driver to the device then
 * call probe on the driver. If the probe succeeds then it is assumed the device is
 * now in a working state!!!.... Documentation/binding.txt
 *
 * This is the magic function that we can use to do special matching if needed....
 * Hence we can add our own style match ids as we can decorate the device and the
 * device_driver with extra data. As we are the bus be dictate what type of register
 * driver and register device / device creation is done
 *
 * We also have driver_unbind / driver_bind to manually ask for linkages....
 *
 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,11,0)
static int omnitekbus_match( struct device * dev, const struct device_driver * driver )
#else
static int omnitekbus_match( struct device * dev, struct device_driver * driver )
#endif
{
    POmniTekCapabilityDevice capDev = NULL;
    POmniTekCapabilityDriver capDriver = NULL;
    const DriverMatchId * matchId = NULL;

    capDev = ToOmniTekCapabilityDevice( dev );
    capDriver = ToOmniTekCapabilityDriver( driver );

    if( capDriver->IdTable != NULL )
    {
        matchId = capDriver->IdTable;
        while( matchId->ExtendedType != 0 || matchId->Type != 0 || matchId->Version != 0 )
        {
            if( matchId->Type == capDev->CapInfo->Type )
            {
                if( IsAnyRegCap( capDev->CapInfo ) && ( matchId->ExtendedType == GetRegCap( capDev->CapInfo ).Type || matchId->ExtendedType == 0 ) && ( matchId->Version == 0 || matchId->Version == capDev->CapInfo->Version ) )
                {
                    return 1;
                }
                if( IsMemMapCap( capDev->CapInfo ) && ( matchId->ExtendedType == GetMemMapCap( capDev->CapInfo ).Type ||  WildcardRegion == matchId->ExtendedType ) && ( matchId->Version == 0 || matchId->Version == capDev->CapInfo->Version ) )
                {
                    return 1;
                }
                if( NotAnyRegCap( capDev->CapInfo ) && ( matchId->Version == 0 || matchId->Version == capDev->CapInfo->Version ) )
                {
                    return 1;
                }
            }
            matchId++;
        }
    }

    return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,4,0)
const struct class * MANUF_FUNC(_GetClass)( void )
#else
struct class * MANUF_FUNC(_GetClass)( void )
#endif
{
    return omnitekbus_device.class;
}
MANUF_EXPORT( _GetClass );

struct bus_type omnitekbus = {
    .name = MANUF_CONCAT("_FPGABus"),
    .match = omnitekbus_match,
};

struct device omnitekbus_device = {
    .init_name = MANUF_CONCAT("_FPGABus0"),
    .release = omnitekbus_device_release
};

extern struct device_attribute dev_attr_debuglevel;

static int __init omnitekbus_init( void )
{
    int ret = 0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,4,0)
    omnitekbus_device.class = class_create( MANUF_STR );
#else
    omnitekbus_device.class = class_create( THIS_MODULE, MANUF_STR );
#endif
    if( IS_ERR( omnitekbus_device.class ) )
    {
        ret = PTR_ERR( omnitekbus_device.class );
        KernelTraceNA( TRACE_LEVEL_CRITICAL, OmniTekBus, "Unable to create class!!!\n" );
        return ret;
    }
    _private_bus_data.CapabilitiesMajorDev = 0;

    ret = INIT_BusDevice( &_private_bus_data );
    if ( ret != SUCCESS )
    	return ret;

    ret = bus_register( &omnitekbus );
    if( ret )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, OmniTekBus, "Unable to register bus!!!\n" );
        return ret;
    }

    ret = device_register( &omnitekbus_device );
    if( ret )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, OmniTekBus, "Unable to register bus device\n" );
        return ret;
    }

    ret = omnitekbus_fops_init( THIS_MODULE, &_private_bus_data, &omnitekbus_device );
    if( ret )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, OmniTekBus, "Unable to make char device for bus\n" );
        return ret;
    }

    ret = device_create_file( &omnitekbus_device, &dev_attr_debuglevel );
    if( ret )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, OmniTekBus, "can't create sysfs debuglevel file!!!\n" );
        return ret;
    }

    ret = alloc_chrdev_region( &_private_bus_data.CapabilitiesMajorDev, 0, MAX_CHARDEVPOOL, MANUF_CONCAT("BusCapsCharDevs") );
    if( ret )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, OmniTekBus, "Error %d alloc_chrdev_region", ret);
        return ret;
    }

    return ret;
}

static void omnitekbus_exit( void )
{
    unregister_chrdev_region( _private_bus_data.CapabilitiesMajorDev, MAX_CHARDEVPOOL );

    device_remove_file( &omnitekbus_device, &dev_attr_debuglevel );

    omnitekbus_fops_deinit( );

    device_unregister( &omnitekbus_device );

    bus_unregister( &omnitekbus );

    DEINIT_BusDevice( &_private_bus_data );

    class_destroy( omnitekbus_device.class );
}
module_init( omnitekbus_init );
module_exit( omnitekbus_exit );
