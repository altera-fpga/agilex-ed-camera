/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/slab.h>
#include <linux/err.h>

#include "linux/Event.h"


void EventListInit( EventList *eventList )
{
    INIT_LIST_HEAD( &(eventList->Head) );
    spin_lock_init( &(eventList->Lock) );
    eventList->LastEventId = 0;
}

bool EventListIsEmpty( EventList *eventList )
{
    bool ret = true;
    SpinLockAcquire( eventList->Lock );

    ret = list_empty( &(eventList->Head) );

    SpinLockRelease( eventList->Lock );

    return ret;
}

void EventListClean( EventList *eventList )
{
    EventItem *eventItem = NULL;
    EventItem *temp = NULL;

    LIST_HEAD(cancel_list);

    SpinLockAcquire( eventList->Lock );

    while ( ! list_empty( &(eventList->Head) ) )
    {
        eventItem = list_entry( (&(eventList->Head))->next, EventItem, List );
        list_del( &( eventItem->List ) );
        list_add_tail( &( eventItem->List ), &cancel_list );
    }

    SpinLockRelease( eventList->Lock );

    list_for_each_entry_safe( eventItem, temp, &cancel_list, List )
    {
        if ( eventItem->Cancel != NULL )
        {
            eventItem->Cancel( eventItem->IOCTLContext );
        }
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,7,12)
        eventfd_signal( eventItem->KernelContext );
#else
        eventfd_signal( eventItem->KernelContext, EventCanceled );
#endif        
        eventfd_ctx_put( eventItem->KernelContext );

        list_del( &( eventItem->List ) );

        kfree( eventItem );
    }
}

EventItem * EventPrepare( EventList *eventList, CapGeneral_EventCtx_IOCTL *userCtx, uint64_t tag, void * eventIOCTLContext, EventCompleteCB eventComplete, EventCancelCB eventCancel )
{
    EventItem * newItem = NULL;
    struct eventfd_ctx * kernelContext = eventfd_ctx_fdget( userCtx->EventFD );
    if ( IS_ERR( kernelContext ))
        return NULL;

    newItem = ( EventItem * )kzalloc( sizeof( EventItem ), GFP_KERNEL );
    if ( newItem == NULL )
    {
        eventfd_ctx_put( kernelContext );
        return NULL;
    }

    INIT_LIST_HEAD( &( newItem->List ) );
    newItem->KernelContext = kernelContext;
    newItem->Cancel = eventCancel;
    newItem->Complete = eventComplete;
    newItem->IOCTLContext = eventIOCTLContext;
    newItem->Tag = tag;
    newItem->Added = false;

    SpinLockAcquire( eventList->Lock );

    newItem->Id = ++eventList->LastEventId;
    userCtx->EventID = newItem->Id;

    SpinLockRelease( eventList->Lock );

    return newItem;
}

bool EventAddAllocated( EventList *eventList, EventItem * eventItem )
{
    SpinLockAcquire( eventList->Lock );

    if ( eventItem->Added )
    {
        SpinLockRelease( eventList->Lock );
        return false;
    }

    list_add_tail( &( eventItem->List ), &(eventList->Head) );
    eventItem->Added = true;

    SpinLockRelease( eventList->Lock );

    return true;
}

bool EventCleanAllocated( EventItem * eventItem )
{
    if ( eventItem->Added )
        return false;

    eventfd_ctx_put( eventItem->KernelContext );

    kfree( eventItem );

    return true;
}


bool EventAdd( EventList *eventList, CapGeneral_EventCtx_IOCTL *userCtx, uint64_t tag, void * eventIOCTLContext, EventCompleteCB eventComplete, EventCancelCB eventCancel )
{
    EventItem * newItem = EventPrepare( eventList, userCtx, tag, eventIOCTLContext, eventComplete, eventCancel ) ;
    if ( newItem == NULL )
        return false;

    return EventAddAllocated( eventList, newItem );
}

bool _EventComplete( EventList *eventList, EventItem * eventItem, bool cancel, void *secondContext, bool fromUserContext )
{
    bool retVal = false;
    if ( eventItem != NULL )
    {
        retVal = true;
        list_del( &( eventItem->List ) );
        SpinLockRelease( eventList->Lock );

        if ( cancel )
        {
        	if( eventItem->Cancel != NULL )
        	{
        		eventItem->Cancel( eventItem->IOCTLContext );
        	}
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,7,12)
            eventfd_signal( eventItem->KernelContext );
#else
            eventfd_signal( eventItem->KernelContext, EventCanceled );
#endif            
        }
        else
        {
            if ( eventItem->Complete != NULL )
            {
                eventItem->Complete( eventItem->IOCTLContext, secondContext, fromUserContext );
            }
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,7,12)
            eventfd_signal( eventItem->KernelContext );
#else
            eventfd_signal( eventItem->KernelContext, EventCompleted );
#endif            
        }
        eventfd_ctx_put( eventItem->KernelContext );

        kfree( eventItem );
    }

    return retVal;
}

bool EventCompleteNextByTag( EventList *eventList, uint64_t eventTag, void *completeContext, bool fromUserContext )
{
    return _EventComplete( eventList, _EventFind( eventList, eventTag, false ), false, completeContext, fromUserContext );
}

bool EventCancel( EventList *eventList, uint64_t eventId )
{
    return _EventComplete( eventList, _EventFind( eventList, eventId, true ), true, NULL, false );
}

bool EventComplete( EventList *eventList, uint64_t eventId, void *completeContext, bool fromUserContext )
{
    return _EventComplete( eventList, _EventFind( eventList, eventId, true ), false, completeContext, fromUserContext );
}

EventItem * _EventFind( EventList *eventList, uint64_t eventId, bool isId )
{
    struct list_head *list = NULL;
    EventItem *item = NULL;

    SpinLockAcquire( eventList->Lock );

    list_for_each( list, &(eventList->Head) )
    {
        item = list_entry( list, EventItem, List );
        if( ( isId && ( eventId == item->Id ) ) || ( !isId && ( eventId == item->Tag ) ) )
        {
            return item;
        }
    }

    SpinLockRelease( eventList->Lock );
    return NULL;
}


