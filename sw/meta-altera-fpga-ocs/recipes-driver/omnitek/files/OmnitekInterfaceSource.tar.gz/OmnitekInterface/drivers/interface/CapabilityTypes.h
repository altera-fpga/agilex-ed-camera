/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef CAPABILITYTYPES_H_
#define CAPABILITYTYPES_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "Common.h"
#include "Memory.h"

/*
 * For information about the following structures and values please see the
 * Capabilities document
 */


// just in case we need to increase the sizes in the future....
typedef uint32_t RegCount_t; //!< Number of registers in block
typedef uint16_t ComponentId_t; //!< Unique component id
typedef uint16_t AssociationId_t; //!< Association id
typedef uint8_t InterruptLevel_t; //!< Interrupt Level
typedef uint8_t InterruptId_t; //!< Interrupt Id

/**
 * @brief Indicator that this capability is not claiming an interrupt
 */
#define NoInterrupt 0xff

/**
 * @brief A block of registers
 */
typedef struct _RegisterBlock
{
    RegCount_t Count; //!< number of 32bit registers in this block
    uint64_t Offset; //!< only needed for non-automapped memory, is the offset for this reg block
    uint32_t *VA; //!< Start address of the first register in the block
    uint32_t *Shadow; //!< The shadow value each register within this block
    Allocateable ShadowMem; //!< needed for cross platform allocations unfortunately
    ot_phys_addr_t PhysicalAddress; //!< the real location of the registers. from the hardwares point of view
} RegisterBlock;
typedef RegisterBlock *PRegisterBlock; //!< Pointer to a ::RegisterBlock

/**
 * @brief Register and offset capability structure
 */
typedef struct _CapRegister
{
    uint16_t Type; //!< Refer to RegCap_t in DriverInterface/OTCapabilityTypes.h
    uint8_t Version; //!< Version of this register capability
    ComponentId_t ComponentId; //!< Unique component id
    AssociationId_t AssociationId; //!< Association id to link other capabilites to this
    InterruptLevel_t InterruptLevel; //!< What interrupt level we are claiming OR #NoInterrupt if no interrupt
    RegCount_t NumBlocks; //!< number of register blocks in this register capability
    RegisterBlock *Blocks; //!< array of register blocks
    Allocateable BlocksMem; //!< INTERNAL: needed for cross platform allocations unfortunately
    // Capability Version 2 Extras
    RegCount_t IRQStatusRegister; //!< Register number within the first register block for the generic irq status. Or 0xffffffff if not valid...
    RegCount_t IRQEnableRegister; //!< Register number within the first register block for the generic irq enable. Or 0xffffffff if not valid...
} CapRegister;
typedef CapRegister *PCapRegister; //!< Pointer to a ::CapRegister

/**
 * @brief Memory Map capability structure
 */
typedef struct _CapMemoryMap
{
    uint8_t Type; //!< Refer to MemMapTypes in DriverInterface/OTCapabilityTypes.h
    uint8_t Bar; //!< If type is BarRegion then this is the PCIe BAR this map is located on
    uint64_t Size; //!< Size in bytes of map region
    uint64_t Offset; //!< Offset in bytes for the start address of the region
    uint32_t *VA; //!< as its likely to be mapped we might as well track it in this structure
} CapMemoryMap;
typedef CapMemoryMap *PCapMemoryMap; //!< Pointer to a CapMemoryMap

/**
 * @brief Interrupt capability structure
 */
typedef struct _CapInterrupt
{
    InterruptId_t Id; //!< unique id to allow multiple interrupt capabilities on a host controller
    uint8_t BaseLevel; //!< The base value for this interrupt
    uint8_t NumUsedBits; //!< The number of used bits, needed to allow tight grouping of interrupt levels
    RegisterBlock EnableRegisters; //!< Enable register block for this interrupt capability
    RegisterBlock StatusRegisters; //!< Status register block for this interrupt capability
} CapInterrupt;
typedef CapInterrupt *PCapInterrupt; //!< Pointer to a CapInterrupt

/**
 * @brief Main capability structure
 *
 * This is the structure that is used to store all information about discovered
 * capabilities within the system.
 */
typedef struct _Capability
{
    uint32_t *BarBase; //!< memory address passed to ::HCBusInterface::DiscoverCapabilities
    uint32_t *Base; //!< virtual address for the start of this Capability
    uint8_t Size; //!< Full size of this capability ( in terms of structure we will read... )
    uint8_t Version; //!< Version of the capability header
    uint8_t Type; //!< see CapabilityTypes in DriverInterface/OTCapabilityTypes.h
    uint8_t SupressDriver; //!< if non 0 do not make a driver for this item... used for host controller override....
    union
    {
        CapMemoryMap MemMap; //!< used if Capability::Type == CapabilityTypes::MemMapCap
        CapInterrupt Interrupt; //!< used if Capability::Type == CapabilityTypes::InterruptCap
        CapRegister Register; //!< used if Capability::Type == CapabilityTypes::RegisterCap OR CapabilityTypes::OffsetCap
        void *Custom; //!< Not currently implemented
    } Ext; //!< Specific capability information
} Capability;
typedef Capability *PCapability; //!< Pointer to a Capability

/*
 * Some macros to perform common tasks.
 */

/**
 * @brief Is the Capability::Type an OmniTek define one?
 */
#define IsOmniTekCapability( t ) ( ( t & 0x7fff ) == t )

/**
 * @brief Given a ::PCapability get the ::CapRegister structure
 */
#define GetRegCap( capPtr ) (capPtr)->Ext.Register

/**
 * @brief Convenience to check to see if the passed ::PCapability is an CapabilityTypes::OffsetCap
 */
#define IsRemRegCap( capPtr ) ( (capPtr)->Type == OffsetCap )

/**
 * @brief Convenience to check to see if the passed ::PCapability is an CapabilityTypes::RegisterCap
 */
#define IsRegCap( capPtr ) ( (capPtr)->Type == RegisterCap )

/**
 * @brief Convenience to check to see if the passed ::PCapability is an CapabilityTypes::OffsetCap OR CapabilityTypes::RegisterCap
 */
#define IsAnyRegCap( capPtr ) ( IsRegCap(capPtr) || IsRemRegCap(capPtr) )

/**
 * @brief Convenience to check to see if the passed ::PCapability neither a CapabilityTypes::OffsetCap OR CapabilityTypes::RegisterCap
 */
#define NotAnyRegCap( capPtr ) ( ( ! IsRegCap(capPtr) ) && ( ! IsRemRegCap(capPtr) ) )

/**
 * @brief Given a ::PCapability get the ::CapInterrupt structure
 */
#define GetIntrCap( capPtr ) (capPtr)->Ext.Interrupt

/**
 * @brief Convenience to check to see if the passed ::PCapability is an CapabilityTypes::InterruptCap
 */
#define IsIntrCap( capPtr ) ( (capPtr)->Type == InterruptCap )

/**
 * @brief Given a ::PCapability get the ::CapMemoryMap structure
 */
#define GetMemMapCap( capPtr ) (capPtr)->Ext.MemMap

/**
 * @brief Convenience to check to see if the passed ::PCapability is an CapabilityTypes::MemMapCap
 */
#define IsMemMapCap( capPtr ) ( (capPtr)->Type == MemMapCap )

/**
 * @brief Struct used for convenient mapping of changing register maps to a static one...
 * Sometimes are firmware is being created the location of registers gets changed.
 * A driver writer can create their own mapping using this struct....
 * Alternatively if there are a few variants of firmware where the locations change this could
 * also be used.
 */
typedef struct _RegMapping
{
    PRegisterBlock Block; //!< which register block
    RegCount_t Reg; //!< which register within a register block
} RegMapping;


/** @}*/

#endif /* CAPABILITYTYPES_H_ */
