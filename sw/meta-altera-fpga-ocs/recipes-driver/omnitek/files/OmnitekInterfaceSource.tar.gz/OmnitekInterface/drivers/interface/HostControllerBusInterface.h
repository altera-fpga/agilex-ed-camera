/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HOSTCONTROLLERBUSINTERFACE_H_
#define HOSTCONTROLLERBUSINTERFACE_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"

#include "CapabilityTypes.h"
#include "HostController.h"
#include "HostControllerInterface.h"
#include "Container.h"

// Generate the definitions for the Capability based OmniTekCollection
ITER_TYPE_DEFS( Capability, Capability )

/**
 * @brief Function pointer for ::INIT_OmniTekHostControllerInterface
 */
typedef void (*INIT_OTHCI)( POmniTekHostControllerInterface hci );

/**
 * @brief Function pointer for ::RegisterHostController
 */
typedef int (*RegHC)( POmniTekHostController hc, POmniTekHostControllerInterface hci );

/**
 * @brief Function pointer for ::DeRegisterHostController
 */
typedef void (*DeRegHC)( POmniTekHostController hc );

/**
 * @brief Function pointer for ::DiscoverCapabilities
 */

typedef OmniTekCollection * (*DisCaps)( POmniTekHostController hc, uint32_t *base, const uint64_t len, ot_phys_addr_t physical_base );

/**
 * @brief Function pointer for ::FinaliseCapabilities
 */
typedef int (*FinCaps)( POmniTekHostController hc );

/**
 * @brief Function pointer for ::ClearCapabilities
 */
typedef void (*ClearCaps)( POmniTekHostController hc );

/**
 * @brief Function pointer for ::PrintCapabilities
 */
typedef void (*PrintCaps)( OmniTekCollection * capCollection );

/**
 * @brief Function pointer for obtaining a ::PCapability from an OmniTekCollection
 * @param[in] col The OmniTekCollection of internal type Capability
 * @param[in] idx The index within said collection
 * @return Pointer to requested Capability OR NULL on error
 */
typedef PCapability (*GetCapAt)( OmniTekCollection * col, uint32_t idx );

/**
 * @brief Windows specific remote interface definition for Host Controller to OmniTekBus communication
 */
typedef struct _HCBusInterface
{
#if BUILDTYPE == BT_WINDOWS
    INTERFACE InterfaceHeader; //!< standard interface header needed for cross stack comms
#endif
    INIT_OTHCI INIT_OmniTekHostControllerInterface; //!< Initialise a ::OmniTekHostControllerInterface structure
    GetCapAt GetCapabilityAt; //!< Get an item from the OmniTekCollection of Capability structures
    RegHC RegisterHostController; //!< Register your HostController with the OmniTekBus
    DeRegHC DeRegisterHostController; //!< DeRegister your HostController with the OmniTekBus
    DisCaps DiscoverCapabilities; //!< Perform a capability discovery via the OmniTekBus
    FinCaps FinaliseCapabilities; //!< Inform the bus that enumeration is complete and can go ahead and make the devices for the capabilities found
    ClearCaps ClearCapabilities; //!< Inform the bus that we no longer want the previously enumerated capabilities
    PrintCaps PrintCapabilities; //!< Debug only, print out the passed Capability collection
} HCBusInterface;
typedef HCBusInterface *PHCBusInterface; //!< Pointer to HCBusInterface

// include platform specific headers
#if BUILDTYPE == BT_WINDOWS
#include "windows/HostControllerBusInterface.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/HostControllerBusInterface.h"
#endif

/** @}*/

#endif /* HOSTCONTROLLERBUSINTERFACE_H_ */
