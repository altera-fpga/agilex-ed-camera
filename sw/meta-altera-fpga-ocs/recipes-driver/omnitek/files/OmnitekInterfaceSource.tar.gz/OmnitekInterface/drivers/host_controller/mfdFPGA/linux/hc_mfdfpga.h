/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HC_MFD_FPGA_H_
#define HC_MFD_FPGA_H_

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#include "Common.h"
#include "HostController.h"
#include "HostControllerBusInterface.h"

typedef struct
{
    uint32_t * CapMemory;
    ot_phys_addr_t CapAddress;
    uint32_t CapLength;
}CapRegion;
#define MAX_CAPABILITY_REGIONS (1)

typedef struct
{
    PCapInterrupt Info;
    unsigned int IRQ;
} LinuxInterruptInfo;

typedef struct
{
    // common to all platforms
    OmniTekHostController hc;
    OmniTekHostControllerInterface hci;
    HCBusInterface BusInterface;

    // if we had interrupts we would need this
    HCISRCB BusISR;
    uint32_t NumInterrupts; //!< total children created.
    LinuxInterruptInfo *Interrupts;
    Allocateable InterruptsMem; //!< needed for cross platform allocations...

    // hardware specific device
    struct platform_device *pdev;

    CapRegion CapRegions[MAX_CAPABILITY_REGIONS];
    uint32_t  nCapRegions;
    
    // for char interface for ioctls
    dev_t Major;
    dev_t Minor;
    struct cdev CDev;

    spinlock_t IrqLock; /*!< SpinLock used to disable interrupts (on current processor) */

    bool registrationDone;

    struct workqueue_struct* wq;
    struct work_struct work;
} DriverInstanceData;

// {AC2F3BC2-2018-4876-8418-7997BD2DE446}
DEFINE_UUID( UUID_USERINTERFACE_HC_MFD_FPGA, 0xAC2F3BC2, 0x2018, 0x4876, 0x84, 0x18, 0x79, 0x97, 0xBD, 0x2D, 0xE4, 0x46 );

#endif /* HC_MFD_FPGA_H_ */
