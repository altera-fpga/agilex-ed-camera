/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef MDMA_IOCTL_H_
#define MDMA_IOCTL_H_

#include "global_defs.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

/** \addtogroup UserlandInterface
 *  @{
 */

/** \cond */
#define CAP_MDMA_IOC_MAGIC (2)
/** \endcond */

/** \cond */
enum
{
	CAP_MDMA_IOCTL_NUM_Transfer = OT_IOCTL_NUMBER(CAP_MDMA_IOC_MAGIC, 1), //!<
};
/** \endcond */

/* Include the platform specific headers  */
#if BUILDTYPE == BT_WINDOWS
#include "windows/MDMA_IOCTL.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/MDMA_IOCTL.h"
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/

#endif /* MDMA_IOCTL_H_ */
