/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "BusPrivate.h"

#include "HostControllerBusInterface.h"

ITER_TYPE_IMPL( Capability, Capability );

ITER_TYPE_IMPL( VirtualBus, VirtualBus )
