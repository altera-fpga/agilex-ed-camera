/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef COMMON_IOCTL_H_
#error "Do not include this directly."
#endif

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


#pragma pack(push,4)

/**
 * @brief This is the payload for all eventfd operations
 */
typedef struct _CapGeneral_EventCtx_IOCTL
{
    int EventFD; //!< The eventfd in userland
    uint64_t EventID; //!< A device unique id for cancelling...
} CapGeneral_EventCtx_IOCTL;

/**
 * @brief The info about which eventfd is being cancelled
 */
typedef struct _CapGeneral_Cancel_IOCTL
{
    uint32_t Version; //!< see the description for more information
    CapGeneral_EventCtx_IOCTL EventInfo; //!< information about what to cancel
} CapGeneral_Cancel_IOCTL;

#pragma pack(pop)

/**
 * @brief Current #CAP_COMMON_IOCTL_Cancel CapGeneral_Cancel_IOCTL::Version number to use
 */
#define CAP_COMMON_IOCTL_Cancel_Version 0

/**
 * @brief IOCTL on devices that support eventfds, used to inform the drive to cancel the use of this eventfd
 * Passed and received data type is CapGeneral_Cancel_IOCTL
 */
#define CAP_COMMON_IOCTL_Cancel   _IOWR( CAP_COMMON_IOC_MAGIC, CAP_COMMON_IOCTL_NUM_Cancel, CapGeneral_Cancel_IOCTL * )

/**
 * @brief Current #CAP_COMMON_IOCTL_QueryInfo CapCommon_QueryInfo_IOCTL::Version number to use
 */
#define CAP_COMMON_IOCTL_QueryInfo_Version 0

/**
 * @brief Current #CAP_COMMON_IOCTL_QueryIOCTLInfo CapCommon_QueryIOCTLInfo_IOCTL::Version number to use
 */
#define CAP_COMMON_IOCTL_QueryIOCTLInfo_Version 0

/**
 * @brief IOCTL on all devices, used to get extra information about abilities and properties.
 * Passed and received data type is CapCommon_QueryInfo_IOCTL
 */
#define CAP_COMMON_IOCTL_QueryInfo   _IOWR( CAP_COMMON_IOC_MAGIC, CAP_COMMON_IOCTL_NUM_QueryInfo, CapCommon_QueryInfo_IOCTL * )

/**
 * @brief IOCTL on all devices, used to get extra information about abilities and properties.
 * Passed and received data type is CapCommon_QueryIOCTLInfo_IOCTL
 */
#define CAP_COMMON_IOCTL_QueryIOCTLInfo   _IOWR( CAP_COMMON_IOC_MAGIC, CAP_COMMON_IOCTL_NUM_QueryIOCTLInfo, CapCommon_QueryIOCTLInfo_IOCTL * )

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/
