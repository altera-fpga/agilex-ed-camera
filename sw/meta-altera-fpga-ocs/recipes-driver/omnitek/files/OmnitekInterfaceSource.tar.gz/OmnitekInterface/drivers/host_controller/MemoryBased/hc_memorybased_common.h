/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HCPRIVATE_H_
#define HCPRIVATE_H_

#define MS 0x1000

#if BUILDTYPE == BT_LINUX
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#endif

#include "Common.h"
#include "HostController.h"
#include "HostControllerBusInterface.h"

typedef struct
{
    // common to all platforms
    OmniTekHostController hc;
    OmniTekHostControllerInterface hci;
    HCBusInterface BusInterface;

    // if we had interrupts we would need this
//    HCISRCB BusISR;
//    uint32_t NumInterrupts; //!< total children created.
//    PCapInterrupt *Interrupts;
//    Allocateable InterruptsMem; //!< needed for cross platform allocations...

    // this hardware specific data
    uint32_t mem[ MS ];
    uint32_t memSize;

#if BUILDTYPE == BT_WINDOWS
    WDFSTRING      BusInstanceString; //!< for bus duplication detection
    PVOID          NotificationHandle; //!< for pnp notifications about the bus

    // if we had interrupts
//    WDFINTERRUPT   WdfInterrupt;
#endif
#if BUILDTYPE == BT_LINUX
    // hardware specific device
    struct platform_device *pdev;

    // for char interface for ioctls
    dev_t Major;
    dev_t Minor;
    struct cdev CDev;

    // if we had interrupts
//    spinlock_t IrqLock; /*!< SpinLock used to disable interrupts (on current processor) */
//    u32 nInterruptStatus; /*!< Interrupt status for this device */
//    u32 nDmaStatus; /*!< Channels that are flagging an interrupt */

#endif
} DriverInstanceData;

// {94E7DE60-71AB-431e-9F11-83CDE32CD6EE}
DEFINE_UUID( UUID_USERINTERFACE_HC_MEMORYBASED, 0x94e7de60, 0x71ab, 0x431e, 0x9f, 0x11, 0x83, 0xcd, 0xe3, 0x2c, 0xd6, 0xee );

void OT_HC_MemoryBased_Enumerate( DriverInstanceData * did );
void OT_HC_MemoryBased_FillInTest( uint32_t *mem );

#endif /* HCPRIVATE_H_ */
