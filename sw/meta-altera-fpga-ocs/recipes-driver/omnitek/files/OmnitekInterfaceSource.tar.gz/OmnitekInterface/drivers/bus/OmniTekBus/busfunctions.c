/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "global_defs.h"

#include "BusPrivate.h"
#include "Common.h"

#include "OTCapabilityTypes.h"
#ifdef USE_WPP
#include "trace.h"
#include "AUTOGEN.busfunctions.tmh"
#endif

void PrintCapability( Capability * cap )
{
    uint32_t j = 0;
    if( cap != NULL )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Base( %p ), Size( %d ), Version( 0x%04X ), Type( 0x%02X ), SupressDriver( %s )\n", cap->Base, cap->Size, cap->Version, cap->Type, ( cap->SupressDriver == 0 ? "No" : "Yes" ) );
        switch( cap->Type )
        {
            case MemMapCap:
            {
                KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "\tMemoryMapCapability: Type( 0x%02X ), Bar( %d ), Size( 0x%016llX ), Offset( 0x%016llX ), VA( %p )\n", cap->Ext.MemMap.Type, cap->Ext.MemMap.Bar, cap->Ext.MemMap.Size, cap->Ext.MemMap.Offset, cap->Ext.MemMap.VA );
                break;
            }
            case InterruptCap:
            {
                KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "\tInterruptCapability: Id( 0x%02X ), BaseLevel( %d ), Count( %d ), NumBits( %d )\n", GetIntrCap(cap).Id, GetIntrCap(cap).BaseLevel, GetIntrCap(cap).EnableRegisters.Count, GetIntrCap(cap).NumUsedBits );
                break;
            }
            case RegisterCap:
            case OffsetCap:
            {
                if ( cap->Type == RegisterCap )
                    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "\tRegisterCapability: Type( 0x%02X ), Version( 0x%02X ), ComponentId( 0x%02X ), AssociationId( 0x%02X ), InterruptLevel( %d ), NumBlocks( %d )\n", GetRegCap(cap).Type, GetRegCap(cap).Version, GetRegCap(cap).ComponentId, GetRegCap(cap).AssociationId, GetRegCap(cap).InterruptLevel, GetRegCap(cap).NumBlocks );
                else
                    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "\tOffsetCap: Type( 0x%02X ), Version( 0x%02X ), ComponentId( 0x%02X ), AssociationId( 0x%02X ), InterruptLevel( %d ), NumBlocks( %d )\n", GetRegCap(cap).Type, GetRegCap(cap).Version, GetRegCap(cap).ComponentId, GetRegCap(cap).AssociationId, GetRegCap(cap).InterruptLevel, GetRegCap(cap).NumBlocks );

                for( j = 0; j < GetRegCap(cap).NumBlocks; j++ )
                {
                    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "\t\tBlock[%u]: Count( %d ), Physical( 0x%p )\n", j, GetRegCap(cap).Blocks[j].Count, (void *)QuadPart( GetRegCap(cap).Blocks[j].PhysicalAddress ) );
                }
                break;
            }
            default:
                break;
        }
    }
}

void PreReleaseCapability( CapabilityItem * item )
{
    uint32_t i = 0;
    Capability *cap = FromCapabilityItem( item );

    switch( cap->Type )
    {
        case MemMapCap:
        {
            if( cap->Ext.MemMap.VA != NULL )
            {
                // as we dont know how the memory was mapped we cannot unmap it. it must be done before the release is done....
                KernelTrace( TRACE_LEVEL_WARNING, OmniTekBus, "cap->Ext.MemMap.VA != NULL for capability @ %p\n", cap->Base );
            }
            break;
        }
        case InterruptCap:
        {
            if( GetIntrCap(cap).EnableRegisters.Shadow != NULL )
            {
                GetIntrCap(cap).EnableRegisters.Shadow = NULL;
                DeleteMemory( &( GetIntrCap(cap).EnableRegisters.ShadowMem ) );
            }
            if( GetIntrCap(cap).StatusRegisters.Shadow != NULL )
            {
                GetIntrCap(cap).StatusRegisters.Shadow = NULL;
                DeleteMemory( &( GetIntrCap(cap).StatusRegisters.ShadowMem ) );
            }
            break;
        }
        case RegisterCap:
        case OffsetCap:
        {
            if( GetRegCap(cap).Blocks != NULL )
            {
                for( i = 0; i < GetRegCap(cap).NumBlocks; i++ )
                {
                    if( GetRegCap(cap).Blocks[ i ].Shadow != NULL )
                    {
                        GetRegCap(cap).Blocks[ i ].Shadow = NULL;
                        DeleteMemory( &( GetRegCap(cap).Blocks[ i ].ShadowMem ) );
                    }
                }

                GetRegCap(cap).Blocks = NULL;
                DeleteMemory( &( GetRegCap(cap).BlocksMem ) );
            }
            break;
        }
        default:
            break;
    }
}

VirtualBusEntry *FindHostControllerEntry( POmniTekHostController hc )
{
    VirtualBusEntry * entry = NULL;
    PBusDevice privateBusData = NULL;
    uint32_t i = 0;

    if( hc == NULL )
        return NULL;
    privateBusData = hc->BusContext;

    for( i = 0; i < CollectionCount( &privateBusData->VirtualBusList ); i++ )
    {
        entry = CollectionGetVirtualBusEntry( &privateBusData->VirtualBusList, i );
        if( FromVirtualBusEntry( entry )->Controller == hc )
        {
            return entry;
        }
    }
    return NULL;
}

VirtualBus *FindVirtualBusFromId( PBusDevice busInfo, const uint32_t busId )
{
    VirtualBusEntry * entry = NULL;
    uint32_t i = 0;

    for( i = 0; i < CollectionCount( &busInfo->VirtualBusList ); i++ )
    {
        entry = CollectionGetVirtualBusEntry( &busInfo->VirtualBusList, i );
        if( FromVirtualBusEntry( entry )->Controller->SlotId == busId )
        {
            return FromVirtualBusEntry( entry );
        }
    }
    return NULL;
}


int INIT_BusDevice( BusDevice *private_data )
{
    if( IsFailure( CollectionCreateVirtualBus( &private_data->VirtualBusList, "OmniTekBus_VBL" ) ) )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to create virtual bus pool!!!\n" );
        return -1;
    }

    MakeMemoryPool( private_data->VirtualBusItemPool, VirtualBusItem );
    if( private_data->VirtualBusItemPool == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to create VirtualBusItem pool!!!\n" );
        return -1;
    }

    MakeMemoryPool( private_data->CapListPool, CapabilityItem );
    if( private_data->CapListPool == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to create CapabilityItem pool!!!\n" );
        return -1;
    }

    // set the used slots to all free
    memset( private_data->UsedSlots, 0, sizeof( private_data->UsedSlots ) );

    SpinLockInit( &private_data->Lock );

    return SUCCESS;
}

void DEINIT_BusDevice( BusDevice *private_data )
{
    ClobberCollectionVirtualBus( &private_data->VirtualBusList, private_data->VirtualBusItemPool, NULL );

    FreeMemoryPool( private_data->VirtualBusItemPool );
    FreeMemoryPool( private_data->CapListPool );

    SpinLockDelete( private_data->Lock );

}

uint32_t ReadRegisterCap( POmniTekCapabilityDevice context, PRegisterBlock block, const RegCount_t reg, uint32_t *readValue )
{
    DeviceLookupData *lookup = NULL;
    OmniTekHostControllerInterface *hci = NULL;

    if( context == NULL )
        return NULL_ARG_1;

    if( block == NULL )
        return NULL_ARG_2;

    if( reg >= block->Count )
        return RANGE_ERROR;

    if( readValue == NULL )
        return NULL_ARG_4;

    lookup = context->BusData;
    hci = &( FromVirtualBusItem( lookup->VirtualBusHandle )->Interface );
    *readValue = hci->ReadHW( block->VA, reg );

    return SUCCESS;
}

uint32_t WriteRegisterCap( POmniTekCapabilityDevice context, PRegisterBlock block, const RegCount_t reg, const uint32_t writeValue )
{
    DeviceLookupData *lookup = NULL;
    OmniTekHostControllerInterface *hci = NULL;

    if( context == NULL )
        return NULL_ARG_1;

    if( block == NULL )
        return NULL_ARG_2;

    if( reg >= block->Count )
        return RANGE_ERROR;

    if( block->Shadow == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Encountered a null Shadow!!!\n" );
        return GENERAL_ERROR;
    }
    lookup = context->BusData;
    hci = &( FromVirtualBusItem( lookup->VirtualBusHandle )->Interface );

    hci->WriteHW( block->VA, reg, writeValue );
    block->Shadow[ reg ] = writeValue;

    return SUCCESS;
}

uint32_t ReadShadowRegisterCap( POmniTekCapabilityDevice context, PRegisterBlock block, const RegCount_t reg, uint32_t *readValue )
{
    if( context == NULL )
        return NULL_ARG_1;

    if( block == NULL )
        return NULL_ARG_2;

    if( reg >= block->Count )
        return RANGE_ERROR;

    if( readValue == NULL )
        return NULL_ARG_4;

    if( block->Shadow == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Encountered a null Shadow!!!\n" );
        return GENERAL_ERROR;
    }

    *readValue = block->Shadow[ reg ];

    return SUCCESS;
}

void BusNOP1( POmniTekHostController hc )
{
    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "HostController : %p\n", hc );
}

void BusNOP2( POmniTekHostController hc, HCISRCB np2 )
{
    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "HostController : %p, HCISRCB: %p\n", hc, np2 );
}

void PrintCapabilities( OmniTekCollection * capCollection )
{
    CapabilityEntry *entry = NULL;
    Capability *cap = NULL;
    uint32_t i = 0;

    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Total Capabilities: %d\n", CollectionCount( capCollection ) );
    for( i = 0; i < CollectionCount( capCollection ); i++ )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "[%d]: ", i );
        entry = CollectionGetCapabilityEntry( capCollection, i );
        if( entry == NULL )
        {
            KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus,"ERROR - Empty element\n" );
        }
        else
        {
            cap = FromCapabilityEntry( entry );
            PrintCapability( cap );
        }
    }
}

void INIT_OmniTekHostControllerInterface( POmniTekHostControllerInterface hci )
{
    if( hci != NULL )
    {
        hci->ReadHW = BusReadHW;
        hci->WriteHW = BusWriteHW;
        hci->RegisterISR = BusNOP2;
        hci->DeRegisterISR = BusNOP1;
        hci->EnableInterrupts = BusNOP1;
        hci->DisableInterrupts = BusNOP1;
        hci->NotifyBusExit = BusNOP1;
    }
    else
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Invalid handle passed to INIT_OmniTekHostControllerInterface\n" );
    }
}

uint32_t BusReadHW( uint32_t *base, const uint64_t offset )
{
    return *( ( volatile uint32_t * )( base + offset ) );
}

void BusWriteHW( uint32_t *base, const uint64_t offset, const uint32_t writeValue )
{
    *( ( volatile uint32_t * )( base + offset ) ) = writeValue;
}

OmniTekCollection * DiscoverCapabilities( POmniTekHostController hc, uint32_t *base, const uint64_t len, ot_phys_addr_t physical_base )
{
    VirtualBusEntry *vbe = NULL;
    VirtualBus *vb = NULL;
    CapabilityItem *ci = NULL;
    Capability *cap = NULL;
    PBusDevice privateBusData = NULL;

    uint64_t i = 0;
    uint32_t regVal = 0;
    uint64_t nextOffset = 0;
    uint32_t tempUInt32 = 0;
    uint64_t tempUInt64 = 0;
    uint64_t startingOffset = 0;

    vbe = FindHostControllerEntry( hc );
    if( vbe == NULL )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Unable to find hc @ %p\n", hc );
        return NULL;
    }
    vb = FromVirtualBusEntry( vbe );
    privateBusData = hc->BusContext;

    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "hc @ %p, base = %p, len = %llu\n", hc, base, len );

    i = 0;
    do
    {
        if( vb->Interface.ReadHW( base, i ) == 0 )
        { // should not occur but its a safety check!
            KernelTrace( TRACE_LEVEL_WARNING, OmniTekBus, "Zeroed memory at %p, exiting cleanly...\n", (base + i) );
            break;
        }
        else
        {
            // TODO: clean this up to be neater!!!! extract a lot of things to macros and separate functions
            ci = NewCapabilityItem( privateBusData->CapListPool );
            if( ci == NULL )
            {
                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot allocate more capabilities giving up...\n" );
                return &vb->CapList;
            }
            cap = FromCapabilityItem( ci );
            startingOffset = i;
            cap->BarBase = base;
            cap->Base = ( base + i );

            regVal = vb->Interface.ReadHW( base, i );

            cap->Size = ( regVal >> 24 );
            cap->Version = ( ( regVal >> 8 ) & 0xff );
            cap->Type = ( regVal & 0xff );
            i++;

            if ( DoesCapabilityExist( cap, &vb->CapList) )
            {
                KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Duplicate entry found at %p\n", cap->Base );
                ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                return &vb->CapList;
            }

            if( i + cap->Size > len )
            {
                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Length not adequate for capability chain\n" );
                ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                return &vb->CapList;
            }

            nextOffset = ( uint64_t )( vb->Interface.ReadHW( base, i++ ) );
            nextOffset |= ( uint64_t )( vb->Interface.ReadHW( base, i++ ) ) << 32;
            nextOffset >>= 2;

            switch( cap->Type )
            {
                case MemMapCap:
                {
                    cap->SupressDriver = 1;

                    regVal = vb->Interface.ReadHW( base, i );
                    cap->Ext.MemMap.Type = ( regVal & 0xff );
                    if( cap->Ext.MemMap.Type == BarRegion )
                        cap->Ext.MemMap.Bar = ( ( regVal >> 8 ) & 0xff );
                    i++;
                    cap->Ext.MemMap.Size = ( uint64_t )( vb->Interface.ReadHW( base, i++ ) );
                    cap->Ext.MemMap.Size |= ( uint64_t )( vb->Interface.ReadHW( base, i++ ) ) << 32;

                    cap->Ext.MemMap.Offset = ( uint64_t )( vb->Interface.ReadHW( base, i++ ) );
                    cap->Ext.MemMap.Offset |= ( uint64_t )( vb->Interface.ReadHW( base, i++ ) ) << 32;

                    if( i != ( startingOffset + cap->Size ) )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Parse Error\n" );
                        ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                        return &vb->CapList;
                    }
                    break;
                }
                case InterruptCap:
                {
                    cap->SupressDriver = 1;

                    regVal = vb->Interface.ReadHW( base, i );
                    GetIntrCap(cap).BaseLevel = ( regVal & 0xff );
                    GetIntrCap(cap).Id = ( ( regVal >> 8 ) & 0xff );

                    GetIntrCap(cap).NumUsedBits = ( ( regVal >> 16 ) & 0xff );

                    GetIntrCap(cap).EnableRegisters.Count = ( ( regVal >> 24 ) & 0xff );
                    GetIntrCap(cap).StatusRegisters.Count = ( ( regVal >> 24 ) & 0xff );
                    i++;

                    GetIntrCap(cap).EnableRegisters.VA = ( base + i );
                    i += GetIntrCap(cap).EnableRegisters.Count;

                    GetIntrCap(cap).StatusRegisters.VA = ( base + i );
                    i += GetIntrCap(cap).StatusRegisters.Count;

                    GetIntrCap(cap).EnableRegisters.Shadow = AllocateMemory( sizeof(uint32_t) * GetIntrCap(cap).EnableRegisters.Count, &( GetIntrCap(cap).EnableRegisters.ShadowMem ) );
                    if( GetIntrCap(cap).EnableRegisters.Shadow == NULL )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot allocate more memory (GetInterruptCap(cap).EnableRegisters.Shadow), aborting!!!!!!\n" );
                        ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                        return &vb->CapList;
                    }

                    GetIntrCap(cap).StatusRegisters.Shadow = AllocateMemory( sizeof(uint32_t) * GetIntrCap(cap).StatusRegisters.Count, &( GetIntrCap(cap).StatusRegisters.ShadowMem ) );
                    if( GetIntrCap(cap).StatusRegisters.Shadow == NULL )
                    {
                        GetIntrCap(cap).EnableRegisters.Shadow = NULL;
                        DeleteMemory( &( GetIntrCap(cap).EnableRegisters.ShadowMem ) );

                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot allocate more memory (GetInterruptCap(cap).Registers.Shadow), aborting!!!!!!\n" );
                        ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                        return &vb->CapList;
                    }

                    if( i != ( startingOffset + cap->Size ) )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Parse Error\n" );
                        ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                        return &vb->CapList;
                    }

                    //KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "EnableRegisters.VA: %p, BaseLevel: %d\n", GetIntrCap(cap).EnableRegisters.VA, GetIntrCap(cap).BaseLevel );
                    break;
                }
                case RegisterCap:
                {
                    GetRegCap(cap).IRQEnableRegister = 0xffffffff;
                    GetRegCap(cap).IRQStatusRegister = 0xffffffff;

                    regVal = vb->Interface.ReadHW( base, i );
                    GetRegCap(cap).Type = ( regVal >> 16 );
                    GetRegCap(cap).Version = ( ( regVal >> 8 ) & 0xff );
                    GetRegCap(cap).InterruptLevel = ( regVal & 0xff );
                    i++;

                    regVal = vb->Interface.ReadHW( base, i );
                    GetRegCap(cap).ComponentId = ( regVal & 0xffff );
                    GetRegCap(cap).AssociationId = ( ( regVal >> 16 ) & 0xffff );
                    i++;

                    if ( cap->Version >= 2 )
                    {
                        regVal = vb->Interface.ReadHW( base, i );

                        if ( regVal & ( 1 << 15 ) )
                            GetRegCap(cap).IRQEnableRegister = ( regVal & ( ( 1 << 15 ) - 1 ) );

                        if ( regVal & ( 1 << 31 ) )
                            GetRegCap(cap).IRQStatusRegister = ( ( regVal >> 16 ) & ( ( 1 << 15 ) - 1 ) );

                        i++;
                    }

                    GetRegCap(cap).NumBlocks = 1;
                    GetRegCap(cap).Blocks = AllocateMemory( sizeof(RegisterBlock), &( GetRegCap(cap).BlocksMem ) );

                    if( GetRegCap(cap).Blocks == NULL )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot allocate more memory (GetRegCap(cap).Blocks), Aborting!!!!!!\n" );
                        // could use a goto here....
                        ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                        return &vb->CapList;
                    }
                    GetRegCap(cap).Blocks[ 0 ].Count = ( RegCount_t )( ( startingOffset + cap->Size ) - i );
                    GetRegCap(cap).Blocks[ 0 ].Shadow = AllocateMemory( sizeof(uint32_t) * GetRegCap(cap).Blocks[ 0 ].Count, &( GetRegCap(cap).Blocks[ 0 ].ShadowMem ) );
                    if( GetRegCap(cap).Blocks[ 0 ].Shadow == NULL )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot allocate more memory (GetRegCap(cap).Blocks[0].Shadow), aborting!!!!!!\n" );
                        // could use a goto here....
                        ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                        return &vb->CapList;
                    }
                    GetRegCap(cap).Blocks[ 0 ].VA = ( base + i );
                    QuadPart( GetRegCap(cap).Blocks[ 0 ].PhysicalAddress ) = QuadPart( physical_base ) + ( i * 4 );
                    i += GetRegCap(cap).Blocks[ 0 ].Count;

                    if ( cap->Version >= 2 )
                    {
                        if ( GetRegCap(cap).IRQEnableRegister != 0xffffffff && GetRegCap(cap).IRQEnableRegister >= GetRegCap(cap).Blocks[ 0 ].Count )
                        {
                            KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot set IRQEnableRegister %u as its outside the mapped size %u\n", GetRegCap(cap).IRQEnableRegister, GetRegCap(cap).Blocks[ 0 ].Count - 1 );
                            GetRegCap(cap).IRQEnableRegister = 0xffffffff;
                        }

                        if ( GetRegCap(cap).IRQStatusRegister != 0xffffffff &&  GetRegCap(cap).IRQStatusRegister >= GetRegCap(cap).Blocks[ 0 ].Count )
                        {
                            KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot set IRQStatusRegister %u as its outside the mapped size %u\n",GetRegCap(cap).IRQStatusRegister, GetRegCap(cap).Blocks[ 0 ].Count - 1 );
                            GetRegCap(cap).IRQStatusRegister = 0xffffffff;
                        }
                    }

                    if( i != ( startingOffset + cap->Size ) )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Parse Error.\n" );
                        ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                        return &vb->CapList;
                    }
                    break;
                }
                case OffsetCap:
                {
                    /*
                     * This capability we want to split up and represent as single entries of the same thing as it fits into our model better
                     */
                    Capability *primaryCap = cap; // we need to keep the original cap as it has the size and other info we need....

                    while( i != ( startingOffset + primaryCap->Size ) )
                    {
                        GetRegCap(cap).IRQEnableRegister = 0xffffffff;
                        GetRegCap(cap).IRQStatusRegister = 0xffffffff;

                        regVal = vb->Interface.ReadHW( base, i );
                        GetRegCap(cap).Type = ( regVal >> 16 );
                        GetRegCap(cap).Version = ( ( regVal >> 8 ) & 0xff );
                        GetRegCap(cap).InterruptLevel = ( regVal & 0xff );
                        i++;

                        regVal = vb->Interface.ReadHW( base, i );
                        GetRegCap(cap).ComponentId = ( regVal & 0xffff );
                        GetRegCap(cap).AssociationId = ( ( regVal >> 16 ) & 0xffff );
                        i++;

                        if ( cap->Version >= 2 )
                        {
                            regVal = vb->Interface.ReadHW( base, i );

                            if ( regVal & ( 1 << 15 ) )
                                GetRegCap(cap).IRQEnableRegister = ( regVal & ( ( 1 << 15 ) - 1 ) );

                            if ( regVal & ( 1 << 31 ) )
                                GetRegCap(cap).IRQStatusRegister = ( ( regVal >> 16 ) & ( ( 1 << 15 ) - 1 ) );

                            i++;
                        }

                        GetRegCap(cap).NumBlocks = ( ( vb->Interface.ReadHW( base, i ) >> 24 ) & 0xff );
                        if ( GetRegCap(cap).NumBlocks > 0 )
                        {
                            uint32_t j;
                            GetRegCap(cap).Blocks = AllocateMemory( sizeof(RegisterBlock) * GetRegCap(cap).NumBlocks, &( GetRegCap(cap).BlocksMem ) );
                            if( GetRegCap(cap).Blocks == NULL )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot allocate more memory (GetRegCap(cap).Blocks), Aborting!!!!!!\n" );
                                // could use a goto here....
                                ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                                return &vb->CapList;
                            }

                            for ( j = 0; j < GetRegCap(cap).NumBlocks; j++ )
                            {
                                tempUInt32 = vb->Interface.ReadHW( base, i++ );
                                tempUInt64 = ( uint64_t )( vb->Interface.ReadHW( base, i++ ) );
                                tempUInt64 |= ( uint64_t )( vb->Interface.ReadHW( base, i++ ) ) << 32;

                                if( ( tempUInt64 & 0x3 ) > 0 )
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Offset (0x%016llx) is not 32bit aligned. Aborting...\n", tempUInt64 );

                                    ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                                    return &vb->CapList;
                                }
#if BUILDTYPE == BT_LINUX && defined( __arm__ )
                                if ( ( tempUInt64 >> 2 ) > 0x40000000 )
#else
                                if ( ( tempUInt64 >> 2 ) > len )
#endif
                                {
#if BUILDTYPE == BT_LINUX && defined( __arm__ )
                                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Offset 0x%016llx (in 32bit words) is outside this memory region 0x%016llx. Aborting...\n", tempUInt64 >> 2, 0x40000000ull );
#else
                                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Offset 0x%016llx (in 32bit words) is outside this memory region 0x%016llx. Aborting...\n", tempUInt64 >> 2, len );
#endif

                                    ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                                    return &vb->CapList;
                                }

                                GetRegCap(cap).Blocks[ j ].Offset = tempUInt64;
/*
                                if ( HasOffsetBeenMapped( QuadPart( physical_base )  + tempUInt64, cap ) )
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Duplicate register offset 0x%016llx\n", QuadPart( physical_base )  + tempUInt64 );
                                    // could use a goto here....
                                    ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                                    return &vb->CapList;
                                }
*/
                                QuadPart( GetRegCap(cap).Blocks[ j ].PhysicalAddress ) = QuadPart( physical_base )  + tempUInt64;

                                GetRegCap(cap).Blocks[ j ].Count = ( tempUInt32 & 0x00ffffff ); // size of a 24 bit number

                                // we can automatically map this in because as a rule this is relative to the bar...
                                GetRegCap( cap ).Blocks[j].VA = base + ( GetRegCap( cap ).Blocks[j].Offset >> 2 );

                                GetRegCap(cap).Blocks[ j ].Shadow = AllocateMemory( sizeof(uint32_t) * GetRegCap(cap).Blocks[ j ].Count, &( GetRegCap(cap).Blocks[ j ].ShadowMem ) );
                                if( GetRegCap(cap).Blocks[ j ].Shadow == NULL )
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot allocate more memory (GetRegCap(cap).Blocks[%d].Shadow), aborting!!!!!!\n", j );
                                    // could use a goto here....
                                    ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                                    return &vb->CapList;
                                }
                            }
                        }

                        if ( cap->Version >= 2 )
                        {
                            if ( GetRegCap(cap).IRQEnableRegister != 0xffffffff &&  GetRegCap(cap).IRQEnableRegister >= GetRegCap(cap).Blocks[ 0 ].Count )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot set IRQEnableRegisterOffset %u as its outside the mapped size %u\n", GetRegCap(cap).IRQEnableRegister, GetRegCap(cap).Blocks[ 0 ].Count - 1 );
                                GetRegCap(cap).IRQEnableRegister = 0xffffffff;
                            }

                            if ( GetRegCap(cap).IRQStatusRegister != 0xffffffff && GetRegCap(cap).IRQStatusRegister >= GetRegCap(cap).Blocks[ 0 ].Count )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot set IRQStatusRegisterOffset %u as its outside the mapped size %u\n",GetRegCap(cap).IRQStatusRegister, GetRegCap(cap).Blocks[ 0 ].Count - 1 );
                                GetRegCap(cap).IRQStatusRegister = 0xffffffff;
                            }
                        }


                        if( i != ( startingOffset + cap->Size ) )
                        {
                            if( IsFailure( CollectionAddCapabilityItem( &vb->CapList, ci ) ) )
                            {
                                ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Failed to add new capability to list\n" );
                                return &vb->CapList;
                            }

                            if ( i > ( startingOffset + cap->Size ) )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Parse Error. Read position past capability\n" );
                                return &vb->CapList;
                            }

                            ci = NewCapabilityItem( privateBusData->CapListPool );
                            if( ci == NULL )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Cannot allocate more capabilities giving up...\n" );
                                return &vb->CapList;
                            }
                            cap = FromCapabilityItem( ci );
                            // todo: revisit this and possibly change base to be an adjusted and same with size
                            cap->Base = primaryCap->Base;
                            cap->Size = primaryCap->Size;
                            cap->Type = primaryCap->Type;
                            cap->Version = primaryCap->Version;
                            cap->BarBase = base;
                        }
                    }

                    if( i != ( startingOffset + cap->Size ) )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Parse Error\n" );
                        ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                        return &vb->CapList;
                    }
                    break;
                }
                default:
                    break;
            }
            i = nextOffset;

            if( IsFailure( CollectionAddCapabilityItem( &vb->CapList, ci ) ) )
            {
                ReleaseCapabilityItem( privateBusData->CapListPool, ci, PreReleaseCapability );
                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Failed to add new capability to list\n" );
            }
        }
    } while( i < len && i != 0 ); // i == 0 if we get a capability telling us no further items exist...

    if ( nextOffset > len )
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Next capability is outside of mapped region. len: %llu, nextOffset: %llu\n", len, nextOffset );

    return &vb->CapList;
}

/*
bool HasOffsetBeenMapped( const uint64_t offset, Capability *cap )
{
    uint32_t o = 0;
    if ( ( ( cap->Type == OffsetCap ) || ( cap->Type == RegisterCap ) ) && ( cap->Ext.Register.Blocks != NULL )  )
    {
        for( o = 0; o < cap->Ext.Register.NumBlocks; ++o )
        {
            if ( cap->Ext.Register.Blocks[ o ].PhysicalAddress == offset )
                return TRUE;
        }
    }

    return FALSE;
}

bool DoesOffsetExist( const uint64_t offset, OmniTekCollection * capList )
{
    CapabilityEntry *entry = NULL;
    Capability *cap = NULL;
    uint32_t i = 0;

    for( i = 0; i < CollectionCount( capList ); i++ )
    {
        entry = CollectionGetCapabilityEntry( capList, i );
        if( entry != NULL )
        {
            cap = FromCapabilityEntry( entry );
            if ( HasOffsetBeenMapped( offset, cap ) )
                return TRUE;
        }
    }

    return FALSE;
}
*/
bool DoesCapabilityExist( Capability *findCap, OmniTekCollection * capList )
{
    CapabilityEntry *entry = NULL;
    Capability *cap = NULL;
    uint32_t i = 0;

    for( i = 0; i < CollectionCount( capList ); i++ )
    {
        entry = CollectionGetCapabilityEntry( capList, i );
        if( entry != NULL )
        {
            cap = FromCapabilityEntry( entry );
            if( cap->Base == findCap->Base )
                return TRUE;
        }
    }

    return FALSE;
}


void ClearCapabilities( POmniTekHostController hc )
{
    VirtualBusEntry *vbe = NULL;

    vbe = FindHostControllerEntry( hc );
    if( vbe == NULL )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to find hc @ %p\n", hc );
        return;
    }

    // cleanup existing children and capabilities
    CleanVirtualBus( vbe );
    // mark as re-enumerateable...
    FromVirtualBusEntry( vbe )->CapListFinalised = 0;
}

int RegisterHostController( POmniTekHostController hc, POmniTekHostControllerInterface hci )
{
    VirtualBusItem * item = NULL;
    VirtualBus * virtualBus = NULL;
    PBusDevice privateBusData = NULL;
    int status;
    uint32_t slotId;

    if( hc == NULL )
    {
        return NULL_ARG_1;
    }
    privateBusData = hc->BusContext;

    if( hci == NULL )
    {
        return NULL_ARG_2;
    }

    SpinLockAcquire( privateBusData->Lock );

    if( FindHostControllerEntry( hc ) != NULL )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "RegisterHostController hc @ %p already registered\n", hc );
        SpinLockRelease( privateBusData->Lock );
        return GENERAL_ERROR;
    }

    for( slotId = 0; slotId < MAX_SLOTS; slotId++ )
    {
        if ( privateBusData->UsedSlots[slotId] == FALSE )
        {
            privateBusData->UsedSlots[slotId] = TRUE;
            break;
        }
    }
    if ( slotId == MAX_SLOTS )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "No enough slots to satisfy adding a new host controller!\n" );
        SpinLockRelease( privateBusData->Lock );
        return RANGE_ERROR;
    }

    item = NewVirtualBusItem( privateBusData->VirtualBusItemPool );
    if( item == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "RegisterHostController unable to allocate new VirtualBusItem\n" );
        privateBusData->UsedSlots[slotId] = FALSE;
        SpinLockRelease( privateBusData->Lock );
        return ALLOC_FAIL;
    }

    virtualBus = FromVirtualBusItem( item );
    virtualBus->Controller = hc;
    virtualBus->InterruptsEnabled = FALSE;

    virtualBus->Interface.ReadHW = hci->ReadHW;
    virtualBus->Interface.WriteHW = hci->WriteHW;
    virtualBus->Interface.RegisterISR = hci->RegisterISR;
    virtualBus->Interface.DeRegisterISR = hci->DeRegisterISR;
    virtualBus->Interface.EnableInterrupts = hci->EnableInterrupts;
    virtualBus->Interface.DisableInterrupts = hci->DisableInterrupts;
    virtualBus->Interface.NotifyBusExit = hci->NotifyBusExit;

    status = INIT_VirtualBus( privateBusData, virtualBus );
    if( IsFailure( status ) )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to initialise VirtualBus: 0x%X\n", status );
        privateBusData->UsedSlots[slotId] = FALSE;
        SpinLockRelease( privateBusData->Lock );
        return status;
    }

    hc->SlotId = slotId;

    memset( virtualBus->CapListName, 0, sizeof( virtualBus->CapListName ) );
    snprintf( virtualBus->CapListName, sizeof( virtualBus->CapListName ) - 1, "CapabilityPool_%d", hc->SlotId );

    status = CollectionCreateCapability( &virtualBus->CapList, virtualBus->CapListName );
    if( IsFailure( status ) )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to make CapabilityCollection: 0x%X\n", status );
        ReleaseVirtualBusItem( privateBusData->VirtualBusItemPool, item, NULL );
        privateBusData->UsedSlots[slotId] = FALSE;
        SpinLockRelease( privateBusData->Lock );
        return status;
    }

    status = CollectionAddVirtualBusItem( &privateBusData->VirtualBusList, item );
    if( IsFailure( status ) )
    {
        ReleaseVirtualBusItem( privateBusData->VirtualBusItemPool, item, NULL );
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to add new VirtualBusItem: 0x%X\n", status );
        privateBusData->UsedSlots[slotId] = FALSE;
        SpinLockRelease( privateBusData->Lock );
        return status;
    }

    hci->RegisterISR( hc, BusISR );

    SpinLockRelease( privateBusData->Lock );
    return SUCCESS;
}

void DeRegisterHostController( POmniTekHostController hc )
{
    VirtualBusEntry *vbe = NULL;
    VirtualBusItem *vbi = NULL;
    PBusDevice privateBusData = NULL;

    vbe = FindHostControllerEntry( hc );
    if( vbe == NULL )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "DeRegisterHostController unable to find hc @ %p\n", hc );
        return;
    }
    privateBusData = hc->BusContext;

    privateBusData->UsedSlots[ hc->SlotId ] = FALSE;

    // deregister the isr first
    FromVirtualBusEntry( vbe )->Interface.DeRegisterISR( hc );

    // cleanup existing children and capabilities
    CleanVirtualBus( vbe );

    // remove from the list
    vbi = CollectionRemoveVirtualBusEntry( &( privateBusData->VirtualBusList ), vbe );

    // kill off the collection, could manually just free the pool but this is better...
    ClobberCollectionCapability( &FromVirtualBusItem( vbi )->CapList, privateBusData->CapListPool, NULL );

    // free the VirtualBusItem
    ReleaseVirtualBusItem( privateBusData->VirtualBusItemPool, vbi, NULL );
}

void ReadTimer( POmniTekHostControllerInterface hci, Capability * cap, uint64_t *value )
{
    uint64_t tmpVal = 0;
    *value = hci->ReadHW( cap->Ext.Register.Blocks[0].VA, TimerLowerTimeReg );
    tmpVal = hci->ReadHW( cap->Ext.Register.Blocks[0].VA, TimerUpperTimeReg );
    *value |= ( tmpVal << 32 );
}

bool BusISR( POmniTekHostController context, POmniTekHostControllerInterface hci, PCapInterrupt interrupt, uint32_t registerNumber )
{
    uint32_t bit;
    uint32_t interruptVal;
    uint32_t i;
    uint32_t j;
    uint64_t isrTime = 0;
    ISRBaseGroup * BaseGroups = context->Interrupts;
    bool ret = FALSE;

    if( context->NumInterrupts == 0 || context->Interrupts == NULL )
        return FALSE;

    if ( context->TimerCap != NULL )
        ReadTimer( hci, context->TimerCap, &isrTime );

    interruptVal = hci->ReadHW( interrupt->StatusRegisters.VA, registerNumber );

    for( bit = 0; bit < ( interrupt->NumUsedBits - ( registerNumber * 32 ) ); bit++ )
    {
        if( ( ( interruptVal >> bit ) & 1 ) == 1 )
        {
            for( i = 0; i < context->NumInterrupts; i++ )
            {
                if( BaseGroups[ i ].BaseLevel == interrupt->BaseLevel && bit < BaseGroups[ i ].NumGroups )
                {
                    for( j = 0; j < BaseGroups[ i ].Groups[ bit ].NumISRs; j++ )
                    {
                        if( BaseGroups[ i ].Groups[ bit ].ISRs[ j ].ISR != NULL )
                        {
                            ret |= BaseGroups[ i ].Groups[ bit ].ISRs[ j ].ISR( BaseGroups[ i ].Groups[ bit ].ISRs[ j ].Context, isrTime );
                        }
                    }
                }
            }
        }
    }

    return ret;
}

void CleanVirtualBus( VirtualBusEntry * vbe )
{
    VirtualBus *vb = NULL;
    uint32_t i = 0;
    uint32_t j =0;
    PBusDevice privateBusData = NULL;

    if( vbe == NULL )
    {
        return;
    }

    vb = FromVirtualBusEntry( vbe );

    if( vb->InterruptsEnabled )
    {
        // before we kill off the children disable the isr
        vb->Interface.DisableInterrupts( vb->Controller );
        vb->InterruptsEnabled = FALSE;
    }

    privateBusData = vb->Controller->BusContext;

    if( vb->Children != NULL )
    {
        RemoveBusChildren( vb );
        DeleteMemory( &vb->ChildrenMem );
        vb->Children = NULL;
    }
    if( vb->ChildLookups != NULL )
    {
        DeleteMemory( &vb->ChildLookupsMem );
        vb->ChildLookups = NULL;
    }
    if ( vb->BaseGroups != NULL )
    {
        for ( i = 0; i < vb->NumISRBaseGroups; i++ )
        {
            if ( vb->BaseGroups[i].Groups != NULL )
            {
                for ( j = 0; j < vb->BaseGroups[i].NumGroups; j++ )
                {
                    if( vb->BaseGroups[i].Groups[j].ISRs != NULL )
                    {
                        vb->BaseGroups[i].Groups[j].ISRs = NULL;
                        DeleteMemory( &vb->BaseGroups[i].Groups[j].ISRsMem );
                    }
                }
                vb->BaseGroups[i].Groups = NULL;
                DeleteMemory( &vb->BaseGroups[i].GroupsMem );
            }
        }
        vb->BaseGroups = NULL;
        DeleteMemory( &vb->BaseGroupsMem );
    }
    vb->Controller->NumInterrupts = 0;
    vb->Controller->Interrupts = NULL;
    vb->Controller->TimerCap = NULL;

    CollectionCleanCapability( &vb->CapList, privateBusData->CapListPool, PreReleaseCapability );
}

// FIXME: should probably break this into multiple functions... at least internally
int FinaliseCapabilities( POmniTekHostController hc )
{
    VirtualBusEntry *vbe = NULL;
    VirtualBus *vb = NULL;
    Capability *cap = NULL;
    OmniTekCapabilityDevice * child = NULL;
    DeviceLookupData * childLookup = NULL;
    ISRBaseGroup * baseGroup = NULL;
    ISRGroup * group = NULL;
    uint32_t i = 0;
    uint32_t j = 0;
    uint32_t k = 0;
    CapInterrupt *interruptCap = NULL;
    uint8_t foundInterrupt;

    vbe = FindHostControllerEntry( hc );
    if( vbe == NULL )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to find hc @ %p\n", hc );
        return GENERAL_ERROR;
    }

    vb = FromVirtualBusEntry( vbe );
    if( vb->CapListFinalised != 0 )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Already finalised. hc @ %p\n", hc );
        return GENERAL_WARNING;
    }

    hc->TimerCap = NULL;

    // work out how many children to create
    for( i = 0; i < CollectionCount( &vb->CapList ); i++ )
    {
        cap = FromCapabilityEntry( CollectionGetCapabilityEntry( &vb->CapList, i ) );
        if ( cap->SupressDriver == 0 )
        {
	        vb->NumChildren++;
        }
        if( cap->Type == InterruptCap )
            vb->NumISRBaseGroups++;

        if ( hc->TimerCap == NULL && IsAnyRegCap( cap ) && GetRegCap( cap ).Type == RegCap_Timer && ((GetRegCap( cap ).Version == TimerVersion) || (GetRegCap( cap ).Version == TimerVersion2)))
            hc->TimerCap = cap;
    }

    if ( vb->NumChildren > MAX_CAPS )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Requested %u devices to be created we support a maximum %u, refusing to create children!\n", vb->NumChildren, MAX_CAPS );
        return RANGE_ERROR;
    }

    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Found %u base interrupt groups to create\n", vb->NumISRBaseGroups );
    if ( vb->NumISRBaseGroups > 0 )
    {
        vb->BaseGroups = AllocateMemory( sizeof( ISRBaseGroup ) * vb->NumISRBaseGroups, &vb->BaseGroupsMem );
        if ( vb->BaseGroups == NULL )
        {
            KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Could not allocate ISR BaseGroups memory. hc @ %p\n", hc );
            vb->NumISRBaseGroups = 0;
            return ALLOC_FAIL;
        }

        j=0;
        // create the level structures...
        for( i = 0; i < CollectionCount( &vb->CapList ); i++ )
        {
            cap = FromCapabilityEntry( CollectionGetCapabilityEntry( &vb->CapList, i ) );
            if( cap->Type == InterruptCap )
            {
                interruptCap = &cap->Ext.Interrupt;
                baseGroup = &vb->BaseGroups[j];

                baseGroup->BaseLevel = interruptCap->BaseLevel;
                baseGroup->NumGroups = interruptCap->NumUsedBits;
                baseGroup->Interrupt = interruptCap;
                if ( baseGroup->NumGroups == 0 )
                {
                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Interrupt Cap has 0 registers. Address: %p, Id: 0x%02X, BaseLevel: 0x%02X\n", cap->Base, interruptCap->Id, interruptCap->BaseLevel );
                    continue;
                }

                baseGroup->Groups = AllocateMemory( sizeof( ISRGroup ) * baseGroup->NumGroups, &baseGroup->GroupsMem );
                if ( baseGroup->Groups == NULL )
                {
                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Could not allocate ISR Groups memory. hc @ %p\n", hc );
                    CleanVirtualBus(vbe);
                    return ALLOC_FAIL;
                }

                KernelTrace( TRACE_LEVEL_INFORMATION, OmniTekBus, "Interrupt Cap Address: %p, Id: 0x%02X, BaseLevel: 0x%02X\n", cap->Base, interruptCap->Id, interruptCap->BaseLevel );

                j++;
            }
        }

        foundInterrupt = FALSE;
        for( i = 0; i < ( vb->NumISRBaseGroups ) && ( foundInterrupt == FALSE ); i++ )
        {
            for( j = 0; ( j < vb->NumISRBaseGroups ) && ( foundInterrupt == FALSE ); j++ )
            {
                if ( ( i != j ) && ( vb->BaseGroups[i].BaseLevel == vb->BaseGroups[j].BaseLevel ) )
                {
                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Multiple interrupts created with the same base level. Ids 0x%02X and 0x%02X. Interrupts will not work as expected.\n", vb->BaseGroups[i].Interrupt->Id, vb->BaseGroups[j].Interrupt->Id );
                    foundInterrupt = TRUE;
                }
            }
        }

        // now find how many children per level....
        for( i = 0; i < CollectionCount( &vb->CapList ); i++ )
        {
            cap = FromCapabilityEntry( CollectionGetCapabilityEntry( &vb->CapList, i ) );
            if ( IsAnyRegCap( cap ) && GetRegCap( cap ).InterruptLevel != NoInterrupt )
            {
                foundInterrupt = FALSE;
                for ( j = 0; j < vb->NumISRBaseGroups; j++ )
                {
                    baseGroup = &vb->BaseGroups[j];
                    if ( GetRegCap( cap ).InterruptLevel >= baseGroup->BaseLevel && GetRegCap( cap ).InterruptLevel < ( baseGroup->BaseLevel + baseGroup->NumGroups ) )
                    {
                        KernelTrace( TRACE_LEVEL_INFORMATION, OmniTekBus, "Add an extra entry to sub level %d\n", GetRegCap( cap ).InterruptLevel - baseGroup->BaseLevel  );
                        baseGroup->Groups[ GetRegCap( cap ).InterruptLevel - baseGroup->BaseLevel ].NumISRs++;
                        foundInterrupt = TRUE;
                        break;
                    }
                }
                if ( ! foundInterrupt )
                {
                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Unable to find interrupt cap for interrupt level %d\n", GetRegCap( cap ).InterruptLevel );
                }
            }
        }

        // now allocate needed memory per level...
        for( i=0; i < vb->NumISRBaseGroups; i++ )
        {
            baseGroup = &vb->BaseGroups[i];
            for ( j=0; j < baseGroup->NumGroups; j++ )
            {
                group = &baseGroup->Groups[j];

                group->BaseGroup = baseGroup;
                group->BitNumber = j;
                if ( group->NumISRs > 0 )
                {
                    group->ISRs = AllocateMemory( sizeof(RegisteredISR) * group->NumISRs, &group->ISRsMem );
                    if( group->ISRs == NULL )
                    {
                        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Could not allocate ISR memory. hc @ %p\n", hc );
                        CleanVirtualBus(vbe);
                        return ALLOC_FAIL;
                    }

                    // we set it to 0 so we can use it as a counter....
                    group->NumISRs = 0;
                }
            }
        }
    }

    KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Found %u children to create\n", vb->NumChildren );
    if ( vb->NumChildren > 0 )
    {
        // make the space for the children
        vb->Children = AllocateMemory( sizeof(OmniTekCapabilityDevice) * vb->NumChildren, &vb->ChildrenMem );
        if( vb->Children == NULL )
        {
            KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Could not allocate CapabilityDevice memory. hc @ %p\n", hc );
            CleanVirtualBus(vbe);
            return ALLOC_FAIL;
        }

        // setup the lookup data
        vb->ChildLookups = AllocateMemory( sizeof(DeviceLookupData) * vb->NumChildren, &vb->ChildLookupsMem );
        if( vb->ChildLookups == NULL )
        {
            KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Could not allocate DeviceLookupData memory. hc @ %p\n", hc );
            goto cleanup_children;
        }
        for( i = 0; i < vb->NumChildren; i++ )
        {
            vb->ChildLookups[ i ].VirtualBusHandle = vbe->Item;
            // TODO: really should increment the the vbe->Item reference count

            vb->Children[ i ].BusData = &vb->ChildLookups[ i ];
            // this is a little bit of a hack.... but its only needed under linux that i can tell....
            vb->Children[ i ].Id = ( vb->Controller->SlotId << 24 ) | ( i );
        }
    }

    for( i = 0, j = 0; i < CollectionCount( &vb->CapList ); i++ )
    {
        cap = FromCapabilityEntry( CollectionGetCapabilityEntry( &vb->CapList, i ) );
        if( cap->SupressDriver == 0 )
        {
            child = &vb->Children[ j ];
            childLookup = &vb->ChildLookups[ j ];

            child->CapInfo = cap;

            snprintf( child->FriendlyName, MAX_NAME_LEN, "s%02d:c%02d:t%02d:v%02d", vb->Controller->SlotId, i, cap->Type, cap->Version );
            childLookup->CapabilityNum = i;

            if ( IsAnyRegCap( cap ) && GetRegCap( cap ).InterruptLevel != NoInterrupt )
            {
                InterruptLevel_t irl = GetRegCap( cap ).InterruptLevel;
                InterruptLevel_t baseLevel;
                InterruptLevel_t indexLevel;
                for( k=0; k < vb->NumISRBaseGroups; k++ )
                {
                    baseGroup = &vb->BaseGroups[k];
                    baseLevel = baseGroup->BaseLevel;

                    //KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "k: %d, irl: %d, baseLevel: %d\n", k, irl, baseLevel );

                    if ( irl >= baseLevel && irl < ( baseLevel + baseGroup->NumGroups ) )
                    {
                        indexLevel = irl - baseLevel;
                        //KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "k: %d, irl: %d, baseLevel: %d, indexLevel: %d      ASSIGNED\n", k, irl, baseLevel, indexLevel );

                        group = &baseGroup->Groups[ indexLevel ];

                        childLookup->ISR = &( group->ISRs[ group->NumISRs++ ] );
                        childLookup->ISR->Group = group;
                        
                        //KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "EnableRegisters.VA: %p, Interrupt->BaseLevel: %d, BaseGroup->BaseLevel: %d, lookup->ISR->Group->BitNumber: %d\n", childLookup->ISR->Group->BaseGroup->Interrupt->EnableRegisters.VA, childLookup->ISR->Group->BaseGroup->Interrupt->BaseLevel, childLookup->ISR->Group->BaseGroup->BaseLevel, childLookup->ISR->Group->BitNumber );
                        break;
                    }
                }
            }

            if( IsFailure( AddCapabilityDevice( child, vb ) ) )
            {
                KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Could not register device %s. hc @ %p\n", child->FriendlyName, hc );
            }
            else
            {
                KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Register device %s. hc @ %p\n", child->FriendlyName, hc );
            }

            j++;
        }
    }

    vb->Controller->NumInterrupts = vb->NumISRBaseGroups;
    vb->Controller->Interrupts = vb->BaseGroups;
    vb->CapListFinalised = 1;

    // now that everything is setup enable interrupts
    vb->Interface.EnableInterrupts( vb->Controller );
    vb->InterruptsEnabled = TRUE;

    return SUCCESS;

cleanup_children:
    vb->NumChildren = 0;
    DeleteMemory( &vb->ChildrenMem );
    vb->Children = NULL;
    return ALLOC_FAIL;
}

uint32_t RegisterISRCallback( POmniTekCapabilityDevice context, BusISRCB cb )
{
    // FIXME: need to use a spin lock to protect the addition and removal of isrs
    // FIXME: we are currently assuming that there is only one registree per bit
    OmniTekHostControllerInterface *hci;
    uint32_t previousVal = 0;
    DeviceLookupData *lookup = NULL;

    if( context == NULL )
        return NULL_ARG_1;

    if( cb == NULL )
        return NULL_ARG_2;

    if( NotAnyRegCap( context->CapInfo ) )
        return INVALID_ARG_1;

    lookup = context->BusData;

    if( lookup->ISR == NULL )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Capability has no interrupt level. %s\n", context->FriendlyName );
        return GENERAL_WARNING;
    }

    if( lookup->ISR->Context == NULL )
    {
        lookup->ISR->Context = context;
        lookup->ISR->ISR = cb;

        hci = &FromVirtualBusItem( lookup->VirtualBusHandle )->Interface;

        //KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "EnableRegisters.VA: %p, Interrupt->BaseLevel: %d, BaseGroup->BaseLevel: %d, lookup->ISR->Group->BitNumber: %d\n", lookup->ISR->Group->BaseGroup->Interrupt->EnableRegisters.VA, lookup->ISR->Group->BaseGroup->Interrupt->BaseLevel, lookup->ISR->Group->BaseGroup->BaseLevel, lookup->ISR->Group->BitNumber );

        previousVal = hci->ReadHW( lookup->ISR->Group->BaseGroup->Interrupt->EnableRegisters.VA, lookup->ISR->Group->BitNumber / 32 );
        previousVal |= (1 << lookup->ISR->Group->BitNumber);
        hci->WriteHW( lookup->ISR->Group->BaseGroup->Interrupt->EnableRegisters.VA, lookup->ISR->Group->BitNumber / 32, previousVal );

        return SUCCESS;
    }
    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Capability has already registered its ISR. %s\n", context->FriendlyName );
    return GENERAL_WARNING;
}

void DeRegisterISRCallback( POmniTekCapabilityDevice context )
{
    // FIXME: need to use a spin lock to protect the addition and removal of isrs
    // FIXME: we are currently assuming that there is only one registree per bit
    OmniTekHostControllerInterface *hci;
    uint32_t previousVal = 0;
    DeviceLookupData *lookup = NULL;

    lookup = context->BusData;
    if( lookup->ISR == NULL )
        return;

    if( lookup->ISR->Context == context )
    {
        hci = &FromVirtualBusItem( lookup->VirtualBusHandle )->Interface;

        previousVal = hci->ReadHW( lookup->ISR->Group->BaseGroup->Interrupt->EnableRegisters.VA, lookup->ISR->Group->BitNumber / 32 );
        previousVal &= ~(1 << lookup->ISR->Group->BitNumber);
        hci->WriteHW( lookup->ISR->Group->BaseGroup->Interrupt->EnableRegisters.VA, lookup->ISR->Group->BitNumber / 32, previousVal );

        lookup->ISR->ISR = NULL;
        lookup->ISR->Context = NULL;
        return;
    }
}

bool TimerGetFrequency( POmniTekCapabilityDevice context, uint32_t * hertz )
{
    DeviceLookupData *lookup = context->BusData;
    VirtualBus* vb = FromVirtualBusItem( lookup->VirtualBusHandle );
    Capability *timerCap = vb->Controller->TimerCap;

    if ( ( timerCap != NULL ) && ( hertz != NULL ) )
    {
        *hertz = vb->Interface.ReadHW( timerCap->Ext.Register.Blocks[0].VA, TimerFrequencyReg );
        if ( *hertz == 0 ) // as per the doc, if we get 0 then its really 250mHz
            *hertz = 250000000;
        return TRUE;
    }
    return FALSE;
}

bool TimerGetTime( POmniTekCapabilityDevice context, uint64_t * time )
{
    DeviceLookupData *lookup = context->BusData;
    VirtualBus* vb = FromVirtualBusItem( lookup->VirtualBusHandle );

    if ( ( vb->Controller->TimerCap != NULL ) && ( time != NULL ) )
    {
        ReadTimer( &vb->Interface, vb->Controller->TimerCap, time );
        return TRUE;
    }
    return FALSE;
}

PCapability GetCapabilityAt( OmniTekCollection * col, uint32_t idx )
{
    CapabilityEntry * capEnt = CollectionGetCapabilityEntry( col, idx );
    if ( capEnt != NULL )
    {
        return FromCapabilityEntry( capEnt );
    }
    return NULL;
}

