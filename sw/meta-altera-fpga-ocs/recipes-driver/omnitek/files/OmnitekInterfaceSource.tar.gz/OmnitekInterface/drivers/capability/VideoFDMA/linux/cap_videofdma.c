/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/*
 * Ownership rules:
 * - First person to queue a buffer or, adds an event to wait on, becomes the master until they call stop.
 * -- Being the master means only you can call stop + start
 * -- also means that your file closed event will stop everything....
 * - Everyone else will be told -EBUSY.
 */


#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/interrupt.h>
#include <linux/dma-mapping.h>
#include <linux/version.h>
#include <linux/pci.h>
#include <linux/mutex.h>
#include "DMACommon.h"

#include "CapabilityDriverBusInterface.h"
#include "CapabilityDevice.h"

#include "capability/VideoFDMA_IOCTL.h"
#include "capability/RegisterAccess_IOCTL.h"
#include "CapabilityBaseIOCTL.h"
#include "OTCapabilityTypes.h"
#include "Common.h"

#include "linux/Event.h"
#include "linux/UserBuffer.h"

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_WARNING;

#define DefaultMaxTargets 1

#if defined(__arm__) && !defined( CONFIG_ARCH_HAS_SG_CHAIN ) && !defined( ARCH_HAS_SG_CHAIN )
#define DefaultMaxSingleHWTransfer_Video  0xf0000
#define DefaultMaxSingleHWTransfer_Event  0xf0000
#else
#if defined(__arm__)
#define DefaultMaxSingleHWTransfer_Video  0x1000000
#define DefaultMaxSingleHWTransfer_Event  0xf0000
#else
#define DefaultMaxSingleHWTransfer_Video  0x2000000
#define DefaultMaxSingleHWTransfer_Event  0x2000000
#endif
#endif

#if defined(__arm__)
#define DefaultMaxQueueLength 8
#else
#define DefaultMaxQueueLength 16
#endif
#define DefaultMinQueueDepth 3

extern struct device_attribute dev_attr_debuglevel;

typedef struct
{
    uint64_t BytesTransfered;
    uint64_t ISRTime;
} EventCompleteContext;

enum
{
    EventTag_DMAEvent = 1,
    EventTag_DMATransfer = 2,
};

void OT_Cap_VideoFDMA_CleanUpTransferContext( CommonTransferContext * ctx )
{
    if( ctx != NULL )
    {
        CleanUserPages( ctx );
        kfree( ctx );
    }
}

void EventComplete_DMAEvent( void * context, void * dataContext, bool fromUserContext )
{
    CommonTransferContext *ctx = context;
    EventCompleteContext *completeContextInfo = dataContext;

    KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "EventComplete\n" );

    if ( CopyToUserPages( ctx, &completeContextInfo->BytesTransfered, sizeof( completeContextInfo->BytesTransfered ), offsetof( CapDataFDMA_Event_IOCTL_Linux, IOCTLInfo.BytesTransfered ), fromUserContext ) )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "Copied BytesTransferd\n" );
    }
    else
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "CopyToUserPages Failed. Failed to copy BytesTransferd\n" );
    }
    if ( CopyToUserPages( ctx, &completeContextInfo->ISRTime, sizeof( completeContextInfo->ISRTime ), offsetof( CapDataFDMA_Event_IOCTL_Linux, IOCTLInfo.EndTime ), fromUserContext ) )
    {
        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "Copied EndTime\n" );
    }
    else
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "CopyToUserPages failed. Failed to copy EndTime\n" );
    }

    OT_Cap_VideoFDMA_CleanUpTransferContext( ctx );
}

void EventCancel_DMAEvent( void * context )
{
    CommonTransferContext *ctx = context;

    KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "EventCancel\n" );

    OT_Cap_VideoFDMA_CleanUpTransferContext( ctx );
}

typedef struct
{
    OmniTekCapabilityDriver Driver;
} OT_Cap_VideoFDMADriver;

typedef struct _CapDevFDOData
{
    POmniTekCapabilityDevice CapDev;
    CapabilityDeviceInterface BusInterface;
    struct cdev CharDev;

    bool IsEventIn;
    bool IsEventOut;
    DMAChannel Channel;

    uint64_t LastISRTime;

    struct mutex RequestMutex;
    struct list_head ActiveQueue;
    struct list_head PendingQueue;
    bool Purging; // flag to test to know not to progress the queue...
    uint32_t NextTargetId;

    struct mutex EventCountMutex;
    uint64_t EventCount;
    uint64_t PastDataCount;
    uint64_t CurrentDataCount;
    EventList AsyncEvents;
    struct workqueue_struct *DPCQueue;

    uint64_t ISRCount;

    struct mutex MasterMutex;
    struct file * MasterHandle;

    GroupedDMATx *NextEventOut;				/* The next transfer to be indicated by SetTransferSize on an EventOut FDMA */
    size_t		 CurrentEventOutDataCount;  /* Current Consumed count into the NextEventOut */
} OT_Cap_VideoFDMADevice;
#define DevToRegCap( radPtr ) GetRegCap( ( radPtr )->CapDev->CapInfo )

typedef struct
{
    struct work_struct my_work; // i believe this is not needed for manual manipulation...
    OT_Cap_VideoFDMADevice * fdo;

    uint8_t InterruptSG;
    uint8_t InterruptEvent;
    uint64_t Time;

    uint32_t SGCount;
    uint32_t EventByteCount;

    uint64_t ISRCount;
} DPCData_t;

static int OT_Cap_VideoFDMA_driver_probe( struct device * dev );
static int OT_Cap_VideoFDMA_driver_remove( struct device *dev );

static const DriverMatchId matchIdsTable[ ] = {
    { RegisterCap, RegCap_DMA_VideoInFDMA, 0 },
    { OffsetCap, RegCap_DMA_VideoInFDMA, 0 },
    { RegisterCap, RegCap_DMA_VideoOutFDMA, 0 },
    { OffsetCap, RegCap_DMA_VideoOutFDMA, 0 },
    { RegisterCap, RegCap_DMA_DataInFDMA, 0 },
    { OffsetCap, RegCap_DMA_DataInFDMA, 0 },
    { RegisterCap, RegCap_DMA_PacketInFDMA, 0 },
    { OffsetCap, RegCap_DMA_PacketInFDMA, 0 },
    { RegisterCap, RegCap_DMA_DataOutFDMA, 0 },
    { OffsetCap, RegCap_DMA_DataOutFDMA, 0 },
    { RegisterCap, RegCap_DMA_PacketOutFDMA, 0 },
    { OffsetCap, RegCap_DMA_PacketOutFDMA, 0 },
    { }
};

static OT_Cap_VideoFDMADriver OT_Cap_VideoFDMA_driver = {
    .Driver = {
        .FriendlyName = MANUF_DEV("_Cap_VideoFDMA"),
        .IdTable = matchIdsTable,
        .Driver = {
            .name = MANUF_DEV("_Cap_VideoFDMA"),
            .probe = OT_Cap_VideoFDMA_driver_probe,
            .remove = OT_Cap_VideoFDMA_driver_remove,
        },
    },
};

void OT_Cap_VideoFDMA_AbortCleanupChannel( OT_Cap_VideoFDMADevice *fdoData );
void OT_Cap_VideoFDMA_ProcessChannelInterrupt( OT_Cap_VideoFDMADevice *fdoData, uint64_t isrTime );
void OT_Cap_VideoFDMA_EventCancel_DMATransfer( void * context );
void OT_Cap_VideoFDMA_EventComplete_DMATransfer( void * context, void *secondContext, bool fromUserContext );
int OT_Cap_VideoFDMA_FillActiveQueue( OT_Cap_VideoFDMADevice *fdoData, const bool bFromIsr );
void OT_Cap_VideoFDMA_PurgePending( OT_Cap_VideoFDMADevice *fdoData );

int OT_Cap_VideoFDMA_InitChannel( OT_Cap_VideoFDMADevice *fdoData, struct device * device )
{
    uint32_t i;
    uint32_t Cap = 0;
    DMASGLBuffer *sglBuf = NULL;
    int status=0;
    DMAChannel *channel = &fdoData->Channel;
    struct device * hcd = channel->Platform.BusInterface->HostControllerDevice;

    channel->MaxFragmentSize = 0x7FFFF8;

    // determine what type of dma we are using, is it 32 bit, part 64 or full 64 bit.
    channel->Has64BitPADR = false;
    channel->Has64BitLADR = false;
    channel->HasSGCount = false;
    if( GetRegCap( fdoData->BusInterface.Device->CapInfo ).Version < 3 )
    {
        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: DMA core is too old, we don't support it\n", fdoData->BusInterface.Device->Id);
        return STATUS_BAD_DMA_CHANNEL;
    }
    if( GetRegCap( fdoData->BusInterface.Device->CapInfo ).Version > 4 )
    {
    	channel->HasSGCount = true;
    }

    DMAAbortChannel( channel );

    DMAReadReg( channel, DMACapReg, &Cap );
    if( Cap & CapReg_64BitPADR )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Channel reports 64 Bit PADR/DPR\n", fdoData->BusInterface.Device->Id);
        channel->Has64BitPADR = true;
    }
    if( Cap & CapReg_64BitLADR )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Channel reports 64 Bit LADR - not supported yet...\n", fdoData->BusInterface.Device->Id);
        channel->Has64BitLADR = true;
    }

    // TODO: make this able to be set via a param...
    if ( fdoData->IsEventIn || fdoData->IsEventOut )
        channel->MaxSingleHWTransfer = DefaultMaxSingleHWTransfer_Event;
    else
        channel->MaxSingleHWTransfer = DefaultMaxSingleHWTransfer_Video;
    channel->MaxTargets = DefaultMaxTargets;
    channel->MaxQueueLength = DefaultMaxQueueLength;
    channel->MinQueueDepth = DefaultMinQueueDepth;

    INIT_LIST_HEAD( &fdoData->ActiveQueue );
    INIT_LIST_HEAD( &fdoData->PendingQueue );

    // create struct to hold our scatter gather lists
    channel->SGLBuffers = AllocateMemory( sizeof( DMASGLBuffer ) * channel->MaxQueueLength, &channel->Platform.SGLBuffersMemory );
    if ( channel->SGLBuffers == NULL )
    {
        KernelTrace( TRACE_LEVEL_FATAL, Cap_VideoFDMA, "FDMA_%u: AllocateMemory failed to allocate array for common buffers\n", fdoData->BusInterface.Device->Id );
        return -ENOMEM;
    }

    // need the +1 as the first page may not be aligned...
    channel->MaxSGLElements = ( channel->MaxSingleHWTransfer / PAGE_SIZE ) + 1;

    // create a common buffer PER possible queue entry
    for ( i = 0; i < channel->MaxQueueLength; i++ )
    {
        sglBuf = &channel->SGLBuffers[i];
        sglBuf->Size =  channel->MaxSGLElements * sizeof( DMA64BitSGLEntry );

        // allocate the linux sg_table now so that we need not care on each transaction. we can just keep using this...
        status = sg_alloc_table( &sglBuf->SGTable, channel->MaxSGLElements, GFP_KERNEL );
        if ( status != 0 )
        {
            KernelTrace( TRACE_LEVEL_FATAL, Cap_VideoFDMA, "FDMA_%u: We cannot create a sg_table to allow for %u pages\n", fdoData->BusInterface.Device->Id, channel->MaxSGLElements );
            continue;
        }

        // now actually allocate memory for the hardware sg list
        sglBuf->pVa = dma_alloc_coherent( hcd, sglBuf->Size, &( sglBuf->PhysAddr ), GFP_KERNEL );
        if( channel->SGLBuffers[i].pVa == NULL )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: dma_alloc_coherent failed (size %#x)\n", fdoData->BusInterface.Device->Id, sglBuf->Size );
            status = -ENOMEM;
        }
    }

    if ( status != 0 )
    {
        for ( i = 0; i < channel->MaxTargets; i++ )
        {
            sglBuf = &channel->SGLBuffers[i];

            sg_free_table( &sglBuf->SGTable );
            if ( sglBuf->pVa != NULL )
            {
                dma_free_coherent( hcd, sglBuf->Size, sglBuf->pVa, sglBuf->PhysAddr );
                sglBuf->pVa = NULL;
            }
        }
        DeleteMemory( &channel->Platform.SGLBuffersMemory );
        channel->SGLBuffers = NULL;
    }
    return 0;
}

int EventOutSetBytes(OT_Cap_VideoFDMADevice *fdoData, uint64_t BytesToTransfered)
{
    mutex_lock( &fdoData->EventCountMutex );

    /* Do we have a DMA buffer Request Pointer active? */
    if( fdoData->NextEventOut == 0 )
    {
        mutex_lock( &fdoData->RequestMutex );
        if ( !list_empty( &fdoData->ActiveQueue ) )
        {
        	fdoData->NextEventOut = list_first_entry(&fdoData->ActiveQueue, GroupedDMATx, Next);
        }
        mutex_unlock( &fdoData->RequestMutex );
    }

    if( fdoData->NextEventOut == 0 )
    {
    	KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: No Request Available\n", fdoData->BusInterface.Device->Id);
    	mutex_unlock( &fdoData->EventCountMutex );
    	return -ENOMEM;
    }

    KernelTrace( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "FDMA_%u: EventOutSetBytes NextEventOut(%p). BytesToTransfered(%llu)\n", fdoData->BusInterface.Device->Id, fdoData->NextEventOut, BytesToTransfered );
    /* We need to flush our cache for the BytesTransfered */
    {
		size_t currentOffset = fdoData->CurrentEventOutDataCount;
		while( BytesToTransfered )
		{
			size_t originalFlushCount;
			DMATx *activeTx = fdoData->NextEventOut->Txs;
			size_t flushCount = BytesToTransfered;


			if( activeTx == NULL )
			{
				fdoData->CurrentEventOutDataCount = 0;
				fdoData->NextEventOut = NULL;
				KernelTrace(TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: List Error\n", fdoData->BusInterface.Device->Id);
				break;
			}

#ifdef OT_GPUDIRECT
			if (activeTx->Flags & DMA_FLAGS_GPUDIRECT)
			{
				KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: EventOutSetBytes not supported for GPUDirect transfers", fdoData->BusInterface.Device->Id);
				mutex_unlock(&fdoData->EventCountMutex);
				return -ENOTSUPP;
			}
#endif

			if( (currentOffset + BytesToTransfered) > activeTx->Size )
				flushCount = BytesToTransfered - ((currentOffset+BytesToTransfered)-activeTx->Size);

			originalFlushCount = flushCount;

			/* Flush the buffer */
			KernelTrace( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "FDMA_%u: currentOffset(%zu) + flushCount(%zu) > activeTx->Size(%u). BytesToTransfered(%llu)\n", fdoData->BusInterface.Device->Id, currentOffset, flushCount , activeTx->Size, BytesToTransfered );

			{
				/* Calculate start and end page */
				size_t startBytes = currentOffset + activeTx->MDL.FirstOffset;
				size_t endBytes = startBytes + flushCount;

				size_t firstPage = ( startBytes >> PAGE_SHIFT );
				size_t firstPageOff = ( startBytes - ( firstPage << PAGE_SHIFT ) );
				dma_addr_t firstPageDMA = 0;
				size_t lastPage = ( endBytes >> PAGE_SHIFT );

				if ( firstPage == lastPage )
				{ // all within the one page so just deal with this page
					firstPageDMA = page_to_phys( activeTx->MDL.Pages[ firstPage ] ) + firstPageOff;
					dma_sync_single_for_device( fdoData->BusInterface.HostControllerDevice,  firstPageDMA, flushCount, DMA_TO_DEVICE );
				}
				else
				{ // we need to iterate over all of it and sync appropriately...
					uint32_t dataInPage = 0;
					for( ; firstPage <= lastPage && flushCount > 0;  )
					{
						dataInPage = ( 1 << PAGE_SHIFT ) - firstPageOff;
						if( dataInPage > flushCount )
							dataInPage = flushCount;

						firstPageDMA = page_to_phys( activeTx->MDL.Pages[ firstPage ] ) + firstPageOff;
						dma_sync_single_for_device( fdoData->BusInterface.HostControllerDevice,  firstPageDMA, dataInPage, DMA_TO_DEVICE );

						firstPage++;
						firstPageOff = 0;
						flushCount -= dataInPage;
					}
				}
			}
			/* Now update the next count information */
			BytesToTransfered -= originalFlushCount;
			currentOffset += originalFlushCount;

			/* Do we need to move onto the next buffer ? */
			if( currentOffset >= activeTx->Size )
			{
				currentOffset = 0;
				mutex_lock(&fdoData->RequestMutex);
				/* Check to see whether we on the end of either the ActiveQueue or PendingQueue */
				if( list_is_last(&(fdoData->NextEventOut->Next), &fdoData->ActiveQueue) || (list_is_last(&(fdoData->NextEventOut->Next), &fdoData->PendingQueue)) )
				{
					/* If on the PendingQueue then no more data left */
					if( list_is_last(&(fdoData->NextEventOut->Next), &fdoData->PendingQueue) )
					{
						KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: No More Entries on PendingQueue.\n", fdoData->BusInterface.Device->Id );
						fdoData->NextEventOut = NULL;
					}
					else
					{
						/* On the last entry of the ActiveQueue, try and switch to the PendingQueue */
						if( !list_empty(&fdoData->PendingQueue) )
						{
							KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Switching to PendingQueue.\n", fdoData->BusInterface.Device->Id );
							fdoData->NextEventOut = list_first_entry(&fdoData->PendingQueue, GroupedDMATx, Next);
						}
						else
						{
							KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: PendingQueue Empty.\n", fdoData->BusInterface.Device->Id );
							fdoData->NextEventOut = NULL;
						}
					}
				}
				else
				{
					/* More entris in the list so move on */
					fdoData->NextEventOut = list_next_entry(fdoData->NextEventOut, Next);
				}
				mutex_unlock(&fdoData->RequestMutex);

				KernelTrace( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "FDMA_%u: NextEventOut(%p). BytesToTransfered(%llu)\n", fdoData->BusInterface.Device->Id, fdoData->NextEventOut, BytesToTransfered );
				if( (fdoData->NextEventOut == NULL) && (BytesToTransfered!=0) )
				{
					fdoData->CurrentEventOutDataCount = currentOffset;
					KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: No Next Request Available\n", fdoData->BusInterface.Device->Id);
					mutex_unlock(&fdoData->EventCountMutex);
					return -ENOMEM;
				}
			}
		}
		fdoData->CurrentEventOutDataCount = currentOffset;
		mutex_unlock(&fdoData->EventCountMutex);
    }
    return 0;
}

long OT_Cap_VideoFDMA_unlocked_ioctl( struct file *filp, unsigned int cmd, unsigned long arg )
{
    long retval = -ENOTTY;
    OT_Cap_VideoFDMADevice *fdoData = container_of( filp->f_path.dentry->d_inode->i_cdev, OT_Cap_VideoFDMADevice, CharDev );

    if( fdoData != NULL )
    {
        switch( cmd )
        {
            case CAP_RA_IOCTL_GetBlockCount:
            case CAP_RA_IOCTL_GetRegisterCount:
            case CAP_RA_IOCTL_RegisterRead:
            case CAP_RA_IOCTL_RegisterShadowRead:
            case CAP_RA_IOCTL_RegisterWrite:
            case CAP_RA_IOCTL_GetMetaData:
                retval =  ProcessCapabilityBaseIOCTL( &GetRegCap( fdoData->CapDev->CapInfo ), &fdoData->BusInterface, arg, cmd );
                break;

            case CAP_COMMON_IOCTL_QueryIOCTLInfo:
            {
                CapCommon_QueryIOCTLInfo_IOCTL inData;
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_from_user failed\n", fdoData->BusInterface.Device->Id);
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_COMMON_IOCTL_QueryIOCTLInfo_Version
                        {
                            retval = 0;
                            switch ( inData.IOCTLNumber )
                            {
                                case CAP_VIDEOFDMA_IOCTL_Transfer:
                                    if ( inData.QueryMaxVersion )
                                    {
                                        inData.IOCTLVersion = CAP_VIDEOFDMA_IOCTL_Transfer_Version1;
                                    }
                                    else
                                    {
                                        switch( inData.IOCTLVersion )
                                        {
                                            case CAP_VIDEOFDMA_IOCTL_Transfer_Version0:
                                            case CAP_VIDEOFDMA_IOCTL_Transfer_Version1:
                                                break;
                                            default:
                                                retval = -EPERM;
                                        }
                                    }
                                    break;
                                default:
                                    retval = -EINVAL;
                                    break;
                            }

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_COMMON_IOCTL_QueryIOCTLInfo_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            case CAP_COMMON_IOCTL_QueryInfo:
            {
                CapCommon_QueryInfo_IOCTL inData;
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_from_user failed\n", fdoData->BusInterface.Device->Id);
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_COMMON_IOCTL_QueryInfo_Version
                        {
                            retval = 0;
                            switch ( inData.Key )
                            {
                                case QueryInfo_CapabilityId:
                                    inData.Value = fdoData->CapDev->Id;
                                    break;
                                case QueryInfo_RegisterUniqueID:
                                case QueryInfo_RegisterAssociationID:
                                case QueryInfo_RegisterVersionId:
                                case QueryInfo_TimerGetTime:
                                case QueryInfo_TimerGetFrequency:
                                case QueryInfo_RegisterPhysAddr:
                                    retval = ProcessCommon_QueryInfo_Register( fdoData->CapDev->CapInfo, &fdoData->BusInterface, &inData );
                                    break;
                                case QueryInfo_DMASupported:
                                    inData.Value = DmaType_Streaming;
                                    break;
                                case QueryInfo_DMAGpuDirectSupported:
#ifdef OT_GPUDIRECT
                                    inData.Value = (dev_is_pci( fdoData->BusInterface.HostControllerDevice ));
#else
                                    inData.Value = false;
#endif
                                    break;
                                case QueryInfo_DMAEventsSupported:
                                    inData.Value = ( fdoData->IsEventIn ) || ( fdoData->IsEventOut );
                                    break;
                                case QueryInfo_DMADirectionRead:
                                    inData.Value = OmDmaGetDirection( GetRegCap( fdoData->CapDev->CapInfo ).Type ) != DMADirection_Output;
                                    break;
                                case QueryInfo_DMADirectionWrite:
                                    inData.Value = OmDmaGetDirection( GetRegCap( fdoData->CapDev->CapInfo ).Type ) != DMADirection_Input;
                                    break;
                                case QueryInfo_DMAMaxTargets:
                                    inData.Value = fdoData->Channel.MaxTargets;
                                    break;
                                case QueryInfo_DMAMaxSingleHWTransfer:
                                    inData.Value = fdoData->Channel.MaxSingleHWTransfer;
                                    break;
                                case QueryInfo_DMAMinQueueDepth:
                                    inData.Value = fdoData->Channel.MinQueueDepth;
                                    break;
                                case QueryInfo_DMAMaxQueueLength:
                                    inData.Value = fdoData->Channel.MaxQueueLength;
                                    break;
                                case QueryInfo_DMAMinTransferBytes: // this will be used....
                                default:
                                    retval = -EINVAL;
                                    break;
                            }

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_COMMON_IOCTL_QueryInfo_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            case CAP_VIDEOFDMA_IOCTL_Stop:
            {
                CapVideoFDMA_VersionOnly_IOCTL inData;
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( CapVideoFDMA_VersionOnly_IOCTL * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_from_user failed\n", fdoData->BusInterface.Device->Id);
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_VIDEOFDMA_IOCTL_Stop_Version
                        {
                            retval = 0;
                            mutex_lock( &fdoData->MasterMutex );
                            if ( ( filp == fdoData->MasterHandle ) || ( fdoData->MasterHandle == NULL ) )
                            {
                                OT_Cap_VideoFDMA_AbortCleanupChannel( fdoData );
                                OT_Cap_VideoFDMA_PurgePending( fdoData );

                                fdoData->MasterHandle = NULL;

                                if ( fdoData->IsEventIn )
                                {
                                    mutex_lock( &fdoData->EventCountMutex );
                                    fdoData->EventCount = 0;
                                    fdoData->PastDataCount = 0;
                                    fdoData->CurrentDataCount = 0;
                                    mutex_unlock( &fdoData->EventCountMutex );
                                }
                                else if( fdoData->IsEventOut )
                                {
                                    mutex_lock( &fdoData->EventCountMutex );
                                    fdoData->CurrentEventOutDataCount = 0;
                                    fdoData->NextEventOut = NULL;
                                    mutex_unlock( &fdoData->EventCountMutex );
                                }
                            }
                            else
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Access failure, someone else is already the master\n", fdoData->BusInterface.Device->Id );
                                retval = -EBUSY;
                            }
                            mutex_unlock( &fdoData->MasterMutex );

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_VIDEOFDMA_IOCTL_Stop_Version;
                            if ( copy_to_user( ( CapVideoFDMA_VersionOnly_IOCTL * )arg, &inData, sizeof( CapVideoFDMA_VersionOnly_IOCTL ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            case CAP_VIDEOFDMA_IOCTL_Start:
            {
                CapVideoFDMA_VersionOnly_IOCTL inData;
                uint32_t sgBackLog = 0;

                mutex_lock( &fdoData->MasterMutex );
                if ( ( filp != fdoData->MasterHandle ) )
                {
                    retval = -EBUSY;
                    KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Access failure, someone else is already the master\n", fdoData->BusInterface.Device->Id );
                    mutex_unlock( &fdoData->MasterMutex );
                    break;
                }

                if ( fdoData->Channel.IsRunning )
                {
                    KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Channel already running\n", fdoData->BusInterface.Device->Id );
                    mutex_unlock( &fdoData->MasterMutex );
                    break;
                }
                // just in case we had previous interrupts...
                DMAReadReg( &fdoData->Channel, DMASGBackLog, &sgBackLog );
                DMAWriteReg( &fdoData->Channel, DMASGBackLog, sgBackLog );

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( CapVideoFDMA_VersionOnly_IOCTL * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_from_user failed\n", fdoData->BusInterface.Device->Id);
                        retval = -ENOMEM;
                        mutex_unlock( &fdoData->MasterMutex );
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_VIDEOFDMA_IOCTL_Start_Version
                        {
                            if ( fdoData->IsEventIn )
                            {
                                mutex_lock( &fdoData->EventCountMutex );
                                fdoData->EventCount = 0;
                                fdoData->PastDataCount = 0;
                                fdoData->CurrentDataCount = 0;
                                mutex_unlock( &fdoData->EventCountMutex );
                            }
                            else if( fdoData->IsEventOut )
                            {
                                mutex_lock( &fdoData->EventCountMutex );
                                fdoData->CurrentEventOutDataCount = 0;
                                fdoData->NextEventOut = NULL;
                                mutex_unlock( &fdoData->EventCountMutex );
                            }

                            // reset the counter so we know where we are starting
                            fdoData->NextTargetId = 0;
                            retval = OT_Cap_VideoFDMA_FillActiveQueue( fdoData, false );
                            if ( retval > 0 )
                            {
//                            	int sgli;
//                            	int sgbi ;
//                            	DMA64BitSGLEntry *sglEntry;
//                    			KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: SGL buffers %ld\n", fdoData->BusInterface.Device->Id, retval);
//                            	for ( sgli = 0; sgli < retval; sgli++ )
//                            	{
//                            		sglEntry = ( DMA64BitSGLEntry * )( fdoData->Channel.SGLBuffers[sgli].pVa );
//                            		for ( sgbi = 0; sgbi < fdoData->Channel.SGLBuffers[sgli].NumElements; sgbi++ )
//                            		{
//                            			KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: SGL[%d]. PADR: %08x%08x, LADR: %08x%08x, DPR: %08x%08x, SIZE: %08x%08x\n", fdoData->BusInterface.Device->Id, fdoData->Channel.SGLBuffers[sgli].NumElements, sglEntry->PADR_HIGH, sglEntry->PADR_LOW, sglEntry->LADR_HIGH, sglEntry->LADR_LOW, sglEntry->DPR_HIGH, sglEntry->DPR_LOW, sglEntry->SIZE_HIGH, sglEntry->SIZE_LOW);
//                                        sglEntry++;
//                            		}
//
//                            	}

                                fdoData->Channel.IsRunning = true;
                                fdoData->BusInterface.TimerGetTime( fdoData->BusInterface.Device, &fdoData->Channel.PreviousISRTime );
                                DMATransactionStart( &fdoData->Channel, fdoData->Channel.SGLBuffers[0].NumElements, OmDmaGetDirection( GetRegCap( fdoData->BusInterface.Device->CapInfo ).Type ) != DMADirection_Input, fdoData->Channel.SGLBuffers[0].PhysAddr );
                                retval = 0;
                            }
                            else if ( retval == 0 )
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Refusing to start as we have no elements\n", fdoData->BusInterface.Device->Id );
                                retval = -ENODATA;
                            }
                            else
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Failed to queue requests\n", fdoData->BusInterface.Device->Id );
                            }
                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_VIDEOFDMA_IOCTL_Start_Version;
                            if ( copy_to_user( ( CapVideoFDMA_VersionOnly_IOCTL * )arg, &inData, sizeof( CapVideoFDMA_VersionOnly_IOCTL ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }
                mutex_unlock( &fdoData->MasterMutex );

                break;
            }
            case CAP_VIDEOFDMA_IOCTL_Transfer:
#ifdef OT_GPUDIRECT
            case CAP_VIDEOFDMA_IOCTL_TransferGpuDirect:
#endif
            {
                unsigned long dataSize = sizeof( DMATransaction_IOCTL_Linux );
                uint32_t dmaFlags = DMA_FLAGS_NONE;
                DMATransaction_IOCTL_Linux *ioctlData = NULL;

#ifdef OT_GPUDIRECT
                if (cmd == CAP_VIDEOFDMA_IOCTL_TransferGpuDirect)
                {
                    if (!dev_is_pci( fdoData->BusInterface.HostControllerDevice ))
                    {
                        retval = -EIO;
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: GPUDirect requires PCI host controller\n", fdoData->BusInterface.Device->Id );
                        break;
                    }

                    dmaFlags |= DMA_FLAGS_GPUDIRECT;
                }
#endif

                mutex_lock( &fdoData->MasterMutex );
                if ( ( filp != fdoData->MasterHandle ) && ( fdoData->MasterHandle != NULL ) )
                {
                    retval = -EBUSY;
                    KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Access failure, someone is already the master\n", fdoData->BusInterface.Device->Id );
                    mutex_unlock( &fdoData->MasterMutex );
                    break;
                }

                if ( fdoData->MasterHandle == NULL )
                { // you are now the master, check to see if there are stale buffers....

                    OT_Cap_VideoFDMA_AbortCleanupChannel( fdoData );
                    OT_Cap_VideoFDMA_PurgePending( fdoData );

                    fdoData->MasterHandle = filp;
                }
                mutex_unlock( &fdoData->MasterMutex );

                ioctlData = kzalloc( dataSize, GFP_KERNEL );
                if ( ioctlData == NULL )
                {
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: kzalloc failure with size: 0x%08lx\n", fdoData->BusInterface.Device->Id, dataSize );
                    retval = -ENOMEM;
                    break;
                }

                if( omnitek_access_ok( VERIFY_WRITE, arg, dataSize ) )
                {
                    if ( copy_from_user( ioctlData, ( void * )arg, dataSize ) != 0 )
                    {
                        kfree( ioctlData );
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_from_user failed\n", fdoData->BusInterface.Device->Id);
                        retval = -ENOMEM;
                        break;
                    }

                    switch ( ioctlData->IOCTLInfo.Version )
                    {
                        case CAP_VIDEOFDMA_IOCTL_Transfer_Version0:
                        case CAP_VIDEOFDMA_IOCTL_Transfer_Version1:
                        {
                            CommonTransferContext *ioctlContext = NULL;
                            EventItem * newEvent = NULL;
                            bool isWriteDMA = ( OmDmaGetDirection( GetRegCap( fdoData->BusInterface.Device->CapInfo ).Type ) != DMADirection_Input );

                            // now we can get the rest of the data....
                            dataSize += ( ioctlData->IOCTLInfo.Dma.nTargets * sizeof( DmaTarget ) );

                            if ( ioctlData->IOCTLInfo.Dma.nTargets < 1 || ioctlData->IOCTLInfo.Dma.nTargets > fdoData->Channel.MaxTargets )
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Invalid number of targets. Given %u, min %u, max %u\n", fdoData->BusInterface.Device->Id, ioctlData->IOCTLInfo.Dma.nTargets, 1, fdoData->Channel.MaxTargets );
                                retval = -EACCES;
                                kfree( ioctlData );
                                break;
                            }
                            if ( ( ioctlData->IOCTLInfo.Dma.Write && !isWriteDMA ) || ( !ioctlData->IOCTLInfo.Dma.Write && isWriteDMA ) )
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Invalid direction for this channel\n", fdoData->BusInterface.Device->Id );
                                retval = -EACCES;
                                kfree( ioctlData );
                                break;
                            }

                            kfree( ioctlData );
                            ioctlData = kzalloc( dataSize, GFP_KERNEL );
                            if ( ioctlData == NULL )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: kzalloc failure with size: 0x%08lx\n", fdoData->BusInterface.Device->Id, dataSize );
                                retval = -ENOMEM;
                                break;
                            }

                            if ( copy_from_user( ioctlData, ( void * )arg, dataSize ) != 0 )
                            {
                                kfree( ioctlData );
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_from_user failed with size: 0x%08lx\n", fdoData->BusInterface.Device->Id, dataSize );
                                retval = -ENOMEM;
                                break;
                            }

                            /* Repeated check in case initial part of ioctlData changed since last time */
                            if ( ioctlData->IOCTLInfo.Dma.nTargets < 1 || ioctlData->IOCTLInfo.Dma.nTargets > fdoData->Channel.MaxTargets )
                            {
                                KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: Invalid number of targets, unexpected change of user data\n", fdoData->BusInterface.Device->Id );
                                retval = -EACCES;
                                kfree( ioctlData );
                                break;
                            }

                            if ( ioctlData->IOCTLInfo.Dma.Targets[0].Size > fdoData->Channel.MaxSingleHWTransfer )
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Buffer too big to complete in a single tx. Given 0x%08x, max 0x%08x\n", fdoData->BusInterface.Device->Id, ioctlData->IOCTLInfo.Dma.Targets[0].Size, fdoData->Channel.MaxSingleHWTransfer );
                                retval = -EACCES;
                                kfree( ioctlData );
                                break;
                            }

                            ioctlContext = kzalloc( sizeof(CommonTransferContext), GFP_KERNEL );
                            if ( ioctlContext == NULL )
                            {
                                kfree( ioctlData );
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA,"FDMA_%u: Couldn't allocate transaction context\n", fdoData->BusInterface.Device->Id );
                                retval = -ENOMEM;
                                break;
                            }

                            retval = MapUserPages( arg, dataSize, ioctlContext );
                            if ( retval != 0 )
                            {
                                CleanUserPages( ioctlContext );
                                kfree( ioctlContext );
                                kfree( ioctlData );
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA,"FDMA_%u: Couldn't map user ioctl pages\n", fdoData->BusInterface.Device->Id );
                                break;
                            }

                            KernelTrace( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "FDMA_%u: nTargets: %d, Targets[0].pVa: %p, Targets[0].Size: 0x%08x\n", fdoData->BusInterface.Device->Id, ioctlData->IOCTLInfo.Dma.nTargets, ioctlData->IOCTLInfo.Dma.Targets[0].DUMMYUNIONNAME.pVa, ioctlData->IOCTLInfo.Dma.Targets[0].Size );

                            newEvent = EventPrepare( &(fdoData->AsyncEvents), &(ioctlData->EventInfo), EventTag_DMATransfer, NULL, OT_Cap_VideoFDMA_EventComplete_DMATransfer, OT_Cap_VideoFDMA_EventCancel_DMATransfer );
                            if ( newEvent != NULL )
                            {
                                GroupedDMATx *pTransaction = NULL;
                                int result = 0;
                                if ( ioctlData->IOCTLInfo.Version < 1 )
                                { // if a version that has no NoSync support directly disable it
                                    int targetNum = 0;
                                    for( targetNum = 0; targetNum < ioctlData->IOCTLInfo.Dma.nTargets; targetNum++ )
                                        ioctlData->IOCTLInfo.Dma.Targets[ targetNum ].bNoSync = 0;
                                }

                                KernelTrace( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA,"FDMA_%u: Creating transaction\n", fdoData->BusInterface.Device->Id );

                                result = DMAPreForwardEnhanced( &pTransaction, &ioctlData->IOCTLInfo, dmaFlags );
                                if( unlikely(result) )
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA,"FDMA_%u: Couldn't create transaction!\n", fdoData->BusInterface.Device->Id );
                                    EventCleanAllocated( newEvent );
                                    retval = -EAGAIN;
                                }
                                else
                                {
                                    newEvent->IOCTLContext = (void *)pTransaction;
                                    EventAddAllocated( &(fdoData->AsyncEvents), newEvent );

                                    pTransaction->EventId = newEvent->Id;
                                    pTransaction->ioctlContext = ioctlContext;
                                    pTransaction->ChannelFDO = fdoData;

                                    mutex_lock( &fdoData->RequestMutex );
                                    list_add_tail( &pTransaction->Next, &fdoData->PendingQueue );
                                    mutex_unlock( &fdoData->RequestMutex );

                                    retval = 0;
                                    if ( copy_to_user( ( void * )arg, ioctlData, dataSize ) != 0 )
                                    {
                                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                        mutex_lock( &fdoData->RequestMutex );
                                        list_del( &pTransaction->Next );
                                        mutex_unlock( &fdoData->RequestMutex );
                                        EventCancel( &(fdoData->AsyncEvents), newEvent->Id );
                                        retval = -ENOMEM;
                                    }
                                }
                            }
                            else
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Failed to create a new event...\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }

                            if ( retval != 0 && ioctlContext != NULL )
                            {
                                KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Failed in some other way...\n", fdoData->BusInterface.Device->Id);
                                CleanUserPages( ioctlContext );
                                kfree( ioctlContext );
                                ioctlContext = NULL;
                            }
                            kfree( ioctlData );

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), ioctlData->IOCTLInfo.Version );
                            ioctlData->IOCTLInfo.Version = CAP_VIDEOFDMA_IOCTL_Transfer_Version1;
                            if ( copy_to_user( ( void * )arg, ioctlData, sizeof( DMATransaction_IOCTL_Linux ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }
                            kfree( ioctlData );
                        }
                    }
                }
                else
                {
                    kfree( ioctlData );
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                    break;
                }
                break;
            }
            case CAP_COMMON_IOCTL_Cancel:
            {
                CapGeneral_Cancel_IOCTL inData;

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( CapGeneral_Cancel_IOCTL * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_from_user failed\n", fdoData->BusInterface.Device->Id);
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_COMMON_IOCTL_Cancel_Version
                        {
                            if ( EventCancel( &(fdoData->AsyncEvents), inData.EventInfo.EventID ) )
                            {
                                retval = 0;
                                KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Canceled event 0x%016llx\n", fdoData->BusInterface.Device->Id, inData.EventInfo.EventID );
                            }
                            else
                            {
                                KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Failed to cancel event 0x%016llx\n", fdoData->BusInterface.Device->Id, inData.EventInfo.EventID);
                                retval = -ENOMEM;
                            }
                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_COMMON_IOCTL_Cancel_Version;
                            if ( copy_to_user( ( CapGeneral_Cancel_IOCTL * )arg, &inData, sizeof( CapGeneral_Cancel_IOCTL ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            case CAP_DATAFDMA_IOCTL_Event:
            {
                CapDataFDMA_Event_IOCTL_Linux inData;


                mutex_lock( &fdoData->MasterMutex );
                if ( ( filp != fdoData->MasterHandle ) && ( fdoData->MasterHandle != NULL ) )
                {
                    retval = -EBUSY;
                    KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Access failure, someone is already the master\n", fdoData->BusInterface.Device->Id );
                    mutex_unlock( &fdoData->MasterMutex );
                    break;
                }

                if ( fdoData->MasterHandle == NULL )
                { // you are now the master, check to see if there are stale buffers....

                    OT_Cap_VideoFDMA_AbortCleanupChannel( fdoData );
                    OT_Cap_VideoFDMA_PurgePending( fdoData );

                    fdoData->MasterHandle = filp;
                }
                mutex_unlock( &fdoData->MasterMutex );

                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( CapDataFDMA_Event_IOCTL_Linux * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_from_user failed\n", fdoData->BusInterface.Device->Id);
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.IOCTLInfo.Version )
                    {
                        case 0: //!< CAP_DATAFDMA_IOCTL_Event_Version
                        {
                            if ( fdoData->IsEventOut )
                            {
                                if ( inData.IOCTLInfo.BytesTransfered > 0 )
                                {
#if 1
                                	retval = EventOutSetBytes(fdoData, inData.IOCTLInfo.BytesTransfered);
                                    DMAWriteReg( &fdoData->Channel, DMABytesTransfered, inData.IOCTLInfo.BytesTransfered );
#else
                                    // FIXME: should probably workout / track the available bytes to transfer...
                                    retval = 0;
                                    DMAWriteReg( &fdoData->Channel, DMABytesTransfered, inData.IOCTLInfo.BytesTransfered );
                                    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: told to transfer 0x%04llx bytes\n", fdoData->BusInterface.Device->Id, inData.IOCTLInfo.BytesTransfered );
#endif
                                }
                                else
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Unable to transfer a packet of 0 bytes!\n", fdoData->BusInterface.Device->Id);
                                    retval = -EINVAL;
                                }
                            }
                            else if ( fdoData->IsEventIn )
                            {
                                CommonTransferContext *txCtx = (CommonTransferContext*)kzalloc( sizeof(CommonTransferContext), GFP_KERNEL );
                                if ( txCtx != NULL )
                                {
                                    retval = MapUserPages( arg, sizeof( CapDataFDMA_Event_IOCTL_Linux ), txCtx );
                                    if ( retval == 0  )
                                    {
                                        if ( EventAdd( &(fdoData->AsyncEvents), &(inData.EventInfo), EventTag_DMAEvent, (void *)txCtx, EventComplete_DMAEvent, EventCancel_DMAEvent ) )
                                        {
                                            retval = 0;
                                            if ( copy_to_user( &(((CapDataFDMA_Event_IOCTL_Linux * )arg)->EventInfo), &(inData.EventInfo), sizeof( CapGeneral_EventCtx_IOCTL ) ) != 0 )
                                            {
                                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                                retval = -ENOMEM;
                                            }
                                            else
                                            {
                                                KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: added new event\n", fdoData->BusInterface.Device->Id);
                                            }
                                        }
                                        else
                                        {
                                            KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Failed to create a new event...\n", fdoData->BusInterface.Device->Id);
                                            retval = -ENOMEM;
                                        }
                                    }
                                    else
                                    {
                                        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Failed to map user pages...\n", fdoData->BusInterface.Device->Id);
                                        OT_Cap_VideoFDMA_CleanUpTransferContext( txCtx );
                                    }
                                }
                                else
                                {
                                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Failed to create transfer context...\n", fdoData->BusInterface.Device->Id);
                                    retval = -ENOMEM;
                                }
                            }
                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.IOCTLInfo.Version );
                            inData.IOCTLInfo.Version = CAP_DATAFDMA_IOCTL_Event_Version;
                            if ( copy_to_user( ( CapDataFDMA_Event_IOCTL_Linux * )arg, &inData, sizeof( CapDataFDMA_Event_IOCTL_Linux ) ) != 0 )
                            {
                                KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: copy_to_user failed\n", fdoData->BusInterface.Device->Id);
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            default:
                KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unhandled in switch\n", fdoData->BusInterface.Device->Id, cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                break;
        }
    }
    else
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: Device Not Found!!!\n", fdoData->BusInterface.Device->Id );
    }
    return retval;
}

void OT_Cap_VideoFDMA_EventComplete_DMATransfer( void * context, void *secondContext, bool fromUserContext )
{
    GroupedDMATx *pTransaction = context;
    struct _CapDevFDOData * fdoData  = pTransaction->ChannelFDO;

    KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: Transaction completed\n", fdoData->BusInterface.Device->Id );

    // remove from active list
    mutex_lock( &fdoData->RequestMutex );
    if( pTransaction->Deleted )
    {
    	mutex_unlock(&fdoData->RequestMutex);
    	return;
    }
    pTransaction->Deleted = true;
    list_del( &pTransaction->Next );
    mutex_unlock( &fdoData->RequestMutex );

    if( fdoData->IsEventIn )
    {
        mutex_lock( &fdoData->EventCountMutex );
        // fdmas have only a single tx...

        KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: This tx size: %u, CurrentDataCount: %llu \n", fdoData->BusInterface.Device->Id, pTransaction->Txs[0].Size, fdoData->CurrentDataCount );
        //DebugDma KernelPrintPlain(( "sgc %u %llu\n", pTransaction->Txs[0].Size, fdoData->CurrentDataCount ));

        fdoData->PastDataCount += pTransaction->Txs[0].Size - fdoData->CurrentDataCount;
        fdoData->CurrentDataCount = 0;

        mutex_unlock( &fdoData->EventCountMutex );
    }

    CopyToUserPages( pTransaction->ioctlContext, &pTransaction->StartTime, sizeof( pTransaction->StartTime ), offsetof( DMATransaction_IOCTL_Linux, IOCTLInfo.Dma.StartTime ), fromUserContext );
    CopyToUserPages( pTransaction->ioctlContext, &pTransaction->EndTime, sizeof( pTransaction->EndTime ), offsetof( DMATransaction_IOCTL_Linux, IOCTLInfo.Dma.EndTime ), fromUserContext );

    CleanUserPages( pTransaction->ioctlContext );
    kfree( pTransaction->ioctlContext );
    DMAGroupedDMATxCleanup( pTransaction, fdoData->BusInterface.HostControllerDevice );
}

void OT_Cap_VideoFDMA_EventCancel_DMATransfer( void * context )
{
    GroupedDMATx *pTransaction = context;
    struct _CapDevFDOData * fdoData  = pTransaction->ChannelFDO;

//    dump_stack();

    KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: Cancel \n", fdoData->BusInterface.Device->Id );

    mutex_lock( &fdoData->RequestMutex );
    if ( pTransaction->Active )
    {
        KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: Cancel - was active \n", fdoData->BusInterface.Device->Id );
        list_del( &pTransaction->Next );
        pTransaction->Deleted = true;
        mutex_unlock( &fdoData->RequestMutex );
        OT_Cap_VideoFDMA_AbortCleanupChannel( fdoData );
    }
    else
    {
        KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: Cancel - Was in queue\n", fdoData->BusInterface.Device->Id );

        if ( ! pTransaction->Deleted )
            list_del( &pTransaction->Next );
        pTransaction->Deleted = true;
        mutex_unlock( &fdoData->RequestMutex );
    }

    CleanUserPages( pTransaction->ioctlContext );
    kfree( pTransaction->ioctlContext );
    DMAGroupedDMATxCleanup( pTransaction, fdoData->BusInterface.HostControllerDevice );
}

void OT_Cap_VideoFDMA_AbortCleanupChannel( OT_Cap_VideoFDMADevice *fdoData )
{
    uint32_t sgBackLog = 0;
    GroupedDMATx * request;

    DMAReadReg( &fdoData->Channel, DMASGBackLog, &sgBackLog );
    KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: AbortCleanupChannel SGBackLog %u\n", fdoData->BusInterface.Device->Id, sgBackLog );

    DMAAbortChannel( &fdoData->Channel );

    KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: Purging active queue\n", fdoData->BusInterface.Device->Id );

    mutex_lock( &fdoData->RequestMutex );
    fdoData->Purging = true;
    while( ! list_empty( &fdoData->ActiveQueue ) )
    {
        request = list_first_entry( &fdoData->ActiveQueue, GroupedDMATx, Next );
        list_del( &request->Next );
        request->Deleted = true;
        // cheat and pretend its not active so the cleanup is easier...
        request->Active = false;
        mutex_unlock( &fdoData->RequestMutex );
        EventCancel( &fdoData->AsyncEvents, request->EventId );
        mutex_lock( &fdoData->RequestMutex );
    }
    fdoData->Purging = false;
    mutex_unlock( &fdoData->RequestMutex );
}

void OT_Cap_VideoFDMA_PurgePending( OT_Cap_VideoFDMADevice *fdoData )
{
    GroupedDMATx * request;
    DMAAbortChannel( &fdoData->Channel );

    KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: Purging pending queue\n", fdoData->BusInterface.Device->Id );

    mutex_lock( &fdoData->RequestMutex );
    fdoData->Purging = true;
    while( ! list_empty( &fdoData->PendingQueue ) )
    {
        request = list_first_entry( &fdoData->PendingQueue, GroupedDMATx, Next );
        list_del( &request->Next );
        request->Deleted = true;
        mutex_unlock( &fdoData->RequestMutex );
        EventCancel( &fdoData->AsyncEvents, request->EventId );
        mutex_lock( &fdoData->RequestMutex );
    }
    fdoData->Purging = false;
    mutex_unlock( &fdoData->RequestMutex );
}

int OT_Cap_VideoFDMA_FileClosed( struct inode * inode, struct file * filp )
{
    OT_Cap_VideoFDMADevice *fdoData = container_of( filp->f_path.dentry->d_inode->i_cdev, OT_Cap_VideoFDMADevice, CharDev );

    mutex_lock( &fdoData->MasterMutex );
    if( ( filp == fdoData->MasterHandle ) || ( fdoData->MasterHandle == NULL ) )
    {
        OT_Cap_VideoFDMA_AbortCleanupChannel( fdoData );
        OT_Cap_VideoFDMA_PurgePending( fdoData );

        fdoData->MasterHandle = NULL;
    }
    mutex_unlock( &fdoData->MasterMutex );

    return 0;
}

const struct file_operations OT_Cap_VideoFDMA_device_fops = {
    .owner = THIS_MODULE,
    .release = OT_Cap_VideoFDMA_FileClosed,
    .unlocked_ioctl = OT_Cap_VideoFDMA_unlocked_ioctl,
};

void OT_Cap_VideoFDMA_DPC( struct work_struct *work )
{
    DPCData_t * dpcData = (DPCData_t *)work;
    OT_Cap_VideoFDMADevice *fdoData = dpcData->fdo;

    if( fdoData->ISRCount > ( dpcData->ISRCount + 2 ) )
    {
        KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: ISR to DPC drift: %llu\n", fdoData->BusInterface.Device->Id, fdoData->ISRCount - dpcData->ISRCount );
    }

    if( dpcData->InterruptSG && dpcData->SGCount > 0 )
    {
    	// TODO: FIXME if the count gets too far ahead the chaining will probably fail
    	uint32_t sgItem;
    	//DebugDma KernelPrintPlain(("Do%u\n", dpcData->SGCount));
    	for( sgItem = 0; sgItem < dpcData->SGCount; sgItem++ )
    		OT_Cap_VideoFDMA_ProcessChannelInterrupt( fdoData, dpcData->Time );
    }
    if ( dpcData->InterruptEvent && fdoData->IsEventIn )
    {
        EventCompleteContext completeContextInfo;
        DMATx *activeTx = NULL;

        uint32_t dataToSync = dpcData->EventByteCount;

        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Event bytes count: 0x%08x\n", fdoData->BusInterface.Device->Id, dataToSync );

        mutex_lock( &fdoData->RequestMutex );
        if ( !list_empty( &fdoData->ActiveQueue ) )
        {
            GroupedDMATx *request = list_first_entry( &fdoData->ActiveQueue, GroupedDMATx, Next );
			activeTx = &request->Txs[0];
        }

#ifdef OT_GPUDIRECT
        if (activeTx && (activeTx->Flags & DMA_FLAGS_GPUDIRECT))
        {
            KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: EventIn interrupt not supported for GPUDirect transfers", fdoData->BusInterface.Device->Id );
            mutex_unlock( &fdoData->RequestMutex );
            goto dpc_cleanup;
        }
#endif

        mutex_lock( &fdoData->EventCountMutex );

        if( dataToSync > 0 )
        {
        	uint64_t PastDataCount = fdoData->PastDataCount;
        	uint32_t origdataToSync = dataToSync;

        	//DebugDma KernelPrintPlain(("Eb %llu %u\n", fdoData->PastDataCount, dataToSync ));
            if ( dataToSync > fdoData->PastDataCount )
            {
                dataToSync-= fdoData->PastDataCount;
                fdoData->PastDataCount = 0;
            }
            else
            {
                fdoData->PastDataCount -= dataToSync;
                dataToSync = 0;
                fdoData->CurrentDataCount= 0;
            }
        	//DebugDma KernelPrintPlain(("Ea %llu %u\n", fdoData->PastDataCount, dataToSync ));
            //KernelPrintPlain(( "Dts %u prev %llu\n", dataToSync, fdoData->PastDataCount ));

            if ( dataToSync > 0 && activeTx != NULL )
            {
                uint32_t startBytes = fdoData->CurrentDataCount + activeTx->MDL.FirstOffset;
                uint32_t endBytes = startBytes + dataToSync;

                uint32_t firstPage = ( startBytes >> PAGE_SHIFT );
                uint32_t firstPageOff = ( startBytes - ( firstPage << PAGE_SHIFT ) );
                dma_addr_t firstPageDMA = 0;
                uint32_t lastPage = ( endBytes >> PAGE_SHIFT );

                if ( fdoData->CurrentDataCount + dataToSync > activeTx->Size )
                {
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: fdoData->CurrentDataCount(%llu) + dataToSync(%u) > activeTx->Size(%u). PastDataCount(%llu). origdataToSync(%u)\n", fdoData->BusInterface.Device->Id, fdoData->CurrentDataCount, dataToSync , activeTx->Size, PastDataCount, origdataToSync  );

                }
                else
                {
                    fdoData->CurrentDataCount+= dataToSync;

                    if ( firstPage == lastPage )
                    { // all within the one page so just deal with this page
                        firstPageDMA = page_to_phys( activeTx->MDL.Pages[ firstPage ] ) + firstPageOff;
                        dma_sync_single_for_cpu( fdoData->BusInterface.HostControllerDevice,  firstPageDMA, dataToSync, DMA_FROM_DEVICE );
                    }
                    else
                    { // we need to iterate over all of it and sync appropriately...
                        uint32_t dataInPage = 0;
                        for( ; firstPage <= lastPage && dataToSync > 0;  )
                        {
                            dataInPage = ( 1 << PAGE_SHIFT ) - firstPageOff;
                            if( dataInPage > dataToSync )
                                dataInPage = dataToSync;

                            firstPageDMA = page_to_phys( activeTx->MDL.Pages[ firstPage ] ) + firstPageOff;
                            dma_sync_single_for_cpu( fdoData->BusInterface.HostControllerDevice,  firstPageDMA, dataInPage, DMA_FROM_DEVICE );

                            firstPage++;
                            firstPageOff = 0;
                            dataToSync -= dataInPage;
                        }
                    }
                }
            }

        }

        fdoData->EventCount+= dpcData->EventByteCount;

        if( fdoData->EventCount == 0 )
        	KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: BYTE Count zero\n", fdoData->BusInterface.Device->Id );

        completeContextInfo.ISRTime = dpcData->Time;
        completeContextInfo.BytesTransfered = fdoData->EventCount;
        if (EventCompleteNextByTag( &(fdoData->AsyncEvents), EventTag_DMAEvent, &completeContextInfo, false) )
        {
            fdoData->EventCount = 0;
        }
        else
        {
            KernelTrace( TRACE_LEVEL_INFORMATION, Cap_VideoFDMA, "FDMA_%u: No one wants the event notification\n", fdoData->BusInterface.Device->Id );
        }
        mutex_unlock( &fdoData->EventCountMutex );
        mutex_unlock( &fdoData->RequestMutex );
    }

#ifdef OT_GPUDIRECT
dpc_cleanup:
#endif
    kfree( work );
}

bool OT_Cap_VideoFDMA_ISR( POmniTekCapabilityDevice context, uint64_t isrTime )
{
	uint32_t sgBackLog = 0;
    uint32_t readValue = 0;
    uint32_t tempValue = 0;
    uint8_t sgInterrupt = 0;
    uint8_t eventInterrupt = 0;
    OT_Cap_VideoFDMADevice *fdoData = NULL;
    uint32_t dataToSync = 0;
    uint64_t isrDiff = 0;

    fdoData = dev_get_drvdata( &(context->Device) );

    if ( unlikely( fdoData == NULL ) )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "Could not get full info!!!\n");
        return false;
    }

    isrDiff = isrTime - fdoData->LastISRTime;
    DMAReadReg( &fdoData->Channel, DMACSR, &readValue );
    DMAWriteReg( &fdoData->Channel, DMACSR, readValue );

    if ( readValue & CSR_EventInterruptStatus )
    {
        eventInterrupt = 1;
        DMAReadReg( &fdoData->Channel, DMABytesTransfered, &dataToSync );
        DMAWriteReg( &fdoData->Channel, DMABytesTransfered, dataToSync );
        //KernelPrintPlain(("Ebt %d 0x%x %u %llu 0x%llx\n", fdoData->BusInterface.Device->Id, readValue, dataToSync , isrDiff, isrTime & 0xFFFFFFFF ));
    }


    // Re-read the CSR register just in case the SG has asserted since the last interrupt
    DMAReadReg( &fdoData->Channel, DMACSR, &tempValue );
    readValue |= (tempValue & CSR_SGInterruptStatus);

    // Clear the event interrupt as we don't want to process it here
    readValue &= ~CSR_EventInterruptStatus;
    DMAWriteReg( &fdoData->Channel, DMACSR, readValue );

    if ( readValue & CSR_SGInterruptStatus )
    {
        if( ( !fdoData->Channel.HasSGCount ) && ( GetRegCap( fdoData->BusInterface.Device->CapInfo ).Version == 4 ) )
        { // Due to version number not being rolled in some verion 4's of the DMA controller we need to do this check
            DMAReadReg( &fdoData->Channel, DMASGBackLog, &sgBackLog );
            if( sgBackLog > 0 )
                fdoData->Channel.HasSGCount = 1;
        }

    	if( fdoData->Channel.HasSGCount )
    	{
            DMAReadReg( &fdoData->Channel, DMASGBackLog, &sgBackLog );
			DMAWriteReg( &fdoData->Channel, DMASGBackLog, sgBackLog );

		    KernelTrace( TRACE_LEVEL_INFORMATION, DMACommon, "FDMA_%u: ISR SGBackLog %u\n", fdoData->BusInterface.Device->Id, sgBackLog );
    	}
    	else
    	{
    		sgBackLog = 1;
    	}

        sgInterrupt = 1;
        //KernelPrintPlain(("SG %d 0x%x sg 0%x %llu 0x%llx\n", fdoData->BusInterface.Device->Id, readValue, sgBackLog, isrDiff, isrTime & 0xFFFFFFFF));
    }

    fdoData->LastISRTime = isrTime;
    if ( ( sgInterrupt && sgBackLog > 0 ) || (eventInterrupt && (dataToSync>0)) )
    {
        DPCData_t * work = (DPCData_t *)kmalloc(sizeof(DPCData_t), GFP_ATOMIC);
    	fdoData->ISRCount++;
        if ( work == NULL )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: Could not allocate memory for DPC!!!\n", fdoData->BusInterface.Device->Id);
        }
        else
        {
        	if( dataToSync == 0 )
        		eventInterrupt = 0;

            INIT_WORK( (struct work_struct *)work, OT_Cap_VideoFDMA_DPC );
            work->ISRCount = fdoData->ISRCount;
            work->fdo = fdoData;
            work->InterruptEvent = eventInterrupt;
            work->EventByteCount = dataToSync;
            work->InterruptSG = sgInterrupt;
            work->SGCount = sgBackLog;
            work->Time = isrTime;
            queue_work( fdoData->DPCQueue, (struct work_struct *)work );
        }

        return true;
    }
    return false;
}

static int OT_Cap_VideoFDMA_driver_probe( struct device * dev )
{
    const char *DMAType[] = {
            "Data","Video","Audio","Packet"
    };
    const char *DMADir[] = {
            "In","Out","Bi","Unknown"
    };

    POmniTekCapabilityDevice fullDev = NULL;
    OT_Cap_VideoFDMADevice *fdoData = NULL;
    int result = 0;
    u32 k;
    u32 block;
    u32 reg;
    uint32_t readVal = 0xffffffff;
    char wqName[10] = {0,};

    fullDev = ToOmniTekCapabilityDevice( dev );

    fdoData = kzalloc( sizeof(OT_Cap_VideoFDMADevice), GFP_KERNEL );
    if( fdoData )
    {
        fdoData->CapDev = fullDev;
        result = MANUF_FUNC(_GetInterfaceForCapDriver)( fdoData->CapDev, &fdoData->BusInterface );
        if (result != 0 )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "Could not Get interface: %d\n", result );
            goto probe_failure_OmniTek_GetInterfaceForCapDriver;
        }
        fdoData->ISRCount = 0;

        result = device_create_file( dev, &dev_attr_debuglevel );
        if( result )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "can't create sysfs debuglevel file!!!\n" );
            goto probe_failure_device_create_file;
        }

        mutex_init( &fdoData->RequestMutex );

        EventListInit( &fdoData->AsyncEvents );

        fdoData->EventCount = 0;
        fdoData->PastDataCount = 0;
        mutex_init( &fdoData->EventCountMutex );

        mutex_init( &fdoData->MasterMutex );
        fdoData->MasterHandle = NULL;

        // Initialise a char device
        cdev_init( &( fdoData->CharDev ), &OT_Cap_VideoFDMA_device_fops );
        fdoData->CharDev.owner = THIS_MODULE;

        // actually add the char device
        result = cdev_add( &fdoData->CharDev, fdoData->BusInterface.Device->CharDevNum, 1 );
        if( result )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: Could not create char device. code: %d\n", fdoData->BusInterface.Device->Id, result);
            goto probe_failure_cdev_add;
        }

        if ( NULL == device_create( MANUF_FUNC(_GetClass)(), dev, fdoData->BusInterface.Device->CharDevNum, NULL, MANUF_DEV("_Cap_%s%sFDMA_%02d_%03d"), DMAType[ OmDmaGetContentType( GetRegCap( fullDev->CapInfo ).Type ) ], DMADir[ OmDmaGetDirection( GetRegCap( fullDev->CapInfo ).Type ) ], SlotIdFromChildId( fullDev->Id ) , BasicChildId( fullDev->Id ) ) )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: Failed to create dev entry\n", fdoData->BusInterface.Device->Id );
            result = -ENOMEM;
            goto probe_failure_device_create;
        }
        snprintf( fullDev->DeviceAccessName, MAX_FILEPATH_LEN, "/dev/"MANUF_DEV("_Cap_%s%sFDMA_%02d_%03d"), DMAType[ OmDmaGetContentType( GetRegCap( fullDev->CapInfo ).Type ) ], DMADir[ OmDmaGetDirection( GetRegCap( fullDev->CapInfo ).Type ) ], SlotIdFromChildId( fullDev->Id ) , BasicChildId( fullDev->Id ) );

        k = 0;
        for ( block = 0; block < GetRegCap( fullDev->CapInfo ).NumBlocks && k < NumDMARegisters; block++ )
        {
            for ( reg = 0; reg < GetRegCap( fullDev->CapInfo ).Blocks[block].Count && k < NumDMARegisters; reg++ )
            {
                fdoData->Channel.Platform.RegMap[k].Block = &(GetRegCap( fullDev->CapInfo ).Blocks[block]);
                fdoData->Channel.Platform.RegMap[k++].Reg = reg;
            }
        }

        snprintf( wqName, 10, MANUF_DEV("%02d%03d"), SlotIdFromChildId( fullDev->Id ) , BasicChildId( fullDev->Id ) );
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,35)
        fdoData->DPCQueue = create_singlethread_workqueue( wqName );
#else
    	fdoData->DPCQueue = alloc_workqueue("%s", WQ_HIGHPRI | WQ_CPU_INTENSIVE, 1, wqName);
#endif
        if( fdoData->DPCQueue == NULL )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: create_singlethread_workqueue failure\n", fdoData->BusInterface.Device->Id);
            goto probe_failure_create_singlethread_workqueue;
        }

        fdoData->Channel.Platform.BusInterface = &fdoData->BusInterface;
        fdoData->IsEventIn = ( GetRegCap( fullDev->CapInfo ).Type == RegCap_DMA_DataInFDMA ) || ( GetRegCap( fullDev->CapInfo ).Type == RegCap_DMA_PacketInFDMA );
        fdoData->IsEventOut = ( GetRegCap( fullDev->CapInfo ).Type == RegCap_DMA_DataOutFDMA ) || ( GetRegCap( fullDev->CapInfo ).Type == RegCap_DMA_PacketOutFDMA );
        result = OT_Cap_VideoFDMA_InitChannel( fdoData, dev );
        if ( result != 0 )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_VideoFDMA, "FDMA_%u: DmaInit. code: %d\n", fdoData->BusInterface.Device->Id, result);
            goto probe_failure_InitChannel;
        }
        fdoData->BusInterface.RegisterISRCallback( fullDev, OT_Cap_VideoFDMA_ISR );

        // Setup the DMA hardware Mode
        DMAReadReg( &fdoData->Channel, DMACSR, &readVal );
        if ( fdoData->IsEventIn )
        {
            readVal |= (CSR_EventInterruptEnable | CSR_DisableSyncControl);
            DMAWriteReg( &fdoData->Channel, DMACSR, readVal );
        }
        if ( fdoData->IsEventOut )
        {
            readVal |= ( CSR_DisableSyncControl );
            DMAWriteReg( &fdoData->Channel, DMACSR, readVal );
        }
        dev_set_drvdata( dev, fdoData );
    }
    else
    {
        result = -ENOMEM;
    }
    goto probe_success;

probe_failure_InitChannel:
    destroy_workqueue( fdoData->DPCQueue );

probe_failure_create_singlethread_workqueue:
    device_destroy( MANUF_FUNC(_GetClass)(), fdoData->BusInterface.Device->CharDevNum );

probe_failure_device_create:
    cdev_del( &fdoData->CharDev );

probe_failure_cdev_add:
    device_remove_file( dev, &dev_attr_debuglevel );
probe_failure_device_create_file:

probe_failure_OmniTek_GetInterfaceForCapDriver:
    kfree( fdoData );

probe_success:

    return result;
}

static bool OT_Cap_VideoFDMA_ProgramDMASingleEntry( DMAChannel *channel, DMA64BitSGLEntry* sglEntry, dma_addr_t valDPRAddr,
                                                    uint32_t MaxFragment, int numFragments, int numMappedPages,
                                                    uint32_t startPageIndex, bool isWrite,
                                                    dma_addr_t* pValPADR, unsigned int* pValSIZE )
{
    uint32_t valLADR = (numFragments == 0) ? 0x11111111 : 0;
    uint32_t valDPRCtrl = ( !isWrite ? DPR_Direction : 0 );

    sglEntry->PADR = *pValPADR;

    if( (numFragments == ( numMappedPages - 1 )) && (*pValSIZE <= MaxFragment) )
    { // end of chain...
        valDPRCtrl |= DPR_EndOfChain | DPR_InterruptAfterTransfer; // Last entry - mark as last and interrupt
        valLADR = 0x22222222;
    }

    sglEntry->DPR = valDPRAddr;
    sglEntry->DPR_LOW |= valDPRCtrl;

    if( ( startPageIndex == 0 ) && ( numMappedPages == 1 ) )
    { // we this is the first lot of transactions and we only have one table entry then
        if ( isWrite ) // if its write direction mark with all 0x2's
            valLADR = 0x22222222;
        else // otherwise all 0x1's
            valLADR = 0x11111111;
    }

    sglEntry->LADR_LOW = valLADR;
    sglEntry->LADR_HIGH = 0;

    sglEntry->SIZE_HIGH = 0;
    sglEntry->SIZE_LOW = *pValSIZE;
    if ( *pValSIZE > MaxFragment )
        sglEntry->SIZE_LOW = MaxFragment;

    if ( *pValSIZE  > MaxFragment )
    {
        *pValSIZE -= MaxFragment;
        *pValPADR += MaxFragment;
        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: this fragment is bigger than the largest we allow so use previous info\n", channel->Platform.BusInterface->Device->Id );

        return false;
    }

    return true;
}

bool OT_Cap_VideoFDMA_ProgramDMA( DMAChannel *channel, DMATx *pContext )
{
    uint32_t pageIdx;
    int numFragments = 0;
    const uint32_t MaxFragment = channel->MaxFragmentSize;
    const uint32_t MaxSGLElements = channel->MaxSGLElements;
//    const bool Has64BitPADR = channel->Has64BitPADR;
    DMA64BitSGLEntry *sglEntry = ( DMA64BitSGLEntry * )( pContext->SGLBuffer->pVa );
    struct page * thisPage = NULL;
    unsigned int page_len;
    unsigned int page_offset;
    struct scatterlist * cur_scatter = pContext->SGLBuffer->SGTable.sgl;
    dma_addr_t valPADR;
    unsigned int valSIZE;
    dma_addr_t valDPRAddr = pContext->SGLBuffer->PhysAddr;

    unsigned int remaining_len = pContext->Size;

    if ( pContext->NextPageIndex > 0 )
    {
        remaining_len -= ( ( 1 << PAGE_SHIFT ) - pContext->MDL.FirstOffset );
        remaining_len -= ( ( 1 << PAGE_SHIFT ) * ( pContext->NextPageIndex - 1 ) );
    }

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Remaining data: 0x%08x\n", channel->Platform.BusInterface->Device->Id, remaining_len );

    if ( pContext->NextPageIndex > 0 )
    { // this is a multipart transfer, we need to unmap the previous pages first...
        // we need to tell the unmap routine how many we said we where going to map last time...
        numFragments = pContext->NumSGMapped;
        dma_unmap_sg( channel->Platform.BusInterface->HostControllerDevice, pContext->SGLBuffer->SGTable.sgl, numFragments, pContext->WriteDirection ? DMA_TO_DEVICE : DMA_FROM_DEVICE );
    }

    pageIdx = pContext->NextPageIndex;
    // map the pages we need into the scatterlist;
    for_each_sg( pContext->SGLBuffer->SGTable.sgl, cur_scatter, MaxSGLElements, numFragments )
    {
        thisPage = pContext->MDL.Pages[ pageIdx ];
        page_offset = 0;
        if( pageIdx == 0 )
            page_offset = pContext->MDL.FirstOffset;

        page_len = ( 1 << PAGE_SHIFT ) - page_offset;
        if (remaining_len < page_len)
        {
            page_len = remaining_len;
        }
        remaining_len -= page_len;

        sg_set_page( cur_scatter, thisPage, page_len, page_offset );

        pageIdx++;
        if ( remaining_len == 0  )
        {
            numFragments++;
            break;
        }
    }

    pContext->SGLBuffer->NumElements = 0;
    pContext->NumSGMapped = 0;
    pContext->NumActualSGMapped = dma_map_sg( channel->Platform.BusInterface->HostControllerDevice, pContext->SGLBuffer->SGTable.sgl, numFragments, pContext->WriteDirection ? DMA_TO_DEVICE : DMA_FROM_DEVICE );
    if( pContext->NumActualSGMapped < 0 )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: dma_map_sg failed. code 0x%08x\n", channel->Platform.BusInterface->Device->Id, pContext->NumActualSGMapped );
        // TODO: blow up somehow.
        return FALSE;
    }
    pContext->NumSGMapped = numFragments;

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Expected fragments %u, mapped %u\n", channel->Platform.BusInterface->Device->Id, pContext->NumSGMapped, pContext->NumActualSGMapped );

    cur_scatter = (pContext->SGLBuffer->SGTable.sgl);
    valPADR = sg_dma_address( cur_scatter );
    valSIZE = sg_dma_len( cur_scatter );

    // now create the sgl for the hardware
    // even thought each original entry is no more than 1 page, the dma_map_sg may override this and give use huge contigious segments

    for ( numFragments = 0; numFragments < (pContext->NumActualSGMapped); )
    {
        bool pageCompleted = false;

        if ( pContext->SGLBuffer->NumElements >= MaxSGLElements )
        {
            KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Failed to create sgl, too many elements\n", channel->Platform.BusInterface->Device->Id );
            return FALSE;
        }

        valDPRAddr += sizeof(DMA64BitSGLEntry);

        pageCompleted = OT_Cap_VideoFDMA_ProgramDMASingleEntry( channel, sglEntry, valDPRAddr, MaxFragment,
                                                                numFragments, pContext->NumActualSGMapped,
                                                                pContext->NextPageIndex, pContext->WriteDirection,
                                                                &valPADR, &valSIZE );
        if (pageCompleted)
        {
            numFragments++;
            cur_scatter = sg_next(cur_scatter);

            if ( numFragments < pContext->NumActualSGMapped )
            {
                valPADR = sg_dma_address( cur_scatter );
                valSIZE = sg_dma_len( cur_scatter );
            }
        }

        pContext->SGLBuffer->NumElements++;
        sglEntry++;
    }
    // next time we need to start from somewhere else....
    pContext->NextPageIndex = pageIdx;

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Total Elements %u\n", channel->Platform.BusInterface->Device->Id, pContext->SGLBuffer->NumElements );

    return TRUE;
}

#ifdef OT_GPUDIRECT
bool OT_Cap_VideoFDMA_ProgramDMAGpuDirect( DMAChannel *channel, DMATx *pContext )
{
    const uint32_t MaxFragment = channel->MaxFragmentSize;
    const uint32_t MaxSGLElements = channel->MaxSGLElements;
    DMA64BitSGLEntry *sglEntry = ( DMA64BitSGLEntry * )( pContext->SGLBuffer->pVa );
    dma_addr_t valPADR;
    unsigned int valSIZE;
    dma_addr_t valDPRAddr = pContext->SGLBuffer->PhysAddr;

    int result = 0;
    int numFragments = 0;
    size_t numberOfPagesMapped = 0;
    GpuDirectMappedPage* currentPage = NULL;

    // Only supported for PCI host controller
    struct device* hc_device = channel->Platform.BusInterface->HostControllerDevice;
    struct pci_dev* pci_device = (hc_device && dev_is_pci(hc_device)) ? to_pci_dev(hc_device) : NULL;

    if ( pContext->NextPageIndex > 0 )
    {
        // Multipart transfers not supported
        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: GPUDirect multipart transfers not supported\n",
                                                         channel->Platform.BusInterface->Device->Id );
        return false;
    }

    result = GpuDirectMapPages( &pContext->GpuPages, pci_device );
    if (result < 0)
    {
        KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: GPUDirect not programming DMA, failed to map pages: error %i\n",
                                                         channel->Platform.BusInterface->Device->Id, result );
        return false;
    }

    pContext->SGLBuffer->NumElements = 0;

    numberOfPagesMapped = GpuDirectGetMappedPageCount( &pContext->GpuPages );
    currentPage = GpuDirectMappedPageFirst( &pContext->GpuPages );

    valPADR = GpuDirectMappedPageAddress( &pContext->GpuPages, currentPage );
    valSIZE = GpuDirectMappedPageLength( &pContext->GpuPages, currentPage );

    for ( numFragments = 0; numFragments < numberOfPagesMapped; )
    {
        bool pageCompleted = false;

        if (!currentPage)
        {
            KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: NULL page pointer\n", channel->Platform.BusInterface->Device->Id );
            return FALSE;
        }

        if ( pContext->SGLBuffer->NumElements >= MaxSGLElements )
        {
            KernelTrace( TRACE_LEVEL_ERROR, Cap_VideoFDMA, "FDMA_%u: Failed to create sgl, too many elements\n", channel->Platform.BusInterface->Device->Id );
            return FALSE;
        }

        // update where the next sgl entry would be
        valDPRAddr += sizeof(DMA64BitSGLEntry);

        pageCompleted = OT_Cap_VideoFDMA_ProgramDMASingleEntry( channel, sglEntry, valDPRAddr, MaxFragment,
                                                                numFragments, numberOfPagesMapped,
                                                                pContext->NextPageIndex, pContext->WriteDirection,
                                                                &valPADR, &valSIZE );

        if (pageCompleted)
        {
            numFragments++;
            currentPage = GpuDirectMappedPageNext( &pContext->GpuPages, currentPage );

            if ( numFragments < numberOfPagesMapped )
            {
                valPADR = GpuDirectMappedPageAddress( &pContext->GpuPages, currentPage );
                valSIZE = GpuDirectMappedPageLength( &pContext->GpuPages, currentPage );
            }
        }

        pContext->SGLBuffer->NumElements++;
        sglEntry++;
    }

    // In the case of GPUDirect, all pages should have been pinned and all pinned pages mapped. Multi-part transfers not supported.
    pContext->NextPageIndex = GpuDirectGetPinnedPageCount( &pContext->GpuPages );

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: GPUDirect Total Elements %u\n", channel->Platform.BusInterface->Device->Id, pContext->SGLBuffer->NumElements );

    return TRUE;
}
#endif

int OT_Cap_VideoFDMA_FillActiveQueue( OT_Cap_VideoFDMADevice *fdoData, const bool bFromIsr )
{
    GroupedDMATx *request;
    struct list_head * entry;
    int activeQueueLength = 0;
    uint32_t targetId;

    mutex_lock( &fdoData->RequestMutex );

    list_for_each( entry, &fdoData->ActiveQueue )
    {
        activeQueueLength++;
    }

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: IsRunning? %s, ActiveQueueLength: %u, MinQueueDepth: %u\n", fdoData->BusInterface.Device->Id, fdoData->Channel.IsRunning ? "Yes" : "No", activeQueueLength, fdoData->Channel.MinQueueDepth );
    if ( fdoData->Channel.IsRunning && activeQueueLength < fdoData->Channel.MinQueueDepth )
    {
        if( bFromIsr )
        {
            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: %d, Buffer Underrun - IsRunning? %s, ActiveQueueLength: %u, MinQueueDepth: %u\n", fdoData->BusInterface.Device->Id, bFromIsr, fdoData->Channel.IsRunning ? "Yes" : "No", activeQueueLength, fdoData->Channel.MinQueueDepth );
        }
        mutex_unlock( &fdoData->RequestMutex );
        return -EACCES;
    }

    while ( activeQueueLength < fdoData->Channel.MaxQueueLength && !list_empty( &fdoData->PendingQueue ) )
    {
        bool programSuccess = false;

        targetId = fdoData->NextTargetId;

        request = list_first_entry( &fdoData->PendingQueue, GroupedDMATx, Next );
        list_del( &request->Next );

        request->Txs[0].SGLBuffer = &fdoData->Channel.SGLBuffers[targetId];
        request->Txs[0].TargetId = targetId;

        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Assigned target %u to sgl %u, %p\n", fdoData->BusInterface.Device->Id, 0, targetId, request );

#ifdef OT_GPUDIRECT
        if (request->Txs[0].Flags & DMA_FLAGS_GPUDIRECT)
        {
            programSuccess = OT_Cap_VideoFDMA_ProgramDMAGpuDirect( &fdoData->Channel, &request->Txs[0] );
        }
        else
#endif
        {
            programSuccess = OT_Cap_VideoFDMA_ProgramDMA( &fdoData->Channel, &request->Txs[0] );
        }

        if( !programSuccess )
        {
            pr_err_ratelimited("Video FDMA failed to program DMA - see ER #85039");
        }

        if ( activeQueueLength > 0 )
        {
            uint32_t previousId = 0;
            if ( targetId == 0 )
                previousId = fdoData->Channel.MaxQueueLength - 1;
            else
                previousId = targetId-1;

            KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: Join %u with %u\n", fdoData->BusInterface.Device->Id, previousId, targetId );
            DMAJoinSgl( &fdoData->Channel.SGLBuffers[previousId], &fdoData->Channel.SGLBuffers[targetId], TRUE, request->Txs[0].bNoSync );
        }


        request->Active = true;
        list_add_tail( &request->Next, &fdoData->ActiveQueue );
        activeQueueLength++;
        fdoData->NextTargetId++;
        fdoData->NextTargetId %= fdoData->Channel.MaxQueueLength;
    }

    mutex_unlock( &fdoData->RequestMutex );

    return activeQueueLength;
}

void OT_Cap_VideoFDMA_ProcessChannelInterrupt( OT_Cap_VideoFDMADevice *fdoData, uint64_t isrTime )
{
    GroupedDMATx *request;

    mutex_lock( &fdoData->RequestMutex );
    if ( list_empty( &fdoData->ActiveQueue ))
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: DMA interrupt with nothing active...\n", fdoData->BusInterface.Device->Id );
        DMAAbortChannel( &fdoData->Channel );

        mutex_unlock( &fdoData->RequestMutex );
        return;
    }

    request = list_first_entry( &fdoData->ActiveQueue, GroupedDMATx, Next );

    KernelTrace( TRACE_LEVEL_VERBOSE, Cap_VideoFDMA, "FDMA_%u: INTERRUPT\n", fdoData->BusInterface.Device->Id );

    if ( request != NULL )
    {
        if ( request->StartTime == 0 )
            request->StartTime = fdoData->Channel.PreviousISRTime;
        request->EndTime = isrTime;
        mutex_unlock( &fdoData->RequestMutex );
        EventComplete( &fdoData->AsyncEvents, request->EventId, NULL, false  );
        mutex_lock( &fdoData->RequestMutex );
    }

    if ( list_empty( &fdoData->ActiveQueue ))
    {
        DMAAbortChannel( &fdoData->Channel );
        mutex_unlock( &fdoData->RequestMutex );
    }
    else
    {
        mutex_unlock( &fdoData->RequestMutex );
        if( OT_Cap_VideoFDMA_FillActiveQueue( fdoData, true ) < 0 )
        {
            // Underrun condition so abort the DMA transfers
            KernelTrace( TRACE_LEVEL_WARNING, Cap_VideoFDMA, "FDMA_%u: Abort due to underrun\n", fdoData->BusInterface.Device->Id );
            OT_Cap_VideoFDMA_AbortCleanupChannel( fdoData );
            OT_Cap_VideoFDMA_PurgePending( fdoData );
        }
    }

    fdoData->Channel.PreviousISRTime = isrTime;
}

void OT_Cap_VideoFDMA_CleanupChannel( OT_Cap_VideoFDMADevice *fdoData )
{
    uint32_t i;
    DMASGLBuffer *sglBuf = NULL;
    DMAChannel *channel = &fdoData->Channel;
    struct device * hcd = channel->Platform.BusInterface->HostControllerDevice;

    OT_Cap_VideoFDMA_AbortCleanupChannel( fdoData );
    OT_Cap_VideoFDMA_PurgePending( fdoData );

    if ( channel->SGLBuffers != NULL )
    {
        for ( i = 0; i < channel->MaxQueueLength; i++ )
        {
            sglBuf = &channel->SGLBuffers[i];

            sg_free_table( &sglBuf->SGTable );
            if ( sglBuf->pVa != NULL )
            {
                dma_free_coherent( hcd, sglBuf->Size, sglBuf->pVa, sglBuf->PhysAddr );
                sglBuf->pVa = NULL;
            }
        }
        DeleteMemory( &channel->Platform.SGLBuffersMemory );
        channel->SGLBuffers = NULL;
    }
}

static int OT_Cap_VideoFDMA_driver_remove( struct device *dev )
{
    OT_Cap_VideoFDMADevice * fdoData = NULL;

    fdoData = dev_get_drvdata( dev );
    if( fdoData != NULL )
    {
        fdoData->BusInterface.DeRegisterISRCallback( fdoData->CapDev );

        OT_Cap_VideoFDMA_CleanupChannel( fdoData );

        EventListClean( &fdoData->AsyncEvents );

        if ( fdoData->DPCQueue != NULL )
        {
            flush_workqueue( fdoData->DPCQueue );
            destroy_workqueue( fdoData->DPCQueue );
        }

        device_remove_file( dev, &dev_attr_debuglevel );

        device_destroy( MANUF_FUNC(_GetClass)(), fdoData->BusInterface.Device->CharDevNum );

        dev_set_drvdata( dev, NULL );
        cdev_del( &fdoData->CharDev );
        kfree( fdoData );
        return 0;
    }
    return -1;
}

int OT_Cap_VideoFDMA_init( void )
{
    int result = 0;

    // tell the bus that we exist and will control some devices
    result = MANUF_FUNC(_capability_driver_register)( &OT_Cap_VideoFDMA_driver.Driver );

    return result;
}

void OT_Cap_VideoFDMA_cleanup( void )
{
    // tell the bus that this driver is gone
    MANUF_FUNC(_capability_driver_unregister)( &OT_Cap_VideoFDMA_driver.Driver );
}

module_init( OT_Cap_VideoFDMA_init );
module_exit( OT_Cap_VideoFDMA_cleanup );
