/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup DriverlandInterface
 *  @{
 */

#ifndef _INTERFACE_TYPES_H_
#error "Do not include this directly."
#endif

#include "../Common.h"

#include <linux/types.h>

/**
 * @brief A 128 bit unique number in the form of a windows GUID
 */
typedef struct _UUID
{
    uint32_t Data1; //!< _
    uint16_t Data2; //!< _
    uint16_t Data3; //!< _
    uint8_t  Data4[ 8 ]; //!< _
} UUID;

/**
 * @brief Create and initialise a UUID
 */
#define DEFINE_UUID( name, l, s1, s2, b1, b2, b3, b4, b5, b6, b7, b8) \
        static const UUID name = { l, s1, s2, { b1, b2,  b3,  b4,  b5,  b6,  b7,  b8 } }


/**
 * @brief Structure for matching a driver to a device
 *
 * Linux method of capability to driver matching. Displayed in order of importance.
 * Best is Type, ExtendedType and Version.
 * Next best is Type, ExtendedType
 * Next best is Type, Version
 * Lowest is Type
 *
 * If all are 0 then we assume its the end of the matching list.
 */
typedef struct _DriverMatchId
{
    uint32_t Type; //!< Required. Capbility.Type
    uint32_t ExtendedType; //!< Optional. ==CapRegister.Type. ==CapMemoryMap.Type
    uint32_t Version; //!< Optional. Capability.Version
} DriverMatchId;

typedef DriverMatchId *PDriverMatchId; //!< pointer to DriverMatchId

typedef struct device * POSDevice; //!< Define a linux device pointer to be our own type

#ifdef CONFIG_PHYS_ADDR_T_64BIT
#define OTPSxphys "llX"
#else
#define OTPSxphys "X"
#endif
typedef phys_addr_t ot_phys_addr_t;

#ifndef QuadPart
#define QuadPart( x ) x
#endif


/** @}*/
