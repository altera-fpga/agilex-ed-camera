/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#ifndef INTERRUPT_IOCTL_H_
#error "Do not include this directly."
#endif

#include "../Common_IOCTL.h"

#include <linux/ioctl.h>

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */


#pragma pack(push,4)
/**
 * Linux specific wrapper for delayed io for type CapDataFDMA_Event_IOCTL
 */
typedef struct _CapInterrupt_InterruptEvent_IOCTL_Linux
{
    CapGeneral_EventCtx_IOCTL EventInfo; //!< The event information, this is used for the async io
    CapInterrupt_InterruptEvent_IOCTL IOCTLInfo; //!< the actual payload. See the type for further info
} CapInterrupt_InterruptEvent_IOCTL_Linux;
#pragma pack(pop)

/**
 * @brief Current #CAP_INTERRUPT_IOCTL_AcquireController CapInterrupt_AcquireController_IOCTL::Version number to use
 */
#define CAP_INTERRUPT_IOCTL_VERSION_AcquireController  0

/**
 * @brief Current #CAP_INTERRUPT_IOCTL_ReleaseController CapInterrupt_ReleaseController_IOCTL::Version number to use
 */
#define CAP_INTERRUPT_IOCTL_VERSION_ReleaseController 0

/**
 * @brief Current #CAP_INTERRUPT_IOCTL_EnableMask CapInterrupt_Mask_IOCTL::Version number to use
 */
#define CAP_INTERRUPT_IOCTL_VERSION_EnableMask        0

/**
 * @brief Current #CAP_INTERRUPT_IOCTL_DisableMask CapInterrupt_Mask_IOCTL::Version number to use
 */
#define CAP_INTERRUPT_IOCTL_VERSION_DisableMask       0

/**
 * @brief Current #CAP_INTERRUPT_IOCTL_InterruptEvent CapInterrupt_InterruptEvent_IOCTL::Version number to use
 */
#define CAP_INTERRUPT_IOCTL_VERSION_InterruptEvent    1


/**
 * @brief IOCTL request device for access as the generic event master
 * Passed and received data type is CapInterrupt_AcquireController_IOCTL
 */
#define CAP_INTERRUPT_IOCTL_AcquireController  _IOWR( CAP_INTERRUPT_IOC_MAGIC, CAP_INTERRUPT_IOCTL_NUM_AcquireController, CapInterrupt_AcquireController_IOCTL * )

/**
 * @brief IOCTL request device to release control as the generic event master
 * Passed and received data type is CapInterrupt_ReleaseController_IOCTL
 */
#define CAP_INTERRUPT_IOCTL_ReleaseController _IOWR( CAP_INTERRUPT_IOC_MAGIC, CAP_INTERRUPT_IOCTL_NUM_ReleaseController, CapInterrupt_ReleaseController_IOCTL * )

/**
 * @brief IOCTL request device mask bits for generic interrupt. This is additive (RMW)
 * Passed and received data type is CapInterrupt_Mask_IOCTL
 */
#define CAP_INTERRUPT_IOCTL_EnableMask        _IOWR( CAP_INTERRUPT_IOC_MAGIC, CAP_INTERRUPT_IOCTL_NUM_EnableMask, CapInterrupt_Mask_IOCTL * )

/**
 * @brief IOCTL request device to unmask bits for generic interrupt.
 * Passed and received data type is CapInterrupt_Mask_IOCTL
 */
#define CAP_INTERRUPT_IOCTL_DisableMask       _IOWR( CAP_INTERRUPT_IOC_MAGIC, CAP_INTERRUPT_IOCTL_NUM_DisableMask, CapInterrupt_Mask_IOCTL * )

/**
 * @brief IOCTL queue of notification handle. will instantly complete if already active and interrupts have happend since last queue
 * Passed and received data type is CapInterrupt_InterruptEvent_IOCTL_Linux
 */
#define CAP_INTERRUPT_IOCTL_InterruptEvent    _IOWR( CAP_INTERRUPT_IOC_MAGIC, CAP_INTERRUPT_IOCTL_NUM_InterruptEvent, CapInterrupt_InterruptEvent_IOCTL_Linux * )

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/
