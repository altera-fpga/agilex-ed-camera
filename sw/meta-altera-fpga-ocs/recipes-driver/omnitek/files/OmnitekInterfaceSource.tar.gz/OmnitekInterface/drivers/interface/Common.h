/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef COMMON_H_
#define COMMON_H_

/**
 * \defgroup DriverlandInterface Inter-Driver Interfaces
 * Driver level interfaces and data structures for all communication between all driver levels
 */

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"

/*
 * Platform specific implementations of
 *
 * IsSuccess( x ) - Check the return of any standard int based api function
 * IsFailure( x ) - Check the return of any standard int based api function
 * KernelPrint( x ) - Print including function and line
 * KernelPrintPlain( x ) - Print without the function or line
 * KernelTrace( Severity, Source, Format, ... ) - Try to use wpp if it exists otherwise just prettry version of KernelPrint...
 *
 * Extra type defines needed for cross platform compatibility.
 */

// include platform specific headers
#if BUILDTYPE == BT_WINDOWS
#include "windows/Common.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/Common.h"
#endif

/** @}*/

#endif /* COMMON_H_ */
