/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef IOCTL_DMACOMMON_H_
#define IOCTL_DMACOMMON_H_

/** \addtogroup UserlandInterface
 *  @{
 */

#include "global_defs.h"

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#pragma pack(push, 4)
/**
 * @brief Basic dma transfer information
 */
typedef struct _DmaTarget
{
    uint32_t Size; //!< Transfer size
	uint32_t cbSize;	//!< Size of this structure
    union {				
        struct {
            uint32_t Offset;
            uint32_t OffsetHigh;
        } DUMMYSTRUCTNAME;
        void* pVa;	//!< Virtual Address of buffer on PC, not is converted to 64bit value for cross between 32bit app and 64bit driver
    } DUMMYUNIONNAME; //!< see pVa
    uint8_t bNoSync; //!< For FDMAs, should be remove the magic sync value from our header and the previous footer. Introduced in V1
    uint32_t LocalAddr; //!< Offset into local address on card
} DmaTarget;

/**
 * @brief Basic dma transfer information
 */
typedef struct _DmaTarget_V2
{
    uint32_t cbSize;    //!< Size of this structure. Not actually used.......
    uint64_t Size; //!< Transfer size
    union {
        void* pVa;  //!< Virtual Address of buffer on PC, not is converted to 64bit value for cross between 32bit app and 64bit driver
        uint64_t PhysAddr; //!< Physical address of buffer
    } DUMMYUNIONNAME; //!< see pVa
    uint8_t bIsPhysAddr; //!< Should we treat it as a physical address?
    uint8_t bNoSync; //!< For FDMAs, should be remove the magic sync value from our header and the previous footer. Introduced in V1
    uint8_t Write; //!< From the perspective of the PC - Write == TRUE -> DMA from PC to Ram
    uint64_t LocalAddr; //!< Offset into local address on card
} DmaTarget_V2;

#ifndef __GNUC__
#pragma warning( push )
#pragma warning( disable : 4200 ) // Disable the zero sized array warning
#endif
/**
 * @brief Grouping structure for multiple dmas in one
 */
typedef struct _DmaXfer
{
	uint32_t cbSize;	//!< Size of this structure
    uint32_t nTargets; //!< Number of targets for this one transaction (usually 1)
    uint8_t Write; //!< From the perspective of the PC - Write == TRUE -> DMA from PC to Ram
    uint64_t StartTime; //!< if we have a timer, this is either the previous isr time OR start dma time
    uint64_t EndTime; //!< if we have a timer, this is the isr time of completion
    DmaTarget Targets[ ]; //!< Allocated targets for this transaction
} DmaXfer;

/**
 * @brief Grouping structure for multiple dmas in one
 */
typedef struct _DmaXfer_V2
{
    uint32_t cbSize;    //!< Size of this structure
    uint32_t nTargets; //!< Number of targets for this one transaction (usually 1)
    uint64_t StartTime; //!< if we have a timer, this is either the previous isr time OR start dma time
    uint64_t EndTime; //!< if we have a timer, this is the isr time of completion
    DmaTarget_V2 Targets[ ]; //!< Allocated targets for this transaction
} DmaXfer_V2;

#ifndef __GNUC__
#pragma warning( pop )
#endif

/**
 * @brief IOCTL structure for all dmas
 *
 * Version is specific to the IOCTL
 */
typedef struct _DMATransaction_IOCTL
{
	uint32_t cbSize;	//!< Size of this structure
    uint32_t Version; //!< request version. Versions 0 and 1
    DmaXfer Dma; //!< Details about the requested transfer
} DMATransaction_IOCTL;

/**
 * @brief IOCTL structure for all dmas
 *
 * Version is specific to the IOCTL
 */
typedef struct _DMATransaction_IOCTL_V2
{
    uint32_t cbSize;    //!< Size of this structure
    uint32_t Version; //!< request version. Version 2+
    DmaXfer_V2 Dma; //!< Details about the requested transfer
} DMATransaction_IOCTL_V2;

#if BUILDTYPE == BT_LINUX

/**
 * @brief Linux specific wrapped "eventable" structure for DMATransactions
 * As there is no real concept of async io for ioctls under Linux we need to
 * use our own mechanism. This is very similar to how libaio works.
 */
typedef struct _DMATransaction_IOCTL_Linux
{
    CapGeneral_EventCtx_IOCTL EventInfo; //!< The event specific information
    DMATransaction_IOCTL IOCTLInfo; //!< The actual ioctl payload
} DMATransaction_IOCTL_Linux;


/**
 * @brief Linux specific wrapped "eventable" structure for DMATransactions
 * As there is no real concept of async io for ioctls under Linux we need to
 * use our own mechanism. This is very similar to how libaio works.
 */
typedef struct _DMATransaction_IOCTL_V2_Linux
{
    CapGeneral_EventCtx_IOCTL EventInfo; //!< The event specific information
    DMATransaction_IOCTL_V2 IOCTLInfo; //!< The actual ioctl payload
} DMATransaction_IOCTL_V2_Linux;

#endif

#pragma pack(pop)

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @}*/

#endif /* IOCTL_DMACOMMON_H_ */
