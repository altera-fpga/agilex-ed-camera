/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef BUSPRIVATE_H_
#define BUSPRIVATE_H_

#include "global_defs.h"

#include "CapabilityDevice.h"
#include "CapabilityTypes.h"
#include "HostController.h"
#include "CapabilityDriverBusInterface.h"
#include "HostControllerBusInterface.h"
#include "Container.h"
#include "Memory.h"

#define TimerVersion 1
#define TimerVersion2 2
#define TimerStatusReg 0
#define TimerFrequencyReg 1
#define TimerLowerTimeReg 2
#define TimerUpperTimeReg 3
#define TimerLowerInterruptTimeReg 4
#define TimerUpperInterruptTimeReg 5


struct _ISRBaseGroup;
struct _ISRGroup;

typedef struct _RegisteredISR
{
    POmniTekCapabilityDevice Context; //!< The context for this ISR
    BusISRCB ISR; //!< The ISR
    struct _ISRGroup * Group;
} RegisteredISR, *PRegisteredISR;

typedef struct _ISRGroup
{
    uint8_t BitNumber;
    uint8_t NumISRs; // typically this will be 1
    RegisteredISR * ISRs; // array of RegisteredISR
    Allocateable ISRsMem;
    struct _ISRBaseGroup *BaseGroup;
} ISRGroup;

typedef struct _ISRBaseGroup
{
    uint8_t BaseLevel;
    uint8_t NumGroups; // unless we need to save memory this will be a multiple of 32
    ISRGroup * Groups;
    Allocateable GroupsMem;
    PCapInterrupt Interrupt;
} ISRBaseGroup;




struct _DeviceLookupData;

typedef struct _VirtualBusItem
{
    POmniTekHostController Controller; //!< The host controller that has registered with us
    OmniTekHostControllerInterface Interface; //!< The interface to use the Controller

    OmniTekCollection CapList; //!< Discovered capabilities collection
    char CapListName[ MAX_NAME_LEN ];
    // spinlock for CapList?
    uint8_t CapListFinalised; //!< has the Controller told us we are ready to go?

    uint32_t NumChildren; //!< total children created.
    OmniTekCapabilityDevice *Children; //!< Our children
    Allocateable ChildrenMem; //!< needed for cross platform allocations...
    struct _DeviceLookupData *ChildLookups; //!< just a spot to put the list....
    Allocateable ChildLookupsMem; //!< needed for cross platform allocations...

    uint8_t NumISRBaseGroups;
    ISRBaseGroup * BaseGroups;
    Allocateable BaseGroupsMem;

    uint8_t InterruptsEnabled;

#if BUILDTYPE == BT_WINDOWS
    WDFCHILDLIST WindowsChildList; //!< this contains the actual child device list...
#endif
} VirtualBus, *PVirtualBus;

ITER_TYPE_DEFS( VirtualBus, VirtualBus )

// This is Bus FDO extension
// this is hidden in the bus struct device using the dev_?et_drvdata routines...
typedef struct _BusDeviceData
{
    OmniTekCollection VirtualBusList; //!< VirtualBus based collection
    MemoryPoolType VirtualBusItemPool;
    MemoryPoolType CapListPool;
    spinlock_t Lock;
    uint8_t UsedSlots[MAX_SLOTS];
#if BUILDTYPE == BT_WINDOWS
    WDFDEVICE BusDevice;
#endif
#if BUILDTYPE == BT_LINUX
    dev_t CapabilitiesMajorDev;
#endif
// spinlock for VirtualBusList?
} BusDevice, *PBusDevice;
#if BUILDTYPE == BT_WINDOWS
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME( BusDevice, BusDeviceGetData );
#endif

/*
 * Used to accelerate the lookup of info about a device
 *
 */
typedef struct _DeviceLookupData
{
    uint32_t CapabilityNum;
    RegisteredISR * ISR;
    VirtualBusItem *VirtualBusHandle; // need to increment the reference when creating this...
#if BUILDTYPE == BT_WINDOWS
    WDFDEVICE ChildDevice;
    GUID IOCTLGUID;
#endif
} DeviceLookupData, *PDeviceLookupData;

/*
 * It MAY make sense to make some standard reg read/write funcs here that the host controller
 * can link to. So only if it really needs to have custom control over the reads it uses a
 * standard implementation.
 */
uint32_t BusReadHW( uint32_t *base, const uint64_t offset );
void BusWriteHW( uint32_t *base, const uint64_t offset, const uint32_t writeValue );
// we can use these to fill in blank handlers for enable / disable registers et al
void BusNOP1( POmniTekHostController );
void BusNOP2( POmniTekHostController, HCISRCB );

bool BusISR( POmniTekHostController context, POmniTekHostControllerInterface hci, PCapInterrupt interrupt, uint32_t registerNumber );

void ReadTimer( POmniTekHostControllerInterface hci, Capability * cap, uint64_t *value );

VirtualBusEntry *FindHostControllerEntry( POmniTekHostController hc );
VirtualBus *FindVirtualBusFromId( PBusDevice busInfo, const uint32_t busId );

// assumed locked spinlock....
void CleanVirtualBus( VirtualBusEntry * vbe );

int INIT_BusDevice( BusDevice *private_data );
void DEINIT_BusDevice( BusDevice *private_data );

void PrintCapability( Capability * cap );

void PreReleaseCapability( CapabilityItem * item );

void RemoveBusChildren( VirtualBus *vb );

int32_t AddCapabilityDevice( POmniTekCapabilityDevice capDev, PVirtualBus vb );

#if BUILDTYPE == BT_LINUX
#define INIT_VirtualBus( x, y ) ( 0 )
#endif
#if BUILDTYPE == BT_WINDOWS
NTSTATUS INIT_VirtualBus( PBusDevice privateBusData, PVirtualBus virtualBus );
#endif





/**
 * @brief Register a callback for interrupts for a specific device instance
 * @param[in] context The device instance wanting to register an interrupt handler
 * @param[in] cb The callback that should be used when a matching interrupt occurs
 * @return See Types.h
 */
uint32_t RegisterISRCallback( POmniTekCapabilityDevice context, BusISRCB cb );

/**
 * @brief De-register a callback for interrupts for a specific device instance
 * @param[in] context The device instance wanting to de-register an interrupt handler
 */
void DeRegisterISRCallback( POmniTekCapabilityDevice context );

/**
 * @brief Read a capabilities register
 *
 * Allow a device to read a register. The register block does not need to be within the capability of the passed device ( although this should
 * be the normal case )
 * @param[in] context The device instance asking for the read. Needed to obtain bus / host controller information
 * @param[in] block The capability block to read from
 * @param[in] reg The register within the block to read from
 * @param[out] readValue Where to read the value goes into
 * @return See Types.h
 */
uint32_t ReadRegisterCap( POmniTekCapabilityDevice context, PRegisterBlock block, const RegCount_t reg, uint32_t *readValue );

/**
 * @brief Write to a capbilities register
 *
 * Allow a device to write a register. The register block does not need to be within the capability of the passed device ( although this should
 * be the normal case )
 * @param[in] context The device instance asking for the write. Needed to obtain bus / host controller information
 * @param[in] block The capability block to write to
 * @param[in] reg The register within the block to write to
 * @param[in] writeValue The value to write into the selected register
 * @return See Types.h
 */
uint32_t WriteRegisterCap( POmniTekCapabilityDevice context, PRegisterBlock block, const RegCount_t reg, const uint32_t writeValue );

/**
 * @brief Read a shadowed value for a specific capabilities register
 *
 * Allow a device to read a shadow register. The register block does not need to be within the capability of the passed device ( although this should
 * be the normal case )
 * @param[in] context The device instance asking for the read. Needed to obtain bus / host controller information
 * @param[in] block The capability block to read from
 * @param[in] reg The register within the block to read from
 * @param[out] readValue Where to read the value goes into
 * @return See Types.h
 */
uint32_t ReadShadowRegisterCap( POmniTekCapabilityDevice context, PRegisterBlock block, const RegCount_t reg, uint32_t *readValue );


bool TimerGetFrequency( POmniTekCapabilityDevice context, uint32_t * hertz );
bool TimerGetTime( POmniTekCapabilityDevice context, uint64_t * time );




bool DoesCapabilityExist( Capability *cap, OmniTekCollection * capList );

/*
// have we already used this offset within an inserted offset capability?
bool DoesOffsetExist( const uint64_t offset, OmniTekCollection * capList );
bool HasOffsetBeenMapped( const uint64_t offset, Capability *cap );
*/

/**
 * @brief Initialise the passed structure to safe defaults
 * @param[in, out] hci The interface to initialise
 */
void INIT_OmniTekHostControllerInterface( POmniTekHostControllerInterface hci );

/**
 * @brief Inform the bus there is a new host controller on the system
 * @param[in, out] hc The context of the new host controller
 * @param[in, out] hci The interface functions to use upon the hc
 * @return See Types.h
 */
int RegisterHostController( POmniTekHostController hc, POmniTekHostControllerInterface hci );

/**
 * @brief For the given host controller and memory location attempt to discover new capabilities.
 *
 * This can be called multiple times. Will append to the list each time. The returned collection should use the
 * Capability collection functions automatically generated by ITER_TYPE for access.
 * @param[in] hc The host controller asking for enumeration
 * @param[in] base The VA of the start memory location
 * @param[in] len The Maximum offset from base to read upto
 * @return The updated collection of type Capability
 */
OmniTekCollection * DiscoverCapabilities( POmniTekHostController hc, uint32_t *base, const uint64_t len, ot_phys_addr_t physical_base );

/**
 * @brief Inform the bus that no further enumeration will be occurring and to create the needed devices
 *
 * DiscoverCapabilities will perform no action once this is done until ClearCapabilities is called
 * @param[in] hc The host controller informing us of completion
 * @return See Types.h
 */
int FinaliseCapabilities( POmniTekHostController hc );

/**
 * @brief Ask the bus to cleanup any enumerated children for the given host controller and reset the finalised flag
 * @param[in] hc The host controller to reset.
 */
void ClearCapabilities( POmniTekHostController hc );

/**
 * @brief General routine to print to the system console about the passed capabilities collection. Debug use only.
 * @param[in] capCollection The capability collection to pretty print.
 */
void PrintCapabilities( OmniTekCollection * capCollection );

/**
 * @brief Inform the bus that the given host controller is trying to exit.
 * @param[in] hc The context of the host controller
 */
void DeRegisterHostController( POmniTekHostController hc );


PCapability GetCapabilityAt( OmniTekCollection * col, uint32_t idx );

#endif /* BUSPRIVATE_H_ */
