/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/module.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/eventfd.h>
#include <linux/version.h>

#include "CapabilityDriverBusInterface.h"
#include "CapabilityDevice.h"

#include "capability/RegisterAccess_IOCTL.h"
#include "capability/Common_IOCTL.h"
#include "CapabilityBaseIOCTL.h"
#include "OTCapabilityTypes.h"

#include "capability/Interrupt_IOCTL.h"
#include "linux/Event.h"
#include "linux/UserBuffer.h"

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_WARNING;
extern struct device_attribute dev_attr_debuglevel;


#define InterruptBits 32

enum
{
    EventTag_InterruptEvent = 1,
};


typedef struct
{
    OmniTekCapabilityDriver Driver;
} OT_Cap_RegisterAccessDriver;

typedef struct
{
    struct cdev CharDev;
    CapabilityDeviceInterface BusInterface;

    EventList ControllerEvents; // for interrupt events....
    spinlock_t ControllerLock;
    struct file * ControllerHandle;
    struct workqueue_struct *ControllerDPCQueue;
    Interrupt_Event_Struct *Interrupts;
    Allocateable InterruptsMem;

} OT_Cap_RegisterAccessDevice;

#define ToCapDev( fdoData ) ((fdoData)->BusInterface.Device)
#define ToCapInfo( fdoData ) ((fdoData)->BusInterface.Device->CapInfo)
#define ToRegCap( fdoData ) ((fdoData)->BusInterface.Device->CapInfo->Ext.Register)


static int OT_Cap_RegisterAccess_driver_probe( struct device * dev );
static int OT_Cap_RegisterAccess_driver_remove( struct device *dev );

static const DriverMatchId matchIdsTable[ ] = {
    { RegisterCap, 0, 0 },
    { OffsetCap, 0, 0 },
    { }
};

static OT_Cap_RegisterAccessDriver OT_Cap_RegisterAccess_driver = {
    .Driver = {
        .FriendlyName = MANUF_DEV("_Cap_RegisterAccess"),
        .IdTable = matchIdsTable,
        .Driver = {
            .name = MANUF_DEV("_Cap_RegisterAccess"),
            .probe = OT_Cap_RegisterAccess_driver_probe,
            .remove = OT_Cap_RegisterAccess_driver_remove,
        },
    },
};

typedef struct
{
    struct work_struct my_work; // i believe this is not needed for manual manipulation...
    OT_Cap_RegisterAccessDevice * fdo;
    uint32_t Bits;
    uint64_t Time;
} DPCData_t;

void OT_Cap_RegisterAccess_CleanUpTransferContext( CommonTransferContext * txCtx )
{
    if ( txCtx != NULL )
    {
        CleanUserPages( txCtx );
        kfree( txCtx );
    }
}

void OT_Cap_RegisterAccess_EventCancel( void * context )
{
    CommonTransferContext *txCtx = (CommonTransferContext *)context;

    KernelTraceNA( TRACE_LEVEL_VERBOSE, Cap_RegisterAccess, "Event Canceled\n" );

    OT_Cap_RegisterAccess_CleanUpTransferContext( txCtx );
}

void OT_Cap_RegisterAccess_EventComplete( void * context, void * completionInfo, bool fromUserContext )
{
    CommonTransferContext *txCtx = (CommonTransferContext *)context;

    if ( ! CopyToUserPages( txCtx, completionInfo, InterruptBits * sizeof(Interrupt_Event_Struct), 0, fromUserContext ) )
    {
        KernelTraceNA(  TRACE_LEVEL_ERROR, Cap_RegisterAccess, "Failed to copy all data\n" );
    }

    OT_Cap_RegisterAccess_CleanUpTransferContext( txCtx );
}

static void OT_Cap_RegisterAccess_DPC( struct work_struct *work )
{
    DPCData_t * dpcData = (DPCData_t *)work;
    OT_Cap_RegisterAccessDevice *fdoData = dpcData->fdo;

    SpinLockAcquire( fdoData->ControllerLock );
    if ( fdoData->ControllerHandle != NULL && dpcData->Bits > 0 )
    {
        uint32_t i;
        // update counts
        for( i = 0; i < InterruptBits; i++ )
        {
            if ( dpcData->Bits & ( 1 << i ) )
            {
                if ( fdoData->Interrupts[i].Count != 0xffffffff )
                {
                    fdoData->Interrupts[i].Count++;
                    fdoData->Interrupts[i].Time = dpcData->Time;
                }
            }
        }

        // this is done synchronously so we can happily pass the point in....
        if ( ! EventCompleteNextByTag( &(fdoData->ControllerEvents), EventTag_InterruptEvent, fdoData->Interrupts, false) )
        {
            KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_RegisterAccess, "Failed or no one wants the event\n" );
        }
        else
        { // someone wanted the counts, so clean them down
            for( i = 0; i < InterruptBits; i++ )
            {
                fdoData->Interrupts[i].Count = 0;
            }
        }
    }
    SpinLockRelease( fdoData->ControllerLock );

    kfree( work );
}

bool OT_Cap_RegisterAccess_ISR( POmniTekCapabilityDevice context, uint64_t isrTime )
{
    uint32_t readValue = 0;
    OT_Cap_RegisterAccessDevice *fdoData = NULL;
    RegisterBlock *block = NULL;
    RegCount_t IRQStatusRegister;
    fdoData = dev_get_drvdata( &(context->Device) );

    if ( unlikely( fdoData == NULL ) )
    {
        return false;
    }
    block = &ToRegCap(fdoData).Blocks[0];
    IRQStatusRegister = ToRegCap(fdoData).IRQStatusRegister;

    fdoData->BusInterface.ReadRegisterCap( context, block, IRQStatusRegister, &readValue );
    fdoData->BusInterface.WriteRegisterCap( context, block, IRQStatusRegister, readValue );

    if ( readValue > 0 )
    {
        DPCData_t * work = (DPCData_t *)kmalloc(sizeof(DPCData_t), GFP_ATOMIC);
        if ( work == NULL )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "Could not allocate memory for DPC!!!\n");
        }
        else
        {
            INIT_WORK( (struct work_struct *)work, OT_Cap_RegisterAccess_DPC );
            work->fdo = fdoData;
            work->Bits = readValue;
            work->Time = isrTime;
            queue_work( fdoData->ControllerDPCQueue, (struct work_struct *)work );
        }
        return true;
    }
    return false;
}

long OT_Cap_unlocked_ioctl_Interrupt( OT_Cap_RegisterAccessDevice *fdoData, struct file *filp, unsigned int cmd, unsigned long arg )
{
    long retval = -ENOTTY;

    POmniTekCapabilityDevice capDev = ToCapDev(fdoData);
    //CapRegister *regCap = &ToRegCap(fdoData);
    RegisterBlock *block = &ToRegCap(fdoData).Blocks[0];
    RegCount_t IRQStatusRegister = ToRegCap(fdoData).IRQStatusRegister;
    RegCount_t IRQEnableRegister = ToRegCap(fdoData).IRQEnableRegister;

    switch( cmd )
    {
        case CAP_INTERRUPT_IOCTL_AcquireController:
        {
            CapInterrupt_AcquireController_IOCTL inData;

            if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
            {
                if( copy_from_user( &inData, ( CapInterrupt_AcquireController_IOCTL * )arg, sizeof( inData ) ) != 0 )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_from_user failed\n" );
                    retval = -ENOMEM;
                    break;
                }
                switch( inData.Version )
                {
                    case 0: //!< CAP_INTERRUPT_IOCTL_VERSION_AcquireController
                    {
                        SpinLockAcquire( fdoData->ControllerLock );
                        if( fdoData->ControllerHandle == NULL )
                        {
                            inData.NumBits = InterruptBits;
                            if( copy_to_user( ( CapInterrupt_AcquireController_IOCTL * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n" );
                                retval = -ENOMEM;
                            }
                            else
                            {
                                // this could be done with a memset...
                                uint32_t i;
                                // clear down the counts
                                for( i = 0; i < InterruptBits; i++ )
                                    fdoData->Interrupts[ i ].Count = 0;

                                fdoData->ControllerHandle = filp;

                                retval = 0;

                                if ( IRQEnableRegister != 0xffffffff  )
                                    fdoData->BusInterface.WriteRegisterCap( capDev, block, IRQEnableRegister, 0 );
                                if ( IRQStatusRegister != 0xffffffff  )
                                    fdoData->BusInterface.WriteRegisterCap( capDev, block, IRQStatusRegister, 0xffffffff );

                                fdoData->BusInterface.RegisterISRCallback( capDev, OT_Cap_RegisterAccess_ISR );
                            }
                        }
                        else
                        {
                            retval = -EACCES;
                        }
                        SpinLockRelease( fdoData->ControllerLock );

                        break;
                    }
                    default:
                    {
                        KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                        inData.Version = CAP_INTERRUPT_IOCTL_VERSION_AcquireController;
                        if( copy_to_user( ( CapInterrupt_AcquireController_IOCTL * )arg, &inData, sizeof( inData ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n" );
                            retval = -ENOMEM;
                        }
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
            }

            break;
        }
        case CAP_INTERRUPT_IOCTL_ReleaseController:
        {
            CapInterrupt_ReleaseController_IOCTL inData;

            if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
            {
                if( copy_from_user( &inData, ( CapInterrupt_ReleaseController_IOCTL * )arg, sizeof( inData ) ) != 0 )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_from_user failed\n" );
                    retval = -ENOMEM;
                    break;
                }
                switch( inData.Version )
                {
                    case 0: //!< CAP_INTERRUPT_IOCTL_VERSION_ReleaseController
                    {
                        SpinLockAcquire( fdoData->ControllerLock );
                        if ( fdoData->ControllerHandle == filp )
                        {
                            fdoData->BusInterface.DeRegisterISRCallback( capDev );
                            EventListClean( &fdoData->ControllerEvents );
                            EventListInit( &fdoData->ControllerEvents );
                            fdoData->ControllerHandle = NULL;

                            if ( IRQEnableRegister != 0xffffffff  )
                                fdoData->BusInterface.WriteRegisterCap( capDev, block, IRQEnableRegister, 0 );
                            if ( IRQStatusRegister != 0xffffffff  )
                                fdoData->BusInterface.WriteRegisterCap( capDev, block, IRQStatusRegister, 0xffffffff );

                            retval = 0;
                        }
                        else
                        {
                            retval = -EACCES;
                        }
                        SpinLockRelease( fdoData->ControllerLock );

                        break;
                    }
                    default:
                    {
                        KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                        inData.Version = CAP_INTERRUPT_IOCTL_VERSION_ReleaseController;
                        if( copy_to_user( ( CapInterrupt_ReleaseController_IOCTL * )arg, &inData, sizeof( inData ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n" );
                            retval = -ENOMEM;
                        }
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
            }

            break;
        }
        case CAP_INTERRUPT_IOCTL_EnableMask:
        {
            CapInterrupt_Mask_IOCTL inData;

            if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
            {
                if( copy_from_user( &inData, ( CapInterrupt_Mask_IOCTL * )arg, sizeof( inData ) ) != 0 )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_from_user failed\n" );
                    retval = -ENOMEM;
                    break;
                }
                switch( inData.Version )
                {
                    case 0: //!< CAP_INTERRUPT_IOCTL_VERSION_EnableMask
                    {
                        if ( IRQEnableRegister != 0xffffffff  )
                        {
                            SpinLockAcquire( fdoData->ControllerLock );
                            if ( fdoData->ControllerHandle == filp )
                            {
                                uint32_t readValue = 0;
                                fdoData->BusInterface.ReadRegisterCap( capDev, block, IRQEnableRegister, &readValue );
                                 readValue |= inData.Mask;
                                fdoData->BusInterface.WriteRegisterCap( capDev, block, IRQEnableRegister, readValue );
                                retval = 0;
                            }
                            else
                            {
                                retval = -EACCES;
                            }
                            SpinLockRelease( fdoData->ControllerLock );
                        }

                        break;
                    }
                    default:
                    {
                        KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                        inData.Version = CAP_INTERRUPT_IOCTL_VERSION_EnableMask;
                        if( copy_to_user( ( CapInterrupt_Mask_IOCTL * )arg, &inData, sizeof( inData ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n" );
                            retval = -ENOMEM;
                        }
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
            }
            break;
        }
        case CAP_INTERRUPT_IOCTL_DisableMask:
        {
            CapInterrupt_Mask_IOCTL inData;

            if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
            {
                if( copy_from_user( &inData, ( CapInterrupt_Mask_IOCTL * )arg, sizeof( inData ) ) != 0 )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_from_user failed\n" );
                    retval = -ENOMEM;
                    break;
                }
                switch( inData.Version )
                {
                    case 0: //!< CAP_INTERRUPT_IOCTL_VERSION_DisableMask
                    {
                        if ( IRQEnableRegister != 0xffffffff  )
                        {
                            SpinLockAcquire( fdoData->ControllerLock );
                            if ( fdoData->ControllerHandle == filp )
                            {
                                uint32_t readValue = 0;
                                fdoData->BusInterface.ReadRegisterCap( capDev, block, IRQEnableRegister, &readValue );
                                readValue = readValue & ~inData.Mask;
                                fdoData->BusInterface.WriteRegisterCap( capDev, block, IRQEnableRegister, readValue );
                                retval = 0;
                            }
                            else
                            {
                                retval = -EACCES;
                            }
                            SpinLockRelease( fdoData->ControllerLock );
                        }

                        break;
                    }
                    default:
                    {
                        KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                        inData.Version = CAP_INTERRUPT_IOCTL_VERSION_DisableMask;
                        if( copy_to_user( ( CapInterrupt_Mask_IOCTL * )arg, &inData, sizeof( inData ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n" );
                            retval = -ENOMEM;
                        }
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
            }

            break;
        }
        case CAP_INTERRUPT_IOCTL_InterruptEvent:
        {
            CapInterrupt_InterruptEvent_IOCTL_Linux inData;

            if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
            {
                if( copy_from_user( &inData, ( CapInterrupt_InterruptEvent_IOCTL_Linux * )arg, sizeof( inData ) ) != 0 )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_from_user failed\n" );
                    retval = -ENOMEM;
                    break;
                }
                switch( inData.IOCTLInfo.Version )
                {
                    case 1: //!< CAP_INTERRUPT_IOCTL_VERSION_InterruptEvent
                    {
                        CommonTransferContext *txCtx = NULL;
                        if( inData.IOCTLInfo.NumBits != InterruptBits )
                        {
                            retval = -ENOMEM;
                            KernelTrace( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "user Num bits (%u) != InterruptBits (%u)\n", inData.IOCTLInfo.NumBits, InterruptBits );
                            break;
                        }

                        txCtx = (CommonTransferContext*)kzalloc( sizeof(CommonTransferContext), GFP_KERNEL );
                        if ( txCtx == NULL )
                        {
                            retval = -ENOMEM;
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "Failed to allocate mem\n" );
                            break;
                        }
                        else
                        {
                            retval = MapUserPages( (unsigned long)(  arg + offsetof( CapInterrupt_InterruptEvent_IOCTL_Linux, IOCTLInfo.Bits  )  ), InterruptBits * sizeof(Interrupt_Event_Struct), txCtx );
                            if ( retval != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "Failed to map user pages\n" );
                                OT_Cap_RegisterAccess_CleanUpTransferContext( txCtx );
                                break;
                            }
                        }

                        SpinLockAcquire( fdoData->ControllerLock );
                        if ( fdoData->ControllerHandle == filp )
                        {
                            if ( EventAdd( &(fdoData->ControllerEvents), &( inData.EventInfo ), EventTag_InterruptEvent, txCtx, OT_Cap_RegisterAccess_EventComplete, OT_Cap_RegisterAccess_EventCancel ) )
                            {
                                retval = 0;
                                if ( copy_to_user( ( CapInterrupt_InterruptEvent_IOCTL_Linux * )arg, &inData, sizeof( inData ) ) != 0 )
                                {
                                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n" );
                                    retval = -ENOMEM;
                                }
                                else
                                { // check for outstanding interrupts, if there are some complete
                                    unsigned int i;
                                    int pending = FALSE;
                                    for( i = 0; i < InterruptBits && !pending; i++ )
                                    {
                                        if ( fdoData->Interrupts[i].Count > 0 )
                                            pending = TRUE;
                                    }

                                    if ( pending )
                                    {
                                        KernelTraceNA( TRACE_LEVEL_INFORMATION, Cap_RegisterAccess, "Interrupts pending, attempt to complete...\n" );
                                        // this is done synchronously so we can happily pass the point in....
                                        if( !EventCompleteNextByTag( &( fdoData->ControllerEvents ), EventTag_InterruptEvent, fdoData->Interrupts, true ) )
                                        {
                                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "Failed to complete...\n" );
                                        }
                                        else
                                        { // someone wanted the counts, so clean them down
                                            for( i = 0; i < InterruptBits; i++ )
                                            {
                                                fdoData->Interrupts[i].Count = 0;
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "Failed to add transaction to queue\n" );
                                OT_Cap_RegisterAccess_CleanUpTransferContext( txCtx );
                                retval = -ENOMEM;
                            }
                        }
                        else
                        {
                            KernelTraceNA( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Someone else already has the lock\n" );
                            OT_Cap_RegisterAccess_CleanUpTransferContext( txCtx );
                            retval = -EACCES;
                        }
                        SpinLockRelease( fdoData->ControllerLock );

                        break;
                    }
                    default:
                    {
                        KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.IOCTLInfo.Version );
                        inData.IOCTLInfo.Version = CAP_INTERRUPT_IOCTL_VERSION_InterruptEvent;
                        if( copy_to_user( ( CapInterrupt_InterruptEvent_IOCTL_Linux * )arg, &inData, sizeof( inData ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n" );
                            retval = -ENOMEM;
                        }
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
            }

            break;
        }
        case CAP_COMMON_IOCTL_Cancel:
        {
            CapGeneral_Cancel_IOCTL inData;

            if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
            {
                if ( copy_from_user( &inData, ( CapGeneral_Cancel_IOCTL * )arg, sizeof(inData) ) != 0 )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_from_user failed\n" );
                    retval = -ENOMEM;
                    break;
                }
                switch ( inData.Version )
                {
                    case 0: //!< CAP_COMMON_IOCTL_Cancel_Version
                    {
                        if ( EventCancel( &(fdoData->ControllerEvents), inData.EventInfo.EventID ) )
                        {
                            retval = 0;
                        }
                        else
                        {
                            retval = -EACCES;
                        }
                        break;
                    }
                    default:
                    {
                        KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                        inData.Version = CAP_COMMON_IOCTL_Cancel_Version;
                        if ( copy_to_user( ( CapGeneral_Cancel_IOCTL * )arg, &inData, sizeof( CapGeneral_Cancel_IOCTL ) ) != 0 )
                        {
                            KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n" );
                            retval = -ENOMEM;
                        }
                    }
                }
            }
            else
            {
                KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
            }

            break;
        }
    }
    return retval;
}

/*
 * TODO: finish implementing this
typedef struct
{
    uint32_t size;
    unsigned long writeLoc;
    char mem[];
} OutputBuffer;
#define GetOutB( buf ) container_of( buf, OutputBuffer, mem );

inline int RetrieveOutputBuffer( unsigned long arg, void * buf, uint32_t size )
{
    OutputBuffer * outBuf = NULL;

    outBuf = kzalloc( size + sizeof( OutputBuffer ), GFP_ATOMIC );
    if ( outBuf == NULL )
        return ALLOC_FAIL;

    outBuf->size = size;
    outBuf->writeLoc = arg;
    buf = outBuf->mem;

    return SUCCESS;
}

inline int ReleaseOutputBuffer( void * buf )
{
    OutputBuffer *outBuf;
    int ret;

    outBuf = GetOutB( buf );
    ret = copy_to_user( (void *)outBuf->writeLoc, outBuf->mem, outBuf->size );
    kfree( outBuf );
    return ret;
}

//status = WdfRequestRetrieveOutputBuffer( Request, sizeof( uint32_t ), &numBlocks, NULL );
*/

long OT_Cap_unlocked_ioctl( struct file *filp, unsigned int cmd, unsigned long arg )
{
    int retval = -ENOTTY;
    OT_Cap_RegisterAccessDevice *fdoData = NULL;

    fdoData = container_of( filp->f_path.dentry->d_inode->i_cdev, OT_Cap_RegisterAccessDevice, CharDev );
    if( fdoData != NULL )
    {
        switch( cmd )
        {
            case CAP_RA_IOCTL_GetBlockCount:
            case CAP_RA_IOCTL_GetRegisterCount:
            case CAP_RA_IOCTL_RegisterRead:
            case CAP_RA_IOCTL_RegisterShadowRead:
            case CAP_RA_IOCTL_RegisterWrite:
            case CAP_RA_IOCTL_GetMetaData:
                retval =  ProcessCapabilityBaseIOCTL( &ToRegCap(fdoData), &fdoData->BusInterface, arg, cmd );
                break;

            case CAP_INTERRUPT_IOCTL_AcquireController:
            case CAP_INTERRUPT_IOCTL_ReleaseController:
            case CAP_INTERRUPT_IOCTL_EnableMask:
            case CAP_INTERRUPT_IOCTL_DisableMask:
            case CAP_INTERRUPT_IOCTL_InterruptEvent:
            case CAP_COMMON_IOCTL_Cancel:
                retval =  OT_Cap_unlocked_ioctl_Interrupt( fdoData, filp, cmd, arg );
                break;

            case CAP_COMMON_IOCTL_QueryInfo:
            {
                CapCommon_QueryInfo_IOCTL inData;
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(inData) ) )
                {
                    if ( copy_from_user( &inData, ( void * )arg, sizeof(inData) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        break;
                    }
                    switch ( inData.Version )
                    {
                        case 0: //!< CAP_COMMON_IOCTL_QueryInfo_Version
                        {
                            retval = 0;
                            switch ( inData.Key )
                            {
                                case QueryInfo_CapabilityId:
                                    inData.Value = ToCapDev(fdoData)->Id;
                                    break;
                                case QueryInfo_RegisterUniqueID:
                                case QueryInfo_RegisterAssociationID:
                                case QueryInfo_RegisterVersionId:
                                case QueryInfo_TimerGetTime:
                                case QueryInfo_TimerGetFrequency:
                                case QueryInfo_RegisterPhysAddr:
                                    retval = ProcessCommon_QueryInfo_Register( fdoData->BusInterface.Device->CapInfo, &fdoData->BusInterface, &inData );
                                    break;
                                case QueryInfo_InterruptNumInterrupts:
                                {
                                    if ( ToRegCap(fdoData).IRQStatusRegister != 0xffffffff  )
                                        inData.Value = InterruptBits;
                                    else
                                        retval = -EINVAL;
                                    break;
                                }
                                default:
                                    retval = -EINVAL;
                                    break;
                            }

                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }

                            break;
                        }
                        default:
                        {
                            KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unsupported version: %d\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd), inData.Version );
                            inData.Version = CAP_COMMON_IOCTL_QueryInfo_Version;
                            if ( copy_to_user( ( void * )arg, &inData, sizeof( inData ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "copy_to_user failed\n");
                                retval = -ENOMEM;
                            }
                        }
                    }
                }
                else
                {
                    retval = -EACCES;
                    KernelTrace( TRACE_LEVEL_ERROR, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Access failure\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                }

                break;
            }
            default:
                KernelTrace( TRACE_LEVEL_WARNING, Cap_RegisterAccess, "Raw: 0x%08X, Magic: 0x%02X, Num: 0x%02X. Unhandled in switch\n", cmd, _IOC_TYPE(cmd), _IOC_NR(cmd) );
                break;
        }
    }
    else
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "Device Not Found!!!\n" );
    }
    return retval;
}

int OT_Cap_RegisterAccess_FileClosed(struct inode * node, struct file * filp)
{
    OT_Cap_RegisterAccessDevice *fdoData = container_of( filp->f_path.dentry->d_inode->i_cdev, OT_Cap_RegisterAccessDevice, CharDev );

    SpinLockAcquire( fdoData->ControllerLock );
    if ( fdoData->ControllerHandle == filp )
    {
        fdoData->BusInterface.DeRegisterISRCallback( ToCapDev(fdoData) );
        EventListClean( &fdoData->ControllerEvents );
        EventListInit( &fdoData->ControllerEvents );
        fdoData->ControllerHandle = NULL;

        if ( ToRegCap(fdoData).IRQEnableRegister != 0xffffffff  )
            fdoData->BusInterface.WriteRegisterCap( ToCapDev( fdoData ), &ToRegCap(fdoData).Blocks[0], ToRegCap(fdoData).IRQEnableRegister, 0 );

    }
    SpinLockRelease( fdoData->ControllerLock );

    return 0;
}

const struct file_operations OT_Cap_RegisterAccess_device_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = OT_Cap_unlocked_ioctl,
    .release = OT_Cap_RegisterAccess_FileClosed,
};

static int OT_Cap_RegisterAccess_driver_probe( struct device * dev )
{
    POmniTekCapabilityDevice capDev = NULL;
    OT_Cap_RegisterAccessDevice *fdoData = NULL;
    int result = 0;

    capDev = ToOmniTekCapabilityDevice( dev );

    fdoData = kzalloc( sizeof(OT_Cap_RegisterAccessDevice), GFP_KERNEL );
    if( fdoData )
    {
        result = MANUF_FUNC(_GetInterfaceForCapDriver)( capDev, &fdoData->BusInterface );
        if (result != 0 )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "Could not Get interface: %d\n", result );
            goto probe_failure_OmniTek_GetInterfaceForCapDriver;
        }

        result = device_create_file( dev, &dev_attr_debuglevel );
        if( result )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "can't create sysfs debuglevel file!!!\n" );
            goto probe_failure_device_create_file;
        }

        // Initialise a char device
        cdev_init( &( fdoData->CharDev ), &OT_Cap_RegisterAccess_device_fops );
        fdoData->CharDev.owner = THIS_MODULE;

        // actually add the char device
        result = cdev_add( &fdoData->CharDev, fdoData->BusInterface.Device->CharDevNum, 1 );
        if( result )
        {
            KernelTrace( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "Could not create char device. code: %d\n", result);
            goto probe_failure_cdev_add;
        }

        if ( NULL == device_create( MANUF_FUNC(_GetClass)(), dev, fdoData->BusInterface.Device->CharDevNum, NULL, MANUF_DEV("_Cap_RegisterAccess_%02d_%03d"), SlotIdFromChildId( capDev->Id ) , BasicChildId( capDev->Id ) ) )
        {
            KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "Failed to create dev entry\n" );
            result = -ENOMEM;
            goto probe_failure_device_create;
        }
        snprintf( capDev->DeviceAccessName, MAX_FILEPATH_LEN, "/dev/"MANUF_DEV("_Cap_RegisterAccess_%02d_%03d"), SlotIdFromChildId( capDev->Id ) , BasicChildId( capDev->Id ) );

        if ( ToRegCap(fdoData).IRQStatusRegister != 0xffffffff  )
        {
            char wqName[10] = {0,};
            snprintf( wqName, 10, MANUF_DEV("%02d%03d"), SlotIdFromChildId( capDev->Id ) , BasicChildId( capDev->Id ) );
#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,35)
            fdoData->ControllerDPCQueue = create_singlethread_workqueue( wqName );
#else
			fdoData->ControllerDPCQueue = alloc_workqueue("%s", WQ_HIGHPRI | WQ_CPU_INTENSIVE, 1, wqName);
#endif
            if( fdoData->ControllerDPCQueue == NULL )
            {
                KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "create_singlethread_workqueue failure\n");
                result = -ENOMEM;
                goto probe_failure_create_singlethread_workqueue;
            }

            fdoData->Interrupts = AllocateMemory( InterruptBits * sizeof(Interrupt_Event_Struct), &fdoData->InterruptsMem );
            if ( fdoData->Interrupts == NULL )
            {
                KernelTraceNA( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "AllocateMemory failure for interrupt counts\n");
                result = -ENOMEM;
                goto probe_failure_InterruptCounts;
            }

            if ( ToRegCap(fdoData).IRQEnableRegister != 0xffffffff  )
                fdoData->BusInterface.WriteRegisterCap( ToCapDev( fdoData ), &ToRegCap(fdoData).Blocks[0], ToRegCap(fdoData).IRQEnableRegister, 0 );
            if ( ToRegCap(fdoData).IRQStatusRegister != 0xffffffff  )
                fdoData->BusInterface.WriteRegisterCap( ToCapDev( fdoData ), &ToRegCap(fdoData).Blocks[0], ToRegCap(fdoData).IRQStatusRegister, 0xffffffff );
        }

        EventListInit( &fdoData->ControllerEvents );
        SpinLockInit( &fdoData->ControllerLock );

        dev_set_drvdata( dev, fdoData );
    }
    else
    {
        result = -ENOMEM;
    }
    goto probe_success;

probe_failure_InterruptCounts:
if ( fdoData->ControllerDPCQueue != NULL )
    destroy_workqueue( fdoData->ControllerDPCQueue );

probe_failure_create_singlethread_workqueue:
    device_destroy( MANUF_FUNC(_GetClass)(), fdoData->BusInterface.Device->CharDevNum );

probe_failure_device_create:
cdev_del( &fdoData->CharDev );

probe_failure_cdev_add:
device_remove_file( dev, &dev_attr_debuglevel );
probe_failure_device_create_file:

probe_failure_OmniTek_GetInterfaceForCapDriver:
kfree( fdoData );

probe_success:
    return result;
}

static int OT_Cap_RegisterAccess_driver_remove( struct device *dev )
{
    OT_Cap_RegisterAccessDevice * fdoData = NULL;

    fdoData = dev_get_drvdata( dev );
    if( fdoData != NULL )
    {
        EventListClean( &fdoData->ControllerEvents );

        if ( fdoData->ControllerDPCQueue != NULL )
            destroy_workqueue( fdoData->ControllerDPCQueue );

        if ( fdoData->Interrupts != NULL )
            DeleteMemory( &fdoData->InterruptsMem );

        device_remove_file( dev, &dev_attr_debuglevel );
        device_destroy( MANUF_FUNC(_GetClass)(), fdoData->BusInterface.Device->CharDevNum );

        dev_set_drvdata( dev, NULL );
        cdev_del( &fdoData->CharDev );
        kfree( fdoData );
        return 0;
    }
    return -1;
}

int OT_Cap_RegisterAccess_init( void )
{
    int result = 0;

    // tell the bus that we exist and will control some devices
    result = MANUF_FUNC(_capability_driver_register)( &OT_Cap_RegisterAccess_driver.Driver );
    if ( result )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, Cap_RegisterAccess, "Error %d RegisterCapabilityDriver", result);
    }

    return result;
}

void OT_Cap_RegisterAccess_cleanup( void )
{
    // tell the bus that this driver is gone
    MANUF_FUNC(_capability_driver_unregister)( &OT_Cap_RegisterAccess_driver.Driver );
}

module_init( OT_Cap_RegisterAccess_init );
module_exit( OT_Cap_RegisterAccess_cleanup );
