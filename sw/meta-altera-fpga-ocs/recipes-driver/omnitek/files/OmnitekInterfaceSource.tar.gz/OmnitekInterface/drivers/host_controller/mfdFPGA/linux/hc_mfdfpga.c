/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/platform_device.h>
#include <linux/slab.h>
#include <asm/io.h>

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#include <linux/interrupt.h>

#include <linux/pci.h>

#include "host_controller/HostController_IOCTL.h"
#include "HostController.h"
#include "HostControllerInterface.h"
#include "HostControllerBusInterface.h"

#include "../../hccommon.h"
#include "hc_mfdfpga.h"

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif

#ifndef CONFIG_PCI
#error "NO PCI SUPPORT!!!!"
#endif

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_VERBOSE;

void OT_HC_MFD_FPGA_BusExit( POmniTekHostController context )
{
    DriverInstanceData *fdoData = container_of( context, DriverInstanceData, hc );
    if ( fdoData->BusInterface.DeRegisterHostController != NULL )
    {
        fdoData->BusInterface.DeRegisterHostController( context );
    }
    context->BusISR = NULL;
    context->SlotId = 0;
}

void OT_HC_MFD_FPGA_BusRegisterISR( POmniTekHostController context, HCISRCB busISR )
{
    unsigned long flags;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    KernelTraceNA( TRACE_LEVEL_INFORMATION, HC_MFD_FPGA, "Request to add isr\n");
    spin_lock_irqsave( &(did->IrqLock), flags );
    did->BusISR = busISR;
    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}

void OT_HC_MFD_FPGA_BusDeRegisterISR( POmniTekHostController context )
{
    unsigned long flags;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    KernelTraceNA( TRACE_LEVEL_INFORMATION, HC_MFD_FPGA, "Request to remove isr\n");
    spin_lock_irqsave( &(did->IrqLock), flags );
    did->BusISR = NULL;
    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}


#define ReadHWValue( va, r)  ioread32( va + (r) )
#define WriteHWValue( va, r, Val) iowrite32( (Val), va + (r))

static irqreturn_t OT_HC_MFD_FPGA_ISR( int irq, void * dev_id )
{
    DriverInstanceData *did = (DriverInstanceData *)dev_id;
    unsigned long flags;
    irqreturn_t irq_return = IRQ_NONE;

    uint32_t i;
    uint32_t j;
    uint32_t status = 0;
    bool ret = FALSE;

    spin_lock_irqsave( &(did->IrqLock), flags );

    if( did->registrationDone && did->BusISR != NULL && did->Interrupts != NULL )
    {
        for ( i = 0; i < did->NumInterrupts; i++)
        {
            for ( j = 0; j < did->Interrupts[i].Info->StatusRegisters.Count; j++ )
            {
                status = ReadHWValue( did->Interrupts[i].Info->StatusRegisters.VA, j );
                if ( status != 0 )
                {
                    ret |= did->BusISR( &did->hc, &did->hci, did->Interrupts[i].Info, j );
                }
            }
        }
    }

    if ( ret )
    {
        irq_return = IRQ_HANDLED;
    }

    spin_unlock_irqrestore( &( did->IrqLock ), flags );

    return irq_return;
}

long OT_HC_MFD_FPGA_unlocked_ioctl( struct file *flip, unsigned int cmd, unsigned long arg )
{
    long retval = -ENOTTY;
    DriverInstanceData *pDid = NULL;

    pDid = container_of( flip->f_path.dentry->d_inode->i_cdev, DriverInstanceData, CDev );
    if( pDid )
    {
        switch( cmd )
        {
            case HC_IOCTL_GetPlatformInfo:
                {
                    HC_GetPlatformInfo_IOCTL *ioctlReturn = (HC_GetPlatformInfo_IOCTL*)arg;
                    if( omnitek_access_ok(VERIFY_WRITE, ioctlReturn, sizeof(HC_GetPlatformInfo_IOCTL) ) )
                    {
                        uint32_t versionIn = HC_IOCTL_GetPlatformInfo_Version;
                        get_user( versionIn, &(ioctlReturn->Version));
                        switch( versionIn )
                        {
                            case 0:
                                {
                                    put_user(HC_IOCTL_GetPlatformInfo_Version, &(ioctlReturn->Version));
                                    put_user(HC_PlatformInfoPCIe, &(ioctlReturn->type));
                                    retval = 0;
                                }
                                break;
                            default:
                                {
                                    put_user( HC_IOCTL_GetPlatformInfo_Version, &( ioctlReturn->Version ) );
                                    retval = -ENOTTY;
                                    KernelTrace( TRACE_LEVEL_WARNING, HC_MFD_FPGA, "IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
                                }
                                break;
                        }
                    }
                }
                break;
            case HC_IOCTL_GetNumRegions:
                {
                    uint32_t versionIn;
                    HC_GetNumRegions_IOCTL *ioctlReturn = (HC_GetNumRegions_IOCTL*)arg;
                    if( omnitek_access_ok(VERIFY_WRITE, ioctlReturn, sizeof(HC_GetNumRegions_IOCTL)) )
                    {
                        get_user( versionIn, &(ioctlReturn->Version) );
                        switch( versionIn )
                        {
                            case 0:
                                {
                                    put_user( HC_IOCTL_GetNumRegions_Version, &(ioctlReturn->Version) );
                                    put_user( pDid->nCapRegions, &(ioctlReturn->NumRegions) );
                                    retval = 0;
                                }
                                break;
                            default:
                                {
                                    put_user( HC_IOCTL_GetNumRegions_Version, &( ioctlReturn->Version ) );
                                    retval = -ENOTTY;
                                    KernelTrace( TRACE_LEVEL_WARNING, HC_MFD_FPGA, "IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
                                }
                                break;
                        }
                    }
                }
                break;
            case HC_IOCTL_GetRegion:
                {
                    uint32_t versionIn;
                    HC_GetRegion_IOCTL *ioctlReturn = (HC_GetRegion_IOCTL*)arg;
                    if( omnitek_access_ok(VERIFY_WRITE, ioctlReturn, sizeof(HC_GetRegion_IOCTL)) )
                    {
                        get_user( versionIn, &(ioctlReturn->Version) );

                        // Set the version number for the return
                        put_user(HC_IOCTL_GetRegion_Version, &(ioctlReturn->Version));
                        switch(versionIn)
                        {
                            case 0:
                                {
                                    uint32_t regionIdx;
                                    get_user( regionIdx, &(ioctlReturn->Idx) );
                                    if( regionIdx < pDid->nCapRegions )
                                    {
                                        uint32_t bufferSize;
                                        uint32_t offset;
                                        get_user( bufferSize, &(ioctlReturn->Size));
                                        get_user( offset, &(ioctlReturn->Offset));

                                        KernelTrace( TRACE_LEVEL_VERBOSE, HC_MFD_FPGA,"HC_IOCTL_GetRegion. Buffer Offset %x, Size %x, required %x\n", offset, bufferSize, pDid->CapRegions[regionIdx].CapLength);

                                        // Check that the return buffer is big enough
                                        if( (bufferSize == 0) || (pDid->CapRegions[regionIdx].CapLength==0) || ((bufferSize + offset) > pDid->CapRegions[regionIdx].CapLength) )
                                        {
                                            put_user( pDid->CapRegions[regionIdx].CapLength, &(ioctlReturn->Size));
                                            retval = -ENOMEM;
                                            KernelTrace( TRACE_LEVEL_WARNING, HC_MFD_FPGA, "HC_IOCTL_GetRegion. Buffer too small %x, offset %x, required %x\n", bufferSize, offset, pDid->CapRegions[regionIdx].CapLength);
                                        }
                                        else // Copy the buffer
                                        {
                                            void* returnPtr;
                                            get_user(returnPtr, &(ioctlReturn->Buffer.pVa));

                                            if( omnitek_access_ok(VERIFY_WRITE, returnPtr, bufferSize) )
                                            {
                                                uint32_t bytesFailed = 0;
                                                if( (bytesFailed=copy_to_user(returnPtr, (((void*)pDid->CapRegions[regionIdx].CapMemory) + offset), bufferSize)) == 0 )
                                                {
                                                    put_user(bufferSize, &(ioctlReturn->Size));
                                                    retval = 0;
                                                }
                                                else
                                                {
                                                    put_user( 0, &(ioctlReturn->Size));
                                                    retval = -ENOMEM;
                                                    KernelTrace( TRACE_LEVEL_ERROR, HC_MFD_FPGA, "HC_IOCTL_GetRegion. failed to copy Region. 0x%x\n", bytesFailed);
                                                }
                                            }
                                            else
                                            {
                                                put_user( pDid->CapRegions[regionIdx].CapLength, &(ioctlReturn->Size));
                                                retval = -ENOMEM;
                                                KernelTraceNA( TRACE_LEVEL_ERROR, HC_MFD_FPGA, "HC_IOCTL_GetRegion. access_ok failed on return buffer\n");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        retval = -EINVAL;
                                        KernelTrace( TRACE_LEVEL_WARNING, HC_MFD_FPGA, "HC_IOCTL_GetRegion. Invalid Region Idx %d [Max %d]\n", regionIdx, pDid->nCapRegions);
                                    }
                                }
                                break;
                            default:
                                {
                                    retval = -ENOTTY;
                                    KernelTrace( TRACE_LEVEL_WARNING, HC_MFD_FPGA, "IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
                                }
                                break;
                        }
                    }
                }
                break;
            case HC_IOCTL_ReadPciConfig:
                KernelTraceNA( TRACE_LEVEL_WARNING, HC_MFD_FPGA,"HC_IOCTL_ReadPciConfig. Not support on MFD\n");
                break;
        }
    }
    return retval;
}

static struct file_operations OT_HC_MFD_FPGA_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = OT_HC_MFD_FPGA_unlocked_ioctl,
};



int OT_HC_MFD_FPGA_Enumerate( DriverInstanceData * did )
{
    OmniTekCollection * capList = NULL;
    Capability *cap = NULL;
    uint32_t i;
    uint32_t j;
    int status;
    uint32_t interruptNum = 0;

    did->NumInterrupts = 0;

    capList = did->BusInterface.DiscoverCapabilities( &did->hc, did->CapRegions[0].CapMemory, did->CapRegions[0].CapLength / 4, did->CapRegions[0].CapAddress );
    if( capList == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, HC_MFD_FPGA, "DiscoverCapabilities: NULL\n" );
    }
    else
    {
        did->BusInterface.PrintCapabilities( capList );
        for ( i = 0; i < CollectionCount( capList ); i++ )
        {
            cap = did->BusInterface.GetCapabilityAt( capList, i );
            if ( cap->Type == InterruptCap )
                did->NumInterrupts++;
        }

        if ( did->NumInterrupts > 0 )
        {
            did->Interrupts = AllocateMemory( sizeof(LinuxInterruptInfo) * did->NumInterrupts, &did->InterruptsMem );
            if ( did->Interrupts == NULL )
            {
                KernelTraceNA( TRACE_LEVEL_ERROR, HC_MFD_FPGA, "Could not allocate memory for interrupts...\n" );
                did->NumInterrupts = 0;
            }
        }

        interruptNum = 0;
        for ( i = 0; i < CollectionCount( capList ); i++ )
        {
            cap = did->BusInterface.GetCapabilityAt( capList, i );
            if ( cap->Type == OffsetCap )
            {
                for( j = 0; j < GetRegCap(cap).NumBlocks; j++ )
                {
                    KernelTrace( TRACE_LEVEL_VERBOSE, HC_MFD_FPGA,"Cap: 0x%04X, SubType: 0x%04X, Id: 0x%04X\n", cap->Type, GetRegCap(cap).Type, GetRegCap(cap).ComponentId  );
                    KernelTrace( TRACE_LEVEL_VERBOSE, HC_MFD_FPGA,"PhysAdd: 0x%08llX, Size: 0x%08X\n", did->CapRegions[0].CapAddress + GetRegCap(cap).Blocks[j].Offset, GetRegCap(cap).Blocks[j].Count * 4 );
                    GetRegCap(cap).Blocks[j].VA = ioremap( did->CapRegions[0].CapAddress + GetRegCap(cap).Blocks[j].Offset, GetRegCap(cap).Blocks[j].Count * 4 );
                }
            }
            if ( cap->Type == InterruptCap && did->Interrupts != NULL )
            {
                did->Interrupts[ interruptNum++ ].Info = &cap->Ext.Interrupt;
            }
        }
    }
    status = did->BusInterface.FinaliseCapabilities( &did->hc );
    if (status != SUCCESS )
    {
        KernelTrace( TRACE_LEVEL_INFORMATION, HC_MFD_FPGA, "FinaliseCapabilities: %d\n", status );

        if ( did->Interrupts != NULL )
        {
            did->NumInterrupts = 0;
            did->Interrupts = NULL;
            DeleteMemory( &did->InterruptsMem );
        }
    }

    return status;
}

void OT_HC_MFD_FPGA_EnableInterrupts( POmniTekHostController context )
{
    unsigned int hw_irq;
    int i;
    unsigned long flags;
    int status;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    spin_lock_irqsave( &(did->IrqLock), flags );

    if( did->Interrupts != NULL )
    {
        for ( i = 0; i < did->NumInterrupts; i++)
        {
            hw_irq = platform_get_irq(did->pdev, i);
            did->Interrupts[i].IRQ = hw_irq;
            if ( did->Interrupts[i].IRQ == 0 )
            {
                KernelTrace( TRACE_LEVEL_WARNING, HC_MFD_FPGA, "Failed to map HW IRQ %u to Linux Virtual IRQ\n", hw_irq);
            }
            else
            {
                status = request_threaded_irq( did->Interrupts[i].IRQ, OT_HC_MFD_FPGA_ISR, NULL, IRQF_SHARED, "OT_HC_MFD_FPGA", did );
                if( status )
                {
                    KernelTrace( TRACE_LEVEL_ERROR, HC_MFD_FPGA, "Couldn't request IRQ line - error %d!\n",status);
                }
                else
                {
                    KernelTrace( TRACE_LEVEL_INFORMATION, HC_MFD_FPGA, "Hooked upto IRQ line %u (%u)\n", hw_irq, did->Interrupts[i].IRQ );
                }
            }
        }
    }


    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}

void OT_HC_MFD_FPGA_DisableInterrupts( POmniTekHostController context )
{
    int i;
    unsigned long flags;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    spin_lock_irqsave( &(did->IrqLock), flags );

    if( did->Interrupts != NULL )
    {
        for ( i = 0; i < did->NumInterrupts; i++)
        {
            free_irq( did->Interrupts[i].IRQ, did );
        }
    }

    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}

extern struct device_attribute dev_attr_debuglevel;

static int OT_HC_MFD_FPGA_probe( struct platform_device *pdev )
{
    int status = 0;
    DriverInstanceData *did = NULL;
    uint32_t i;
    uint32_t CapRegionsIndex = 0;
    char nameBuf[MAX_FILEPATH_LEN];
    unsigned long flags;

    KernelTraceNA( TRACE_LEVEL_INFORMATION, HC_OmniTek, "OT_HC_MFD_FPGA_probe\n");

    did = kzalloc( sizeof( DriverInstanceData ), GFP_KERNEL );
    if( did == NULL )
    {
        status = -ENOMEM;
        goto probe_err;
    }

    did->pdev = pdev;

    status = device_create_file( &pdev->dev, &dev_attr_debuglevel );
    if( status )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_MFD_FPGA, "can't create sysfs debuglevel file!!!\n" );
        goto probe_err_kzalloc;
    }

    MANUF_FUNC( _GetInterfaceHCInterface )( &did->hc, &did->BusInterface );

    did->BusInterface.INIT_OmniTekHostControllerInterface( &did->hci );
    did->hci.NotifyBusExit = OT_HC_MFD_FPGA_BusExit;
    did->hci.EnableInterrupts = OT_HC_MFD_FPGA_EnableInterrupts;
    did->hci.DisableInterrupts = OT_HC_MFD_FPGA_DisableInterrupts;
    did->hci.RegisterISR = OT_HC_MFD_FPGA_BusRegisterISR;
    did->hci.DeRegisterISR = OT_HC_MFD_FPGA_BusDeRegisterISR;

    snprintf( did->hc.InstanceName, MAX_NAME_LEN, "%s:%d", dev_name( &pdev->dev ), pdev->id );
    snprintf( did->hc.TypeName, MAX_NAME_LEN, MANUF_DEV("_HC_MFD_FPGA") );
    did->hc.Uuid = UUID_USERINTERFACE_HC_MFD_FPGA;
    did->hc.Device = &pdev->dev;

    spin_lock_init(&(did->IrqLock));
    status = did->BusInterface.RegisterHostController( &did->hc, &did->hci );
    if ( status != SUCCESS )
    {
        goto probe_err_device_create_file;
    }

    // start char dev code
    snprintf( nameBuf, MAX_FILEPATH_LEN, MANUF_DEV("_HC_MFD_FPGA_%02d"), did->hc.SlotId );
    status = alloc_chrdev_region( &( did->Major ), 0, 1, nameBuf );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_MFD_FPGA, "Error %d alloc_chrdev_region\n", status );
        goto probe_err_RegisterHostController;
    }

    did->Minor = MKDEV( MAJOR( did->Major ), MINOR( did->Major ) );
    cdev_init( &( did->CDev ), &OT_HC_MFD_FPGA_fops );
    did->CDev.owner = THIS_MODULE;
    status = cdev_add( &( did->CDev ), did->Minor, 1 );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_MFD_FPGA, "Error %d cdev_add\n", status );
        goto probe_err_alloc_chrdev_region;
    }

    if ( NULL == device_create( MANUF_FUNC(_GetClass)(), &pdev->dev, did->Minor, NULL, nameBuf ) )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_MFD_FPGA, "Failed to create host controller dev entry\n" );
        status = -1;
        goto probe_err_cdev_add;
    }
    else
    {
        snprintf( did->hc.DeviceAccessName, MAX_FILEPATH_LEN, "/dev/%s", nameBuf );
    }
    // end char dev code

    dev_set_drvdata( &pdev->dev, did );
    
    for( i = 0; i < MAX_CAPABILITY_REGIONS; i++ )
    {
        struct resource *mem_resource;
        mem_resource = platform_get_resource(pdev, IORESOURCE_MEM, i);
        if (mem_resource != NULL)
        {
            resource_size_t mem_phy;
            resource_size_t mem_size;
            uint32_t *mem_base;

            mem_phy = mem_resource->start;
            mem_size = (uint32_t)resource_size(mem_resource);
            mem_base = devm_ioremap_resource(&pdev->dev, mem_resource);
            if( IS_ERR(mem_base))
            {
                KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_MFD_FPGA, "Request memory resource failed");
            }
            KernelTrace( TRACE_LEVEL_INFORMATION, HC_MFD_FPGA, "Memory resource at Phys:0x%llx Virt:%p\n", mem_phy, mem_base);

            if( !mem_base )
            {
                KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_MFD_FPGA, "Request memory resource failed, got zero address\n" );
            }
            else
            {
                did->CapRegions[ CapRegionsIndex ].CapAddress = (ot_phys_addr_t)mem_phy;
                did->CapRegions[ CapRegionsIndex ].CapLength = (uint32_t)mem_size;
                did->CapRegions[ CapRegionsIndex ].CapMemory = mem_base;
                
                CapRegionsIndex++ ;
            }
        }
    }
    KernelTrace( TRACE_LEVEL_INFORMATION, HC_MFD_FPGA, "%d Mem resources allocated\n", CapRegionsIndex );
    did->nCapRegions = CapRegionsIndex;

    status = OT_HC_MFD_FPGA_Enumerate( did );
    if ( status != SUCCESS )
        goto probe_err_ioremap;

    KernelTraceNA( TRACE_LEVEL_INFORMATION, HC_OmniTek, "OT_HC_MFD_FPGA_register successful\n");
    spin_lock_irqsave( &(did->IrqLock), flags );
    did->registrationDone = TRUE;
    spin_unlock_irqrestore( &( did->IrqLock ), flags );

    request_module_nowait(MANUF_DEV("_Cap_RegisterAccess"));

    KernelTraceNA( TRACE_LEVEL_INFORMATION, HC_OmniTek, "OT_HC_MFD_FPGA_probe successful\n");
    return 0;

probe_err_ioremap:
    device_destroy( MANUF_FUNC(_GetClass)(), did->Minor );
probe_err_cdev_add:
    cdev_del( &( did->CDev ) );
probe_err_alloc_chrdev_region:
    unregister_chrdev_region( did->Major, 1 );
probe_err_RegisterHostController:
    did->BusInterface.DeRegisterHostController( &did->hc );
probe_err_device_create_file:
    device_remove_file( &pdev->dev, &dev_attr_debuglevel );
probe_err_kzalloc:
    kfree( did );
probe_err:
    platform_set_drvdata( pdev, NULL );

    return status;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,11,0)
static void OT_HC_MFD_FPGA_remove( struct platform_device * pdev )
#else
static int OT_HC_MFD_FPGA_remove( struct platform_device * pdev )
#endif
{
    DriverInstanceData *did = NULL;

    did = platform_get_drvdata( pdev );
    if ( did != NULL )
    {
        did->BusInterface.DeRegisterHostController( &did->hc );

        if ( did->Interrupts != NULL )
        {
            did->NumInterrupts = 0;
            did->Interrupts = NULL;
            DeleteMemory( &did->InterruptsMem );
        }
        device_destroy( MANUF_FUNC(_GetClass)(), did->Minor );
        cdev_del( &( did->CDev ) );
        unregister_chrdev_region( did->Major, 1 );
        device_remove_file( &pdev->dev, &dev_attr_debuglevel );
        kfree( did );
        platform_set_drvdata( pdev, NULL );
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(6,11,0)
    return 0;
#endif    
}

static const struct platform_device_id OT_HC_MFD_FPGA_id_table[ ] = {
    {  MANUF_DEV("-hc-mfd-fpga"), 0 },
    { },
};
MODULE_DEVICE_TABLE( platform, OT_HC_MFD_FPGA_id_table );

static struct platform_driver OT_HC_MFD_FPGA_driver = {
    /* Match this driver using this name also present in the MFD driver */
    .driver        = {
        .name    = MANUF_DEV("_HC_MFD_FPGA"),
    },
    .probe        = OT_HC_MFD_FPGA_probe,
    .remove        = OT_HC_MFD_FPGA_remove,
};

module_platform_driver(OT_HC_MFD_FPGA_driver);
