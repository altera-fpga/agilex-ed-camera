/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

/** \addtogroup UserlandInterface
 *  @{
 */

#include "global_defs.h"

#if BUILDTYPE == BT_WINDOWS

#ifndef _CUSTOMISE_H_
#define _CUSTOMISE_H_

#include <guiddef.h>

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

// {114043B2-C53B-45c6-A89E-94BCEE05F9CC}
/**
 * @brief The OmniTekBus ioctl interface....
 * This GUID should be modified for an individual manufacturer.
 */
DEFINE_GUID( GUID_DEVINTERFACE_OMNITEKBUS, 0x114043b2, 0xc53b, 0x45c6, 0xa8, 0x9e, 0x94, 0xbc, 0xee, 0x5, 0xf9, 0xcc );

// {55975EED-C2B3-42d4-BA7E-4165CE9EA83A}
/**
 * @brief The OmniTekBus remote interface for HostControllers
 * This GUID should be modified for an individual manufacturer.
 */
DEFINE_GUID( GUID_HCINTERFACE_OMNITEKBUS, 0x55975eed, 0xc2b3, 0x42d4, 0xba, 0x7e, 0x41, 0x65, 0xce, 0x9e, 0xa8, 0x3a );

// {C69BE431-2C58-4eba-B94C-A38C39A9328A}
/**
 * @brief The OmniTekBus interface for CapabilityDevice's / Drivers
 * This GUID should be modified for an individual manufacturer.
 */
DEFINE_GUID( GUID_CAPDEVINTERFACE_OMNITEKBUS, 0xc69be431, 0x2c58, 0x4eba, 0xb9, 0x4c, 0xa3, 0x8c, 0x39, 0xa9, 0x32, 0x8a );

#ifndef __GUIDS_H_
/** \cond */
#define __GUIDS_H_
/** \endcond */

// {A4F6BCA5-4440-4D9D-87AD-FB1D92CB2F60}
/**
 * @brief This is the GUID used to expose the Capabilities on the bus.
 * This should be modified for an individual manufacturer. It should match the MFG_GUID in the driver INF files.
 * Note: The GUID_CAPDEVCLASS_OMNITEKBUS and MFG_NAME should match
 */
DEFINE_GUID(GUID_CAPDEVCLASS_OMNITEKBUS, 0xa4f6bca5, 0x4440, 0x4d9d, 0x87, 0xad, 0xfb, 0x1d, 0x92, 0xcb, 0x2f, 0x60);

/** \cond */
#define MFG_GUID "{A4F6BCA5-4440-4D9D-87AD-FB1D92CB2F60}"
/** \endcond */

/** \cond */
#define MERGE_INNER(pre_fix,post_fix) pre_fix##post_fix
#define MERGE_OUTER(pre_fix, post_fix) MERGE_INNER(pre_fix,post_fix)
#define MERGE_MFG(post_fix) MERGE_OUTER(MFG_GUID,post_fix)
/** \endcond */

/** \cond */
#define OT_CAPDEV_BASE MERGE_MFG("\\OmniTek")
#define OT_CAPDEV_FALLBACK MERGE_MFG("\\OmniTekBusFallback")
/** \endcond */

#endif /* __GUIDS_H_ */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /*_CUSTOMISE_H_*/

#endif /* BUILDTYPE == BT_WINDOWS */

#if BUILDTYPE == BT_LINUX

/*
 * Linux customisation guide:
 * Before you start make sure you have done a full clean.
 * You are required to change:
 * - MANUFACTURER
 *   - This is used for function exports and also the bus device name
 * - MANUFACTURER_PREFIX
 *   - This is used for sub devices names (items that appear in /dev)
 * - MOD_NAME
 *   - This is in all module Makefiles. As the Linux build system does not use the name we supply within the driver you will need to manually modify these for every driver.
 * Optional:
 * - MANUF_BUS_FILE
 *   - This is the filename that use used in /dev to represent the bus.
 *
 *  Note: Changing MANUFACTURER or MANUF_BUS_FILE will break the OmniTekInterface and you will need to recompile it.
 *  The supplied rules file (90-omnitekbus.rules) will need to be changed to reflect any changes above to run your applications as a non-root user.
 */

/**
 * @brief Manufactures name
 * This is used symbol exports, function names, part of the bus devices name and various other bits.
 * This must not contain spaces. Suggest that is is alphanumeric only (underscores may work...)
 */
#define MANUFACTURER OmniTek

/**
 * @brief Manufactures prefix
 * This is used for driver character device names.
 * This must not contain spaces. Suggest that is is alphanumeric only (underscores may work...)
 */
#define MANUFACTURER_PREFIX OT

/** \cond */
#define MERGE_INNER(pre_fix,post_fix) pre_fix##post_fix
#define MERGE_OUTER(pre_fix, post_fix) MERGE_INNER(pre_fix,post_fix)
#define MERGE_MANUFACTURER(post_fix) MERGE_OUTER(MANUFACTURER, post_fix)

#define MERGE_STRING_INNER(pre_fix, post_fix) #pre_fix post_fix
#define MERGE_STRING_OUTER(pre_fix,post_fix) MERGE_STRING_INNER( pre_fix, post_fix )

#define STRING_INNER(v) #v
#define STRING_OUTER(v) STRING_INNER( v )

#define MANUF_STR STRING_OUTER(MANUFACTURER)
#define MANUF_CONCAT(post_fix) MERGE_STRING_OUTER(MANUFACTURER, post_fix)
/** \endcond */

/**
 * @brief Autoprefixed EXPORT_SYMBOL declaration
 * @param[in] func_postfix Non-manufacturer specific function name
 * @return Symbol export for inclusion into the Linux kernel global namespace
 */
#define MANUF_EXPORT( func_postfix ) EXPORT_SYMBOL( MERGE_MANUFACTURER( func_postfix ) )

/**
 * @brief Autoprefixed EXPORT_SYMBOL_GPL declaration
 * @param[in] func_postfix Non-manufacturer specific function name
 * @return GPL Symbol export for inclusion into the Linux kernel global namespace
 */
#define MANUF_EXPORT_GPL( func_postfix ) EXPORT_SYMBOL_GPL( MERGE_MANUFACTURER( func_postfix ) )

/**
 * @brief Autoprefixed function name declaration
 * Use this when creating exported functions, so that the kernel shouldn't have clashes for symbol names
 * @param[in] func_postfix Non-manufacturer specific function name
 * @return Manufacture specific function name suitable for export into kernel namespace
 */
#define MANUF_FUNC( func_postfix ) MERGE_MANUFACTURER( func_postfix )

/**
 * @brief Autoprefixed /dev entry name for individual driver char devices
 * @param[in] post_fix Driver specific post fix string
 * @return string suitable for use as a char device for /dev
 */
#define MANUF_DEV(post_fix) MERGE_STRING_OUTER(MANUFACTURER_PREFIX, post_fix)

/**
 * Autoprefixed /dev entry name for the bus interface itself
 */
#define MANUF_BUS_FILE MANUF_CONCAT("Bus")

#endif

#ifndef MAX_SLOTS
/**
 * @brief The maximum number of concurrently accessible host controllers / fpgas.
 */
#define MAX_SLOTS 32
#endif

#ifndef MAX_CAPS
/**
 * @brief The maximum number of device device attached capabilities per slot
 */
#define MAX_CAPS 512
#endif

/** \cond */
#if MAX_SLOTS > ( 1 << 8 )
#error "We can only support up to 256 slots per system"
#endif

#if MAX_CAPS > ( 1 << 24 )
#error "We can only support up to 16777216 capabilities per slot"
#endif
/** \endcond */


/** @}*/
