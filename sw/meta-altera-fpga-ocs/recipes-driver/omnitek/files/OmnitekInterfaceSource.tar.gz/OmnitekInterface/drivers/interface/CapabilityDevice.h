/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef CAPABILITYDEVICE_H_
#define CAPABILITYDEVICE_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"
#include "CapabilityTypes.h"
#include "Types.h"

#if BUILDTYPE == BT_LINUX
#include <linux/device.h>
#endif
/**
 * @brief Get the child portion of the ::OmniTekCapabilityDevice::Id
 * @param[in] id The ::OmniTekCapabilityDevice::Id
 */
#define BasicChildId( id )     ( id & 0x00ffffff )

/**
 * @brief Get the slot number portion of the ::OmniTekCapabilityDevice::Id
 * @param[in] id ::OmniTekCapabilityDevice::Id
 */
#define SlotIdFromChildId( id ) ( ( id >> 24 ) & 0xff )

#if BUILDTYPE == BT_LINUX

#define CDEV_MINOR( id ) ( ( SlotIdFromChildId( id ) * MAX_CAPS ) + BasicChildId( id ) )

#define MAX_CHARDEVPOOL ( MAX_SLOTS * MAX_CAPS )

#if MAX_CHARDEVPOOL > ( 1 << 20 )
#error "Unable to allocate enough char devices!"
#endif


#endif

#if BUILDTYPE == BT_WINDOWS
/**
 * @brief Callback for forcing capability drivers to stop accessing the hc
 * @param[in] DetachContext an opaque pointer for the end driver
 */
typedef void (*ForceDetachCB)(void * DetachContext);
#endif

/**
 * @brief The main context structure of a device instance. This is the pdo in Windows
 */
typedef struct _OmniTekCapabilityDevice
{
    char FriendlyName[ MAX_NAME_LEN ]; //!< Instance descriptor...
    char DeviceAccessName[ MAX_FILEPATH_LEN ]; //!< what to use to open this file!
    PCapability CapInfo; //!< Pointer to the capability we care for...
    void *BusData; //!< To speed up access to bus related activities. Bus core only uses this
    uint32_t Id; //!< a unique id for this device...
#if BUILDTYPE == BT_LINUX
    dev_t CharDevNum; //!< LINUX ONLY: Bus allocated char device id
    struct device Device; //!< LINUX ONLY: private data is in here. have access to the driver here too this private data is touched only be the owning driver....
#endif
#if BUILDTYPE == BT_WINDOWS
    void * DriverData; //!< WINDOWS ONLY: device driver specific private data...
    ForceDetachCB Detach; //!< WINDOWS ONLY: Callback to detach driver contact
    void * DetachContext; //!< WINDOWS ONLY: Callback context for detaching driver contact
#endif
} OmniTekCapabilityDevice;
typedef OmniTekCapabilityDevice *POmniTekCapabilityDevice; //!< Pointer to a OmniTekCapabilityDevice

// include platform dependent headers
#if BUILDTYPE == BT_WINDOWS
#include "windows/CapabilityDevice.h"
#endif

#if BUILDTYPE == BT_LINUX
#include "linux/CapabilityDevice.h"
#endif

/** @}*/

#endif /* CAPABILITYDEVICE_H_ */
