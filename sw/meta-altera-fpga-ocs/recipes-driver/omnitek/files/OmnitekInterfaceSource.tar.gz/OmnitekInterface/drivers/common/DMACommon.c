/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "global_defs.h"
#include "DMACommon.h"
#include "CapabilityDriverBusInterface.h"


