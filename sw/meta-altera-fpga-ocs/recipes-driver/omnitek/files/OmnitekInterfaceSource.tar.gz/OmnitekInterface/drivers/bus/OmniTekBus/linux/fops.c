/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "fops.h"
#include "Common.h"
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include "OTCapabilityTypes.h"

#include "bus/OmniTekBus_IOCTL.h"

struct _omnitek_fops_data
{
    dev_t Major;
    dev_t Minor;
    struct cdev CDev;
    PBusDevice BusData;
};

static struct _omnitek_fops_data omnitek_fops_data;

struct file_operations omnitekbus_fops = {
    .unlocked_ioctl = omnitekbus_fops_unlocked_ioctl,
};

int omnitekbus_fops_init( void * module, PBusDevice busData, struct device * dev )
{
    int ret = 0;
    ret = alloc_chrdev_region( &( omnitek_fops_data.Major ), 0, 1, MANUF_BUS_FILE"Int" );
    if( ret )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Error %d alloc_chrdev_region\n", ret);
        return ret;
    }
    omnitek_fops_data.Minor = MKDEV( MAJOR( omnitek_fops_data.Major ), MINOR( omnitek_fops_data.Major ) );

    omnitekbus_fops.owner = module;
    cdev_init( &( omnitek_fops_data.CDev ), &omnitekbus_fops );
    omnitek_fops_data.CDev.owner = module;

    ret = cdev_add( &( omnitek_fops_data.CDev ), omnitek_fops_data.Minor, 1 );
    if( ret )
    {
        KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "Error %d cdev_add\n", ret );
        return ret;
    }

    if ( NULL == device_create( MANUF_FUNC(_GetClass)(), dev, omnitek_fops_data.Minor, NULL, MANUF_BUS_FILE ) )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Failed to create bus dev entry\n" );
        return -1;
    }

    omnitek_fops_data.BusData = busData;

    return ret;
}

void omnitekbus_fops_deinit( void )
{
    device_destroy( MANUF_FUNC(_GetClass)(), omnitek_fops_data.Minor );

    cdev_del( &( omnitek_fops_data.CDev ) );
    unregister_chrdev_region( omnitek_fops_data.Major, 1 );
}

long omnitekbus_fops_unlocked_ioctl( struct file *filp, unsigned int cmd, unsigned long arg )
{
    long retval = -ENOTTY;
    struct _omnitek_fops_data *fopsData = container_of( filp->f_path.dentry->d_inode->i_cdev, struct _omnitek_fops_data, CDev );

    if ( fopsData )
    {
        switch( cmd )
        {
            case OTBUS_IOCTL_GetNumSlots:
            {
                OTBus_Slots *slotsData = kzalloc( sizeof(OTBus_Slots) + ( CollectionCount( & fopsData->BusData->VirtualBusList ) * sizeof( uint32_t ) ), GFP_ATOMIC  );

                if ( slotsData == NULL )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Failed to allocate memory to process ioctl\n" );
                    return -ENOMEM;
                }
                // check access with min required size
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(OTBus_Slots) ) )
                {
                    if ( copy_from_user( slotsData, ( OTBus_Slots * )arg, sizeof(OTBus_Slots) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        goto exit_gns;
                    }
                    switch ( slotsData->Version )
                    {
                        case 0: //!< OTBUS_IOCTL_GetNumSlots_Version
                        {
                            uint32_t neededSize;
                            const uint32_t actualNumSlots = CollectionCount( & fopsData->BusData->VirtualBusList );
                            KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Request NumSlots: %d, expected: %d\n", slotsData->NumSlots, actualNumSlots );

                            neededSize = sizeof( OTBus_Slots ) + ( actualNumSlots * sizeof( uint32_t ) );
                            // now we know the version we can check the size again as we know the format...
                            if( omnitek_access_ok( VERIFY_WRITE, arg, neededSize ) && slotsData->NumSlots >= CollectionCount( & fopsData->BusData->VirtualBusList ) )
                            {
                                VirtualBusEntry *vbe = NULL;
                                uint32_t i;

                                if ( copy_from_user( slotsData, ( OTBus_Slots * )arg, neededSize ) != 0 )
                                {
                                    KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_from_user failed\n");
                                    retval = -ENOMEM;
                                    goto exit_gns;
                                }

                                for ( i = 0; i < actualNumSlots; i++ )
                                {
                                    vbe = CollectionGetVirtualBusEntry( & fopsData->BusData->VirtualBusList, i );
                                    slotsData->SlotIds[i] = FromVirtualBusEntry( vbe )->Controller->SlotId;
                                }
                                retval = 0;
                                slotsData->NumSlots = actualNumSlots;
                                if ( copy_to_user( ( OTBus_Slots * )arg, slotsData, neededSize ) != 0 )
                                {
                                    KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_to_user failed\n");
                                    retval = -ENOMEM;
                                    goto exit_gns;
                                }
                            }
                            else
                            {
                                if ( copy_from_user( slotsData, ( OTBus_Slots * )arg, sizeof( OTBus_Slots ) ) != 0 )
                                {
                                    KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_from_user failed\n");
                                    retval = -ENOMEM;
                                    goto exit_gns;
                                }
                                /* Zero size is valid as this is a request to determine size */
                                if( slotsData->NumSlots != 0 )
                                {
                                    KernelTrace( TRACE_LEVEL_WARNING, OmniTekBus, "CMD:%d. In buffer too small. Requested %d, Required %d\n", cmd, slotsData->NumSlots, actualNumSlots );
                                }
                                /* Tell the caller how many actual slots are required */
                                slotsData->Version = OTBUS_IOCTL_GetNumSlots_Version;
                                slotsData->NumSlots = actualNumSlots;

                                if ( copy_to_user( ( OTBus_Slots * )arg, slotsData, sizeof( OTBus_Slots ) ) != 0 )
                                {
                                    KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_to_user failed\n");
                                    retval = -ENOMEM;
                                    goto exit_gns;
                                }
                                retval = -EINVAL;
                            }

                            break;
                        }
                        default:
                        {

                            KernelTrace( TRACE_LEVEL_WARNING, OmniTekBus, "CMD:%d. Unsupported version: %d\n", cmd, slotsData->Version );
                            slotsData->Version = OTBUS_IOCTL_GetNumSlots_Version;
                            if ( copy_to_user( ( OTBus_Slots * )arg, slotsData, sizeof( OTBus_Slots ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_to_user failed\n");
                                retval = -ENOMEM;
                                goto exit_gns;
                            }
                            retval = -ENOTTY;
                            break;
                        }
                    }
exit_gns:;
                }
                else
                {
                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "CMD:%d. Access failure\n", cmd );
                }

                kfree( slotsData );

                break;
            }
            case OTBUS_IOCTL_GetSlot:
            {
                OTBus_SlotInfo *slotsData = kzalloc( sizeof(OTBus_SlotInfo) , GFP_ATOMIC  );

                if ( slotsData == NULL )
                {
                    KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Failed to allocate memory to process ioctl\n" );
                    return -ENOMEM;
                }
                // check access with min required size
                if( omnitek_access_ok( VERIFY_WRITE, arg, sizeof(OTBus_SlotInfo) ) )
                {
                    VirtualBus *vb = NULL;

                    if ( copy_from_user( slotsData, ( OTBus_SlotInfo * )arg, sizeof(OTBus_SlotInfo) ) != 0 )
                    {
                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_from_user failed\n");
                        retval = -ENOMEM;
                        goto exit_gs;
                    }

                    switch ( slotsData->Version )
                    {
                        case 0: //!< OTBUS_IOCTL_GetSlot_Version
                        {
                            KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Request SlotId: %d\n", slotsData->SlotId );
                            vb = FindVirtualBusFromId( fopsData->BusData, slotsData->SlotId );
                            if ( vb != NULL )
                            {
                                uint32_t requestedCapDevs = slotsData->NumCapDevs;
                                uint32_t neededSize = sizeof(OTBus_SlotInfo) + ( sizeof( OTBus_CapDevInfo ) * vb->NumChildren );
                                kfree( slotsData );
                                slotsData = kzalloc( neededSize , GFP_ATOMIC  );
                                if ( slotsData == NULL )
                                {
                                    KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "Failed to allocate memory to process ioctl\n" );
                                    return -ENOMEM;
                                }

                                KernelTrace( TRACE_LEVEL_VERBOSE, OmniTekBus, "Request cap devs: %d, actual: %d\n", requestedCapDevs , vb->NumChildren );
                                // now we know the version we can check the size again as we know the format...
                                if( omnitek_access_ok( VERIFY_WRITE, arg, neededSize ) && requestedCapDevs >= vb->NumChildren )
                                {
                                    uint32_t i;
                                    slotsData->NumCapDevs = vb->NumChildren;

                                    memcpy( slotsData->HostControllerInfo.TypeName, vb->Controller->TypeName, MAX_NAME_LEN );
                                    memcpy( slotsData->HostControllerInfo.Path, vb->Controller->DeviceAccessName, MAX_FILEPATH_LEN );
                                    // NOTE: I#m not a big fan of copying structs like this but it should be ok....
                                    memcpy( &slotsData->HostControllerInfo.Uuid, &vb->Controller->Uuid, sizeof ( UUID ) );

                                    retval = 0;
                                    for ( i = 0; i < vb->NumChildren; i++ )
                                    {
                                        memcpy( slotsData->CapDevs[i].Path, vb->Children[i].DeviceAccessName, MAX_FILEPATH_LEN );
                                        slotsData->CapDevs[i].Type = vb->Children[i].CapInfo->Type;
                                        slotsData->CapDevs[i].Version = vb->Children[i].CapInfo->Version;
                                        if ( vb->Children[i].CapInfo->Type == MemMapCap )
                                        {
                                            slotsData->CapDevs[i].SubType = vb->Children[i].CapInfo->Ext.MemMap.Type;
                                        }
                                        else if ( IsAnyRegCap( vb->Children[i].CapInfo ) )
                                        {
                                            slotsData->CapDevs[i].SubType = GetRegCap( vb->Children[i].CapInfo).Type;
                                        }
                                        else
                                        {
                                            slotsData->CapDevs[i].SubType = 0;
                                        }
                                    }

                                    if ( copy_to_user( ( OTBus_SlotInfo * )arg, slotsData, neededSize ) != 0 )
                                    {
                                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_to_user failed\n");
                                        retval = -ENOMEM;
                                        goto exit_gs;
                                    }
                                }
                                else
                                {
                                    if( copy_from_user(slotsData, ( OTBus_SlotInfo * )arg, sizeof(OTBus_SlotInfo)) != 0 )
                                    {
                                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_to_user failed\n");
                                        retval = -ENOMEM;
                                        goto exit_gs;
                                    }
                                    /* NumCapDevs is valid as this is how the usermode determines how many slots are required */
                                    if( slotsData->NumCapDevs != 0 )
                                    {
                                        KernelTrace( TRACE_LEVEL_WARNING, OmniTekBus, "CMD:%d. In buffer too small. Requested %d, Required %d\n", cmd, slotsData->NumCapDevs, vb->NumChildren );
                                    }
                                    slotsData->Version = OTBUS_IOCTL_GetSlot_Version;
                                    slotsData->NumCapDevs = vb->NumChildren;

                                    if ( copy_to_user( ( OTBus_SlotInfo * )arg, slotsData, sizeof( OTBus_SlotInfo ) ) != 0 )
                                    {
                                        KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_to_user failed\n");
                                        retval = -ENOMEM;
                                        goto exit_gs;
                                    }
                                    retval = -EINVAL;
                                }
                            }
                            else
                            {
                                retval = -EINVAL;
                                KernelTrace( TRACE_LEVEL_WARNING, OmniTekBus, "CMD:%d. SlotId not found: %d\n", cmd, slotsData->SlotId );
                            }
                            break;
                        }
                        default:
                        {

                            KernelTrace( TRACE_LEVEL_WARNING, OmniTekBus, "CMD:%d. Unsupported version: %d\n", cmd, slotsData->Version );
                            slotsData->Version = OTBUS_IOCTL_GetSlot_Version;
                            if ( copy_to_user( ( OTBus_SlotInfo * )arg, slotsData, sizeof( OTBus_SlotInfo ) ) != 0 )
                            {
                                KernelTraceNA( TRACE_LEVEL_ERROR, OmniTekBus, "copy_to_user failed\n");
                                retval = -ENOMEM;
                                goto exit_gs;
                            }
                            retval = -ENOTTY;
                            break;
                        }
                    }
exit_gs:;
                }
                else
                {
                    KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "CMD:%d. Access failure\n", cmd );
                }

                kfree( slotsData );

                break;
            }

            default:
                KernelTrace( TRACE_LEVEL_ERROR, OmniTekBus, "CMD:%d. Unhandled in switch\n", cmd );
                break;
        }
    }

    return retval;
}
