/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef OMNITEKBUS_H_
#define OMNITEKBUS_H_

#include "../BusPrivate.h"

extern struct bus_type omnitekbus;
extern struct device omnitekbus_device;
extern BusDevice _private_bus_data;

void omnitekbus_capdevice_release( struct device *dev );

#endif /* OMNITEKBUS_H_ */
