/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef GPUDIRECT_H_
#define GPUDIRECT_H_

#include <linux/types.h>
#include "nvidia/nv-p2p.h"

// Small amount of global state per buffer
#define MAX_GPU_BUFFERS 256

struct GpuDirectPages
{
    uintptr_t token;

    size_t bufferLengthBytes;

    uint64_t virtualAddress;
    nvidia_p2p_page_table_t* pPageTable;

    struct pci_dev* pPciDevice;
    nvidia_p2p_dma_mapping_t* pMapping;
};

typedef uint64_t GpuDirectMappedPage;

/**
 * GpuDirectPinPages() - Pin pages in GPU memory, resulting in physical addresses.
 * @pGpuVirtualAddress: Pointer to GPU memory buffer, virtual address in GPU space. Must be aligned to 64KB.
 * @size: Number of bytes in the GPU memory buffer
 * @pPages: GPU page information to be updated with the pinnned page information
 *
 * @return
 *   0          in case of success
 *   -EINVAL    One of the parameters was invalid
 *   -EIO       Attempt to pin pages when already pinned
 *   -ENOTSUPP  pGpuVirtualAddress is not aligned to 64KB
 *   -ENOMEM    Too many GPU buffers pinned (see MAX_GPU_BUFFERS above)
 *   or other error code from underlying GPU driver
 */
int GpuDirectPinPages( void* pGpuVirtualAddress, size_t size, struct GpuDirectPages* pPages );

/**
 * GpuDirectUnpinPages() - Unpin previously pinned GPU pages if any
 * @pPages: GPU page information, possibly containing pinned GPU pages
 */
void GpuDirectUnpinPages( struct GpuDirectPages* pPages );

/**
 * GpuDirectGetPinnedPageCount() - Get the number of pinned pages
 * @pPages: GPU page information
 *
 * @return Number of pinned GPU pages
 */
size_t GpuDirectGetPinnedPageCount( struct GpuDirectPages* pPages );

/**
 * GpuDirectMapPages() - Map GPU pages for DMA, resulting in DMA addresses that can be used by external devices.
 * @pPages: GPU page information. Must contain pinned GPU pages.
 * @pciDevice: PCI device that will perform DMA operations using the resulting addresses
 *
 * @return
 *   0      for success
 *   -EINVAL    One of the parameters was invalid
 *   -ENOMEM    No pages pinned
 *   -EIO       Pages are already mapped for DMA
 *   or other error code from underlying GPU driver
 */
int GpuDirectMapPages( struct GpuDirectPages* pPages, struct pci_dev* pciDevice );

/**
 * GpuDirectUnmapPages() - Unmap previously mapped GPU pages if any
 * @pPages: GPU page information, possibly containing mapped GPU pages
 */
void GpuDirectUnmapPages( struct GpuDirectPages* pPages );

/**
 * GpuDirectGetMappedPageCount() - Get the number of mapped pages
 * @pPages: GPU page information
 *
 * @return Number of mapped GPU pages
 */
size_t GpuDirectGetMappedPageCount( struct GpuDirectPages* pPages );

/**
 * GpuDirectMappedPageFirst() - Get the first in the list of mapped pages
 * @pPages: GPU page information
 *
 * @return First mapped GPU page, or NULL if no pages are mapped
 */
GpuDirectMappedPage* GpuDirectMappedPageFirst( struct GpuDirectPages* pPages );

/**
 * GpuDirectMappedPageNext() - Get the next in the list of mapped pages
 * @pPages: GPU page information
 * @pCurrentPage: A mapped GPU page belonging to pPages
 *
 * @return The mapped GPU page following pCurrentPage in the list, or NULL if no pages are mapped
 */
GpuDirectMappedPage* GpuDirectMappedPageNext( struct GpuDirectPages* pPages, GpuDirectMappedPage* pCurrentPage );

/**
 * GpuDirectMappedPageAddress() - Get the DMA address of a mapped page
 * @pPages: GPU page information
 * @pPage: A mapped GPU page
 *
 * @return The DMA address of the mapped GPU page, or 0 if the page is not valid
 */
dma_addr_t GpuDirectMappedPageAddress( struct GpuDirectPages* pPages, GpuDirectMappedPage* pPage );

/**
 * GpuDirectMappedPageLength() - Get the DMA address of a mapped page
 * @pPages: GPU page information
 * @pPage: A mapped GPU page
 *
 * @return The size in bytes of the mapped GPU page, or 0 if the page is not valid
 */
size_t GpuDirectMappedPageLength( struct GpuDirectPages* pPages, GpuDirectMappedPage* pPage );

#endif
