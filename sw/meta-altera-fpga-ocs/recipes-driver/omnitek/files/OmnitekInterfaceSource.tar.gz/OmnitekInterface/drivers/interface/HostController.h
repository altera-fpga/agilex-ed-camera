/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#ifndef HOSTCONTROLLER_H_
#define HOSTCONTROLLER_H_

/** \addtogroup DriverlandInterface
 *  @{
 */

#include "global_defs.h"

#include "CapabilityTypes.h"
#include "Types.h"

// needed forward declaration of the host controller as we want to use it in the callback
struct _OmniTekHostController;
struct _OmniTekHostControllerInterface;

/**
 * @brief Callback for the hc to use when an interrupts occurs.
 */
typedef bool (*HCISRCB)( struct _OmniTekHostController * context, struct _OmniTekHostControllerInterface * hci, PCapInterrupt interrupt, uint32_t registerNumber );

/**
 * @brief Main context structure for host controller.
 * This would be the HostControllers FDO in Windows.
 */
typedef struct _OmniTekHostController
{
    char InstanceName[ MAX_NAME_LEN ]; //!< some sort of interface descriptor
    char TypeName[ MAX_NAME_LEN ]; //!< some sort of type descriptor
    char DeviceAccessName[ MAX_FILEPATH_LEN ]; //!< what to use to open this file!
    uint32_t SlotId; //!< This is set by the Bus, it should not be touched by anyone else
    HCISRCB BusISR; //!< Callback for the hc to use when an interrupts occurs.
    void * BusContext; //!< needed context information for the host controller to use when talking to the bus
    uint8_t NumInterrupts; //!< this is set by the bus...
    void  * Interrupts; //!< this is set by the bus...
    UUID Uuid; //!< A unique id for this class of host controller
    void * TimerCap; //!< filled in by the bus
#if BUILDTYPE == BT_WINDOWS
    WDFDEVICE WindowsDevice; //!< WINDOWS ONLY: Unfortunately we need this to get our private data back and for other purposes
#endif
#if BUILDTYPE == BT_LINUX
    struct device *Device; //!< LINUX ONLY: Needed for access from capability devices for dma opperations
#endif
// spin lock for BusISR?
} OmniTekHostController;
typedef OmniTekHostController *POmniTekHostController; //!< Pointer to a OmniTekHostController

/** @}*/

#endif /* HOSTCONTROLLER_H_ */
