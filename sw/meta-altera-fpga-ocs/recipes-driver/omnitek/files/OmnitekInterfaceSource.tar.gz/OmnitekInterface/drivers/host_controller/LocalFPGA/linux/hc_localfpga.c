/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/platform_device.h>
#include <linux/slab.h>
#include <asm/io.h>
#include <linux/dma-mapping.h>

#include <linux/interrupt.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/uaccess.h>

#include <linux/of_device.h>
#include <linux/of_address.h>
#include <linux/of_irq.h>
#include <linux/irq.h>

#include "host_controller/HostController_IOCTL.h"
#include "HostController.h"
#include "HostControllerInterface.h"
#include "HostControllerBusInterface.h"

#include "../../hccommon.h"
#include "hc_localfpga.h"

MODULE_LICENSE("GPL");
#ifdef OMNI_DRIVER_VERSION
MODULE_VERSION( STRING_OUTER(OMNI_DRIVER_VERSION) );
#else
#error "No version set..."
#endif

#define FromDevToDID( dev ) container_of( dev, DriverInstanceData, pdev );
#define FromHCToDID( hstc ) container_of( hstc, DriverInstanceData, hc );

#define GIC_DT_OFFSET (32)
#define GIC_PHANDLE_IRQ_NUM_IDX (1)

// Set base debug level for this driver
int OT_DebugLevel = TRACE_LEVEL_WARNING;

void OT_HC_LocalFPGA_BusExit( POmniTekHostController context )
{
    DriverInstanceData *fdoData = container_of( context, DriverInstanceData, hc );
    if ( fdoData->BusInterface.DeRegisterHostController != NULL )
    {
        fdoData->BusInterface.DeRegisterHostController( context );
    }
    context->BusISR = NULL;
    context->SlotId = 0;
}

void OT_HC_LocalFPGA_BusRegisterISR( POmniTekHostController context, HCISRCB busISR )
{
    unsigned long flags;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    KernelTraceNA( TRACE_LEVEL_VERBOSE, HC_LocalFPGA, "Request to add isr\n");
    spin_lock_irqsave( &(did->IrqLock), flags );
    did->BusISR = busISR;
    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}

void OT_HC_LocalFPGA_BusDeRegisterISR( POmniTekHostController context )
{
    unsigned long flags;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    KernelTraceNA( TRACE_LEVEL_VERBOSE, HC_LocalFPGA, "Request to remove isr\n");
    spin_lock_irqsave( &(did->IrqLock), flags );
    did->BusISR = NULL;
    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}


#define ReadHWValue( va, r)  *(volatile unsigned int *)( va + (r) )
#define WriteHWValue( va, r, Val) *(volatile unsigned int *)( va + (r) ) = (Val)

irqreturn_t OT_HC_LocalFPGA_ISR( int irq, void * dev_id )
{
    DriverInstanceData *did = (DriverInstanceData *)dev_id;
    unsigned long flags;
    irqreturn_t irq_return = IRQ_NONE;

    uint32_t i;
    uint32_t j;
    uint32_t status = 0;
    bool ret = FALSE;

    spin_lock_irqsave( &(did->IrqLock), flags );

    if( did->BusISR != NULL && did->Interrupts != NULL )
    {
        for ( i = 0; i < did->NumInterrupts; i++)
        {
            for ( j = 0; j < did->Interrupts[i].Info->StatusRegisters.Count; j++ )
            {
                status = ReadHWValue( did->Interrupts[i].Info->StatusRegisters.VA, j );
                if ( status != 0 )
                {
                    ret |= did->BusISR( &did->hc, &did->hci, did->Interrupts[i].Info, j );
                }
            }
        }
    }

    if ( ret )
        irq_return = IRQ_HANDLED;

    spin_unlock_irqrestore( &( did->IrqLock ), flags );

    return irq_return;
}


uint32_t copyRegion(void __user *pUserDst, const void *pKernelSrc, uint32_t size)
{
	uint32_t bytesNotCopied = size;
	KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA, "HC_IOCTL_GetRegion. Src %p, Dst %p Size %x\n", pKernelSrc, pUserDst, size);
#if 0
	bytesNotCopied = copy_to_user(pUserDst, pKernelSrc, size);
#else
	// FIXME - For some unexplained reason copy_to_user is failing on the Zynq, so use a slow copy
	// Once we get the Hardware debugger we might be able to work it out.
	{
		uint32_t *pDst = (uint32_t*)pUserDst;
		uint32_t *pSrc = (uint32_t*)pKernelSrc;

		// Convert to uint32_t values
		bytesNotCopied /= sizeof(uint32_t);
		while( bytesNotCopied )
		{
			uint32_t temp = *pSrc++;

			put_user(temp, pDst);
			pDst++;
			bytesNotCopied--;
		}
	}
#endif
	return bytesNotCopied;
}

long OT_HC_LocalFPGA_unlocked_ioctl( struct file *flip, unsigned int cmd, unsigned long arg )
{
	long retval = -ENOTTY;
	DriverInstanceData *pDid = NULL;

	pDid = container_of( flip->f_path.dentry->d_inode->i_cdev, DriverInstanceData, CDev );
	if( pDid )
	{
		switch( cmd )
		{
			case HC_IOCTL_GetPlatformInfo:
				{
					HC_GetPlatformInfo_IOCTL *ioctlReturn = (HC_GetPlatformInfo_IOCTL*)arg;
					if( omnitek_access_ok(VERIFY_WRITE, arg, sizeof(HC_GetPlatformInfo_IOCTL) ) )
					{
						uint32_t versionIn = HC_IOCTL_GetPlatformInfo_Version;
						get_user( versionIn, &(ioctlReturn->Version));
						switch( versionIn )
						{
							case 0:
								{
									put_user(HC_IOCTL_GetPlatformInfo_Version, &(ioctlReturn->Version));
									put_user(HC_PlatformInfoSoc, &(ioctlReturn->type));
									retval = 0;
								}
								break;
							default:
								{
			                        put_user( HC_IOCTL_GetPlatformInfo_Version, &( ioctlReturn->Version ) );
			                        retval = -ENOTTY;
			                        KernelTrace( TRACE_LEVEL_WARNING, HC_LocalFPGA,"IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
								}
								break;
						}
					}
				}
				break;
			case HC_IOCTL_GetNumRegions:
				{
					uint32_t versionIn;
					HC_GetNumRegions_IOCTL *ioctlReturn = (HC_GetNumRegions_IOCTL*)arg;
					if( omnitek_access_ok(VERIFY_WRITE, arg, sizeof(HC_GetNumRegions_IOCTL)) )
					{
						get_user( versionIn, &(ioctlReturn->Version) );
						switch( versionIn )
						{
							case 0:
								{
									put_user( HC_IOCTL_GetNumRegions_Version, &(ioctlReturn->Version) );
									put_user( MAX_CAPABILITY_REGIONS, &(ioctlReturn->NumRegions) );
									retval = 0;
								}
								break;
							default:
								{
			                        put_user( HC_IOCTL_GetNumRegions_Version, &( ioctlReturn->Version ) );
			                        retval = -ENOTTY;
			                        KernelTrace( TRACE_LEVEL_WARNING, HC_LocalFPGA,"IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
								}
								break;
						}
					}
				}
				break;
			case HC_IOCTL_GetRegion:
				{
					uint32_t versionIn;
					HC_GetRegion_IOCTL *ioctlReturn = (HC_GetRegion_IOCTL*)arg;
					if( omnitek_access_ok(VERIFY_WRITE, arg, sizeof(HC_GetRegion_IOCTL)) )
					{
						get_user( versionIn, &(ioctlReturn->Version) );

						// Set the version number for the return
						put_user(HC_IOCTL_GetRegion_Version, &(ioctlReturn->Version));
						switch(versionIn)
						{
							case 0:
								{
									uint32_t regionIdx;
									get_user( regionIdx, &(ioctlReturn->Idx) );
									if( regionIdx < MAX_CAPABILITY_REGIONS )
									{
										uint32_t bufferSize;
										uint32_t offset;
										get_user( bufferSize, &(ioctlReturn->Size));
										get_user( offset, &(ioctlReturn->Offset));

										KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA,"HC_IOCTL_GetRegion. Buffer Offset %x, Size %x, required %x\n", offset, bufferSize, pDid->CapRegions[regionIdx].CapLength);

										// Check that the return buffer is big enough
										if( (bufferSize == 0) || (pDid->CapRegions[regionIdx].CapLength==0) || ((bufferSize + offset) > pDid->CapRegions[regionIdx].CapLength) )
										{
											put_user( pDid->CapRegions[regionIdx].CapLength, &(ioctlReturn->Size));
											retval = -ENOMEM;
											KernelTrace( TRACE_LEVEL_WARNING, HC_LocalFPGA,"HC_IOCTL_GetRegion. Buffer to small Offset %x, Size %x, required %x\n", offset, bufferSize, pDid->CapRegions[regionIdx].CapLength);
										}
										else // Copy the buffer
										{
											void* returnPtr;
											get_user(returnPtr, &(ioctlReturn->Buffer.pVa));

											if( omnitek_access_ok(VERIFY_WRITE, returnPtr, bufferSize) )
											{
												uint8_t *pRegionPtr = (uint8_t*)pDid->CapRegions[regionIdx].CapMemory;
												pRegionPtr += offset;

												if( copyRegion(returnPtr, pRegionPtr, bufferSize) == 0 )
												{
													put_user(bufferSize, &(ioctlReturn->Size));
													retval = 0;
												}
												else
												{
													put_user( 0, &(ioctlReturn->Size));
													retval = -ENOMEM;
													KernelTraceNA( TRACE_LEVEL_WARNING, HC_LocalFPGA,"HC_IOCTL_GetRegion. failed to copy Region\n");
												}
											}
											else
											{
												put_user( pDid->CapRegions[regionIdx].CapLength, &(ioctlReturn->Size));
												retval = -ENOMEM;
												KernelTraceNA( TRACE_LEVEL_ERROR, HC_LocalFPGA, "HC_IOCTL_GetRegion. access_ok failed on return buffer\n");
											}
										}
									}
									else
									{
										retval = -EINVAL;
										KernelTrace( TRACE_LEVEL_WARNING, HC_LocalFPGA,"HC_IOCTL_GetRegion. Invalid Region Idx %d [Max %d]\n", regionIdx, MAX_CAPABILITY_REGIONS);
									}
								}
								break;
							default:
								{
			                        retval = -ENOTTY;
			                        KernelTrace( TRACE_LEVEL_WARNING, HC_LocalFPGA,"IoControlCode:%d. Unsupported version: %d\n", cmd, versionIn );
								}
								break;
						}
					}
				}
				break;
			case HC_IOCTL_ReadPciConfig:
			    KernelTraceNA( TRACE_LEVEL_WARNING, HC_LocalFPGA,"HC_IOCTL_ReadPciConfig. Not support on SOC\n");
				break;
		}
	}
	return retval;
}

static struct file_operations OT_HC_LocalFPGA_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = OT_HC_LocalFPGA_unlocked_ioctl
};



int OT_HC_LocalFPGA_Enumerate( DriverInstanceData * did )
{
    OmniTekCollection * capList = NULL;
    Capability *cap = NULL;
    uint32_t i;
    uint32_t j;
    int status;
    uint32_t interruptNum = 0;

    did->NumInterrupts = 0;

    capList = did->BusInterface.DiscoverCapabilities( &did->hc, did->CapRegions[0].CapMemory, did->CapRegions[0].CapLength / 4, did->CapRegions[0].CapAddress );
    if( capList == NULL )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, HC_LocalFPGA, "DiscoverCapabilities: NULL\n" );
    }
    else
    {
        did->BusInterface.PrintCapabilities( capList );
        for ( i = 0; i < CollectionCount( capList ); i++ )
        {
            cap = did->BusInterface.GetCapabilityAt( capList, i );
            if ( cap->Type == InterruptCap )
                did->NumInterrupts++;
        }

        if ( did->NumInterrupts > 0 )
        {
            did->Interrupts = AllocateMemory( sizeof(LinuxInterruptInfo) * did->NumInterrupts, &did->InterruptsMem );
            if ( did->Interrupts == NULL )
            {
                KernelTraceNA( TRACE_LEVEL_ERROR, HC_LocalFPGA, "Could not allocate memory for interrupts...\n" );
                did->NumInterrupts = 0;
            }
        }

        interruptNum = 0;
        for ( i = 0; i < CollectionCount( capList ); i++ )
        {
            cap = did->BusInterface.GetCapabilityAt( capList, i );
            if ( cap->Type == OffsetCap )
            {
                for( j = 0; j < GetRegCap(cap).NumBlocks; j++ )
                {
                    //KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA,"Cap: 0x%04X, SubType: 0x%04X, Id: 0x%04X\n", cap->Type, GetRegCap(cap).Type, GetRegCap(cap).ComponentId  );
                    //KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA,"PhysAdd: 0x%08llX, Size: 0x%08X\n", did->CapRegions[0].CapAddress + GetRegCap(cap).Blocks[j].Offset, GetRegCap(cap).Blocks[j].Count * 4 );
                    GetRegCap(cap).Blocks[j].VA = ioremap( did->CapRegions[0].CapAddress + GetRegCap(cap).Blocks[j].Offset, GetRegCap(cap).Blocks[j].Count * 4 );
                }
            }
            if ( cap->Type == InterruptCap && did->Interrupts != NULL )
            {
                did->Interrupts[ interruptNum++ ].Info = &cap->Ext.Interrupt;
            }
        }
    }
    status = did->BusInterface.FinaliseCapabilities( &did->hc );
    if (status != SUCCESS )
    {
        KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA, "FinaliseCapabilities: %d\n", status );

        if ( did->Interrupts != NULL )
        {
            did->Interrupts = NULL;
            DeleteMemory( &did->InterruptsMem );
        }
    }

    return status;
}

#define PS7_DEV_CFG_0_BASEADDR 0xF8007000
#define PS7_DEV_CFG_0_HIGHADDR 0xF8007fff

void OT_HC_LocalFPGA_EnableInterrupts( POmniTekHostController context )
{
    unsigned int hw_irq, dt_hw_irq;
    int i;
    unsigned long flags;
    int status;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );

    // Note: No spinlock here as functions called below are not safe in atomic context. Not a problem in practice
    //       as this function is only ever called in the context of the OT_HC_LocalFPGA_probe function

    // Note: LocalFPGA only used for ARM SoC FPGAs, OK to rely on specifics of ARM arch / DT

    for ( i = 0; i < did->NumInterrupts; i++)
    {
        struct of_phandle_args out_irq;
        uint32_t of_irq_idx = 0;
        uint32_t nr = 0;
        bool found_irq = false;
        hw_irq = did->Interrupts[i].Info->Id;
        dt_hw_irq = hw_irq - GIC_DT_OFFSET;

        while ( status == 0 )
        {
            KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA, "Looking for hw_irq %u\n", hw_irq );
            status = of_irq_parse_one( did->pdev->dev.of_node, nr, &out_irq );
            if ( (status == 0) && (out_irq.args[GIC_PHANDLE_IRQ_NUM_IDX] == dt_hw_irq) )
            {
                KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA, "hw_irq %u (DT value of %u) found at DT IRQ index %u\n", hw_irq, dt_hw_irq, nr );
                of_irq_idx = nr;
                found_irq = true;
                break;
            }
            nr++;
        }

        if ( !found_irq )
        {
            KernelTrace( TRACE_LEVEL_ERROR, HC_LocalFPGA, "Failed to find hw_irq %u (DT value of %u) in DT\n", hw_irq, dt_hw_irq );
        }
        else
        {
            did->Interrupts[i].IRQ = of_irq_get( did->pdev->dev.of_node, of_irq_idx );
        }

        if ( did->Interrupts[i].IRQ == 0 )
        {
            KernelTrace( TRACE_LEVEL_ERROR, HC_LocalFPGA, "Failed to map HW IRQ %u to Linux Virtual IRQ\n", hw_irq );
        }
        else
        {
            status = request_threaded_irq( did->Interrupts[i].IRQ, &OT_HC_LocalFPGA_ISR, NULL, IRQF_SHARED, "OT_HC_LocalFPGA", did );
            if( status )
            {
                KernelTrace( TRACE_LEVEL_ERROR, HC_LocalFPGA, "Couldn't request IRQ line %u (%u) - error %d!\n", hw_irq, did->Interrupts[i].IRQ, status);
            }
            else
            {
                KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA, "Hooked upto IRQ line %u (%u)\n", hw_irq, did->Interrupts[i].IRQ );
            }
        }
    }
}

void OT_HC_LocalFPGA_DisableInterrupts( POmniTekHostController context )
{
    int i;
    unsigned long flags;
    DriverInstanceData *did = container_of( context, DriverInstanceData, hc );
    spin_lock_irqsave( &(did->IrqLock), flags );

    for ( i = 0; i < did->NumInterrupts; i++)
    {
        free_irq( did->Interrupts[i].IRQ, did );
    }

    spin_unlock_irqrestore( &( did->IrqLock ), flags );
}

extern struct device_attribute dev_attr_debuglevel;

static struct of_device_id OT_HC_LocalFPGA_of_match[];

int OT_HC_LocalFPGA_probe( struct platform_device *pdev )
{
    int status = 0;
    DriverInstanceData *did = NULL;
    void * remapped_location = NULL;
#ifdef PLG    
    uint32_t rdata;
#endif    
    struct resource registerLocation;

    char nameBuf[MAX_FILEPATH_LEN];

    const struct of_device_id *of_id = of_match_device(OT_HC_LocalFPGA_of_match, &pdev->dev);
    if ( ! of_id )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, HC_LocalFPGA, "Failed to get of match!\n" );
        return -EINVAL;
    }

    status = of_address_to_resource(pdev->dev.of_node, 0, &registerLocation);
    if( status )
    {
        KernelTraceNA( TRACE_LEVEL_ERROR, HC_LocalFPGA, "Failed to get register location\n" );
        return status;
    }

    KernelTrace( TRACE_LEVEL_INFORMATION, HC_LocalFPGA, "Address: 0x%pa, Byte Len: 0x%llx\n", &registerLocation.start, ( u64 )( ( registerLocation.end - registerLocation.start ) + 1 ) );
    if ( ( registerLocation.start == 0 ) || ( registerLocation.end == 0 ) || ( registerLocation.end <= registerLocation.start ) )
        return -1;

    status = dma_set_coherent_mask( &pdev->dev, DMA_BIT_MASK( 64 ) );
    if( status )
    {
        KernelTraceNA( TRACE_LEVEL_WARNING, HC_LocalFPGA, "Couldn't set 64 bit DMA mask, attempting 32\n" );
        status = dma_set_coherent_mask( &pdev->dev, DMA_BIT_MASK( 32 ) );
        if( status )
        {
            KernelTraceNA( TRACE_LEVEL_ERROR, HC_LocalFPGA, "Couldn't set 32 bit DMA mask, blowup...?\n" );
            return status;
        }
    }

#ifdef PLG
    // check that the fpga is actually programmed before bothering about using it.....
    remapped_location = ioremap( PS7_DEV_CFG_0_BASEADDR, PS7_DEV_CFG_0_HIGHADDR - PS7_DEV_CFG_0_BASEADDR );
    if ( !remapped_location )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_LocalFPGA, "Could not access FPGA registers at %#08x of size %#08x\r\n", PS7_DEV_CFG_0_BASEADDR, PS7_DEV_CFG_0_HIGHADDR - PS7_DEV_CFG_0_BASEADDR );
        return -ENOMEM;
    }

    rdata = ioread32( remapped_location + 0xC ); // Read the INT_STS register
    if( (rdata & 0x04) == 0x0 ) // PCFG_DONE_INT, bit 2
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_LocalFPGA, "FPGA not programmed. Please load firmware then try again\r\n" );
        iounmap( remapped_location );
        return -ENODEV;
    }
    iounmap( remapped_location );
#endif
    remapped_location = NULL;

    // we are now ok to go

    did = kzalloc( sizeof( DriverInstanceData ), GFP_KERNEL );
    if( did == NULL )
    {
        status = -ENOMEM;
        goto probe_err;
    }

    status = device_create_file( &pdev->dev, &dev_attr_debuglevel );
    if( status )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_LocalFPGA, "can't create sysfs debuglevel file!!!\n" );
        goto probe_err_kzalloc;
    }

    MANUF_FUNC( _GetInterfaceHCInterface )( &did->hc, &did->BusInterface );

    did->BusInterface.INIT_OmniTekHostControllerInterface( &did->hci );
    did->hci.NotifyBusExit = OT_HC_LocalFPGA_BusExit;
    did->hci.EnableInterrupts = OT_HC_LocalFPGA_EnableInterrupts;
    did->hci.DisableInterrupts= OT_HC_LocalFPGA_DisableInterrupts;
    did->hci.RegisterISR = OT_HC_LocalFPGA_BusRegisterISR;
    did->hci.DeRegisterISR = OT_HC_LocalFPGA_BusDeRegisterISR;

    snprintf( did->hc.InstanceName, MAX_NAME_LEN, "%s:%d", pdev->name, pdev->id );
    snprintf( did->hc.TypeName, MAX_NAME_LEN, MANUF_DEV("_HC_LocalFPGA") );
    did->hc.Uuid = UUID_USERINTERFACE_HC_LOCALFPGA;
    did->hc.Device = &pdev->dev;

    did->CapRegions[0].CapAddress = registerLocation.start;
    did->CapRegions[0].CapLength = ( registerLocation.end - registerLocation.start ) + 1;

    did->CapRegions[0].CapMemory = ioremap( did->CapRegions[0].CapAddress, did->CapRegions[0].CapLength );
    KernelTrace( TRACE_LEVEL_VERBOSE, HC_LocalFPGA,"CapMemory %p, CapLength %d\n", did->CapRegions[0].CapMemory, did->CapRegions[0].CapLength);
    did->pdev = pdev; // incase we need to go from a host controller back to a pdev...

    spin_lock_init(&(did->IrqLock));
    status = did->BusInterface.RegisterHostController( &did->hc, &did->hci );
    if ( status != SUCCESS )
    {
        goto probe_err_device_create_file;
    }

    // start char dev code
    snprintf( nameBuf, MAX_FILEPATH_LEN, MANUF_DEV("_HC_LocalFPGA_%02d"), did->hc.SlotId );
    status = alloc_chrdev_region( &( did->Major ), 0, 1, nameBuf );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_LocalFPGA,"Error %d alloc_chrdev_region\n", status );
        goto probe_err_RegisterHostController;
    }

    did->Minor = MKDEV( MAJOR( did->Major ), MINOR( did->Major ) );
    cdev_init( &( did->CDev ), &OT_HC_LocalFPGA_fops );
    did->CDev.owner = THIS_MODULE;
    status = cdev_add( &( did->CDev ), did->Minor, 1 );
    if( status )
    {
        KernelTrace( TRACE_LEVEL_CRITICAL, HC_LocalFPGA,"Error %d cdev_add\n", status );
        goto probe_err_alloc_chrdev_region;
    }

    if ( NULL == device_create( MANUF_FUNC(_GetClass)(), &pdev->dev, did->Minor, NULL, nameBuf ) )
    {
        KernelTraceNA( TRACE_LEVEL_CRITICAL, HC_LocalFPGA, "Failed to create host controller dev entry\n" );
        goto probe_err_cdev_add;
    }
    else
    {
        snprintf( did->hc.DeviceAccessName, MAX_FILEPATH_LEN, "/dev/%s", nameBuf );
    }
    // end char dev code

    status = OT_HC_LocalFPGA_Enumerate( did );
    if( status != SUCCESS )
        goto probe_err_device_create;

    platform_set_drvdata( pdev, did );

    return 0;

probe_err_device_create:
    device_destroy( MANUF_FUNC(_GetClass)(), did->Minor );
probe_err_cdev_add:
    cdev_del( &( did->CDev ) );
probe_err_alloc_chrdev_region:
    unregister_chrdev_region( did->Major, 1 );
probe_err_RegisterHostController:
    did->BusInterface.DeRegisterHostController( &did->hc );
probe_err_device_create_file:
    device_remove_file( &pdev->dev, &dev_attr_debuglevel );
    iounmap( did->CapRegions[0].CapMemory );
probe_err_kzalloc:
    kfree( did );
probe_err:
    platform_set_drvdata( pdev, NULL );

    return status;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6,11,0)
void OT_HC_LocalFPGA_remove( struct platform_device *pdev )
#else
int OT_HC_LocalFPGA_remove( struct platform_device *pdev )
#endif
{
    DriverInstanceData *did = NULL;

    did = platform_get_drvdata( pdev );
    if ( did != NULL )
    {
        did->BusInterface.DeRegisterHostController( &did->hc );

        if ( did->Interrupts != NULL )
        {
            did->Interrupts = NULL;
            DeleteMemory( &did->InterruptsMem );
        }

        device_destroy( MANUF_FUNC(_GetClass)(), did->Minor );
        cdev_del( &( did->CDev ) );
        unregister_chrdev_region( did->Major, 1 );
        device_remove_file( &pdev->dev, &dev_attr_debuglevel );
        iounmap( did->CapRegions[0].CapMemory );
        kfree( did );
        platform_set_drvdata( pdev, NULL );
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(6,11,0)
    return 0;
#endif    
}

void OT_HC_LocalFPGA_device_release( struct device *dev )
{
}

static struct of_device_id OT_HC_LocalFPGA_of_match[] /*__devinitdata */= {
        // should be like: "OmniTek,OT-hc-localfpga"
  { .compatible = MANUF_CONCAT(",") MANUF_DEV("-hc-localfpga"), },
  {}
};
MODULE_DEVICE_TABLE(of, OT_HC_LocalFPGA_of_match );

static const struct platform_device_id OT_HC_LocalFPGA_id_table[ ] = {
    {  MANUF_DEV("-hc-localfpga"), 0 },
    { },
};
MODULE_DEVICE_TABLE( platform, OT_HC_LocalFPGA_id_table );

static struct platform_driver OT_HC_LocalFPGA_driver = {
    .driver = {
        .name = MANUF_DEV("-hc-localfpga"),
        .owner = THIS_MODULE,
        .of_match_table = OT_HC_LocalFPGA_of_match,
    },
    .probe = OT_HC_LocalFPGA_probe,
    .remove = OT_HC_LocalFPGA_remove,
    .id_table = OT_HC_LocalFPGA_id_table,
};

int OT_HC_LocalFPGA_init( void )
{
    int result = 0;
    result = platform_driver_register( &OT_HC_LocalFPGA_driver );
    if( result != 0 )
    {
        return result;
    }

    return result;
}

void OT_HC_LocalFPGA_cleanup( void )
{
    platform_driver_unregister( &OT_HC_LocalFPGA_driver );
}

module_init( OT_HC_LocalFPGA_init );
module_exit( OT_HC_LocalFPGA_cleanup );
