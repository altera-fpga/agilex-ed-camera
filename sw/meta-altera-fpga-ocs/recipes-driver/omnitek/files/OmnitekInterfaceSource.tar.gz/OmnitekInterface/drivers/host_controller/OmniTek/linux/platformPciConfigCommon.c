/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include <linux/pci.h>
#include "hccommon.h"
#include "platformPciConfigCommon.h"
#include "Customise.h"

uint32_t MANUF_FUNC(_PlatformReadPciConfig)(DriverInstanceData *pDeviceInstance, uint32_t Offset, void *pBuffer, uint32_t ReadSize)
{
	uint32_t bytesRead = 0;

	// Check that we have complete access to the buffer
	if( omnitek_access_ok(VERIFY_WRITE, pBuffer, ReadSize) )
	{
	    uint8_t *pDstByte = NULL;
		uint32_t* pDst = (uint32_t*)pBuffer;

		// Seems that Linux doesn't have bulk PCI Config space Read functions
		// so we'll read in dwords
		while( ReadSize > sizeof(uint32_t) )
		{
			uint32_t localDWord;
			if( pci_read_config_dword(pDeviceInstance->pdev, Offset, &localDWord ) != 0 )
				break;

			if( copy_to_user( pDst, &localDWord, sizeof(localDWord ) ) != 0 )
			{
				bytesRead = 0;
				ReadSize = 0;
				break;
			}

			Offset += sizeof(uint32_t);
			ReadSize -= sizeof(uint32_t);
			bytesRead += sizeof(uint32_t);
			pDst++;
		}

		// Read any remaining bytes as bytes
		pDstByte = (uint8_t*)pDst;
		while( ReadSize > 0 )
		{
			uint8_t localByte;
			if( pci_read_config_byte(pDeviceInstance->pdev, Offset, &localByte) != 0 )
				break;

			if( copy_to_user( pDstByte, &localByte, sizeof(localByte ) ) != 0 )
			{
				bytesRead = 0;
				break;
			}

			ReadSize -= sizeof(uint8_t);
			Offset += sizeof(uint8_t);
			bytesRead += sizeof(uint8_t);
			pDstByte ++;
		}
	}

	return bytesRead;
}
MANUF_EXPORT_GPL(_PlatformReadPciConfig);
