/* Copyright (C) Altera Corporation
 *
 * SPDX-License-Identifier: GPL-2.0-only */

#include "hccommon.h"
#include "pciConfigCommon.h"

#if BUILDTYPE == BT_LINUX
#include "linux/platformPciConfigCommon.h"
#define DECLSPEC_ALIGN(a)
#endif
#if BUILDTYPE == BT_WINDOWS
#include "windows/platformPciConfigCommon.h"
#endif

#ifdef USE_WPP
#include "trace.h"
#include "AUTOGEN.pciConfigCommon.tmh"
#endif

/// ReadPciConfig
/// Returns the number of bytes read
uint32_t ReadPciConfig(DriverInstanceData *pDeviceInstance, uint32_t offset, void *pBuffer, uint32_t readSize)
{
	return PlatformReadPciConfig(pDeviceInstance, offset, pBuffer, readSize);
}

/// ReadPciHeaderType
/// Returns the header type, 0 if failed
uint8_t ReadPciConfigHeaderType(DriverInstanceData *pDeviceInstance)
{
	DECLSPEC_ALIGN(MEMORY_ALLOCATION_ALIGNMENT) uint8_t pciHeaderType = 0;
	uint32_t bytesRead;

	if((bytesRead = ReadPciConfig(pDeviceInstance, OT_PCI_HEADER_TYPE_OFFSET, &pciHeaderType, sizeof(pciHeaderType)))
													!= sizeof(pciHeaderType))
	{
		KernelTrace(TRACE_LEVEL_ERROR, PciConfig,
					"ReadPciConfigHeaderType: Failed to read Config Space at offset %u, bytesRead %d\n",
					OT_PCI_HEADER_TYPE_OFFSET, bytesRead);
		return 0;
	}

	return pciHeaderType;
}

/// ReadPciConfigNextCapabilityOffset
/// Returns the Next Capability offset in the PCI Common Header
uint8_t ReadPciConfigNextCapabilityOffset(DriverInstanceData *pDeviceInstance)
{
	uint32_t bytesRead;
	DECLSPEC_ALIGN(MEMORY_ALLOCATION_ALIGNMENT) uint8_t offset = 0;
	uint8_t headerType = ReadPciConfigHeaderType(pDeviceInstance);
	if( (headerType!=0) && (headerType!=1) )
	{
		KernelTrace(TRACE_LEVEL_ERROR, PciConfig, "ReadPciConfigNextCapabilityOffset: Invalid PCI Config HeaderType %d\n", headerType);
		return 0; // Not the correct Header Type
	}

	if( (bytesRead=ReadPciConfig(pDeviceInstance, OT_PCI_NEXT_CAPABILITY_OFFSET, &offset, sizeof(offset))) != sizeof(offset) )
	{
		KernelTrace(TRACE_LEVEL_ERROR, PciConfig, "ReadPciConfigNextCapabilityOffset: Faied to read next offset, bytesRead %d\n", bytesRead);
		return 0; // Failed to read the Next Capability
	}

	return offset;
}

/// GetPciConfigHeader
/// Returns the offset to the required PCI header. If ID is not found then 0 is returned
uint8_t GetPciConfigHeaderOffset(DriverInstanceData *pDeviceInstance, uint8_t ID)
{
	bool bFound = FALSE;

	//Read the first capability offset
	uint8_t offset = ReadPciConfigNextCapabilityOffset(pDeviceInstance);

	// Search for the required ID
	while( offset != 0 )
	{
		uint32_t bytesRead;
		DECLSPEC_ALIGN(MEMORY_ALLOCATION_ALIGNMENT) OT_PCI_CAPABILITIES_HEADER header;
		if( (bytesRead=ReadPciConfig(pDeviceInstance, offset, &header, sizeof(header))) != sizeof(header) )
		{
			KernelTrace(TRACE_LEVEL_ERROR, PciConfig, "GetPciConfigHeaderOffset: Failed to read OT_PCI_CAPABILITIES_HEADER at offset %d, bytesRead %d\n", offset, bytesRead);
			break; // Failed to read Header
		}

		if(header.CapabilityID == ID )
		{
			// We've found the ID we want, exit the loop
			bFound = TRUE;
			break;
		}
		// Read the next header
		offset = header.Next;
	}
	return (bFound==TRUE)?offset:0;
}

/// GetPcieConfigHeader
/// Returns the offset to the required PCIe Header. If ID is not found then 0 is returned
uint16_t GetPcieConfigHeaderOffset(DriverInstanceData *pDeviceInstance, uint16_t ID)
{
	bool bFound = FALSE;
	uint16_t offset = 0;

	// First read to see whether we have a PCI Express Capability
	if( GetPciConfigHeaderOffset(pDeviceInstance, OT_PCI_CAPABILITY_ID_PCI_EXPRESS) == 0 )
	{
		KernelTrace(TRACE_LEVEL_ERROR, PciConfig, "GetPcieConfigHeaderOffset: Failed to find OT_PCI_CAPABILITY_ID_PCI_EXPRESS at offset %d\n", offset);
		return 0; // No PCI EXPRESS Capability present so assume this is not a PCI Express device
	}

	// Read all the header offset
	offset = OT_PCI_EXPRESS_NEXT_CAPABILITY_OFFSET;
	while( offset != 0)
	{
		uint32_t bytesRead;
		DECLSPEC_ALIGN(MEMORY_ALLOCATION_ALIGNMENT) OT_PCI_EXPRESS_ENHANCED_CAPABILITY_HEADER extendedHeader;

		if( (bytesRead=ReadPciConfig(pDeviceInstance, offset, &extendedHeader, sizeof(extendedHeader))) != sizeof(extendedHeader) )
		{
			KernelTrace(TRACE_LEVEL_ERROR, PciConfig, "GetPcieConfigHeaderOffset: Failed to read OT_PCI_EXPRESS_ENHANCED_CAPABILITY_HEADER at offset %d, bytesRead %d\n", offset, bytesRead);
			break; // Failed to read the OT_PCI_EXPRESS_ENHANCED_CAPABILITY_HEADER
		}

		if( extendedHeader.CapabilityID == ID )
		{
			// Found the required ID
			bFound = TRUE;
			break;
		}
		offset = extendedHeader.Next;
	}
	return (bFound==TRUE)?offset:0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// DumpPciConfig
/// Debug Routine
void DumpPciConfig(DriverInstanceData *pDeviceInstance)
{
	bool bPciExpressCapable = FALSE;

	uint8_t nextCap = ReadPciConfigNextCapabilityOffset(pDeviceInstance);

	while( nextCap != 0x0 )
	{
		DECLSPEC_ALIGN(MEMORY_ALLOCATION_ALIGNMENT) OT_PCI_CAPABILITIES_HEADER capabilityHeader;
		if( ReadPciConfig(pDeviceInstance, nextCap, &capabilityHeader, sizeof(capabilityHeader)) != sizeof(capabilityHeader) )
		{
			KernelTrace(TRACE_LEVEL_ERROR, PciConfig, "DumpPciConfig: Failed to read Config Space at offset %d, OT_PCI_CAPABILITIES_HEADER\n", nextCap);
			break;
		}
		KernelTrace(TRACE_LEVEL_INFORMATION, PciConfig, "DumpPciConfig: Capability ID %d, Next Cap %d\n", capabilityHeader.CapabilityID, capabilityHeader.Next);
		if( capabilityHeader.CapabilityID == OT_PCI_CAPABILITY_ID_PCI_EXPRESS )
			bPciExpressCapable = TRUE;
		nextCap = capabilityHeader.Next;
	}

	if( bPciExpressCapable )
	{
		uint32_t bytesRead = 0;
		uint16_t extNextOffset = 0;
		DECLSPEC_ALIGN(MEMORY_ALLOCATION_ALIGNMENT) OT_PCI_EXPRESS_ENHANCED_CAPABILITY_HEADER extCap;

		// Start at the base of the PCI Express registers
		extNextOffset = OT_PCI_EXPRESS_NEXT_CAPABILITY_OFFSET;

		// Iterate all the PCI Express extended headers
		while( extNextOffset)
		{
			if( (bytesRead = ReadPciConfig(pDeviceInstance, extNextOffset, &extCap , sizeof(extCap))) != sizeof(extCap) )
			{
				KernelTrace(TRACE_LEVEL_ERROR, PciConfig, "DumpPciConfig: Failed to read Config Space, PCI_EXPRESS_CAPABILITY_OFFSET, bytesRead %d, at offset %d\n", bytesRead, extNextOffset);
				break;
			}
			KernelTrace(TRACE_LEVEL_INFORMATION, PciConfig, "DumpPciConfig: Ext Capability ID %d, Version %d, Next Cap %d\n", extCap.CapabilityID, extCap.Version, extCap.Next);

			extNextOffset = extCap.Next;
		}
	}
}

